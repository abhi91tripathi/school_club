<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/
class Institute extends AdminAppModel {
    public $useTable='institutes';
    
    public function afterSave($created, $options = array()) {
        
        $translation=ClassRegistry::init('I18nModel');
          $institute=ClassRegistry::init('Institute');
          $institute_data=$this->data;
          $fields_array=array_keys($institute_data['Institute']);
            $fields_array2=configure::read('institute_fields');
           $comman=array_intersect($fields_array,$fields_array2); 
         if($created==true){
             $id=$this->getLastInsertID();
             $institute_data['Institute']['institute_id']=$id;
         }
         $c=0;
        if(count($comman)>=1){
          $institute->bindTranslation($comman);
        if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'spa',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
             $institute->locale='spa';
               $institute->save($institute_data);
              
              
            }
          if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'ita',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
               $institute->locale='ita';
               $institute->save($institute_data);
            }  
        
         if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'por',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
               $institute->locale='por';
               $institute->save($institute_data);
            } 
            
             if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'nld',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
               $institute->locale='nld';
               $institute->save($institute_data);
            } 
            if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'fra',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
               $institute->locale='fra';
               $institute->save($institute_data);
            } 
           if(count($comman)!=count($translation->find('all',array('conditions'=>array('I18nModel.locale'=>'eng',
                'I18nModel.model'=>'Institute',
                'I18nModel.foreign_key'=>$institute_data['Institute']['institute_id'],
                'I18nModel.field'=>$comman
                
                )))))
            {
               $institute->locale='eng';
               $institute->save($institute_data);
            
           } 
          
           }
    }
    
      
    public $belongsTo=array(
	'Country'=>array(
	 'className'=>'Country',
	  'foreignKey'=>'country_id',
	  
	 ),
	 'Language'=>array(
	  'className'=>'Language',
	  'foreignkey'=>'language_id'
	 ),
	 'Destination'=>array(
	  'className'=>'Destination',
	  'foreignkey'=>'destination_id'
	 ),
        'Currency'=>array(
	  'className'=>'Currency',
	  'foreignkey'=>'currency_id'
	 )
	);
    
}
