<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Accommodation and having validation for accommodation
*/
class Accommodation extends AdminAppModel {


    public $validate = array(
			'title'=>array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			)
		);
             
	
}
