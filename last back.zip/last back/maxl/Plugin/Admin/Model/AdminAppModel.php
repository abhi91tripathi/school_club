<?php

App::uses('AppModel', 'Model');

class AdminAppModel extends AppModel {

    
    
  
}
