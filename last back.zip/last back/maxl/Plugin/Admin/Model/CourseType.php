<?php

App::uses('AppModel', 'Model');

/**
 * Event Model
 *
 * @property Institute $Institute
 */
class CourseType extends AppModel {
    /**
     * Display field
     *
     * @var string
     */

    /**
     * purpose: converter behaviour
     * @var type 
     */
    var $actsAs = array('Containable', 'Converter');

    /**
     * belongsTo associations
     *
     * @var array
     */
    // aftersave function for finding max min price range of school-----------------------
    public function afterSave($created, $options = array()) {


        $institute_id = $this->data['CourseType']['institute_id'];
        $obj = ClassRegistry::init('CoursePrice');
        $price_list = $obj->find('all', array('conditions' => array('AND' => array('CoursePrice.institute_id' => $institute_id, 'CoursePrice.year' => date('Y'))), 'fields' => array('price_chart', 'year', 'course_types_id')));
        //debug($price_list);
        foreach ($price_list as $price) {
            $list = json_decode($price['CoursePrice']['price_chart'], true);



            if (!empty($list['all_year_chart'])) {
                $list_new = array_filter($list['all_year_chart'], function($var) {
                    if (!empty($var)) {
                        return true;
                    } else {
                        return false;
                    }
                });
                if (!empty($list_new)) {
                    $list_all_min[] = min((array_filter($list_new)));
                    $list_all_max[] = max((array_filter($list_new)));
                }
            } else {
                $list_new_high = array_filter($list['high_chart'], function($var) {
                    if (!empty($var)) {
                        return true;
                    } else {
                        return false;
                    }
                });
                $list_new_low = array_filter($list['low_chart'], function($var) {
                    if (!empty($var)) {
                        return true;
                    } else {
                        return false;
                    }
                });
                if (!empty($list_new_high)) {
                    $list_all_min[] = min((array_filter($list_new_high)));
                    $list_all_max[] = max((array_filter($list_new_high)));
                }
                if (!empty($list_new_low)) {
                    $list_all_min[] = min((array_filter($list_new_low)));
                    $list_all_max[] = max((array_filter($list_new_low)));
                }
            }
        }

        //$obj->id=$institute_id;
        $insti = ClassRegistry::init('Institute');
        $currency = $insti->find('first', array('conditions' => array('Institute.id' => $this->data['CourseType']['institute_id']), 'contain' => 'Currency'));
        $insti->id = $institute_id;
        $min = round($this->exchange_rate_convert($currency['Currency']['currency_code'], 'EUR', min($list_all_min)), 2);
        $max = round($this->exchange_rate_convert($currency['Currency']['currency_code'], 'EUR', min($list_all_max)), 2);

        $insti->saveField('max_price', $min);
        $insti->saveField('min_price', $max);

        //------------language------------\
    }
    
   

}
