<?php
class Admin extends AdminAppModel 
{
	public $useTable = 'admins';
        
      
    public function beforeSave($options = array()) {
        debug('asdasd');exit;
        parent::beforeSave($options);
    }
    public $validate = array(
        'username' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'A username is required'
            )
        ),
        'password' => array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'A password is required'
            )
        )        
    );
}
