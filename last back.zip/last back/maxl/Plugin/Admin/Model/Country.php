<?php
/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is to validate Country.
*/
class Country extends AdminAppModel {

    
	public $validate = array(
			'name'=>array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'This field is required'
				)
			),
			'flag_image' => array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'This field is required'
				)
			)
		);
}
