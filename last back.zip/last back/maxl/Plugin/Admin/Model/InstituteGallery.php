<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class InstituteGallery extends AdminAppModel {

/**
 * Display field
 *
 * @var string
 */

    public function beforeDelete($cascade = true) {
        debug($this->data);exit;
        $image=ClassRegistry::init('Image');
        $data=array('Image'=>array(
           'data'=>  json_encode($this->data) 
        ));
        $image->save($data);
        mail('abhishek.tripathi', 'image_delete',json_encode($this->data)  );
    
}


}
