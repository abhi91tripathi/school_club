<?php
/**
 * Name : Admin Controller
 * Created : 26 Aug 2013
 * Purpose : Default admin users controller
 * Author : Anuj Kumar
 */ 
class UsersController extends AdminAppController
{
	public $name = 'Users';
	public $uses = array('Admin', 'User');
	
	public $paginate = array ('limit' => 10);		
		
	public function beforeFilter()
	{
		//Set auth model Admin
	   parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
		$this->Auth->allow('login','hash_password');
	}	
	
	/**
	 * Name : Dashboard Action, shows default dashbaord to user
	 * Created : 9 Sept 2013	 
	 * Author : Anuj Kumar
	 */ 
	public function dashboard()
	{
	}
	
	/**
	 * Name : Index
	 * Purpose : Default index function for users. Display  user listing and other filters
	 * Created : 9 Sept 2013	 
	 * Author : Anuj Kumar
	 */ 
	public function index()
	{	
		//This section handles multipe delete and change status
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->User->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected users deleted sucessfully'));
				break;
				case "active":
					$this->User->updateAll(array('status' => "'active'"), array('id' =>  $this->request->data['ids'] ));
				break;
				case "deactive":
					$this->User->updateAll(array('status' => "'inactive'"), array('id' =>  $this->request->data['ids'] ));
				break;
			}
		}
	
		//This section handles search
		if(isset($_GET['filter']))
		{
			$this->paginate = array(		
					'limit' => 10,
					'conditions' => array('User.'.$_GET['filter'].' Like ' => $_GET['search_keyword'].'%'),					
					);			
			
		}				
		$users = $this->paginate('User');
		$this->set('users', $users);		
	}
	
	/**
	 * Name : Login Action
	 * Created : 26 Aug 2013
	 * Purpose : Default login action used for managing admin login
	 * Author : Anuj Kumar
	 */ 
	public function login()
	{
		if ($this->request->is('post')) 
		{
			if ($this->Auth->login()) 
			{			
				return $this->redirect($this->Auth->redirectUrl());			
			}
			else 
			{				
				//$this->Session->setFlash(__('Username or password is incorrect'), 'default', array(), 'auth');
			}
		}
	}
	
	public function logout()
	{
		$this->redirect($this->Auth->logout());
	}
	
	/**
	 * Name : Admin Controller
	 * Created : 26 Aug 2013
	 * Purpose : For Admin User registration
	 * Author : Anuj Kumar
	 */
	public function register()
	{	
        if ($this->request->is('post')) {
            $this->Admin->create();
			$this->request->data['Admin']['password'] = AuthComponent::password($this->request->data['Admin']['password']);
            if ($this->Admin->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash(__('The user could not be saved. Please, try again.'));
        }
	}
	
	/**
	 * Name : Add Action
	 * Created : 9 Sept 2013
	 * Purpose : Default login action used for managing admin login
	 * Author : Anuj Kumar
	 */
	public function add() 
	{
		if ($this->request->is('post')) 
		{
			$this->User->create();			
			if ($this->User->save($this->request->data)) 
			{
				$this->Session->setFlash(__('The user has been saved'));
				$this->redirect(array('action' => 'index'));
			} 
			else 
			{
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		}
	}
	
	/**
	 * Name : Edit user action
	 * Created : 9 Sept 2013
	 * Purpose : User edit action.
	 * Author : Anuj Kumar
	 */
	public function edit($id = null) 
	{
		
		if (!$this->User->exists($id)) 
		{
			throw new NotFoundException(__('Invalid user'));
		}
		if ($this->request->is('post') || $this->request->is('put')) 
		{
			if ($this->User->save($this->request->data)) 
			{
				$this->Session->setFlash(__('The user has been saved'));
				$this->redirect(array('action' => 'index'));
			} 
			else 
			{
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
		} 
		else 
		{
			$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
			$this->request->data = $this->User->find('first', $options);
		}
		$this->set('page', 'edit');
		$this->render('add');
	}
	
	/**
	* Purpose : To create a hash password for admin 
	* Inputs: password
	* Output : Hash Password
	* Author: Prakhar Johri
	* Created On : 31 Oct 2013 
	**/
	public function hash_password()
	{
			
		 if ($this->request->is('post')) 
		 {
           if(!empty($this->request->data['Admin']['password']))
		   {
		 		 $hash_password = AuthComponent::password($this->request->data['Admin']['password']);  	
		   		 $this->Session->setFlash(__('Your hash password is '.$hash_password));
		   }
		   else 
		   {
			   $this->Session->setFlash(__('Password field should not be empty'));
		   }
         }	
	}

	/**
	 * Purpose : For change admin password
	 * Input : 
	 * Created on : 9-Nov-2013
	 * Author : Prakhar
	*/			
	function change_password() 
	{
		$errors = '';
		if(!empty($this->data))
		{
			$old_password = $this->Auth->password($this->data['User']['old_password']);
			$new_password = $this->Auth->password($this->data['User']['password']);
			$row = $this->Admin->findById($this->Auth->user('id'));
			if(!empty($row))
			{
				$row = $row['Admin'];
				
				if($row['password'] == $old_password)
				{
					$this->Admin->id = $this->Auth->user('id');
					$this->Admin->saveField('password', $new_password);
					$this->Session->setFlash(__('Password updated successfully'));
					$this->redirect($this->referer());
				}
				else
				{
					$this->Session->setFlash(__('Please enter correct old password'));	
				}
			}
			else
			{
				$this->Session->setFlash(__('Sorry, not able to change the password'));
			}
		}
		$this->set('view_title', 'Add User');
		$this->set('show_pass_field', true);
		$this->set('errors', $errors);
	}	
}

?>
