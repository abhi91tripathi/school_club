<?php
/**
* Author : Vivek Kumar
* Creation Date : 13th Oct 2014
* Description : FOR Translate
*/

class TranslateController extends AdminAppController 
{
	var $name = 'Translate';
	var $uses = array('Language');
            public function beforeFilter() {    
                parent::beforeFilter();        //Set auth model Admin   
                     $this->Auth->authenticate = array(   
                         'Form' => array('userModel' => 'Admin')    
                         );        
                     $this->Auth->allow('register');    

            }
	
	
	/**
	* Author : Vivek Kumar
	* Creation Date : 13th Oct 2014
	* Description : Display the list of language to translate
	*/
	
	function index()
	{
		$this->loadModel('Language');
		$languages =configure::read('local');
		$this->set('languages', $languages);
	}	
	
	function update($translate = '')
	{
        
		if (empty($translate))
		{
			$this->Session->setFlash(__('Please select the language to translate'), 'flash_error');
			$this->redirect(array('controller' => 'languages', 'action' => 'list', 'admin' => true));
		}
		
		if(!empty($this->data['Language']))
		{
                   //debug($this->data['Language']);exit;
			$data_save = $this->data['Language'];			
			$write_file = APP.'Locale/'.$translate.'/LC_MESSAGES/default.po';
			$myfile = fopen($write_file, "w") or die(__('Unable to open file!'));
			$translate_array = array();
			foreach ($data_save['msgid'] as $key => $data)
			{				
				$msgid = $data_save['msgid'][$key];
				$msgstr = $data_save['msgstr'][$key];
				$translate_array[$msgid] = $msgstr;
				//echo '<br/>';
				$txt = 'msgid "'.$msgid.'"';
				$txt .= "\r\n";
				$txt .='msgstr "'.$msgstr.'"';
				$txt .= "\r\n\n";
				fwrite($myfile, $txt);
			}
			fclose($myfile);
			if ($translate == 'eng')
			{
                           $this->__update_other_languages($translate_array, $translate);
			}	
			$this->Session->setFlash(__('Translation process updated successfully.'), 'flash_success');
			
		}
		
		
		$lang_trans_file = APP.'/Locale/'.$translate.'/LC_MESSAGES/default.po';
		$lang_list = array();
		
		if (file_exists($lang_trans_file))
		{
			$lang_content = file_get_contents($lang_trans_file);			
			if ($lang_content != '')
			{
				$lang_data = explode('<br />', nl2br($lang_content));				
				foreach ($lang_data as $key => $lang)
				{
					if (stristr($lang_data[$key], "msgid"))
					{
						$msgid = explode('msgid', $lang_data[$key]);
						$msgKey = str_replace('"','',$msgid[1]); 
						//$msgKey = str_replace("'",'',$msgKey); 
						
						$msgstr = explode('msgstr', $lang_data[$key+1]);
						$msgval = str_replace('"','',@$msgstr[1]);
						//$msgval = str_replace("'",'',@$msgval);
						$lang_list[trim($msgKey)] = trim($msgval); 
					}
				}				
				$updated_array = array_diff($lang_list, array('')) + array_intersect($lang_list,  array(''));
				$lang_list = array_reverse($updated_array);
			}			
		}
		
		$this->set('translate', $translate);
                configure::write('debug',2);
		
		$this->set('lang_list', json_encode($lang_list));
	}
	
	function __update_other_languages($translate_array, $translate)
	{
		$languages = configure::read('local');
		foreach ($languages as $language)
                    if($language!='eng')
                    {
		{
			//$lang_trans = $language['Language']['translate'];
			//$lang_name = $language['Language']['en_title'];
			$lang_trans_file = APP.'/Locale/'.$language.'/LC_MESSAGES/default.po';
			if (file_exists($lang_trans_file))
			{
				$lang_content = file_get_contents($lang_trans_file);			
				if ($lang_content != '')
				{
					$lang_data = explode('<br />', nl2br($lang_content));				
					foreach ($lang_data as $key => $lang)
					{
						if (stristr($lang_data[$key], "msgid"))
						{
							$msgid = explode('msgid', $lang_data[$key]);
							$msgKey = str_replace('"','',$msgid[1]); 
							//$msgKey = str_replace("'",'',$msgKey); 
							
							$msgstr = explode('msgstr', $lang_data[$key+1]);
							$msgval = str_replace('"','',@$msgstr[1]);
							//$msgval = str_replace("'",'',@$msgval);
							$lang_list[trim($msgKey)] = trim($msgval); 
						}
					}					
					$different_lang_list = array_diff_key($translate_array, $lang_list);
					if (count($different_lang_list))
					{
						$lang_keys = array_keys($different_lang_list);
						$lang_values = array_fill(0, count($lang_keys), null);
						$new_array = array_combine($lang_keys, $lang_values);
						$lang_list = array_merge($new_array, $lang_list);
					}						
				}
				if (count($lang_list))
				{	
					$write_file = APP.'Locale/'.$language.'/LC_MESSAGES/default.po';
					$myfile = fopen($write_file, "w") or die(__('Unable to open file!'));
					$translate_array = array();
					foreach ($lang_list as $msgid => $msgstr)
					{				
						$txt = 'msgid "'.$msgid.'"';
						$txt .= "\r\n";
						$txt .='msgstr "'.$msgstr.'"';
						$txt .= "\r\n\n";
						fwrite($myfile, $txt);
					}
					fclose($myfile);
				}
			}
		}	
        }
	}
        public function auto_translation($text_to_translate,$to){
               App::import('Vendor', 'translate/config.inc.php');
               App::import('Vendor', 'translate/class/MicrosoftTranslator');
               /**
                    * @var string Microsoft/Bing Primary Account Key
                    */
                   if (!defined('ACCOUNT_KEY')) {
                       define('ACCOUNT_KEY', 'zOUK7ZPVhBv0x4m9pKRcDg1LtOhCrpDzKUZgTUutpR4');
                   }
                   if (!defined('CACHE_DIRECTORY')) {
                       define('CACHE_DIRECTORY', 'your_home_directory/translate/cache/');
                   }
                   if (!defined('LANG_CACHE_FILE')) {
                       define('LANG_CACHE_FILE', 'lang.cache');
                   }
                   if (!defined('ENABLE_CACHE')) {
                       define('ENABLE_CACHE', true);
                   }
                   if (!defined('UNEXPECTED_ERROR')) {
                       define('UNEXPECTED_ERROR', 'There is some un expected error . please check the code');
                   }
                   if (!defined('MISSING_ERROR')) {
                       define('MISSING_ERROR', 'Missing Required Parameters ( Language or Text) in Request');
                   }

                $translator = new MicrosoftTranslator(ACCOUNT_KEY);
                //$text_to_translate = 'hello';
               // $to = 'it';
                $from ='';
                $translator->translate($from, $to, $text_to_translate);
                $data=json_decode($translator->response->jsonResponse,true);
                $sd=['</string>','<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">'];
               
                return str_replace($sd, '', $data['translation']);
               
               
               
               
            
        }
}
?>
