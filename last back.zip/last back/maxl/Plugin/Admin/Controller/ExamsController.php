<?php
/**
 * Name : exams Controller
 * Created : 3 Apr 2014
 * Purpose : To manage the languages.
 * Author : Ritish
 */ 
class ExamsController extends AdminAppController
{
	public $name = 'exams';
	public $uses = array('Admin.Exam');
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
	}
	
	/**
	 * Name : Index
	 * Purpose : For language listing
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function index($id=null)
	{
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->Exam->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected exams deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Exam.' . $field_name . ' Like' => $value . '%'));
			}
		}
		if($id)
		{
			$edit_lang = $this->Exam->find('first', array('conditions' => array('Exam.id' => $id), 'fields' => array('id','title','icon')));
			$this->set('edit_lang',$edit_lang);
		}
		
		$this->paginate = array('order' => 'id desc','limit' => 10);
		$exams = $this->paginate('Exam', $conditions);
		$this->set('exams',$exams);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new Exam
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function add()
	{
            $local = CakeSession::read("Language");
            $local_list = configure::read('local');
		if($this->request->is('post'))
		{
			$data = $this->data;
                           $fields_data =configure::read('exam');
                            $this->Exam->bindTranslation($fields_data);
                            $this->Exam->locale= $local_list[$local];
			if($this->Exam->save($data))
			{
				$this->Session->setFlash('Exam saved successfully');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('The Exam could not be saved. Please, try again.'));
			}
		}
	}
	
	/**
	 * Name : Edit
	 * Purpose : To edit the Exam
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function edit($id = null)
	{
            $local = CakeSession::read("Language");
            $local_list = configure::read('local');
            $this->loadModel('I18nModel');
            $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'Exam')));
         if ($local_data) {
            $this->Exam->locale= $local_list[$local];
            $fields_data = configure::read('exam');
            $this->Exam->bindTranslation($fields_data);
        }
            
		if($this->request->is('post'))
		{
			$this->add();
		}
		$edit_Exam = $this->Exam->find('first', array('conditions' => array('Exam.id' => $id)));
		$this->set('edit_Exam', $edit_Exam);
		$this->render('add');
	}
}
