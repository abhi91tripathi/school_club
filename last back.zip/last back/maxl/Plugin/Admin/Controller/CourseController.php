<?php

/**
 * Project : img180.com
 * Author : Nitin
 * Creation Date : 16 Oct 2013
 * Description : FOR AD (add, edit & manage)
 */
class CourseController extends AdminAppController {

    var $name = 'Course';
    var $uses = array('Admin.Course', 'Admin.CourseType', 'Admin.CoursePrice');

    function beforeFilter() {
        parent::beforeFilter();
      
        
    }

    /**
     * Purpose : Listing of courses   
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function index() {
        $cond_arr = array();

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('Course.id' => 'desc')
        );

        $result_arr = $this->paginate('Course');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Courses';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list');
    }

    /**
     * Purpose : add main course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function add() {
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        if (!empty($this->data)) {

            $data_arr = $this->data;
            $data_arr['Course']['slug'] = $this->get_slug($data_arr['Course']['title']);

            $this->Course->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'course', 'action' => 'index'));
        }

        $this->set('view_title', 'Add Course');
        $this->set('errors', $errors);
    }

    /**
     * Purpose : edit main course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function edit($id) {
        $local = CakeSession::read("Language");
                $local_list = configure::read('local');
                $this->loadModel('I18nModel');
                $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'Course')));
                if ($local_data) {
                    $fields_data =configure::read('course');
                    $this->Course->bindTranslation($fields_data);
                }
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->Course->id = $id;
        if (!empty($this->data)) {

            $data_arr = $this->data;
            $data_arr['Course']['slug'] = $this->get_slug($data_arr['Course']['title']);
            
            $fields_data =configure::read('course');
            $this->Course->bindTranslation($fields_data);
            
            $this->Course->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'course', 'action' => 'index'));
        }
        $this->data = $this->Course->findById($id);
        $this->set('view_title', 'Add Course');
        $this->set('errors', $errors);
        $this->render('add');
    }

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->Course->deleteAll(array('Course.id' => $ids), true);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->Course->updateAll(array('Course.featured' => "'Yes'"), array('Course.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->Course->updateAll(array('Course.featured' => "'No'"), array('Course.id' => $ids));
                    $message = 'Inactivated successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }

    /**
     * Purpose : Listing of sub courses   
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function list_sub_course($id) {
        $cond_arr = array('CourseType.institute_id' => $id);
        $this->set('institute_id', $id);

        $this->CourseType->bindModel(
                array('belongsTo' => array(
                        'Course' => array(
                            'className' => 'Course',
                            'foreignKey' => 'course_id'
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
                $cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('CourseType.id' => 'desc')
        );

        $result_arr = $this->paginate('CourseType');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Courses';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list_sub_course');
    }

    /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     * updated on:9 june 2014
     * by:Abhishek Tripathi
     */
    function add_sub_course($institute_id) {

        $this->set('institute_id', $institute_id);
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Course');
        $this->loadModel('CoursePrice');
        $this->loadModel('Admin.Institute');
        $this->loadModel('Currency');
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');

        $current_year = date('Y');
        $this->set('current_year', $current_year);
        if (!empty($this->data)) {

            $data_arr = $this->data;

            //debug($this->request->data);exit;
            //get slug from name
            $slug = $this->get_slug($data_arr['CourseType']['title']);
            $conditions = array("CourseType.slug" => $slug);
            $count = $this->CourseType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['CourseType']['slug'] = $slug;
            }
            $data_arr['CourseType']['institute_id'] = $institute_id;

            $data_arr['CourseType']['lesson_schedule_data'] = json_encode($this->request->data['CourseType']['lesson_schedule_data']);
            $data_arr['CourseType']['course_available_data'] = json_encode($this->request->data['CourseType']['course_available_data']);
            $data_arr['CourseType']['lesson_schedule'] = json_encode($this->request->data['CourseType']['lesson_schedule']);
            //$data_arr['CourseType']['price_chart'] = json_encode($this->request->data['CourseType']['price_chart']);
            
            $this->discount_enable_new($this->request->data['CourseType']['Discount'],$institute_id);
            $data_arr['CourseType']['discount'] = json_encode($this->request->data['CourseType']['Discount']);
            $data_arr['CourseType']['group_course'] = json_encode($this->request->data['CourseType']['group']);

            $this->CourseType->locale= $local_list[$local];
            $fields_data = configure::read('course');
            $this->CourseType->bindTranslation($fields_data);

            if ($this->CourseType->save($data_arr)) {
                $current_price_list = array('CoursePrice' => array(
                        'institute_id' => $institute_id,
                        'course_types_id' => $this->CourseType->getlastInsertId(),
                        'price_chart' => json_encode($data_arr['CourseType']['current_year']['price_chart']),
                        'plan' => $data_arr['CourseType']['current_year']['plan'],
                        'min_no_course' => $data_arr['CourseType']['current_year']['min_no_course'],
                        'max_no_course' => $data_arr['CourseType']['current_year']['max_no_course'],
                        'year' => $current_year,
                ));
                $this->CoursePrice->create();
                $this->CoursePrice->save($current_price_list);


                if (isset($this->request->data['save'])) {
                    $this->redirect(array('controller' => 'course', 'action' => 'edit_sub_course', $institute_id, $this->CourseType->getLastInsertId()));
                    $this->Session->setFlash(__('Save successfully.'), 'flash_success');
                } else {
                    $this->redirect(array('controller' => 'course', 'action' => 'list_sub_course', $institute_id));
                    $this->Session->setFlash(__('Added successfully.'), 'flash_success');
                }
            } else {
                $this->Session->setFlash(__('Sorry please try again'), 'flash_success');
                $this->redirect(array('controller' => 'course', 'action' => 'list_sub_course', $institute_id));
            }
        }
        $next_year_date = array('31 August', '30 september', '31 October', '30 November', '31 December', '31 january of next year');
        $this->set('next_year_date', $next_year_date);
        $level = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advance', 'Proficient', 'All level');
        $this->set('level', $level);

        $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $institute_id)));

        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);


        $courses = $this->Course->find('list');
        $this->set('courses', $courses);
        for ($i = 1; $i <= 52; $i++) {
            $week[$i] = $i;
        }
        $this->set('week', $week);
        $this->set('view_title', 'Add Course');
        $this->set('errors', $errors);
    }

    /**
     * Purpose : upload pdf file
     * Input :	input field name
     * Created on : 7 may 2014
     * Author : Rupesh Sharma
     */
    function upload_file($institute_id, $field_name) {

        $this->Upload = $this->Components->load('Upload');
        $config['upload_path'] = UPLOAD_INSTITUE_DIR . $institute_id . '/';
        $config['allowed_types'] = 'pdf';
        $config['max_size'] = 1200;
        $config['encrypt_name'] = false;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        if ($this->Upload->do_upload($field_name)) {

            $filedata_arr = $this->Upload->data();
            return $filedata_arr['file_name'];
        }
    }

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE for sub courses
     * Created on : 9 May 2014
     * Author : Rupesh Sharma
     */
    function sub_course_manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->CourseType->deleteAll(array('CourseType.id' => $ids), true);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->CourseType->updateAll(array('CourseType.published' => "1"), array('CourseType.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->CourseType->updateAll(array('CourseType.published' => "0"), array('CourseType.id' => $ids));
                    $message = 'Inactivated successfully.';
                } elseif ($task == "Duplicate") {
                    $course_list = $this->CourseType->find('all', array('conditions' => array('CourseType.id' => $ids)));

                    //debug($course_list);

                    foreach ($course_list as $course) {
                        $old_course_id = $course['CourseType']['id'];
                        $course = Hash::remove($course, 'CourseType.id');
                        unset($course_id);
                        $this->CourseType->save($course);
                        $course_id = $this->CourseType->getLastInsertId();
                        $this->CoursePrice->recursive = -1;
                        $coursePrice = $this->CoursePrice->find('all', array('conditions' => array('CoursePrice.course_types_id' => $old_course_id)));
                        //debug($coursePrice);exit;
                        foreach ($coursePrice as $price) {
                            $price = Hash::remove($price, 'CoursePrice.id');
                            $price = Hash::remove($price, 'CoursePrice.course_types_id');
                            $price = Hash::insert($price, 'CoursePrice.course_types_id', $course_id);
                            $this->CoursePrice->create();
                            $this->CoursePrice->save($price);
                        }
                        //debug($price);exit;
                    }
                    $message = 'Duplicate successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }

    /**
     * Purpose : FOR ADMIN to edit sub course information
     * Created on : 9 june 2014
     * Author : Abhishek Tripathi
     */
    public function edit_sub_course($instituted, $id) {
        
    
       $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'CourseType')));
        
        if ($local_data) {
            $this->CourseType->locale= $local_list[$local];
            $fields_data = configure::read('coursetype');
            $this->CourseType->bindTranslation($fields_data);
        }
        $this->set('institute_id', $instituted);
        $errors = array();
        $this->CourseType->id = $id;
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Admin.CoursePrice');
        $this->loadModel('Admin.Institute');
        $this->loadModel('Currency');
        $current_year = date('Y');
        $last_year = date('Y', strtotime('-1 years'));
        $nextyear = date('Y', strtotime('+1 years'));
        $this->set('current_year', $current_year);
        $this->set('last_year', $last_year);
        $this->set('next_year', $nextyear);
        if (!empty($this->data)) {

            $this->CourseType->id = $id;
            $data_arr = $this->data;
            

            if ((!empty($data_arr['CourseType']['current_year']['plan'])) && (!empty($data_arr['CourseType']['current_year']['plan'])) && (!empty($data_arr['CourseType']['current_year']['plan']))) {
                $current_price_list = array('CoursePrice' => array(
                        'institute_id' => $instituted,
                        'course_types_id' => $id,
                        'price_chart' => json_encode($data_arr['CourseType']['current_year']['price_chart']),
                        'plan' => $data_arr['CourseType']['current_year']['plan'],
                        'min_no_course' => $data_arr['CourseType']['current_year']['min_no_course'],
                        'max_no_course' => $data_arr['CourseType']['current_year']['max_no_course'],
                        'year' => $current_year,
                ));
                if ($current_year_price = $this->get_price_year($current_year, $instituted, $id)) {
                    $this->CoursePrice->id = $current_year_price;
                    $this->CoursePrice->save($current_price_list);
                } else {
                    $this->CoursePrice->create();
                    $this->CoursePrice->save($current_price_list);
                }
            }
            if ((!empty($data_arr['CourseType']['last_year']['plan'])) && (!empty($data_arr['CourseType']['last_year']['plan'])) && (!empty($data_arr['CourseType']['last_year']['plan']))) {
                $last_price_list = array('CoursePrice' => array(
                        'institute_id' => $instituted,
                        'course_types_id' => $id,
                        'price_chart' => json_encode($data_arr['CourseType']['last_year']['price_chart']),
                        'plan' => $data_arr['CourseType']['last_year']['plan'],
                        'min_no_course' => $data_arr['CourseType']['last_year']['min_no_course'],
                        'max_no_course' => $data_arr['CourseType']['last_year']['max_no_course'],
                        'year' => $last_year,
                ));
                if ($last_year_price = $this->get_price_year($last_year, $instituted, $id)) {
                    $this->CoursePrice->id = $last_year_price;
                    $this->CoursePrice->save($last_price_list);
                } else {
                    $this->CoursePrice->create();
                    $this->CoursePrice->save($last_price_list);
                }
            }

            if ((!empty($data_arr['CourseType']['next_year']['plan'])) && (!empty($data_arr['CourseType']['next_year']['plan'])) && (!empty($data_arr['CourseType']['next_year']['plan']))) {
                $next_price_list = array('CoursePrice' => array(
                        'institute_id' => $instituted,
                        'course_types_id' => $id,
                        'price_chart' => json_encode($data_arr['CourseType']['next_year']['price_chart']),
                        'plan' => $data_arr['CourseType']['next_year']['plan'],
                        'min_no_course' => $data_arr['CourseType']['next_year']['min_no_course'],
                        'max_no_course' => $data_arr['CourseType']['next_year']['max_no_course'],
                        'year' => $nextyear
                ));

                if ($next_year_price = $this->get_price_year($nextyear, $instituted, $id)) {
                    $this->CoursePrice->id = $next_year_price;
                    $this->CoursePrice->save($next_price_list);
                } else {
                    $this->CoursePrice->create();
                    $this->CoursePrice->save($next_price_list);
                }
            }

            //get slug from name
            $slug = $this->get_slug($data_arr['CourseType']['title']);
            $conditions = array("CourseType.slug" => $slug);
            $count = $this->CourseType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['CourseType']['slug'] = $slug;
            }
            $data_arr['CourseType']['institute_id'] = $instituted;
            $data_arr['CourseType']['lesson_schedule_data'] = json_encode($this->request->data['CourseType']['lesson_schedule_data']);
            $data_arr['CourseType']['course_available_data'] = json_encode($this->request->data['CourseType']['course_available_data']);
            $data_arr['CourseType']['lesson_schedule'] = json_encode($this->request->data['CourseType']['lesson_schedule']);
            
          $this->discount_enable($this->request->data['CourseType']['Discount'],$instituted,$id);
            
            $data_arr['CourseType']['discount'] = json_encode($this->request->data['CourseType']['Discount']);
            $data_arr['CourseType']['group_course'] = json_encode($this->request->data['CourseType']['group']);
            $this->CourseType->locale= $local_list[$local];
            $fields_data = configure::read('coursetype');
            $this->CourseType->bindTranslation($fields_data);
            
            $this->CourseType->save($data_arr);
            if (isset($this->request->data['save'])) {
                $this->redirect(array('controller' => 'course', 'action' => 'edit_sub_course', $instituted, $id));
                $this->Session->setFlash(__('Save successfully.'), 'flash_success');
            } else {
                $this->redirect(array('controller' => 'course', 'action' => 'list_sub_course', $instituted));
                $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            }
        }
        $data_arr = $this->CourseType->findById($id);

        $level = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advance', 'Proficient', 'All level');
        $this->set('level', $level);
        $lesson_schedule_data['lesson_schedule_data'] = json_decode($data_arr['CourseType']['lesson_schedule_data'], true);
        if (!empty($lesson_schedule_data)) {
            $new_arr = array_merge($data_arr['CourseType'], $lesson_schedule_data);
            $data_arr = array('CourseType' => $new_arr);
        }
        $course_available['course_available_data'] = json_decode($data_arr['CourseType']['course_available_data'], true);

        if (!empty($course_available)) {
            $new_arr = array_merge($data_arr['CourseType'], $course_available);
            $data_arr = array('CourseType' => $new_arr);
        }
        $price_chart['price_chart'] = json_decode($data_arr['CourseType']['price_chart'], true);

        if (!empty($price_chart)) {
            $new_arr = array_merge($data_arr['CourseType'], $price_chart);
            $data_arr = array('CourseType' => $new_arr);
        }
        $discount['Discount'] = json_decode($data_arr['CourseType']['discount'], true);
        if (!empty($discount)) {
            $new_arr = array_merge($data_arr['CourseType'], $discount);
            $data_arr = array('CourseType' => $new_arr);
        }
        $group_course['group'] = json_decode($data_arr['CourseType']['group_course'], true);
        if (!empty($group_course)) {
            $new_arr = array_merge($data_arr['CourseType'], $group_course);
            $data_arr = array('CourseType' => $new_arr);
        }
        $lesson_schedule['lesson_schedule'] = json_decode($data_arr['CourseType']['lesson_schedule'], true);
        if (!empty($lesson_schedule)) {
            $new_arr = array_merge($data_arr['CourseType'], $lesson_schedule);
            $data_arr = array('CourseType' => $new_arr);
        }
        $this->CoursePrice->recursive = -1;
        $course_price_lists = $this->CoursePrice->find('all', array('conditions' => array('AND' => array('CoursePrice.institute_id' => $instituted, 'CoursePrice.course_types_id' => $id))));
        foreach ($course_price_lists as $course_price_list) {
            if ($last_year == $course_price_list['CoursePrice']['year']) {
                $course_price_list['CoursePrice']['price_chart'] = json_decode($course_price_list['CoursePrice']['price_chart'], true);
                $data_arr['CourseType']['last_year'] = $course_price_list['CoursePrice'];
            }
            if ($current_year == $course_price_list['CoursePrice']['year']) {
                $course_price_list['CoursePrice']['price_chart'] = json_decode($course_price_list['CoursePrice']['price_chart'], true);
                $data_arr['CourseType']['current_year'] = $course_price_list['CoursePrice'];
            }
            if ($nextyear == $course_price_list['CoursePrice']['year']) {
                $course_price_list['CoursePrice']['price_chart'] = json_decode($course_price_list['CoursePrice']['price_chart'], true);
                $data_arr['CourseType']['next_year'] = $course_price_list['CoursePrice'];
            }
        }

        $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $instituted), 'fields' => array('currency_id')));
        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);




        //  debug($data_arr);
        $this->data = $data_arr;

        $courses = $this->Course->find('list');
        $this->set('courses', $courses);
        $selected_course = array($this->data['CourseType']['course_id']);
        $this->set('selected_course', $selected_course);
        $this->set('view_title', 'Add Course');
        for ($i = 1; $i <= 52; $i++) {
            $week[$i] = $i;
        }
        $this->set('week', $week);
        $this->set('errors', $errors);
        $this->render('add_sub_course');
    }

    /**
     * Purpose:get price list id
     * created on:16 june 2014
     * created by:Abhishek Tripathi
     * */
    public function get_price_year($year = null, $institute_id = null, $course_id = null) {
        $this->loadModel('CoursePrice');

        $year = $this->CoursePrice->find('first', array('conditions' => array('AND' => array('CoursePrice.year' => $year, 'CoursePrice.institute_id' => $institute_id, 'CoursePrice.course_types_id' => $course_id)), 'fields' => array('id')));

        if ($year) {
            return $year['CoursePrice']['id'];
        } else {
            return FALSE;
        }
    }

    /**
     * Purpose:get limit range of price editor
     * created on:7 oct 2014
     * created by:Abhishek Tripathi
     * */
    public function get_limit() {
        $max = $this->request->data['max'];
        $min = $this->request->data['min'];
        $html = '<option value="">Please choose</option>';
        for ($i = $min; $i <= $max; $i++) {
            $html.='<option value="' . $i . '">' . $i . '</option>';
        }
        echo $html;
        exit;
    }

    /**
     * Purpose: this function is upload course image
     * created on 21 july 2014
     * created by:Abhishek Tripathi
     * */
    public function upload() {
        // debug($this->params);exit;
        if (isset($this->params->form['course_image'])) {
            $one = $this->params->form['course_image'];
            $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
            $path = 'files' . DS . 'course_image' . DS;
            move_uploaded_file($one['tmp_name'], $path . $name);
            // $this->Resize = $this->Components->load('ImageResize');
            // $this->Resize->resize( $path.$name, '870', '320', $path.$name);
            $response['image_name'] = $name;
            $response['path'] = FULL_BASE_URL . $this->webroot . 'files/course_image/' . $name;
            echo json_encode($response);
            exit;
        }
    }
    
    /**
     * Purpose: this function is upload course category_image
     * created on dece 2014
     * created by:Abhishek Tripathi
     * */
    public function category_image() {
        // debug($this->params);exit;
        if (isset($this->params->form['course_image'])) {
            $one = $this->params->form['course_image'];
            $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
            $path = 'files' . DS . 'course_category' . DS;
            move_uploaded_file($one['tmp_name'], $path . $name);
            // $this->Resize = $this->Components->load('ImageResize');
            // $this->Resize->resize( $path.$name, '870', '320', $path.$name);
            $response['image_name'] = $name;
            $response['path'] = FULL_BASE_URL . $this->webroot . 'files/course_category/' . $name;
            echo json_encode($response);
            exit;
        }
    }

            public function discount_enable($data=null,$id=null,$course_id=null){
               //debug($id);
                    $this->loadModel('Institute');
                    $this->Institute->id=$id;
                    if($data['plan']!=4){
                        $this->Institute->saveField('discount_available',1);
                      
                    }
                    else{
                        $institute_commision_discount=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('Institute.commission')));
                        $discount=json_decode($institute_commision_discount['Institute']['commission'],true);
                        if(!empty($discount['com_registration_fee_dis']) ||!empty($discount['com_accommodation_fee_dis']) || !empty($discount['com_courses_dis']) || !empty($discount['com_accommodation_dis']) || !empty($discount['com_transfer_dis']))
                        {
                            $this->Institute->saveField('discount_available',1);
                        }
                        else{
                            $course_discount_list=$this->CourseType->find('all',array('conditions'=>array('AND'=>array('CourseType.institute_id'=>$id,'CourseType.id >'=>$course_id)),'fields'=>array('CourseType.discount')));
                            $discount_available=0;
                            foreach($course_discount_list as $discount_list){
                                $discount_course=  json_decode($discount_list['CourseType']['discount'],true);
                                if(!empty($discount_course['plan']) && $discount_course['plan']!=4 ){
                                    $discount_available=1;
                                }
                            }
                            
                            if($discount_available==1){
                                $this->Institute->saveField('discount_available',1);
                            }
                            else{
                               $this->Institute->saveField('discount_available',0);  
                            }
                           
                            
                        }
                            //$coures_list=$this->CourseType->find('all',array('conditions'=>array('')));
                    }
                    return true;
            }
            
              public function discount_enable_new($data=null,$id=null){
               //debug($id);
                    $this->loadModel('Institute');
                    $this->Institute->id=$id;
                    if($data['plan']!=4){
                        $this->Institute->saveField('discount_available',1);
                      
                    }
                    return true;
            }
            
            
            /**
     * Purpose : Listing of subcourses   
     * Created on : 15-04-15
     * Author : Abhishek Tripathi
     */
    function subcourse_list() {
        configure::write('debug',2);
        $this->loadModel('CourseSubcategory');
        $cond_arr = array();

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('Course.id' => 'desc')
        );

        $result_arr = $this->paginate('CourseSubcategory');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Courses subcategory';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
       
    }
    
    
    /**
     * Purpose : add sub course
     * Created on : 15-04-15
     * Author : Abhsihek Tripathi
     */
    function add_subcategory() {
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('CourseSubcategory');
        if (!empty($this->data)) {

            $data_arr = $this->data;
           

            $this->CourseSubcategory->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'course', 'action' => 'subcourse_list'));
        }
        $course=$this->Course->find('list',array('fields'=>array('id','title')));
        $this->set('course_list',$course);
        $this->set('view_title', 'Add Course subcategory');
        $this->set('errors', $errors);
    }
    
      /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function manage_subcourse() {
        $this->loadModel('CourseSubcategory');
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->CourseSubcategory->deleteAll(array('CourseSubcategory.id' => $ids), true);
                    $message = 'Deleted successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }
    
}
