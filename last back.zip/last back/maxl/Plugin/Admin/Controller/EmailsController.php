<?php

/**
 * Name : Email Controller
 * Created : 8 Nov 2013
 * Purpose : Default Email controller
 * Author : Prakhar Johri
 */
class EmailsController extends AdminAppController {
	
	public $name = 'Emails';
	public $uses = array('Email');
	
	public $paginate = array ('limit' => 30);		
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
		$this->Auth->allow('register');
	}	
		
	/**
	 * name : manage method
	 * Purpose : Manage all the Email templates
	 * author : Prakhar Johri
	 * Created : 8 Nov 2013
	 */
	public function manage()
	{

		$this->loadModel('EmailTemplate');

		$conditions = array();
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			if(!empty($this->request->data['ids']))
			{
				switch($this->request->data['option'])
				{
					case "delete":
						$this->EmailTemplate->deleteAll(array('id' => $this->request->data['ids']));
						$this->Session->setFlash(__('Selected email template deleted sucessfully'));
					break;
					case "active":
						$this->EmailTemplate->updateAll(array('status' => "'active'"), array('id' =>  $this->request->data['ids'] ));
					break;
					case "deactive":
						$this->EmailTemplate->updateAll(array('status' => "'inactive'"), array('id' =>  $this->request->data['ids'] ));
					break;
				}
			}
		}
		if($this->request->is('ajax'))
		{
			$this->layout = 'ajax';
		}

		$this->paginate = array(
				'limit' => 30,
				'order' => array('id' => 'DESC')
		);
		$templates = $this->Paginate('EmailTemplate');
		
		$this->set('templates',$templates);
		
	}
	
	/**
	 * name : add method
	 * Purpose : Add new email template
	 * author : Prakhar Johri
	 * Created : 8 Nov 2013 
	 */	
	function add($id = NULL)
	{
             $this->loadModel('Admin.EmailTemplate');
             $presonal_detail=array('{{student_image}}','{{first_name}}','{{last_name}}','{{gender}}','{{date_of_birth}}','{{nationality}}','{{student_email}}');
             $Booking=array('{{school_logo}}','{{school_name}}','{{booking_id}}','{{booking_date}}','{{starting_date}}','{{duration}}','{{transfer}}','{{comment}}','{{course}}','{{accommodation}}','{{extra_fee}}','{{language_level}}','{{previously_attended}}','{{terms_conditions}}','{{cancel_policiy}}');
             $Payment=array('{{payment_type}}','{{payment_status}}','{{payment_id}}','{{deposit_due_now_eur}}');
             $confirm_page=array('{{student_phone}}','{{student_address}}','{{post_code}}','{{city}}','{{country}}','{{pasport_id}}','{{emergency_name}}','{{emergency_email}}','{{emergency_phone}}',
                 '{{emergency_address}}','{{emergency_post_code}}','{{emergency_city}}','{{emergency_country}}','{{thanks_page_comment}}','{{smoker}}','{{children}}','{{pets}}','{{special_diets}}'
                 );
             $discount_key=array('{{course_reg_discount_key}}','{{course_dis_commision_key}}','{{accomodatio_reg_discount_key}}','{{accommodation_dis_key}}');
             $discount_value_student_currency=array('{{course_reg_discount_value}}','{{course_dis_commision_dis_value}}','{{accomodatio_reg_discount_value}}','{{accommodation_dis_value}}');
             $discount_value_school_currency=array('{{course_reg_discount_value_school_currency}}','{{course_dis_commision_dis_value_school_currency}}','{{accomodatio_reg_discount_value_school_currency}}','{{accommodation_dis_value_school_currency}}');
             $price_student_currency=array('{{course_registration_fee}}','{{course_price}}','{{accommodation_registration_fee}}','{{accommodation_price}}','{{total}}','{{deposit_due_now}}','{{extra_fee}}');
             $price_school_currency=array('{{course_registration_fee_school_currency}}','{{course_price_school_currency}}','{{accommodation_registration_fee_school_currency}}','{{accommodation_price_school_currency}}','{{total_school_currency}}','{{deposit_due_now_school_currency}}','{{extra_fee_price_school_currency}}');
             $schoo_process=array('{{accept_link}}','{{reject_link}}','{{school_website}}','{{school_contact}}','{{school_phone}}','{{school_email}}','{{review_request_link}}');
             $email_friend=array('{{Your_name}}','{{meta_title}}','{{url}}');
             $undifiend=array('{{first_name}}','{{last_name}}','{{username}}','{{password}}','{{email}}','{{domain}}','{{activation_link}}','{{activation_link_send_date}}','{{forgot_password_link}}','{{forgot_password_link_send_date}}','{{message}}','{{domain}}');
             
             
		
		if($this->request->data)
		{
			$data_arr = $this->request->data;
			$data_arr['EmailTemplate']['name'] = $this->data['EmailTemplate']['email_identifier'];
			if(empty($this->request->data['EmailTemplate']['id']))
			{
				$data_arr['EmailTemplate']['email_identifier'] = $this->EmailTemplate->generate_identifier($this->data['EmailTemplate']['email_identifier']);
			}
                          $fields_data = configure::read('email_template');
                        $this->EmailTemplate->bindTranslation($fields_data);
			$this->EmailTemplate->save($data_arr);
			if(!empty($this->request->data['EmailTemplate']['id']))
			{
				$this->Session->setFlash('Email Template has been updated successfully');
			}
			else
			{
				$this->Session->setFlash('Email Template save successfully');
			}
			$this->redirect('manage');
		}
		if(!empty($id))
		{
			$this->request->data = $this->EmailTemplate->findById($id);
		}
                $this->set(compact('key_word'));
	}
	
	/**
	 * name : edit method
	 * Purpose :edit email template
	 * author : Prakhar Johri
	 * Created : 8 Nov 2013
	 */
	function edit($id = NULL)
	{
        $this->loadModel('EmailTemplate');
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'EmailTemplate')));
      
        if ($local_data) {
            $fields_data = configure::read('email_template');
            $this->EmailTemplate->bindTranslation($fields_data);
        } 
            
            
             $presonal_detail=array('{{student_image}}','{{first_name}}','{{last_name}}','{{gender}}','{{date_of_birth}}','{{nationality}}','{{student_email}}');
             $Booking=array('{{school_logo}}','{{school_name}}','{{booking_id}}','{{booking_date}}','{{starting_date}}','{{duration}}','{{transfer}}','{{comment}}','{{course}}','{{accommodation}}','{{extra_fee}}','{{language_level}}','{{previously_attended}}','{{terms_conditions}}','{{cancel_policiy}}');
             $Payment=array('{{payment_type}}','{{payment_status}}','{{payment_id}}','{{deposit_due_now_eur}}');
             $confirm_page=array('{student_phone}}','{{student_address}}','{{post_code}}','{{city}}','{{country}}','{{pasport_id}}','{{emergency_name}}','{{emergency_email}}','{{emergency_phone}}',
                 '{{emergency_address}}','{{emergency_post_code}}','{{emergency_city}}','{{emergency_country}}','{{thanks_page_comment}}','{{smoker}}','{{children}}','{{pets}}','{{special_diets}}'
                 );
             $discount_key=array('{{course_reg_discount_key}}','{{course_dis_commision_key}}','{{accomodatio_reg_discount_key}}','{{accommodation_dis_key}}');
             $discount_value_student_currency=array('{{course_reg_discount_value}}','{{course_dis_commision_dis_value}}','{{accomodatio_reg_discount_value}}','{{accommodation_dis_value}}');
             $discount_value_school_currency=array('{{course_reg_discount_value_school_currency}}','{{course_dis_commision_dis_value_school_currency}}','{{accomodatio_reg_discount_value_school_currency}}','{{accommodation_dis_value_school_currency}}');
             $price_student_currency=array('{{course_registration_fee}}','{{course_price}}','{{accommodation_registration_fee}}','{{accommodation_price}}','{{total}}','{{deposit_due_now}}','{{extra_fee_price}}');
             $price_school_currency=array('{{course_registration_fee_school_currency}}','{{course_price_school_currency}}','{{accommodation_registration_fee_school_currency}}','{{accommodation_price_school_currency}}','{{total_school_currency}}','{{deposit_due_now_school_currency}}','{{extra_fee_price_school_currency}}');
             $schoo_process=array('{{accept_link}}','{{reject_link}}','{{school_website}}','{{school_contact}}','{{school_phone}}','{{school_email}}','{{school_city}}','{{review_request_link}}');
             $email_friend=array('{{Your_name}}','{{meta_title}}','{{url}}');
             $undifiend=array('{{first_name}}','{{last_name}}','{{username}}','{{password}}','{{email}}','{{domain}}','{{activation_link}}','{{activation_link_send_date}}','{{forgot_password_link}}','{{forgot_password_link_send_date}}','{{message}}','{{domain}}');
             
             
            
		if($this->request->data)
		{
			$data_arr = $this->request->data;
			$data_arr['EmailTemplate']['name'] = $this->data['EmailTemplate']['email_identifier'];
			unset($data_arr['EmailTemplate']['email_identifier']);
                        $fields_data = configure::read('email_template');
                        $this->EmailTemplate->bindTranslation($fields_data);
                        
			$this->EmailTemplate->save($data_arr);
			if(!empty($this->request->data['EmailTemplate']['id']))
			{
				$this->Session->setFlash('Email Template has been updated successfully');
			}
			else
			{
				$this->Session->setFlash('Email Template save successfully');
			}
			$this->redirect('manage');
        }
		if(!empty($id))
		{
                       $fields_data = configure::read('email_template');
            $this->EmailTemplate->bindTranslation($fields_data);
			$this->request->data = $this->EmailTemplate->findById($id);
		}
                        $this->set(compact('key_word','presonal_detail','Booking','Payment','confirm_page','discount_key','discount_kye','discount_value_student_currency','discount_value_school_currency',
                                'price_student_currency','price_school_currency','schoo_process','email_friend','undifiend'
                                ));

	}

	 /**
	 * name : delete method
	 * Purpose :delete email template
	 * author : Prakhar Johri
	 * Created : 8 Nov 2013
	 */
	public function delete($id = null) {
		
		$this->loadModel('EmailTemplate');
		$this->EmailTemplate->id = $id;
		$data =$this->EmailTemplate->findById($id);
		$email =$data['EmailTemplate']['email_identifier'];
		$this->EmailTemplate->delete($id);
                $this->Session->setFlash(__('User was not deleted'));
		$this->redirect(array('action' => 'manage'));
	}
}
