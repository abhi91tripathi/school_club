<?php

/**
 * Name : CMS Controller
 * Created : 8 Nov 2013
 * Purpose : Default CMS controller
 * Author : Prakhar Johri
 */
class CmsController extends AdminAppController {

    public $name = 'Cms';
    public $uses = array('Cms');
    public $paginate = array('limit' => 10);

    public function beforeFilter() {
        parent::beforeFilter();
        //Set auth model Admin
        $this->Auth->authenticate = array(
            'Form' => array('userModel' => 'Admin')
        );
        $this->Auth->allow('register');
    }

    /**
     * Name : Index
     * Purpose : Default index function for CMS Pages. Display  CMS page listing and other filters
     * Created : 8 Nov 2013	 
     * Author : Prakhar Johri
     */
    public function index() {
        //This section handles multipe delete and change status
        if (isset($this->request->data['option']) && !empty($this->request->data['option'])) {
            if (!empty($this->request->data['ids'])) {
                switch ($this->request->data['option']) {
                    case "delete":
                        $this->Cms->deleteAll(array('id' => $this->request->data['ids']));
                        $this->Session->setFlash(__('Selected users deleted sucessfully'));
                        break;
                    case "active":
                        $this->Cms->updateAll(array('status' => "'active'"), array('id' => $this->request->data['ids']));
                        break;
                    case "deactive":
                        $this->Cms->updateAll(array('status' => "'inactive'"), array('id' => $this->request->data['ids']));
                        break;
                }
            }
        }

        //This section handles search
        if (isset($_GET['filter'])) {
            $this->paginate = array(
                'limit' => 10,
                'conditions' => array('Cms.' . $_GET['filter'] . ' Like ' => $_GET['search_keyword'] . '%'),
            );
        }
        $cms = $this->paginate('Cms');
        $this->set('cms', $cms);
    }

    /**
     * Name : Add Action
     * Created : 8 Nov 2013
     * Purpose : For add new CMS Pages
     * Author : Prakhar Johri
     */
    public function add() {
        if ($this->request->is('post')) {
            $this->Cms->create();
            if ($this->Cms->save($this->request->data)) {
                $this->Session->setFlash(__('The Cms has been saved'));
                $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The Cms could not be saved. Please, try again.'));
            }
        }
    }

    /**
     * Name : Edit user action
     * Created :8 Nov 2013
     * Purpose : For edit CMS page
     * Author : Prakhar Johri
     */
    public function edit($id = null) {
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'Cms')));
        
        if ($local_data) {
            $this->Cms->locale= $local_list[$local];
            $fields_data = configure::read('cms_fields');
            $this->Cms->bindTranslation($fields_data);
        }
        if ($this->request->is('post') || $this->request->is('put')) {
            $this->Cms->id=$id;
            $fields_data =configure::read('cms_fields');
            $this->Cms->bindTranslation($fields_data);
            $this->Cms->locale= $local_list[$local];
            $this->Cms->save($this->data);
            $this->Session->setFlash(__('Cms page is saved'));
            $this->redirect(array('action'=> 'edit',$id));
            
        }
            $options = array('conditions' => array('Cms.' . $this->Cms->primaryKey => $id));
            $this->request->data = $this->Cms->find('first', $options);
        
        $this->set('page', 'edit');
        $this->render('add');
    }

    /**
     * Name : list of language level
     * Created :3 nov 2014
     * Purpose : language level stander for student define by admin
     * Author : Abhishek Tripathi
     */
    public function level_list() {
        $this->loadModel('LanguageLevel');
        $cms = $this->paginate('LanguageLevel');
        $this->set('cms', $cms);
    }

    /**
     * Name : list of language level add and edit
     * Created :3 nov 2014
     * Purpose : language level stander for student define by admin
     * Author : Abhishek Tripathi
     */
    public function edit_language_level($id = null) {
        $this->loadModel('LanguageLevel');

        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'LanguageLevel')));
        if ($local_data) {
            $fields_data = configure::read('language_level');
            $this->LanguageLevel->bindTranslation($fields_data);
        }

        if ($this->request->is('put') || $this->request->is('post')) {
            $this->LanguageLevel->id = $id;
            $fields_data = configure::read('language_level');
            $this->LanguageLevel->bindTranslation($fields_data);
            if ($this->LanguageLevel->save($this->request->data)) {
                $this->Session->SetFlash(__('Successfully completed'));
                $this->redirect(array('action' => 'level_list'));
            } else {
                $this->Session->SetFlash(__('Sorry please try again'));
            }
        }
        if ($id !== null) {
            $this->data = $this->LanguageLevel->find('first', array('conditions' => array('LanguageLevel.id' => $id)));
            $this->LanguageLevel->id = $id;
        }

        $this->render('add_level');
    }

    /**
     * Name : edit tooltip 
     * Created :20 nov 2014
     * Purpose : change tooltip description
     * Author : Abhishek Tripathi
     */
    public function tooltip_add($id = null) {
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'Tooltip')));
        if ($local_data) {
            $fields_data = configure::read('tooltip');
            $this->Tooltip->bindTranslation($fields_data);
        }

        $this->loadModel('Tooltip');
        if ($this->request->is('put')) {
            $fields_data = configure::read('tooltip');
            $this->Tooltip->bindTranslation($fields_data);
            if ($this->Tooltip->save($this->request->data)) {
                $this->Session->setFlash(__('Successfully saved'));
            } else {
                $this->Session->setFlash(__('Please try again'));
            }
        }
        $this->data = $this->Tooltip->find('first', array('conditions' => array('Tooltip.id' => $id)));
    }

    /**
     * Name :list of tooltip
     * Created :20 nov 2014
     * Purpose : list of tootltip
     * Author : Abhishek Tripathi
     */
    public function tooltip_manage($id = null) {
        $this->loadModel('Tooltip');
        $cms = $this->paginate('Tooltip');
        $this->set('cms', $cms);
    }

    public function discount() {
        $this->loadModel('DiscountContent');
        $DiscountContent = $this->paginate('DiscountContent');
        $this->set('DiscountContent', $DiscountContent);
    }

    public function discount_edit($id = null) {
        
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $this->loadModel('DiscountContent');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'DiscountContent')));
        //debug($local_data);exit;
        if ($local_data) {
            $fields_data = configure::read('discount_content');
            $this->DiscountContent->bindTranslation($fields_data);
             $this->DiscountContent->locale=$local_list[$local]; 
        }
       
        if ($this->request->is('post') || $this->request->is('put')) {
           
            $fields_data = configure::read('discount_content');
            $this->DiscountContent->bindTranslation($fields_data);
            $this->DiscountContent->locale=$local_list[$local];   
            if ($this->DiscountContent->save($this->request->data)) {
                $this->Session->setFlash(__('Discount content page is saved'));
                $this->redirect(array('action' => 'discount'));
            }
            else {
                $this->Session->setFlash(__('Error saving page, please check again.'));
            }
        } else {
            
            $options = array('conditions' => array('DiscountContent.' . $this->DiscountContent->primaryKey => $id));
            $this->request->data = $this->DiscountContent->find('first', $options);
        }
        $DiscountContent = $this->paginate('DiscountContent');
        $this->set('DiscountContent', $DiscountContent);
        $this->set('page', 'edit');
    }

    public function site_search() {
        $this->loadModel('SiteSearch');

        $cms = $this->paginate('SiteSearch');
        $this->set('cms', $cms);
    }

    /**
     * Name : list of language level add and edit
     * Created :3 nov 2014
     * Purpose : language level stander for student define by admin
     * Author : Abhishek Tripathi
     */
    public function edit_search_code($id = null) {
        $this->loadModel('SiteSearch');
  
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'SiteSearch')));
        if ($local_data) {
            $fields_data = configure::read('site_search');
            $this->SiteSearch->bindTranslation($fields_data);
        }
        if ($this->request->is('put') || $this->request->is('post')) {
            $this->SiteSearch->id = $id;
            
            $fields_data = configure::read('site_search');
            $this->SiteSearch->bindTranslation($fields_data);
            
            if ($this->SiteSearch->save($this->request->data)) {
                $this->Session->SetFlash(__('Successfully completed'));
                $this->redirect(array('action' => 'site_search'));
            } else {
                $this->Session->SetFlash(__('Sorry please try again'));
            }
        }
        if ($id !== null) {
            $this->data = $this->SiteSearch->find('first', array('conditions' => array('SiteSearch.id' => $id)));
            $this->SiteSearch->id = $id;
        }
    }
    
    public function default_meta_edit($id=null){
            $this->loadModel('DefaultMeta');
            $local = CakeSession::read("Language");
            $local_list = configure::read('local');
      
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id, 'I18nModel.model' => 'DefaultMeta')));
        if ($local_data) {
            $fields_data = configure::read('DefaultMeta');
            $this->DefaultMeta->bindTranslation($fields_data);
        }
        
        if ($this->request->is('put') || $this->request->is('post')) {
            $fields_data = configure::read('DefaultMeta');
            $this->DefaultMeta->bindTranslation($fields_data);
           if($this->DefaultMeta->save($this->request->data)){
                $this->Session->SetFlash(__('Successfully completed'));
                $this->redirect(array('action' => 'default_meta'));
           }
            
        }
        $this->data=$this->DefaultMeta->find('first',array('conditions'=>array('DefaultMeta.id'=>$id)));
       
    }
    
    
    public function default_meta(){
        $this->loadModel('DefaultMeta');
        $conditions = array();
        if (isset($_GET['filter'])) {
            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
                $conditions = array_merge($conditions, array('Language.' . $field_name . ' Like' => $value . '%'));
            }
        }
        
        $this->paginate = array('order' => 'id desc', 'limit' => ADMIN_NUM_PER_PAGE);
        $default_meta = $this->paginate('DefaultMeta', $conditions);
        $this->set('default_meta', $default_meta);
    }

}

?>
