<?php
/**
 * Name : Destination Controller
 * Created : 3 Apr 2014
 * Purpose : To manage the Country and destination of schools
 * Author : Ritish
 */ 
class DestinationController extends AdminAppController
{
	public $name = 'destination';
	public $uses = array('Admin.Country', 'Admin.Destination');
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
	}
	
	/**
	 * Name : Index
	 * Purpose : For Destination Listing
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function index()
	{
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->Destination->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected destinations deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Destination.' . $field_name . ' Like' => $value . '%'));
			}
		}
		$this->Destination->virtualFields = array('country_name' => 'SELECT c.name FROM countries c WHERE c.id = Destination.country_id');
		$this->paginate = array('order' => 'id desc','limit' => ADMIN_NUM_PER_PAGE);
		$destinations = $this->paginate('Destination', $conditions);	
		$this->set('destinations',$destinations);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new destination. In this the country will add when the user select the add new option on the othe hand if the user seletc the country the destination will saved under that country.
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function add()
	{
		if($this->request->is('post'))
		{
			$data = $this->data;
			
			if(empty($this->data['Destination']['country_id']))
			{
				$this->Country->save($this->data);
				$data['Destination']['country_id'] = $this->Country->getLastInsertId();
			}
			else if(($this->data['Country']['flag_image']))
			{
				unlink(ROOT . '/app/Plugin/Admin/webroot/img/country_flags/' . $this->data['Country']['flag_image']);
			}
                                $data['Destination']['slug']=$this->hyphenize($data['Destination']['name']);
			if($this->Destination->save($data))
			{
				$this->Session->setFlash('Destination saved successfully');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->set('country_invalidfields', $this->Country->validationErrors);
				$this->set('destination_invalidfields', $this->Destination->validationErrors);
				$this->Session->setFlash(__('The Destination could not be saved. Please, try again.'));
			}
		}
		$countries = $this->Country->find('list',array('list', array('fields' => 'name')));
		$this->set('countries', $countries);
	}
	
	/**
	 * Name: Edit
	 * Purpose": To edi the destination
	 * Created: 3 Apr 2013
	 * Author: Ritish
	 */
	 function edit($id = Null)
	 {
                     
               $local = CakeSession::read("Language");
                $local_list = configure::read('local');
                $this->loadModel('I18nModel');
                $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'Destination')));
               
                if ($local_data) {
                    $fields_data =configure::read('destination');
                    $this->Destination->bindTranslation($fields_data);
                }
		if($this->request->is('put'))
		{       $data = $this->data;
			$this->Destination->id=$id;
                        $data['Destination']['slug']=$this->hyphenize($data['Destination']['name']);
                        $fields_data =configure::read('destination');
                        $this->Destination->bindTranslation($fields_data);
                          // debug(Configure::read('Config.language'));exit;
                         $this->Destination->save($data);
                         $this->redirect(array('action'=>'edit',$id));
			
		}
                 $this->data=$this->Destination->find('first',array('conditions'=>array('Destination.id'=>$id)));
		$this->Destination->virtualFields = array('country_name' => 'SELECT c.name FROM countries c WHERE c.id = Destination.id');
		$edit_destination = $this->Destination->findById($id);
		$this->set('edit_destination', $edit_destination);
		$countries = $this->Country->find('list',array('list', array('fields' => 'name')));
		$this->set('countries', $countries);
                $this->render('add');
	
	 }
	 
	/**
	 * Purpose":this function is call through ajax to check if the destination is already exist under the selected country or not.
	 * inputs: destination name in post, country id in post && id in post (check in all records except this one)
	 * outputs: if exists then return false else true
	 * Created: 3 Apr 2013
	 * Author: Ritish
	 */ 
	 function isexist()
	 {
		if($this->data['Destination']['country_id'])
		{
			$destination_cnt = $this->Destination->find('count', array('conditions' => array('Destination.name' => trim( $this->data['Destination']['name'] ), 'Destination.country_id' => $this->data['Destination']['country_id'], 'Destination.id <>' => $this->data['Destination']['id'])));
			if($destination_cnt > 0)
				die('false');
		}
		else
			die('true');
	 }
	 
	 /**
	 * Purpose: this function is call through ajax to check if the country is already exist or not.
	 * inputs: country name in post
	 * outputs: if exists then return false else true
	 * Created: 3 Apr 2013
	 * Author: Ritish
	 */ 
	 function iscountry_exist()
	 {
		if($this->data['Country']['name'])
		{
			$country_exist_cnt = $this->Country->find('count', array('conditions' => array('Country.name' => trim( $this->data['Country']['name'] ))));
			if($country_exist_cnt > 0)
				die('false');
		}
		die('true'); 
	 }
	 
	 /**
	  * Purpose: this function is upload banner image and flag image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload(){
	  	       if(isset($this->params->form['embassy_image'])){
	  	       	 $one= $this->params->form['embassy_image'];
	    	     $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'destination' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				 $this->Resize = $this->Components->load('ImageResize');
				 $this->Resize->resize( $path.$name, '870', '320', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/destination/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
			   else{
			   	 $one= $this->params->form['flag_image'];
	    	     $name ='f_'.date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'destination' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				  $this->Resize = $this->Components->load('ImageResize');
				 $this->Resize->resize( $path.$name, '46', '28', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/destination/' . $name;
			     echo json_encode($response);exit; 
			   }
	  }
 
	 /**
	  * Purpose: function for list of country
	  * created on 23 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function country_list(){
	  	$this->loadModel('Country');
			$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Country.' . $field_name . ' Like' => $value . '%'));
			}
		}
	     $this->paginate = array('order' => 'id desc','limit' => ADMIN_NUM_PER_PAGE);
		 $country = $this->paginate('Country', $conditions);	
		 $this->set('countries',$country);
	  }
	  
	   /**
	  * Purpose: function for country edit
	  * created on 23 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function country_edit($id=null){
              
                $local = CakeSession::read("Language");
                $local_list = configure::read('local');
                $this->loadModel('I18nModel');
                $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'Country')));

                        if ($local_data) {
                            $fields_data =configure::read('country');
                            $this->Country->bindTranslation($fields_data);
                        }
	  	$this->loadModel('Country');
                if($this->request->is('put'))
		{
                        $data = $this->request->data;
			$this->Country->id=$id;
                        $data['Country']['slug']=$this->hyphenize($data['Country']['name']);
                        $fields_data =configure::read('country');
                        $this->Country->bindTranslation($fields_data); 
                        $this->Country->save($data);
			$this->Session->setFlash('Country updated successfully');
                        $this->redirect(array('action'=>'country_edit',$id));
		}
                $this->data=$this->Country->find('first',array('conditions'=>array('Country.id'=>$id)));
		
		
	  }
	  
	  	 /**
	  * Purpose: this function is upload flag image
	  * created on 31 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload_flag(){
	  	       if(isset($this->params->form['flag_image'])){
	  	       	 $one= $this->params->form['flag_image'];
	    	     $name ='f_'.date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'country_flag' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				  $this->Resize = $this->Components->load('ImageResize');
				 //$this->Resize->resize( $path.$name, '46', '28', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/country_flag/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
			   if(isset($this->params->form['banner_image'])){
	  	       	 $one= $this->params->form['banner_image'];
	    	     $name ='f_'.date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'country_banner' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				  $this->Resize = $this->Components->load('ImageResize');
				  $this->Resize->resize( $path.$name, '870', '320', $path.$name);
		
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/country_banner/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
	  }

    /**
     * Purpose : FOR ADMIN manage delete logo
     * Created on : 13 august
     * Author : Abhishek TRipathi
     */
    function manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->Course->deleteAll(array('Course.id' => $ids), true);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->Course->updateAll(array('Course.featured' => "'Yes'"), array('Course.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->Course->updateAll(array('Course.featured' => "'No'"), array('Course.id' => $ids));
                    $message = 'Inactivated successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }
    
        /**
	  * Purpose: Add country
	  * created on 25 november 2014
	  * created by:Abhishek Tripathi
	  **/
                                
    public function add_country(){
        if($this->request->is('post'))
        {
             $this->request->data['Country']['slug']=$this->hyphenize($this->request->data['Country']['name']);
            if($this->Country->save($this->request->data)){
                $this->Session->setFlash(__('The Country saved successfully.'));
                $this->redirect(array('controller'=>'Destinations','action'=>'country_list'));
            }
            else{
                $this->Session->setFlash(__('Please try again'));
            }
        }
        $this->render('country_edit');
    }
}
