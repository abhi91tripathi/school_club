<?php
/**
 * Name : Facilities Controller
 * Created : 3 Apr 2014
 * Purpose : To manage the languages.
 * Author : Ritish
 */ 
class AccomodationFacilitiesController extends AdminAppController
{
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
	}
	
	/**
	 * Name : Index
	 * Purpose : For language listing
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function index($id=null)
                
                
	{
            
             
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->AccomodationFacility->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected facilities deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('AccomodationFacility.' . $field_name . ' Like' => $value . '%'));
			}
		}
		if($id)
		{
			$edit_lang = $this->Facility->find('first', array('conditions' => array('AccomodationFacility.id' => $id), 'fields' => array('id','title','icon')));
			$this->set('edit_lang',$edit_lang);
		}
		
		$this->paginate = array('order' => 'id desc','limit' => 10);
		$facilities = $this->paginate('AccomodationFacility', $conditions);
		$this->set('facilities',$facilities);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new Facility
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function add()
	{
                    $fields_data =configure::read('accommodation_facilities');
                    $this->AccomodationFacility->bindTranslation($fields_data);
		if($this->request->is('post'))
		{
			$data = $this->data;
                         $this->AccomodationFacility->bindTranslation($fields_data);
			if($this->AccomodationFacility->save($data))
			{
				$this->Session->setFlash('Facility saved successfully');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('The Facility could not be saved. Please, try again.'));
			}
		}
	}
	
	/**
	 * Name : Edit
	 * Purpose : To edit the Facility
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function edit($id = null)
	{
              $local = CakeSession::read("Language");
                $local_list = configure::read('local');
                $this->loadModel('I18nModel');
                $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'AccomodationFacility')));
           
                if ($local_data) {
                    
                    $fields_data =configure::read('accommodation_facilities');
                    $this->AccomodationFacility->bindTranslation($fields_data);
                    
                }
		$this->AccomodationFacility->id = $id;
		if($this->request->is('post'))
		{
			$this->add();
		}
       
		$edit_facility = $this->AccomodationFacility->find('first', array('conditions' => array('AccomodationFacility.id' => $id)));
                
             
		$this->set('edit_facility', $edit_facility);
		$this->render('add');
	}
}
