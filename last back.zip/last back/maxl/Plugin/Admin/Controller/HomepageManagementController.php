<?php

/**
 * Name : HomepageManagement Controller
 * Created : 2 Apr 2014
 * Purpose : To manage the home page content
 * Author : Ritish
 */
class HomepageManagementController extends AdminAppController {

    public $name = 'homepage_management';
    public $uses = array('Admin.HomepageBlockText', 'Admin.Testimonial', 'HomepageBanner');
    public $components = array('Uploader');

    public function beforeFilter() {
        //Set auth model Admin
        parent::beforeFilter();
        $this->Auth->authenticate = array(
            'Form' => array('userModel' => 'Admin')
        );
    }

    /**
     * Name : testimonial
     * Purpose : For Testimonial Listing
     * Created : 2 Apr 2014	
     * Author : Ritish
     */
    public function testimonial() {
        if (isset($this->request->data['option']) && !empty($this->request->data['option'])) {
            switch ($this->request->data['option']) {
                case "delete":
                    // TO unlink all of client images of deleted testimonials
                    $client_images_name = $this->Testimonial->find('list', array('conditions' => array('Testimonial.id' => $this->request->data['ids']), 'fields' => 'client_image'));
                    $path = ROOT . '/app/Plugin/Admin/webroot/img/homepage_block_images/';
                    foreach ($client_images_name as $images_name) {
                        unlink($path . $images_name);
                    }
                    // To delete records
                    $this->Testimonial->deleteAll(array('id' => $this->request->data['ids']));
                    $this->Session->setFlash(__('Selected testimonials deleted sucessfully'));
                    break;
                case "active":
                    $this->Testimonial->updateAll(array('status' => "'activate'"), array('id' => $this->request->data['ids']));
                    break;
                case "deactive":
                    $this->Testimonial->updateAll(array('status' => "'inactive'"), array('id' => $this->request->data['ids']));
                    break;
            }
            $this->redirect($this->referer());
        }

        $conditions = array();
        if (isset($_GET['filter'])) {
            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
                $conditions = array_merge($conditions, array('Testimonial.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array('order' => 'id asc', 'limit' => 10);
        $testimonials = $this->paginate('Testimonial', $conditions);
        $this->set('testimonials', $testimonials);
    }

    /**
     * Name : add_testimonial
     * Purpose : To add new testimonial
     * Created : 2 Apr 2014
     * Author : Ritish
     */
    public function add_testimonial() {
        if ($this->request->is('post')) {
            $fields_data = configure::read('testitmonial');
            $this->Testimonial->bindTranslation($fields_data);
            if ($this->Testimonial->save($this->data)) {
                $this->Session->setFlash('Testimonial saved successfully');
                $this->redirect(array('action' => 'testimonial'));
            } else {
                $this->Session->setFlash(__('The Testimonial could not be saved. Please, try again.'));
            }
        }
    }

    /**
     * Name : edit_testimonial
     * Purpose : To edit the testimonial
     * Created : 2 Apr 2014
     * Author : Ritish
     */
    public function edit_testimonial($id = Null) {
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'Testimonial')));
        if ($local_data) {
            $fields_data = configure::read('testitmonial');
            $this->Testimonial->bindTranslation($fields_data);
        }
        if ($this->request->is('post')) {
            $this->add_testimonial();
        }
        $edit_testimonial = $this->Testimonial->findById($id);
        $this->set('edit_testimonial', $edit_testimonial);
        $this->render('add_testimonial');
    }

    /**
     * Name : block_text
     * Purpose : block_text function for the listing of block text and images.
     * Created : 2 Apr 2014
     * Author : Ritish
     */
    public function block_text($id = null) {
        if (isset($this->request->data['option']) && !empty($this->request->data['option'])) {
            switch ($this->request->data['option']) {
                case "delete":
                    $this->HomepageBlockText->deleteAll(array('id' => $this->request->data['ids']));
                    $this->Session->setFlash(__('Selected blocks deleted sucessfully'));
                    break;
            }
        }
        if ($id) {
            $edit_block = $this->HomepageBlockText->findById($id);
            $this->set('edit_block', $edit_block);
        }
        $this->paginate = array('order' => 'id asc', 'limit' => 10);
        $block_content = $this->paginate('HomepageBlockText');
        $this->set('block_content', $block_content);
    }

    /*
     * Name: save_block
     * Purpose: To add new block through ajax.
     * Returns: it new row of block which will be append to block listing table
     * Created: 2 apr 2014
     * Author: Ritish
     */

    function save_block() {
        $fields_data = configure::read('home_page_block');
            $this->HomepageBlockText->bindTranslation($fields_data);
        if ($this->request->is('post')) {

            if ($this->HomepageBlockText->save($this->data)) {
                $block = $this->data;
                if (empty($block['HomepageBlockText']['id']))
                    $block['HomepageBlockText']['id'] = $this->HomepageBlockText->getLastInsertId();
                $this->set('block', $block);
                $this->Session->setFlash('Information saved successfully');
                $this->redirect(array('action' => 'block_text'));
            }
            else {
                $this->Session->setFlash(__('The Information could not be saved. Please, try again.'));
                $this->block_text(!empty($block['HomepageBlockText']['id']) ? $block['HomepageBlockText']['id'] : '');
                $this->render('block_text');
            }
        }
    }

    /*
     * Name: banner
     * Purpose: To change the banner image of home page
     * Created: 4 apr 2014
     * Author: Ritish
     */

    function banner($id = null) {

        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local],'I18nModel.model'=>'HomepageBanner')));
       
        if ($local_data) {
            $fields_data = configure::read('home_page_banner');
            $this->HomepageBanner->bindTranslation($fields_data);
        }
        if ($this->request->is('put')) {

            $data_arr = $this->request->data;
            $this->HomepageBanner->id = $id;
            $fields_data = configure::read('home_page_banner');
            $this->HomepageBanner->bindTranslation($fields_data);

            if ($this->HomepageBanner->save($data_arr)) {
                @unlink('admin/img/homepage_block_images/' . $banner['HomepageBanner']['image']);
                $this->Session->setFlash('Banner savd successfully');
                $this->redirect($this->referer());
            } else {
                $this->Session->setFlash(__('The banner could not be saved. Please, try again.'));
            }
        }
        $banner = $this->HomepageBanner->find('first');
        $this->set('banner', $banner);
        $this->data = $banner;
    }

    /**
     * Purpose:add affliate logo for bottom slider
     * created:11/08/2014
     * Author:Abhishek Tripathi
     */
    public function add_logo() {
        $this->loadModel('AffiliationLogo');
        if ($this->request->is('post')) {
            //debug($this->request->data);exit;
            if ($this->AffiliationLogo->save($this->request->data)) {
                $this->Session->setFlash('Logo savd successfully');
                $this->redirect(array('action' => 'logo_list'));
            } else {
                $this->Session->setFlash('Please try again');
                //$this->redirect($this->referer());
            }
        }
    }

    /**
     * Purpose:affliate logo list for bottom slider
     * created:11/08/2014
     * Author:Abhishek Tripathi
     */
    public function logo_list() {
        $this->loadModel('AffiliationLogo');
        $logo = $this->paginate('AffiliationLogo');

        $view_title = "Logo list";
        $this->set(compact('logo', 'view_title'));
    }

    /**
     * Purpose: this function is upload banner image and flag image
     * created on 21 july 2014
     * created by:Abhishek Tripathi
     * */
    public function upload() {
        //debug($this->params);exit;
        $one = $this->params->form['flag_image'];
        $name = date('ydmhis');
        $path = 'files' . DS . 'affiliation_logo' . DS;
        $thumbnails = Thumbnail::logo_image();
        $params = array('size' => REVIEW_MAX_IMAGE_SIZE);

        $image_new_name = 'color_' . date('ydmhis');
        $this->Uploader->upload($one, $path . DS, $thumbnails, $image_new_name, $params);

        $extention = pathinfo($one['name'], PATHINFO_EXTENSION);
        switch (strtolower($extention)) {
            case 'gif': $image = imagecreatefromgif($path . 'REVcolor_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                imagegif($image, $path . 'REVgray_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                break;
            case 'jpg': $image = imagecreatefromjpeg($path . 'REVcolor_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                imagejpeg($image, $path . 'REVgray_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                break;
            case 'jpg': $image = imagecreatefromjpeg($path . 'REVcolor_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                imagejpeg($image, $path . 'REVgray_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                break;
            case 'jpeg': $image = imagecreatefromjpeg($path . 'REVcolor_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                imagejpeg($image, $path . 'REVgray_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                break;
            case 'png': $image = imagecreatefrompng($path . 'REVcolor_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                imagepng($image, $path . 'REVgray_' . $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
                break;
        }

        $response['image_name'] = $name . '.' . strtolower(pathinfo($one['name'], PATHINFO_EXTENSION));
        $response['path'] = FULL_BASE_URL . $this->webroot . 'files/affiliation_logo/' . 'color_' . $response['image_name'];
        echo json_encode($response);
        exit;
    }

    public function resize($imagePath, $new_height, $new_width) {
        if (file_exists($imagePath)) {
            $imageInfo = getimagesize($imagePath);
            $old_x = $imageInfo[0];
            $old_y = $imageInfo[1];
            if ($old_x > $old_y) {
                $thumb_w = $new_width;
                $thumb_h = $old_y * ($new_height / $old_x);
            }
            if ($old_x < $old_y) {
                $thumb_w = $old_x * ($new_width / $old_y);
                $thumb_h = $new_height;
            }
            if ($old_x == $old_y) {
                $thumb_w = $new_width;
                $thumb_h = $new_height;
            }
            $mimeType = $imageInfo['mime'];
            $destination = imagecreatetruecolor($thumb_w, $thumb_h);
            if ($mimeType == 'image/jpeg' || $mimeType == 'image/pjpeg') {
                $source = imagecreatefromjpeg($imagePath);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);
                imagejpeg($destination, $imagePath);
            } else if ($mimeType == 'image/gif') {
                $source = imagecreatefromgif($imagePath);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);
                imagegif($destination, $imagePath);
            } else if ($mimeType == 'image/png' || $mimeType == 'image/x-png') {
                $source = imagecreatefrompng($imagePath);
                imagecopyresampled($destination, $source, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);
                imagepng($destination, $imagePath);
            } else {
                $this->_error('This image type is not supported.');
            }
            imagedestroy($source);
            imagedestroy($destination);
        } else {
            $this->_error('The requested file does not exist.');
        }
    }

    /**
     * Purpose: this function is use for admin delete logo
     * created on 14 august 2014
     * created by:Abhishek Tripathi
     * */
    public function delete_logo($id = null) {
        $this->loadModel('AffiliationLogo');
        $this->AffiliationLogo->id = $id;
        if ($this->AffiliationLogo->delete()) {
            $this->Session->setFlash('Logo deleted successfully');
            $this->redirect(array('action' => 'logo_list'));
        } else {
            $this->Session->setFlash('Please try again');
            $this->redirect(array('action' => 'logo_list'));
        }
    }

    /**
     * Purpose: this function is use for  bottom text
     * created on 27 august 2014
     * created by:Abhishek Tripathi
     * */
    public function bottom_text() {
        $this->loadModel('HomepageBottomText');
        $bottom_text = $this->paginate('HomepageBottomText');
        $view_title = 'Bottom Block text';
        $this->set(compact('bottom_text', 'view_title'));
    }

    /**
     * Purpose: this function is use for admin edit bottom text
     * created on 27 august 2014
     * created by:Abhishek Tripathi
     * */
    public function edit_bottom_text($id = null) {
        $this->loadModel('HomepageBottomText');
         $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'HomepageBottomText')));
    
        if ($local_data) {
            $fields_data = configure::read('home_page_bottom_text');
            $this->HomepageBottomText->bindTranslation($fields_data);
        }
        
        if ($this->request->is('put')) {
            $this->HomepageBottomText->id = $id;
             $fields_data = configure::read('home_page_bottom_text');
            $this->HomepageBottomText->bindTranslation($fields_data);
            
            if ($this->HomepageBottomText->save($this->request->data)) {
                $this->Session->setFlash('Text edit successfully');
                $this->redirect(array('action' => 'bottom_text'));
            } else {
                $this->Session->setFlash('Please try again');
            }
        }
        $this->data = $this->HomepageBottomText->findById($id);
    }

    /**
     * Purpose: this function is use for admin edit bottom text
     * created on 2 september 2014
     * created by:Abhishek Tripathi
     * */
    public function edit_block($id = null) {
        //in case of edit
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        $this->loadModel('I18nModel');
        $local_data = $this->I18nModel->find('first', array('conditions' => array('I18nModel.locale' => $local_list[$local], 'I18nModel.foreign_key' => $id,'I18nModel.model'=>'HomepageBlockText')));
        if ($local_data) {
            $fields_data = configure::read('home_page_block');
            $this->HomepageBlockText->bindTranslation($fields_data);
        }
        
        if (isset($this->request->data['option']) && !empty($this->request->data['option'])) {
            switch ($this->request->data['option']) {
                case "delete":
                    $this->HomepageBlockText->deleteAll(array('id' => $this->request->data['ids']));
                    $this->Session->setFlash(__('Selected blocks deleted sucessfully'));
                    $this->redirect(array('action' => 'block_text'));
                    break;
            }
        }
        if ($id) {
            $edit_block = $this->HomepageBlockText->findById($id);
            //debug($edit_block);exit;
            $this->set('edit_block', $edit_block);
        }
    }

}
