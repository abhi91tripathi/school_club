//Purpose:Ajax form submission
//created on:28/05/14
//Author:Abhishek Tripathi

var form_list=["accreditation_info","school_presentation_info","ousr_team_info","facility_info",'location_info','student_profile_info','first_day_info','activities_info','additional_info','course_info','exam_info','accommodation_info','visa_basic_info','term_info','invoice_info','payment_info','visa_info','regional_pricing_info','enrollment_info','bank_info','commission_info','landing_area','seo_info'];


var form_list_school=["accreditation_info","school_presentation_info","ousr_team_info","facility_info",'location_info','student_profile_info','first_day_info','activities_info','additional_info','course_info','exam_info','accommodation_info','visa_basic_info','term_info','enrollment_info','invoice_info','bank_info','payment_info','visa_info','regional_pricing_info'];

var form_list_pre=["accreditation_info","school_presentation_info","facility_info",'location_info','activities_info','student_profile_info','exam_info','visa_basic_info','landing_area','enrollment_info','invoice_info','seo_info'];

$(document).ready(function(){
    date();
   // form_submit();
    //varriable for price plan action
      $('.go_top').on('click',function(){
          $("html, body").animate({ scrollTop: 0 }, "100000");
    })
   
    
    
     //   Purpose:on click event when click in save button in shool add form
    //    created on:09/06/14
    //    Author:Abhishek tripathi
    
    $('.trigger_save').on('click',function(){
       
          //form_submit(0);
          $('#general_info').submit();

    });
    
     $('.trigger_save_school').on('click',function(){
      var counter=0;
    School_form_submit(counter);
 
    });
    
    
       //   Purpose:on click event when click in save button in shool premium listing  add form
    //    created on:09/06/14
    //    Author:Abhishek tripathi
    $('.trigger_save_pre').on('click',function(){
        
        $('#general_info_pre').submit();
        

    });
    
    //    Purpose:click on basic course detail on school add form radio button
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    
    $('.book_material').on('click',function(){
        if($(this).val()==3){
            $(this).parent().find('#book_material_specify').hide().val('');
            $('#bookmaterial').show();
        }
        else{
            if($(this).val()==4){
              $(this).parent().find('#bookmaterial').hide().val(''); 
              $('#book_material_specify').show();
            }
            else{
                $('#book_material_specify').hide().val('');
                 $('#bookmaterial').hide().val('');
            }
           
        }
    })
    
    //    Purpose:click on course staring date for beginnners radio button
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    
    $('.course_starting_beginer').on('click',function(){
        if($(this).val()!=4){
            $(this).parent().find('#course_starting_date_beginers_div').hide().val('');
            $(this).parent().find('#course_starting_date_beginers').hide().val('');
        }
        else{
            //$(this).parent().find('#course_starting_date_beginers').show();
               $(this).parent().find('#course_starting_date_beginers_div').show();
             $('#course_starting_date_beginers_div').multiDatesPicker({
                                 altField: '#course_starting_date_beginers',
                                 dateFormat: "dd-mm-yy",
                                 
                        });
         
        }
    })
    //    Purpose:click event on course starting date radio button
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    
    $('.course_starting').on('click',function(){
        if($(this).val()!=4){
           // $(this).parent().find('#course_starting_date').hide().val('');
             $(this).parent().find('#course_starting_date_div').hide().val('');
           
        }
        else{
            $(this).parent().find('#course_starting_date_div').show();
             $('#course_starting_date_div').multiDatesPicker({
                                 altField: '#course_starting_date',
                                 dateFormat: "dd-mm-yy",
                                 
                        });
        }
    })
    
    //    Purpose:click on course available radio button
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    
    $('.course_avail').on('click',function(){
    	
    	
     
        if($(this).val()==1){
        	
            $(this).parent().find('.courese_avail_range_box').hide();
            $(this).parent().find('.courese_avail_range_box').find('input').val('');
            
        }
        else{
            $(this).parent().find('.courese_avail_range_box').show();
            $('#max_week').val(51);

        }
    })
   
    //    Purpose:click event on lesson schedule radio button
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    
    $('.lesson_schedule_btn').on('click',function(){
        if($(this).val()==1){
            $(this).next().find('#morning_range').show();
            $('#afternoon_range').hide();
            $('#afternoon_range').find('input').val('');
            $(this).parent().find('textarea').hide();
            $(this).parent().find('textarea').val('');
        }
        else{
            if($(this).val()==2){
                $(this).next().find('#afternoon_range').show();
                $('#morning_range').hide();
                $('#morning_range').find('input').val('');
                $(this).parent().find('textarea').hide();
                $(this).parent().find('textarea').val('');
            }
            else{
                $(this).parent().find('textarea').show();
                $('#morning_range').hide();
                $('#morning_range').find('input').val('');
                $('#afternoon_range').hide();
                $('#afternoon_range').find('input').val('');
            }
        }
    })
    
    //Purpose:click event onclick on discount radion button
    //created on:17 june 2014
    //Author:Abhishek Tripathi
    $('.discount_selection').on('click',function(){
        var value=$(this).val();
        
        switch(value){
            case '1':
                $('.discount_percent').show();
                $('.discount_price').hide().val('');
                $('.discount_weekly').hide().val('');
                break;
            case '2':
                 $('.discount_percent').hide().val('');
                $('.discount_price').show();
                $('.discount_weekly').hide().val('');
                break;
            case '3':
                 $('.discount_percent').hide().val('');
                $('.discount_price').hide().val('');
                $('.discount_weekly').show();
                break;
                
        }
    })

   
    
    
    
    $('.lesson_schedule_btn').on('click',function(){
        if($(this).val()==1){
            $(this).next().find('#morning_range').show();
            $('#afternoon_range').hide();
            $('#afternoon_range').find('input').val('');
        }
        else{
            if($(this).val()==2){
                $(this).next().find('#afternoon_range').show();
                $('#morning_range').hide();
                $('#morning_range').find('input').val('');
            }
        }
    })
   
  
   

    
    $('#general_info').validate(
    {
        submitHandler: function(form){
        	  tinyMCE.triggerSave();
            $('#general_info').ajaxSubmit({
                success: function(d) {
                    var data=JSON.parse(d);
                    $('.hidden_frm').show();
                    $('.institute_id').val(data.id);
                    $('.load_image').attr('data-url',JS_SITE_URL+'admin/institute/upload_images/'+data.id);
                    $('#general_info').find('.msg_box').show();
                    $('#general_info').find('.msg_box').html('Successfully saved');
                    $('.cuurency_symbol').html(data.currency_symbol);
                    
                    form_submit(0);
                    setTimeout(function(){
                        $('#general_info').find('.msg_box').fadeOut('1000')
                    }, 2000);
               
                }
            });
        }

    });
    
//    pupose:for ajax form sumission on admin school premium add form
//    created on:9 june 2014,
//    Author: Abhishek Tripathi


 $('#general_info_pre').validate(
    {
        submitHandler: function(form){
        	  tinyMCE.triggerSave();
            $('#general_info_pre').ajaxSubmit({
                success: function(d) {
                    var data=JSON.parse(d);
                    $('.hidden_frm').show();
                    $('.institute_id').val(data.id);
                    $('.load_image').attr('data-url',JS_SITE_URL+'admin/institute/upload_images/'+data.id);
                    $('#general_info_pre').find('.msg_box').show();
                    $('#general_info_pre').find('.msg_box').html('Successfully saved');
                    $('.cuurency_symbol').html(data.currency_symbol);
                    
                    form_submit_pre(0);
                    setTimeout(function(){
                        $('#general_info_pre').find('.msg_box').fadeOut('1000')
                    }, 2000);
               
                }
            });
        }

    });
   //purpose:on click on add closing date
    //created on:11 june 2014
    //Author:Abhishek Tripathi
    var count=0;
    $('.add_event_btn').on('click',function(){
        
        var x='';
        x+='<tr><td><label>Date</lable></td>';
        x+='<td><select name="data[Institute][event]['+count+'][title]" ><option value="0">Please choose</option><option value="1">Bank holiday</option><option value="2">School closure</option></select>'
        x+=' <input type="text" name="data[Institute][event]['+count+'][date]" class="datepicker" />&nbsp;<input type="button" class="'+count+'_remove_date" onClick="javascript:remove_date_js('+count+')"  value="Delete"></td>';
    
        x+='</tr>'
        $('#second').append(x);
        date();
        $('.ui-datepicker-trigger').show();
        count++;
    });
    
    
    //purpose:on click special price offer checkbox event
    //created on:11 june 2014
    //Author:Abhishek Tripathi
    
    $('.special_price').on('click',function(){
       if($(this).val()==1){
           $('#offered_countries').show();
       } 
       else{
           $('#offered_countries').hide();
           $('.offer_input').find('input').val('');
       }
    });
      //purpose:on click on price selection radio button
    //created on:16 june 2014
    //Author:Abhishek Tripathi
   $('.price_selection').on('click',function(){
	   if($(this).val()==1){
		   $('.new_price').hide();
		   $('.price_editor_allyear').hide();
		   $('.price_editor_heigh_low').hide();
		   }
		else{
			$('.new_price').show();
		  
			}   
	   }); 
    
    //purpose:click on add course button
    //created on:4 july 2014
    //Author:Abhishek Tripathi   
   $('#event_date').focus();
   
   
    //purpose:click on listing button
    //created on:6 april 2014
    //Author:Abhishek Tripathi 
   $('.listing_btn').on('click',function(){
      
      if($(this).is(':checked')){
       $.post(JS_SITE_URL+'admin/Institute/listing_type',{id:$(this).parent().find('.institute_id').val(),value:$(this).val()},function(d){
		location.reload();
	});
      } 
   });
});




$(function () {
    $('#logo_upload').fileupload({
        formdata:{
            'dfsdf':'sdfsdf'
        },
        dataType: 'json',
        success:function(d){
           
            $('#logo_image').attr('src',d.path);
            $('#logo_image').show();
            
            $('#logo_name_form').val(d.image_name);
        }
    });
    $('#upload_land_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#main_img_image').attr('src',d.path);
            $('#main_img_image').show();
            
            $('#main_img_name').val(d.image_name);
            
        }
    });
    $('#upload_brand_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#brand_image').attr('src',d.path);
            $('#brand_image').show();
            
            $('#brand_image_name').val(d.image_name);
            
        }
    });
    $('#upload_embassy_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#embassy_img_image').attr('src',d.path);
            $('#embassy_img_image').show();
            
            $('#embassy_image_name').val(d.image_name);
            
        }
    });
    $('#upload_our_team_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#our_team_image').attr('src',d.path);
            $('#our_team_image').show();
            
            $('#our_team_name').val(d.image_name);
            
        }
    });
    $('#first_day_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#first_day_img_image').attr('src',d.path);
            $('#first_day_img_image').show();
            
            $('#first_day_image_name').val(d.image_name);
            
        }
    });
    $('#upload_activities_social_image').fileupload({
        dataType: 'json',
        success:function(d){
            $('#activities_social_image').attr('src',d.path);
            $('#activities_social_image').show();
            
            $('#activities_social_image_name').val(d.image_name);
            
        }
    });
     $('#accredation_upload').fileupload({
        dataType: 'json',
        success:function(d){
           
            
            $('#acceradation_image').attr('src',JS_SITE_URL+d.path);
            $('#acceradation_image').show();
            
            $('#acceradation_image_name').val(d.image_name);
            
        }
    });
     $('#thumbnail_upload').fileupload({
        dataType: 'json',
        success:function(d){
           
            
            $('#thumbnail_image').attr('src',d.path);
            $('#thumbnail_image').show();
            
            $('#thumbnail_name_form').val(d.image_name);
            
        }
    });
});
function date(){
    $(function() {
        $( ".datepicker" ).datepicker({
            showOn: "button",
             dateFormat: "dd-mm-yy",
            buttonImage: JS_SITE_URL+"admin/images/calendar.gif",
            buttonImageOnly:true
        });
    });  
}
$(function() {
    $( "#start_premium" ).datepicker({
        
        changeMonth: true,
         dateFormat: "dd-mm-yy",
        numberOfMonths: 1,
        minDate: '0',
        onClose: function( selectedDate ) {
         
            $( "#expiry_date" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#expiry_date" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
         dateFormat: "dd-mm-yy",
        numberOfMonths: 1,
        onClose: function( selectedDate ) {
            $( "#start_premium" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
    
    
    
    $( "#season_range_from" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
         dateFormat: "dd-mm-yy",
        numberOfMonths: 1,
        onClose: function( selectedDate ) {
            $( "#season_range_to" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#season_range_to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
         dateFormat: "dd-mm-yy",
        numberOfMonths: 1,
        onClose: function( selectedDate ) {
            $( "#season_range_from" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
    $( "#course_avail_from" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        dateFormat: "dd-mm-yy",
        numberOfMonths: 1,
        onClose: function( selectedDate ) {
            $( "#course_avial_to" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#course_avial_to" ).datepicker({
        defaultDate: "+1w",
        dateFormat: "dd-mm-yy",
        changeMonth: true,
        numberOfMonths: 1,
        onClose: function( selectedDate ) {
            $( "#course_avail_from" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
    $( "#discount_valid_to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
       dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#discount_valid_from" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#discount_valid_from" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
         dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#discount_valid_to" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
    $( "#discount_valid_course_from" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
         dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#discount_valid_course_to" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#discount_valid_course_to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
         dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#discount_valid_course_from" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
       $( "#accommodation_season_range_from" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
         dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#accommodation_season_range_to" ).datepicker( "option", "minDate", selectedDate );
        }
    });
    $( "#accommodation_season_range_to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
         dateFormat: "dd-mm-yy",
        onClose: function( selectedDate ) {
            $( "#accommodation_season_range_from" ).datepicker( "option", "maxDate", selectedDate );
        }
    });
    $(function() {
        $( "#course_starting_date" ).datepicker({
				createButton:false,
				displayClose:true,
				closeOnSelect:false,
				selectMultiple:true
			}
		)
		.bind(
			'click',
			function()
			{
				$(this).dpDisplay();
				this.blur();
				return false;
			}
		)
		.bind(
			'dateSelected',
			function(e, selectedDate, $td, state)
			{
				console.log('You ' + (state ? '' : 'un') // wrap
					+ 'selected ' + selectedDate);
				
			}
		)
		.bind(
			'dpClosed',
			function(e, selectedDates)
			{
				console.log('You closed the date picker and the ' // wrap
					+ 'currently selected dates are:');
				console.log(selectedDates);
			});
    }); 
});

$(function(){      
    $('#morning_range .time').timepicker({
        'showDuration': true,
        'step':15,  
        'timeFormat': 'g:i a'
    });

    $('#afternoon_range .time').timepicker({
        'showDuration': true,
        'step':15,  
        'timeFormat': 'g:i a'
    });

 


})

//    pupose:for ajax form sumission on admin school add form
//    created on:9 june 2014,
//    Author: Abhishek Tripathi
function form_submit(i){
   var reuse=i;
    //for(var i=0;i<form_list.length;i++){
      var form_id='#'+form_list[i];
        $(form_id).validate(
    {
        submitHandler: function(form){
            tinyMCE.triggerSave();
            $(form_id).ajaxSubmit({
                success: function(d) {
                    var data=JSON.parse(d);
                    $(form_id).find('.msg_box').show();
                    $(form_id).find('.msg_box').html('Successfully saved');
                    i=reuse;
                    i++;
                    console.log(form_list[i])
                    form_submit(i);
                    setTimeout(function(){
                        $(form_id).find('.msg_box').fadeOut('1000')
                    }, 2000); 
                }
            });
       }

    });
    $(form_id).submit();

}


   //purpose:function for remove closing date
    //created on:23 july 2014
    //Author:Abhishek Tripathi

function remove_date(id){
	
	$('.'+id+'_remove_date').parent().parent().remove();
	$.post(JS_SITE_URL+'admin/Institute/remove_event',{id:id},function(d){
		
	});
}
function remove_date_js(id){
	
	$('.'+id+'_remove_date').parent().parent().remove();
	
}

 //purpose:function for save all form
    //created on:1 August 2014
    //Author:Abhishek Tripathi
function trigger_all_form(){
	
	var form_list=["accreditation_info","recognation_info"];
	
}

//    pupose:for ajax form sumission on school add form
//    created on:9 june 2014,
//    Author: Abhishek Tripathi
function School_form_submit(counter,section,id){
      
     var reuse=counter;
    //for(var i=0;i<form_list.length;i++){
      var form_id='#'+form_list_school[counter];
      
        $(form_id).validate(
    {
    	 submitHandler: function(form){
        	
            tinyMCE.triggerSave();
            $(form_id).ajaxSubmit({
            	
                success: function(d) {
                	
                    var data=JSON.parse(d);
                    $(form_id).find('.msg_box').show();
                    $(form_id).find('.msg_box').html('Successfully saved');
                  
                     counter=reuse;
                     counter++;
                     if(counter>20){
                   switch(section){
                    		case 'Course':
                    		$('.'+section+'_loader').hide();
                    		document.location =JS_SITE_URL+ 'Courses/add_sub_course/'+id;
                    		break;
                    		case 'Accommodation':
                    		$('.'+section+'_loader').hide();
                    		document.location =JS_SITE_URL+ 'accomodation/add_sub_accomodation/'+id;
                    		break;
                    		case 'Extra_fee':
                    		$('.'+section+'_loader').hide();
                    		document.location =JS_SITE_URL+ 'Schools/add_extra_fee/'+id;
                    		break;
                    	}
                    	}
   
                    console.log(form_list_school[counter])
                    School_form_submit(counter,section,id);
                    setTimeout(function(){
                        $(form_id).find('.msg_box').fadeOut('1000')
                    }, 2000); 
                }
            });
       }

    });
    $(form_id).submit();

}

//    pupose:for ajax form sumission on admin school premium add form
//    created on:9 june 2014,
//    Author: Abhishek Tripathi
function form_submit_pre(i){
   var reuse=i;
    //for(var i=0;i<form_list.length;i++){
      var form_id='#'+form_list_pre[i];
        $(form_id).validate(
    {
        submitHandler: function(form){
            tinyMCE.triggerSave();
            $(form_id).ajaxSubmit({
                success: function(d) {
                    var data=JSON.parse(d);
                    $(form_id).find('.msg_box').show();
                    $(form_id).find('.msg_box').html('Successfully saved');
                    i=reuse;
                    i++;
                    console.log(form_list_pre[i])
                    form_submit_pre(i);
                    setTimeout(function(){
                        $(form_id).find('.msg_box').fadeOut('1000')
                    }, 2000); 
                }
            });
       }

    });
    $(form_id).submit();

}



  
