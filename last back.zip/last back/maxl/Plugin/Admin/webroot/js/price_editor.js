//Purpose:price editor
//created on:28/05/14
//Author:Abhishek Tripathi

$(document).ready(function(){
	
	  $('#last_get_chart_high').on('click',function(){
        var high_to=$('#last_high_to').val();
        var high_from=$('#last_high_from').val();
        var price=$('#last_high_price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log($('#price_season').val());
       
        if($('#last_price_season').val()==1)
        {
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#last_week_sch_high_'+count).find('.last_price_val').html(price);
                $('#last_week_sch_high_'+count).find('input').val(price);
                count++;
            }
        }
        else{
            for(var i=1;i<=range_diff;i++)
            {
                $('#last_week_sch_low_'+count).find('.last_price_val').html(price);
                $('#last_week_sch_low_'+count).find('input').val(price);
                count++;
            }  
        }
    
   
    
    });
    
      $('#next_get_chart_high').on('click',function(){
        var high_to=$('#next_high_to').val();
        var high_from=$('#next_high_from').val();
        var price=$('#next_high_price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log($('#price_season').val());
       
        if($('#next_price_season').val()==1)
        {
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#next_week_sch_high_'+count).find('.next_price_val').html(price);
                $('#next_week_sch_high_'+count).find('input').val(price);
                count++;
            }
        }
        else{
            for(var i=1;i<=range_diff;i++)
            {
                $('#next_week_sch_low_'+count).find('.next_price_val').html(price);
                $('#next_week_sch_low_'+count).find('input').val(price);
                count++;
            }  
        }
    
   
    
    });
    
    
    
     $('#get_chart_high').on('click',function(){
        var high_to=$('#high_to').val();
        var high_from=$('#high_from').val();
        var price=$('#high_price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log($('#price_season').val());
       
        if($('#price_season').val()==1)
        {
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#week_sch_high_'+count).find('.price_val').html(price);
                $('#week_sch_high_'+count).find('input').val(price);
                count++;
            }
        }
        else{
            for(var i=1;i<=range_diff;i++)
            {
                $('#week_sch_low_'+count).find('.price_val').html(price);
                $('#week_sch_low_'+count).find('input').val(price);
                count++;
            }  
        }
    
    
    
  
    
    });
     //    Purpose:price plan seclection
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    $('.price_plan').on('click',function(){
       
        var action=$(this).val();
        console.log(action);
        switch(action)
        {
            case '1':
                $('.price_editor_heigh_low').hide();
                $('.price_editor_allyear').show();
                $('#min_week').val('1');
                $('#max_week').val('52');
                $('#high_to').val('');
                $('#high_from').val('');
                $('.price').val('');
                $('.list').remove();
               get_chart();
                break;
            case '2':
                $('.price_editor_heigh_low').show();
                $('.price_editor_allyear').hide();
                $('#min_week').val('1');
                $('#max_week').val('52');
                $('#high_to').val('');
                $('#high_from').val('');
                $('.price').val('');
                $('.list').remove();
                get_chart();
                break;
               
        }
    });
    
    //  Purpose:price plan seclection last year
    //  created on:06/06/14
    //  Author:Abhishek tripathi
    $('.last_price_plan').on('click',function(){
       
        var action=$(this).val();

        switch(action)
        {
            case '1':
                $('.last_price_editor_heigh_low').hide();
                $('.last_price_editor_allyear').show();
                $('#last_min_week').val('1');
                $('#last_max_week').val('52');
                $('#last_high_to').val('');
                $('#last_high_from').val('');
                $('.last_price').val('');
                $('.last_list').remove();
               get_chart_lastyear();
                break;
            case '2':
                $('.last_price_editor_heigh_low').show();
                $('.last_price_editor_allyear').hide();
                $('#last_min_week').val('1');
                $('#last_max_week').val('52');
                $('#last_high_to').val('');
                $('#last_high_from').val('');
                $('.last_price').val('');
                $('.last_list').remove();
                get_chart_last();
                break;
               
        }
    });
    
          //    Purpose:price plan seclection last year
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    $('.next_price_plan').on('click',function(){
       
        var action=$(this).val();

        switch(action)
        {
            case '1':
                $('.next_price_editor_heigh_low').hide();
                $('.next_price_editor_allyear').show();
                $('#next_min_week').val('1');
                $('#next_max_week').val('52');
                $('#next_high_to').val('');
                $('#next_high_from').val('');
                $('.next_price').val('');
                $('.next_list').remove();
                get_chart_nextyear();
                
               
                break;
            case '2':
                $('.next_price_editor_heigh_low').show();
                $('.next_price_editor_allyear').hide();
                $('#next_min_week').val('1');
                $('#next_max_week').val('52');
                $('#next_high_to').val('');
                $('#next_high_from').val('');
                $('.next_price').val('');
                $('.next_list').remove();
                get_chart_nextyear();
                break;
               
        }
    });
    //    Purpose:price edition on chart for all year
    //    created on:06/06/14
    //    Author:Abhishek tripathi
   
    $('.get_chart').on('click',function(){
        

        var high_to=$('#high_to_all').val();
        var high_from=$('#high_from_all').val();
        var price=$(this).parent().find('.price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log(range_diff);
       
     
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#week_all_year_'+count).find('.price_val').html(price);
                $('#week_all_year_'+count).find('input').val(price);
                count++;
            }
      
       
    })
    
     //    Purpose:price edition on chart for all year for last year
    //    created on:06/06/14
    //    Author:Abhishek tripathi
   
    $('.last_get_chart').on('click',function(){
  
               var high_to=$('#high_to_all').val();
        var high_from=$('#high_from_all').val();
        var price=$(this).parent().find('.price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log(range_diff);
       
     
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#week_all_year_'+count).find('.price_val').html(price);
                $('#week_all_year_'+count).find('input').val(price);
                count++;
            }
      

    })
    
         //    Purpose:price edition on chart for all year for last year
    //    created on:06/06/14
    //    Author:Abhishek tripathi
   
    $('.next_get_chart').on('click',function(){
    
//        var price=$(this).parent().find('.next_price').val();
//        $('.next_chart_all_year').find('.next_price_val').html(price);
//        $('.next_chart_all_year').find('input').val(price);
        
        
                 var high_to=$('#next_high_to_all').val();
        var high_from=$('#next_high_from_all').val();
        var price=$(this).parent().find('.next_price').val();
        var range_diff=high_from-high_to;
        var count=high_to;
        range_diff++;
        //console.log(high_to+':'+high_from+':'+range_diff);
        console.log(range_diff);
       
     
      
            for(var i=1;i<=range_diff;i++)
            {
                $('#next_week_all_year_'+count).find('.next_price_val').html(price);
                $('#next_week_all_year_'+count).find('input').val(price);
                count++;
            }
      
    })
  
    //    Purpose:price edition on chart for high & low
    //    created on:06/06/14
    //    Author:Abhishek tripathi
	
	})



//    pupose:for creat chart on select max/min week
//    created on:6 june 2014,
//    Author: Abhishek Tripathi

function get_chart(){
  
    var min_week=$('#min_week').val();
   
    var max_week=$('#max_week').val();
    var dif=max_week-min_week;
     dif++;
     console.log(dif);
    var count=min_week;
    {
        $('.list').remove();
        
       
        if($('#CourseTypeCurrentYearPlan1:checked').length > 0){
            for(var i=1;i<=dif;i++)
            {
                
                //alert('safdsf');
                $('.chart_all_year').append('<div class="list" id="week_all_year_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="price_val">---</span><input class="price_all_year" type="hidden" name=data[CourseType][current_year][price_chart][all_year_chart]['+count+']></div>');
           
                count++;
            }  
            
            $.post(JS_SITE_URL+'admin/Course/get_limit',{max:max_week,min:min_week},function(d){
				
				$('#high_to_all').html(d);
				$('#high_from_all').html(d);
				})
        }
        else{
     
            for(var i=1;i<=dif;i++)
            {
                
                //alert('safdsf');
                $('.chart_low_high').append('<div class="list" id="week_sch_high_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="price_val">---</span><input type="hidden" name=data[CourseType][current_year][price_chart][high_chart]['+count+']></div>');
                $('.chart_high_low').append('<div class="list" id="week_sch_low_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="price_val">---</span><input type="hidden" name=data[CourseType][current_year][price_chart][low_chart]['+count+']></div>');
                count++;
            }
             $.post(JS_SITE_URL+'admin/Course/get_limit',{max:max_week,min:min_week},function(d){
				
				$('#high_to').html(d);
				$('#high_from').html(d);
				})
        }
        
    }
}


//    pupose:for creat chart on select max/min week for last year
//    created on:6 june 2014,
//    Author: Abhishek Tripathi

function get_chart_lastyear(){
  
    var min_week=$('#last_min_week').val();
    var max_week=$('#last_max_week').val(51);
    var dif=max_week-min_week;
    var count=min_week;
       dif++;
   
    {
        $('.last_list').remove();
        
       
        if($('#CourseTypeLastYearPlan1:checked').length > 0){
            
            for(var i=1;i<=dif;i++)
            {
                
               
                $('.last_chart_all_year').append('<div class="last_list" id="last_week_all_year_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="last_price_val">---</span><input class="last_price_all_year" type="hidden" name=data[CourseType][last_year][price_chart][all_year_chart]['+count+']></div>');
           
                count++;
            }  
        }
        else{
     
            for(var i=1;i<=dif;i++)
            {
                
                //alert('safdsf');
                $('.last_chart_low_high').append('<div class="last_list" id="last_week_sch_high_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="last_price_val">---</span><input type="hidden" name=data[CourseType][last_year][price_chart][high_chart]['+count+']></div>');
                $('.last_chart_high_low').append('<div class="last_list" id="last_week_sch_low_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="last_price_val">---</span><input type="hidden" name=data[CourseType][last_year][price_chart][low_chart]['+count+']></div>');
                count++;
            }
        }
        
    }
}
//    pupose:for create chart on select max/min week for last year
//    created on:6 june 2014,
//    Author: Abhishek Tripathi

function get_chart_nextyear(){
  
    var min_week=$('#next_min_week').val();
    var max_week=$('#next_max_week').val();
    var dif=max_week-min_week;
    var count=min_week;
    
   dif++;
    {
        $('.next_list').remove();
        
       
        if($('#CourseTypeNextYearPlan1:checked').length > 0){
            
            for(var i=1;i<=dif;i++)
            {
                
               
                $('.next_chart_all_year').append('<div class="next_list" id="next_week_all_year_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="next_price_val">---</span><input class="next_price_all_year" type="hidden" name=data[CourseType][next_year][price_chart][all_year_chart]['+count+']></div>');
           
                count++;
            }  
            $.post(JS_SITE_URL+'admin/Course/get_limit',{max:max_week,min:min_week},function(d){
				
				$('#next_high_to_all').html(d);
				$('#next_high_from_all').html(d);
				})
        }
        else{
     
            for(var i=1;i<=dif;i++)
            {
                
                //alert('safdsf');
                $('.next_chart_low_high').append('<div class="next_list" id="next_week_sch_high_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="next_price_val">---</span><input type="hidden" name=data[CourseType][next_year][price_chart][high_chart]['+count+']></div>');
                $('.next_chart_high_low').append('<div class="next_list" id="next_week_sch_low_'+count+'"><span>week '+count+'&nbsp;&nbsp;</span><span class="next_price_val">---</span><input type="hidden" name=data[CourseType][next_year][price_chart][low_chart]['+count+']></div>');
                count++;
            }
            $.post(JS_SITE_URL+'admin/Course/get_limit',{max:max_week,min:min_week},function(d){
				
				$('#next_high_to').html(d);
				$('#next_high_from').html(d);
				})
        }
        
    }
}



//    pupose:for get limit of price editor
//    created on:9 june 2014,
//    Author: Abhishek Tripathi
function get_limit(){
	var min_week=$('#min_week').val();
    var max_week=$('#max_week').val();
	
	 $.post(JS_SITE_URL+'admin/Course/get_limit',{max:max_week,min:min_week},function(d){
				if($('#CourseTypeCurrentYearPlan1').is(':checked')){
				$('#high_to_all').html(d);
				$('#high_from_all').html(d);
			}
			if($('#CourseTypeCurrentYearPlan2').is(':checked')){
				$('#high_to').html(d);
				$('#high_from').html(d);
			}
				})
    var next_min_week=$('#next_min_week').val();
    var next_max_week=$('#next_max_week').val();		
    
    $.post(JS_SITE_URL+'admin/Course/get_limit',{max:next_max_week,min:next_min_week},function(da){
				if(	$('#CourseTypeNextYearPlan1').is(':checked')){
				$('#next_high_to_all').html(da);
				$('#next_high_from_all').html(da);
			}
				if(	$('#CourseTypeNextYearPlan2').is(':checked')){
					
				$('#next_high_to').html(da);
				$('#next_high_from').html(da);
			}
				})	
	}
