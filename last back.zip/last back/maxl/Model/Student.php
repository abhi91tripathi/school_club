<?php
/**
 * Student Model
 * @author Abhishek Agrawal
 * @since [version]
 */
class Student extends AppModel
{
	//The $name variable is always a good idea to add, and is used to overcome some class name oddness in PHP4.
	var $name = 'Student';
	// var $useTable = false;
	 var $actsAs = array('Converter');
	var $validationSet = array(
			'Form3' => array(
				'telephone' => array(
					'rule' => 'notEmpty',
					'message' => 'Telephone is required.'
				),
				'id_number' => array(
					'rule' => 'notEmpty',
					'message' => 'Passport or Id Number  is required.'
				),
				'postcode' => array(
					'rule1' => array(
						'rule' => 'notEmpty',
						'message' => 'postcode is required.'
					),
				),
				'city' => array(
					'rule' => 'notEmpty',
					'message' => 'city is required.'
				),
				'country' => array(
					'rule' => 'notEmpty',
					'message' => 'country is required.'
				),
				'smoker' => array(
					'rule' => 'notEmpty',
					'message' => 'smoker is required.'
				),
				'childrens' => array(
					'rule' => 'notEmpty',
					'message' => 'Childrens is required.'
				),
				'pets' => array(
					'rule' => 'notEmpty',
					'message' => 'Pets is required.'
				),
				'special_diets' => array(
					'rule' => 'notEmpty',
					'message' => 'Special diets is required.'
				),
				'address' => array(
					'rule' => 'notEmpty',
					'message' => 'Address is required.'
				),
				/*'pimage' => array(
					'rule' => 'notEmpty',
					'message' => 'Picture is required.'
				),*/
			),
			'Form2' => array(
				'first_name' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'First name is required.'
					),
				),
				'last_name' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Last name is required.'
					),
				),
				'nationality' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Nationality is required.'
					),
				),
				'email' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Email is required.'
					),
					'email' => array(
						'rule' => 'email',
						'message' => 'Use correct email format.'
					),
				),
				
				'gender' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Please select a gender.'
					),
				),
				'terms' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Please select a terms and conditions.'
					),
				),
			),
			'Form1' => array(
				'course_id' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Please select a course.'
					),
				),
				'institute_id' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Please select a institute.'
					),
				),
				'start_date' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Start date is required.'
					),
					'date' => array(
						'rule' => array('date', 'ymd'),
						'message' => 'Use correct format(YYYY-MM-DD).'
					),
				),
				'no_of_week' => array(
					'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Please select number of weeks.'
					),
				),
			)
	);
	public $hasOne  = array(
			'Emergency' => array('className' => 'Emergency',
								// 'foreignKey' => '',
								// 'conditions' => array(),
								// 'fields' => array(),
								// 'order' => '',
			),
			'Payment' => array('className' => 'Payment',
								// 'foreignKey' => '',
								// 'conditions' => array(),
								// 'fields' => array(),
								// 'order' => '',
			),
		);
	public $belongsTo  = array(
			'Institute' => array('className' => 'Institute',
								// 'foreignKey' => '',
								// 'conditions' => array(),
								// 'fields' => array(),
								// 'order' => '',
			),
			'CourseType' => array('className' => 'CourseType',
								'foreignKey' => 'course_id',
								// 'conditions' => array(),
								// 'fields' => array(),
								// 'order' => '',
			),
			'AccomodationType' => array('className' => 'AccomodationType',
								'foreignKey' => 'accomodation_id',
								// 'conditions' => array(),
								// 'fields' => array(),
								// 'order' => '',
			),
		);
	/*public function beforeSave($options = array())
	{
		$reg_fee='';$week_price='';$accom_price='';$final_price='';$bookMaterialFee='';$deposit_now='';$discount='';
		if(isset($this->data['Student']['reg_fee']) && $this->data['Student']['reg_fee']!='')
		{
			$reg_fee = $this->Getfloat($this->data['Student']['reg_fee']);
		}
		if(isset($this->data['Student']['week_price']) && $this->data['Student']['week_price']!='')
		{
			$week_price = $this->Getfloat($this->data['Student']['week_price']);
		}
		if(isset($this->data['Student']['accom_price']) && $this->data['Student']['accom_price']!='')
		{
			$accom_price =  $this->Getfloat($this->data['Student']['accom_price']);
		}
		if(isset($this->data['Student']['final_price']) && $this->data['Student']['final_price']!='')
		{
			$final_price =  $this->Getfloat($this->data['Student']['final_price']);
		}
		if(isset($this->data['Student']['bookMaterialFee']) && $this->data['Student']['bookMaterialFee']!='')
		{
			$bookMaterialFee =  $this->Getfloat($this->data['Student']['bookMaterialFee']);
		}
		if(isset($this->data['Student']['deposit_now']) && $this->data['Student']['deposit_now']!='')
		{
			$deposit_now =  $this->Getfloat($this->data['Student']['deposit_now']);
		}
		if(isset($this->data['Student']['discount']) && $this->data['Student']['discount']!='')
		{
			$discount =  $this->Getfloat($this->data['Student']['discount']);
		}
		$this->data['Student']['reg_fee'] = !empty($reg_fee) ? $reg_fee : 0;
		$this->data['Student']['week_price'] = !empty($week_price) ? $week_price : 0;
		$this->data['Student']['accom_price'] = !empty($accom_price) ? $accom_price : 0;
		$this->data['Student']['final_price'] = !empty($final_price) ? $final_price : 0;
		$this->data['Student']['bookMaterialFee'] = !empty($bookMaterialFee) ? $bookMaterialFee : 0;
		$this->data['Student']['deposit_now'] = !empty($deposit_now) ? $deposit_now : 0;
		$this->data['Student']['discount'] = !empty($discount) ? $discount : 0;
	}
	
	public function Getfloat($str) {
	  if(strstr($str, ",")) {
		$str = str_replace(".", "", $str); // replace dots (thousand seps) with blancs
		$str = str_replace(",", ".", $str); // replace ',' with '.'
	  }
	 
	  if(preg_match("#([0-9\.]+)#", $str, $match)) { // search for number that may contain '.'
		return floatval($match[0]);
	  } else {
		return floatval($str); // take some last chances with floatval
	  }
	} */
}
