<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class CourseType extends AppModel {

/**
 * Display field
 *
 * @var string
 */
    
public $actsAs = array(
        'Translate' => array(
            'title','slug','description','group_course'
        )
    );

/**
 * belongsTo associations
 *
 * @var array
 */
 

 
 
	public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			
			
		)
	);
        public $hasMany = array(
        'CoursePrice' => array(
            'className' => 'CoursePrice',
            'foreignKey' => 'course_types_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' => true
        )
            );
}
