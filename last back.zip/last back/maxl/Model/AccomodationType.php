<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class AccomodationType extends AppModel {

/**
 * Display field
 *
 * @var string
 */
public $actsAs = array(
        'Translate' => array(
            'title','slug','description'
        )
    );

/**
 * belongsTo associations
 *
 * @var array
 */
 
 
 
 
 
 
	public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			
		)
	);
        public $hasMany = array(
        'AccomodationPrice' => array(
            'className' => 'AccomodationPrice',
            'foreignKey' => 'accomodation_types_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' => true
        )
            );
}
