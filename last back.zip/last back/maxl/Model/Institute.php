<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Institute and having validation for institute
 */
class Institute extends AppModel {
                

    /**
     * purpose: containable behaviour
     * @var type 
     */
    var $actsAs = array('Containable','Converter');


    /**
     * Purpose: to get data basis of language id ,destination id and course min weeks
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:language_id,destination_id and no of weeks
     * @return: array of institute
     * * @var type 
     */
    public function get_search($language = null, $destination = null, $weeks = null) {
        
        $option = array(
            'AND' => array(
                'language_id' => $language,
                'destination_id' => $destination
            )
        );
        $fields = array('id', 'title', 'tag_line', 'logo','average_rating','rating_user');
        $contain=array('CoursePrice'=>array('conditions'=>array(
            'min_no_course <='=>$weeks
        ),'fields'=>array('id')
         )
            
            );
        $institute = $this->find('all', array('conditions' => $option, 'fields' => $fields,'contain' =>$contain));
        
        return $institute;
    }
	
	/**
     * Purpose: to get data basis of language id ,destination id and course min weeks
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:language_id,destination_id and no of weeks
     * @return: array of institute
     * * @var type 
     */
     public function get_info($name=null){
		 $cond_arr=array();
     	if(!empty($name)){
		append_condition($cond_arr,'Institute.slug', 'equal', $name);
	        }
		$institute=$this->find('first',array('conditions'=>$cond_arr));
                
                    return $institute;
     }
     
    
     /**
     * Purpose: to get school list on basis of country id
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:country id
     * @return: array of institute
     * * @var type 
     */
     
     public function get_school_list($id=null){

		
		 $school_list=$this->find('list',array('conditions'=>array('country_id'=>$id)));
		 return $school_list;
		 }
	 
	 /**
     * Purpose: to get school list on basis of language id
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:language id
     * @return: array of institute
     * * @var type 
     */
	 public function get_school_list_lang($id=null,$country_id=null,$city_id=null){
                
		$this->bindTranslation(configure::read('institute_fields'));
	 	$cond_arr=array();
	 	if($id!=null){
			append_condition($cond_arr,'Institute.language_id', 'equal', $id);
			}
		if($country_id!=null){
			append_condition($cond_arr,'Institute.country_id', 'equal', $country_id);
			}
		if($city_id!=null){
			append_condition($cond_arr,'Institute.destination_id', 'equal', $city_id);
			}
		 $school_list=$this->find('list',array('conditions'=>$cond_arr,'order'=>array('Institute.title ASC')));
		 
		 return $school_list;
	 }
	 
	 
	 
	  /**
     * Purpose: to get country id list
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:language id
     * @return: array of of country id
     * * @var type 
     */
	 
	 public function get_country_id($id=null){
		 $cond_arr=array();
                 $institute_id=null;
                 $this->recursive=-1;
                 $I18nModel=ClassRegistry::init('I18nModel');
                  $local = CakeSession::read("Language");
                $local_list = configure::read('local');
		 if($id!=null){
			append_condition($cond_arr,'Institute.language_id', 'equal', $id);
			}
	 	$fields_institute=array('id');
                $fields_countr=array('country_id');
                $this->bindTranslation(configure::read('institute_fields'));
                $Institute_id=$this->find('list',array('conditions'=>$cond_arr,'fields'=>$fields_institute));
                $I18nModel_ins=$I18nModel->find('list',array('conditions'=>array('I18nModel.model'=>'Institute','I18nModel.locale'=>$local_list[$local],'I18nModel.field'=>'title','I18nModel.foreign_key'=>$Institute_id),'fields'=>array('foreign_key')));
                if($I18nModel_ins!=null){
			append_condition($cond_arr,'Institute.id', 'equal', $I18nModel_ins);
			}
                
                $countries=$this->find('list',array('conditions'=>$cond_arr,'fields'=>$fields_countr));
                return $countries;
	 }
	 
	 	  /**
     * Purpose: to get country id list
     * created on :15 sep 2014
     * @author:Abhishek Tripathi
     * @param:language id
     * @return: array of of destination id
     * * @var type 
     */
	 
	 public function get_destination_id($id=null){
             
                $cond_arr=array();
                $I18nModel=ClassRegistry::init('I18nModel');
                $local = CakeSession::read("Language");
                $local_list = configure::read('local');
		 if($id!=null){
			append_condition($cond_arr,'Institute.language_id', 'equal', $id);
			}
                        
	 	$fields=array('destination_id');
                $fields_institute=array('id');
                $fields_desti=array('destination_id');
                $this->bindTranslation(configure::read('institute_fields'));
                $Institute_id=$this->find('list',array('conditions'=>$cond_arr,'fields'=>$fields_institute));
                $I18nModel_ins=$I18nModel->find('list',array('conditions'=>array('I18nModel.model'=>'Institute','I18nModel.locale'=>$local_list[$local],'I18nModel.field'=>'title','I18nModel.foreign_key'=>$Institute_id),'fields'=>array('foreign_key')));
                if($I18nModel_ins!=null){
			append_condition($cond_arr,'Institute.id', 'equal', $I18nModel_ins);
			}
                
                $this->bindTranslation(configure::read('institute_fields'));
	 	$destination=$this->find('list',array('conditions'=>$cond_arr,'fields'=>$fields_desti));
		///debug($countries);exit;
		return $destination;
	 }
	 
	 /**
     * Purpose: to get data basis of institute_id
     * created on :19 sept 14
     * @author:Abhishek Tripathi
     * @param:institute_id
     * @return: array of institute
     * * @var type 
     */
     public function get_info_id($id=null,$slug=null){
     
         $local = CakeSession::read("Language");
         $local_list = configure::read('local');
         $condition=array();
        if($id!=null){
			append_condition($condition,'Institute.id', 'equal', $id);
     	}
     	if($slug!=null){
            $I18nModel=ClassRegistry::init('I18nModel');
            $I18nModel_ins=$I18nModel->find('first',array('conditions'=>array('I18nModel.model'=>'Institute','I18nModel.locale'=>$local_list[$local],'I18nModel.field'=>'slug','I18nModel.content'=>$slug),'fields'=>array('foreign_key')));
            append_condition($condition,'Institute.id', 'equal', $I18nModel_ins['I18nModel']['foreign_key']);
     	}
		$contain=array(
		'InstituteGallery'=>array('limit'=>2),
		'Country'=>array('fields'=>array('id','name','flag_image')),
		'Destination'=>array('fields'=>array('name','id')),
                  'Currency'=>array('fields'=>array('currency_code'))
		);
		$fields=array('id','logo','embassy_image','about_embassy','title','min_price','accreditation','slug','average_rating','rating_user','listing_type');
                $this->bindTranslation(configure::read('institute_fields'));
		$institute=$this->find('first',array('conditions'=>$condition,'contain'=>$contain));
                
                $institute['Institute']['min_price']=round($this->exchange_rate_convert('EUR', CakeSession::read('CURRENCY'),$institute['Institute']['min_price']),0);
		
      return $institute;
     }
     
    
    public function beforeFind($queryData = array()) {
    if($queryData['fields'][0]=='mode'){
           return $queryData;
           
       }
      if(!empty($queryData['conditions']['AND']['Institute.mode']) && $queryData['conditions']['AND']['Institute.mode']==1)
       {
              return $queryData;
       }
      if(!empty($queryData['conditions']['AND']['Institute.previous']) && $queryData['conditions']['AND']['Institute.previous']==1)
       {
           $defaultConditions = array('Institute.id' =>$queryData['conditions']['AND']['Institute.id']);
           unset($queryData['conditions']);
           $queryData['conditions'] =$defaultConditions;
          
           return $queryData;
       } 
       
     else{
        $defaultConditions = array('Institute.published' => 1);
        $queryData['conditions'] = array_merge($queryData['conditions'], $defaultConditions);
        return $queryData; 
     }
        
  } 
    
   /**
     * Purpose: latest school info
     * created on :6 oct 2014
     * @author:Abhishek Tripathi
     * @param:institute_id
     * @return: array of institute
     * * @var type 
     */
     public function get_latest_school($id=null){
       
     	$condition=array(
     	'Institute.id'=>$id
		);
		$contain=array(
		'InstituteGallery'=>array('limit'=>2),
		'Country'=>array('fields'=>array('id','name','flag_image')),
		'Destination'=>array('fields'=>array('name','id')),
                  'Currency'=>array('fields'=>array('currency_code'))    
		);
		$fields=array('id','logo','embassy_image','about_embassy','title','min_price','accreditation','slug','average_rating','rating_user','discount_available','thumbnail_image','overwrite_slug','listing_type');
		$this->bindTranslation(configure::read('institute_fields'));
                $institute=$this->find('all',array('conditions'=>$condition,'contain'=>$contain,'fields'=>$fields));
		
      return $institute;
     }  
	 /**
     * Purpose: to get school list on slug
     * created on :10 oct 2014
     * @author:Abhishek Tripathi
     * @return: array of institute
     * * @var type 
     */
	 
	 public function get_school_list_slug(){
		 $cond_arr=array();
                 $this->bindTranslation(configure::read('institute_fields'));
		  $school_list=$this->find('list',array('conditions'=>$cond_arr,'fields'=>array('slug','title'),'order'=>array('Institute.title ASC')));
		  return $school_list;
		 }
   // Association----------------------	 
                 
     
    public $belongsTo=array(
	'Country'=>array(
	 'className'=>'Country',
	  'foreignKey'=>'country_id',
	  
	 ),
	 'Language'=>array(
	  'className'=>'Language',
	  'foreignkey'=>'language_id'
	 ),
	 'Destination'=>array(
	  'className'=>'Destination',
	  'foreignkey'=>'destination_id'
	 ),
        'Currency'=>array(
	  'className'=>'Currency',
	  'foreignkey'=>'currency_id'
	 )
	);

    public $hasMany = array(
        'CourseType' => array(
            'className' => 'CourseType',
            'foreignKey' => 'institute_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' => true
        ),
          'CoursePrice' => array(
            'className' => 'CoursePrice',
            'foreignKey' => 'institute_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' =>true
        ),
         'InstituteGallery' => array(
            'className' => 'InstituteGallery',
            'foreignKey' => 'institute_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' =>true
        ),
        'AccomodationType'=>array(
          'className' => 'AccomodationType',
            'foreignKey' => 'institute_id',
            'conditions' => '',
            'fields'=>'',
            'order' => '',
            'limit' => '',
            'dependent' =>true
        ),
        'Review'=>array(
          'className'=>'Review',
           'foreignKey'=>'institute_id',
           'dependent'=>true,
           'conditions'=>array('Review.status'=>1)
        )
        
    );

}
