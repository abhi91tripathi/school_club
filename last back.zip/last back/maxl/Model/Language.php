<?php
App::uses('AppModel', 'Model');
/**
 * Language Model
 *

 */
class Language extends AppModel {
	
	  /**
         *Purpose:get language id on basis of language name
         * created on:8 August
         * @param:Language name
         * @Author: Abhishek TRipathi 
         */
        //
        
    
        
	public function get_language_id($name=null){
		$fields=array('id');
		    $translation=ClassRegistry::init('I18nModel');
                    $locale=Configure::read('local');
                    $data=$translation->find('first',array('conditions'=>array('I18nModel.model'=>'Language','I18nModel.locale'=>$locale[CakeSession::read("Language")],'I18nModel.content'=>$name)));
                if($data){
                    return $data['I18nModel']['foreign_key'];
                }
            
		
	}
        public function beforeFind($query) {
            parent::beforeFind($query);
              $fields_data =configure::read('language');
            $this->bindTranslation($fields_data);
            return $query;
        }
        
        
	
	
} 
