<?php

/**
 * Project: Max Languages
 * Author: Abhishek Tripathi
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/


class Course extends AppModel {
    
        var $actsAs = array('Containable', 'Translate' => array(
            'title', 'slug'
        ));
        

        
    public $hasMany = array(
        'CourseType' => array(
            'className' => 'CourseType',
            'foreignKey' => 'course_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' => true,
           
        )
    );
             
	
}
