<?php


App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class TestsController extends AppController {
  
  var $uses = array();
    var $components = array("Google");
    var $name = "Search";
    
    function index()
    {
        configure::write('debug',2);
        
        
         $start = (empty($this->params['url']['start']) ? 0 : $this->params['url']['start']);
        $term = 'colleges';
        $search_results = array();
    
        
        
        
        //just send them back if the search is empty
        if(empty($term))
        {
            $this->redirect($this->referer());
        }
        else
        {
            $search_results = $this->Google->run_search($term, $start, false);
                        //debug($search_results) //uncomment to see return's structure
        }
        
        
        $this->set("search_results", $search_results);
        
        $this->render();

    
    } 
    
}
