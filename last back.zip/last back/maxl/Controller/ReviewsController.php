<?php
/*
 * Name : Reviews
 * Created : 9 oct 2014
 * Purpose : Reviews controller
 * Author : Abhishek Tripathi
 */
class ReviewsController extends AppController {
	
           public $components = array('Uploader', 'Email');
		


        public function write(){
	
	$this->loadModel('Institute');
	$institute=$this->Institute->get_school_list_slug();
	
        
                        $LAYOUT_META_TITLE = 'Which language school would you like to review? | Maxlanguages.com';
                        $LAYOUT_META_DESCRIPTION = "Select a language school and write a review about your language course abroad. By Sharing your experience, you’re helping other to make better choices.";
                        $og_image=SITE_URL."img/og_image.jpeg";
                        $Siteurl=Configure::read('SITE_URL');
                        $review_url=Configure::read('review_url'); 
                        $UNIVERSAL_SLUG=array(      
                                    'en'=>$Siteurl['en'].$review_url['en'],
                                    'fr'=>$Siteurl['fr'].$review_url['fr'],
                                    'es'=>$Siteurl['es'].$review_url['es'],
                                    'it'=>$Siteurl['it'].$review_url['it'],
                                    'de'=>$Siteurl['de'].$review_url['de'],
                                    'pt'=>$Siteurl['pt'].$review_url['pt'],
                                );
                        $review_detail_url=Configure::read('review_detail_url'); 
                        $UNIVERSAL_SLUG_detail=array(      
                                    'en'=>$Siteurl['en'].$review_detail_url['en'],
                                    'fr'=>$Siteurl['fr'].$review_detail_url['fr'],
                                    'es'=>$Siteurl['es'].$review_detail_url['es'],
                                    'it'=>$Siteurl['it'].$review_detail_url['it'],
                                    'de'=>$Siteurl['de'].$review_detail_url['de'],
                                    'pt'=>$Siteurl['pt'].$review_detail_url['pt'],
                                ); 
                        $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image','UNIVERSAL_SLUG','UNIVERSAL_SLUG_detail')); 
			$this->set(compact('institute'));
                        $this->set(compact('institute'));
	}
        public function detail(){
                $this->loadModel('Institute');
                        $slug=$this->params->query['institute'];
			$institute=$this->Institute->get_info_id('',$slug);
                       (!empty($institute['Institute']['logo'])?$institute['Institute']['logo']:'no-image.jpg');
                          $LAYOUT_META_TITLE = 'Write a review about [SCHOOL NAME] | Maxlanguages.com';
                          $LAYOUT_META_DESCRIPTION = "Write a review about your language course at [SCHOOL NAME]. By Sharing your experience, you’re helping other to make better choices.";
                          $og_image=SITE_URL."img/og_image.jpeg";
                          $search = array('[SCHOOL NAME]');
                          $replace_from = array($institute['Institute']['title']);
                          $LAYOUT_META_TITLE =  str_replace($search, $replace_from, $LAYOUT_META_TITLE) ;
                          $LAYOUT_META_DESCRIPTION =  str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION) ;
                          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image')); 
                          if(!empty($this->params->query['student'])){
                              $this->loadModel('Student');
                              $id=  ($this->params->query['student']);
                              $student=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
                          }
                          $Siteurl=Configure::read('SITE_URL');
                          $review_detail_url=Configure::read('review_detail_url'); 
                          $UNIVERSAL_SLUG_detail=array(      
                                    'en'=>$Siteurl['en'].$review_detail_url['en'].'/add',
                                    'fr'=>$Siteurl['fr'].$review_detail_url['fr'].'/add',
                                    'es'=>$Siteurl['es'].$review_detail_url['es'].'/add',
                                    'it'=>$Siteurl['it'].$review_detail_url['it'].'/add',
                                    'de'=>$Siteurl['de'].$review_detail_url['de'].'/add',
                                    'pt'=>$Siteurl['pt'].$review_detail_url['pt'].'/add',
                                ); 
                          
                           $review_url=Configure::read('review_url'); 
                        $UNIVERSAL_SLUG=array(      
                                    'en'=>$Siteurl['en'].$review_url['en'],
                                    'fr'=>$Siteurl['fr'].$review_url['fr'],
                                    'es'=>$Siteurl['es'].$review_url['es'],
                                    'it'=>$Siteurl['it'].$review_url['it'],
                                    'de'=>$Siteurl['de'].$review_url['de'],
                                    'pt'=>$Siteurl['pt'].$review_url['pt'],
                                );
                         
                        $this->set(compact('institute','student','Siteurl','review_url','UNIVERSAL_SLUG_detail','UNIVERSAL_SLUG'));
		  
   }	


 /**
	  * Purpose: this function is upload user image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload(){
		 //debug($this->params);exit;
	  	       if(isset($this->params->form['image_input'])){
	  	       	 $one= $this->params->form['image_input'];
                        $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'review_user' . DS;
				// move_uploaded_file($one['tmp_name'], $path . $name);
				// $this->Resize = $this->Components->load('ImageResize');
				// $this->Resize->resize( $path.$name, '870', '320', $path.$name);
				 $thumbnails = Thumbnail::review_images();
				 $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
				 
				 $image_new_name = date('ydmhis');
				 $this->Uploader->upload($one, $path.DS, $thumbnails, $image_new_name, $params);		
				 $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/review_user/REV'.$name;
			     echo json_encode($response);exit; 
				
	  	       }
		}
 /**
	  * Purpose: this function is upload user image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function add(){
		  if($this->request->is('post'))
			  {
                        $Siteurl=Configure::read('SITE_URL');
                        $review_detail_url=Configure::read('review_detail_url'); 
                        $UNIVERSAL_SLUG=array(      
                                    'en'=>$Siteurl['en'].$review_detail_url['en'],
                                    'fr'=>$Siteurl['fr'].$review_detail_url['fr'],
                                    'es'=>$Siteurl['es'].$review_detail_url['es'],
                                    'it'=>$Siteurl['it'].$review_detail_url['it'],
                                    'de'=>$Siteurl['de'].$review_detail_url['de'],
                                    'pt'=>$Siteurl['pt'].$review_detail_url['pt'],
                                ); 
                              
                            if($this->Review->save($this->request->data))
                                            {
                           
                                                $this->Session->setFlash('success');
                                                $link=$UNIVERSAL_SLUG[CakeSession::read("Language")].'?institute='.$this->request->data['Review']['institute_slug'];
                                                $this->redirect($link);
                                       
                                            }
                                            else
                                            {
                                                $this->Session->setFlash('success');
                                                $link=$UNIVERSAL_SLUG[CakeSession::read("Language")].'?institute='.$this->request->data['Review']['institute_slug'];
                                                $this->redirect($link);

                                            }
                            }
	}

 /**
	  * Purpose: this function helpfull review
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	 public function helpfull(){
		 $this->loadModel('Like');
		 if($this->request->is('post')){
			 $ip=$this->request->clientIp();
			 $id=$this->request->data['id'];
			  $con=array('AND'=>array('ip_address'=>$ip,'review_id'=>$id));
			  			
			 $review=$this->Like->find('first',array('conditions'=>$con));
            
			 if($review){
                 $this->Like->id=$review['Like']['id'];
                 $like=(($this->request->data['helpfull']=='yes'?1:2));
                 $this->Like->saveField('like',$like);
                 $response['error']=0;
                 $response['message']='updated';
                 echo json_encode($response);
                 exit;
				 }
			else{
				
                 $like=($this->request->data['helpfull']=='yes'?1:2);
                 $like_array=array('Like'=>array(
                  'ip_address'=>$ip,
                  'like'=>$like,
                  'review_id'=>$id
                 ));
                 
                 $this->Like->save($like_array);
                 $response['error']=0;
                 $response['message']='success';
                 echo json_encode($response);
                 exit;
				
				}	 
			
			 }
		 
		 } 
                 
                 
		public function test(){
			} 
	  
                        
               public function daily_report(){
                   Configure::write('debug',2);
                   $this->loadModel('EmailTemplate');
                   $latest_reviews=$this->Review->find('all',array('conditions'=>array('Review.created >= NOW() - INTERVAL 1 DAY')));
                   $this->loadModel('Institute');
                   $this->loadModel('Setting');
                   $setting=$this->Setting->find('first');
                   $setting_value=json_decode($setting['Setting']['value'],true);
                   $html="";
                    foreach($latest_reviews as $review){
                       $school=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$review['Review']['institute_id']),'fields'=>array('Institute.title','Institute.slug')));
                       $html.='<p>School Name:'.$school['Institute']['title'].'</p>';
                       $html.='<p>Student Name:'.$review['Review']['first_name'].' '.$review['Review']['last_name'].'</p>';
                       $html.='<p>Student Email:'.$review['Review']['email'].'</p>';
                       $html.='<p>Star Rating:'.$review['Review']['rating'].' star</p>';
                       $html.='<p>Text:'.$review['Review']['post'].'</p>';
                       $html.='<p>==========================================</p>';
                       $this->Review->id=$review['Review']['id'];
                       $review['Review']['mail_to_admin']=1;
                       $this->Review->save($review);
                     }
                     if(!empty($latest_reviews)){
                      $srch_array =array();
                        $email_values = $this->EmailTemplate->getvalues('daily_report', $srch_array,$srch_array);
                        $to_emailid = $setting_value['Settings']['replay_to'];
                        $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
                        $this->Email->to =$to_emailid;
                        $this->Email->subject = $email_values['subject'];
                        $this->Email->sendAs = 'html';
                        $this->Email->send($html);
                     }
                        exit;
                        $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
               }   
               
               
	public function detail_page($token=null){
	
		$this->loadModel('Institute');
		  if($this->request->is('get')){
			$slug=$this->params->query['institute'];
			$institute=$this->Institute->get_info_id('',$slug);
			(!empty($institute['Institute']['logo'])?$institute['Institute']['logo']:'no-image.jpg');
                          $LAYOUT_META_TITLE = 'Write a review about [SCHOOL NAME] | Maxlanguages.com';
                          $LAYOUT_META_DESCRIPTION = "Write a review about your language course at [SCHOOL NAME]. By Sharing your experience, you’re helping other to make better choices.";
                          $og_image=SITE_URL."img/og_image.jpeg";
                          $search = array('[SCHOOL NAME]');
                          $replace_from = array($institute['Institute']['title']);
                          $LAYOUT_META_TITLE =  str_replace($search, $replace_from, $LAYOUT_META_TITLE) ;
                          $LAYOUT_META_DESCRIPTION =  str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION) ;
                          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image')); 
			$this->set(compact('institute'));
		  }
   }	

}

?>
