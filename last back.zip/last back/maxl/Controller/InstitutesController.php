<?php

/*
 * Name : Homes
 * Created : 3 Apr 2013
 * Purpose : Homepage controller
 * Author : Ritish
 */

class InstitutesController extends AppController {

    var $name = 'Institutes';
    var $uses = array('Institute', 'HomepageBlockText', 'Testimonial', 'HomepageBanner');
    public $helpers = array('Converter');
    
    public $middle_slug=array(
        'en'=>'-in-',
        'fr'=>'-ecoles-',
        'es'=>'-en-',
        'it'=>'-in-',
        'de'=>'-in-',
        'pt'=>'-em-'
    ); 
    
     public $prefix=array(
        'en'=>'learn',
        'fr'=>'cours',
        'es'=>'cursos',
        'it'=>'corsi',
        'de'=>'sprachkurs',
        'pt'=>'cursos'
    ); 
     
      public $sufix=array(
        'en'=>'abroad',
        'fr'=>'etranger',
        'es'=>'extranjero',
        'it'=>'estero',
        'de'=>'estero',
        'pt'=>'estero'
    ); 
      
      public $all_language=array(
        'en'=>'language',
        'fr'=>'langue',
        'es'=>'idioma',
        'it'=>'lingue',
        'de'=>'sprache',
        'pt'=>'idiomas'
      );

    /*
     * Purpose: Institute view
     * Created : 28 Apr 2014
     * Author: Rupesh Sharma
     */

    function index($id) {
        $this->loadModel('Institute');
        $this->loadModel('Facility');
        $this->loadModel('InstituteGallery');
        $this->loadModel('CourseType');
        $this->loadModel('Course');
        $this->loadModel('AccomodationType');
        $this->loadModel('Accomodation');
        $this->loadModel('AccomodationTypeAccomodationFacilities');
        $this->loadModel('Country');
        $this->loadModel('Exam');
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('InstituteExam');

        $institute = $this->Institute->find('first', array(
            'conditions' => array(
                'Institute.id' => $id
            )
        ));
        // json data decode
        $student_profile = json_decode($institute['Institute']['student_profile'], true);
        $new_arr = array_merge($institute['Institute'], $student_profile);
        $institute = array(
            'Institute' => $new_arr
        );

        $this->set('institute', $institute);

        $facility = $this->Facility->find('list', array(
            'joins' => array(
                array(
                    'table' => 'institute_facilities',
                    'alias' => 'ifacility',
                    'type' => 'inner',
                    'foreignKey' => false,
                    'conditions' => array(
                        'ifacility.facility_id = Facility.id and ifacility.institute_id = ' . $id
                    )
                )
            ),
            'fields' => array(
                'Facility.title',
                'Facility.icon'
            )
        ));
        if (!empty($facility)) {
            $this->set('facility', $facility);
        }
        $institute_gallery = $this->InstituteGallery->find('list', array(
            'conditions' => array(
                'InstituteGallery.institute_id' => $id
            ),
            'fields' => array(
                'img'
            )
        ));
        if (!empty($institute_gallery)) {
            $this->set('institute_gallery', $institute_gallery);
        }

        $this->Course->bindModel(array(
            'hasMany' => array(
                'CourseType' => array(
                    'className' => 'CourseType',
                    'conditions' => array(
                        'institute_id' => $id
                    )
                )
            )
        ));
        $coursetype = $this->Course->find('all', array(
            'fields' => array(
                'Course.id',
                'Course.title'
            )
        ));
        if (!empty($coursetype)) {

            $this->set('coursetype', $coursetype);
        }

        $this->AccomodationTypeAccomodationFacilities->bindModel(array(
            'belongsTo' => array(
                'AccomodationFacility' => array(
                    'className' => 'AccomodationFacility',
                    'fields' => array(
                        'AccomodationFacility.title',
                        'AccomodationFacility.icon'
                    )
                )
            )
        ));
        $this->AccomodationType->bindModel(array(
            'hasMany' => array(
                'AccomodationTypeAccomodationFacilities' => array(
                    'className' => 'AccomodationTypeAccomodationFacilities',
                    'fields' => array(
                        'AccomodationTypeAccomodationFacilities.accomodation_facility_id'
                    )
                )
            )
        ));
        $this->Accomodation->bindModel(array(
            'hasMany' => array(
                'AccomodationType' => array(
                    'className' => 'AccomodationType'
                )
            )
        ));
        $accomodationtype = $this->Accomodation->find('all', array(
            'fields' => array(
                'Accomodation.id',
                'Accomodation.title'
            ),
            'recursive' => 5
        ));
        if (!empty($accomodationtype)) {

            $this->set('accomodationtype', $accomodationtype);
            //pr($accomodationtype);
            //die();
        }

        $options['joins'] = array(
            array(
                'table' => 'institute_exams',
                'alias' => 'InstituteExam',
                'type' => 'inner',
                'conditions' => array(
                    'InstituteExam.exam_id = Exam.id && InstituteExam.institute_id =' . $id . ''
                )
            )
        );
        $exam = $this->Exam->find('list', $options);
        if (!empty($exam)) {

            $this->set('exam', $exam);
        }
        $extra_fee = $this->InstituteExtraFee->find('all', array(
            'conditions' => array(
                'InstituteExtraFee.institute_id' => $id
            ),
            'fields' => array(
                'InstituteExtraFee.title',
                'InstituteExtraFee.type',
                'InstituteExtraFee.price'
            )
        ));
        if (!empty($extra_fee)) {
                $this->set('extra_fee', $extra_fee);
        }
    }

    /**
     * Purpose:School page (it contain the complete information of school)
     * created on :21 july 2014
     * created by: Abhishek Tripathi
     */
    
    public function view($name = null) {
        $name = $this->params['slug'];
        $this->loadModel('I18nModel');
        $institute_info=$this->I18nModel->find('first',array('conditions'=>array('I18nModel.model'=>'Institute','I18nModel.content'=>$name,'I18nModel.field'=>'slug'),'fields'=>array('foreign_key')));
        $fields_data=configure::read('institute_fields');
        $this->Institute->bindTranslation($fields_data);
        $institute = $this->Institute->find('first',array('conditions'=>array('Institute.id'=>$institute_info['I18nModel']['foreign_key'])));
        $this->loadModel('Facility');
        $this->loadModel('InstituteGallery');
        $this->loadModel('CourseType');
        $this->loadModel('Course');
        $this->loadModel('AccomodationType');
        $this->loadModel('AccomodationPrice');
        $this->loadModel('Accomodation');
        $this->loadModel('AccomodationTypeAccomodationFacilities');
        $this->loadModel('Country');
        $this->loadModel('Exam');
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('InstituteExam');
        $this->loadModel('Review');
        $this->loadModel('CourseSubcategory');
        $this->loadModel('DefaultMeta');
        $local = CakeSession::read("Language");
        $local_list = configure::read('local');
        //---------------------------set cookiew latest viewed school-----6 oct 2014------------------------//
        $arr = array();
        $arr = $this->Cookie->read('institute_id');
        if (count($arr)) {
            if (count($arr) >= 8) {
                    array_shift($arr);
                }
            if (in_array($institute['Institute']['id'], $arr)) {
                $arr = array_diff($arr, array($institute['Institute']['id']));
            }
             array_push($arr, $institute['Institute']['id']);
        } else {
            $arr[] = $institute['Institute']['id'];
        }
        //debug($arr);exit;
        $this->Cookie->write('institute_id', $arr, false, 3600 * 24 * 60);
        //------------------------------------------------------------------------------------------------------------//
        $id = $institute['Institute']['id'];
        $country_name=$this->I18nModel->find('first',array('conditions'=>array('I18nModel.locale'=>$local_list[$local],'I18nModel.model'=>'Country','I18nModel.field'=>'slug','I18nModel.foreign_key'=>$institute['Country']['id']),'fields'=>array('content')));
        $country_name = $country_name['I18nModel']['content'];
        $language=$this->I18nModel->find('first',array('conditions'=>array('I18nModel.locale'=>$local_list[$local],'I18nModel.model'=>'Language','I18nModel.field'=>'title','I18nModel.foreign_key'=>$institute['Language']['id']),'fields'=>array('content')));
        $language = $language['I18nModel']['content'];
        $city_name = $institute['Destination']['name'];
        $school_name = $institute['Institute']['title'];
        $country_slug=$country_name;
        $city_slug=$institute['Destination']['slug'];
        $this->AccomodationTypeAccomodationFacilities->bindModel(array(
            'belongsTo' => array(
                'AccomodationFacility' => array(
                    'className' => 'AccomodationFacility',
                    'fields' => array(
                        'AccomodationFacility.title',
                        'AccomodationFacility.icon'
                    )
                )
            )
        ));
        $accomodations = $this->Accomodation->find('all', array(
            'fields' => array(
                'Accomodation.id',
                'Accomodation.title',
                'Accomodation.slug'
            ),
            
        ));
        
        $accomodationtype=[];
        if (!empty($accomodations)) {
            foreach ($accomodations as $key=>$accomodation){
                $LIST=array();
                $contain='AccomodationPrice';
                $accomodation_list=$this->AccomodationType->find('all',array('conditions'=>array(
                    'AccomodationType.institute_id'=>$id,
                    'AccomodationType.accomodation_id'=>$accomodation['Accomodation']['id']
                ),
                    'contain'=>$contain
                    ));
                
                foreach($accomodation_list as $list){
                    $LIST[]=$list['AccomodationType'];
                }
          
                 $accomodation_info[]=array('Accomodation'=>$accomodation['Accomodation'],'AccomodationType'=>$LIST);
                 $accomodationtype=$accomodation_info;
                
            }
            
        }
        
        if (!empty($accomodationtype)) {
            
            $this->set('accomodationtype', $accomodationtype);
        }
        $this->Course->recursive = -1;
        $courses = $this->Course->find('all');
        $coursetype=[];
        if (!empty($courses)) {
            foreach ($courses as $key=>$course){
                $LIST=array();
                $contain='CoursePrice';
                $couser_list=$this->CourseType->find('all',array('conditions'=>array(
                    'CourseType.institute_id'=>$id,
                    'CourseType.course_id'=>$course['Course']['id']
                ),
                    'contain'=>$contain
                    ));
                
                foreach($couser_list as $list){
                    $LIST[]=$list['CourseType'];
                }
                
                 $course_info[]=array('Course'=>$course['Course'],'CourseType'=>$LIST);
                 $coursetype=$course_info;
                
            }
            $this->set('coursetype', $coursetype);
        }
        $facility = $this->Facility->find('list', array(
            'joins' => array(
                array(
                    'table' => 'institute_facilities',
                    'alias' => 'ifacility',
                    'type' => 'inner',
                    'foreignKey' => false,
                    'conditions' => array(
                        'ifacility.facility_id = Facility.id and ifacility.institute_id = ' . $id
                    )
                )
            ),
            'fields' => array(
                'Facility.title',
                'Facility.icon'
            )
        ));
        if (!empty($facility)) {
            $this->set('facility', $facility);
        }
        $institute_gallery = $this->InstituteGallery->find('list', array(
            'conditions' => array(
                'InstituteGallery.institute_id' => $id
            ),
            'fields' => array(
                'img'
            )
        ));
        if (!empty($institute_gallery)) {
            $this->set('institute_gallery', $institute_gallery);
        }
        $options['joins'] = array(
            array(
                'table' => 'institute_exams',
                'alias' => 'InstituteExam',
                'type' => 'inner',
                'conditions' => array(
                    'InstituteExam.exam_id = Exam.id && InstituteExam.institute_id =' . $id . ''
                )
            )
        );
        $exam = $this->Exam->find('list', $options);
        if (!empty($exam)) {

            $this->set('exam', $exam);
        }

        //----------------list of accredation ------------------------------
        $this->loadModel('Accreditation');
        $accrediation_list = $this->Accreditation->find('list', array(
            'fields' => array(
                'id',
                'image_name'
            )
        ));
        $view = 'school';

        //------------------list of rating----------------------------------

        $reviews = $this->Review->reviews($id, $this->request->clientIp());

        //----------------------student profile-------------
        //------------------List of courses related to institute select---------------------------------
        
        $inst_courses = $this->CourseType->find('all', array('conditions' => array('CourseType.institute_id' => $id), 'fields' => array('CourseType.id,CourseType.title')));
        $student_profile = json_decode($institute['Institute']['student_profile'], true);
        if (!empty($student_profile)) {
            $new_arr = array_merge($institute['Institute'], $student_profile);
            $institute ['Institute'] = $new_arr;
        }
        //----------------------extra fee---------------------------------
        $extra_fee = $this->InstituteExtraFee->find('all', array('conditions' => array('AND'=>array('InstituteExtraFee.institute_id' => $id,'InstituteExtraFee.published'=>1))));

        //---------------LanguageLevel------------------------------------
        $this->loadModel('LanguageLevel');
        $level = $this->LanguageLevel->find('all');
        
        //-------------------Events---------------------------------------
        $this->loadModel('Event');
        $event=$this->Event->find('all',array('conditions'=>array('Event.institute_id'=>$id),'order'=>'Event.start_date ASC'));
       
        //----------------------language-List-------------------------------------------
        $this->loadModel('Language');
        $languages_list = $this->Language->find('list', array('fields' => array('id', 'title')));
        
        //--------------------currency------------------------------------------------------
        $this->loadModel('Currency');
        $currency_info=$this->Currency->find('first',array('conditions'=>array('Currency.id'=>$institute['Institute']['currency_id']),'fields'=>array('name','currrency_symbol','currency_code')));
       
        //---------------------tootip----------------------------------------------------------
        $this->loadModel('Tooltip');
        $tooltip=$this->Tooltip->find('all');
        //--Meta setup===
        $default_content=$this->DefaultMeta->find('first',array('conditions'=>array('DefaultMeta.page'=>'school')));
        
        $main_title = $default_content['DefaultMeta']['main_title'];
        
        $LAYOUT_META_TITLE = $default_content['DefaultMeta']['title'];
        $LAYOUT_META_DESCRIPTION = $default_content['DefaultMeta']['description'];
        $LAYOUT_NEXT_TO_LOGO= $default_content['DefaultMeta']['next_to_logo'];
        $search = array('[language]','[country]', '[city]','[school]');
        
        $replace_from = array($language, $country_name, $city_name,$institute['Institute']['title']);
        if(!empty($institute['Institute']['seo_detail'])){
            $seo=  json_decode($institute['Institute']['seo_detail'], true);
            if(!empty($seo['meta_title'])){
               $LAYOUT_META_TITLE=$seo['meta_title'] ;
            }
            if(!empty($seo['meta_description'])){
               $LAYOUT_META_TITLE=$seo['meta_description'] ;
            }
            
        }
        $LAYOUT_META_TITLE = str_replace($search, $replace_from, $LAYOUT_META_TITLE);
        $LAYOUT_META_DESCRIPTION = str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION);
        $LAYOUT_NEXT_TO_LOGO = str_replace($search, $replace_from, $LAYOUT_NEXT_TO_LOGO);
        $this->set('institute_id', $id);
        $rating = $this->Review->rating($id);
        $og_image=SITE_URL.'uploads/institute/'.$institute['Institute']['id'].'/main_img_'.$institute['Institute']['main_img'];
        $institute_info=$this->I18nModel->find('list',array('conditions'=>array('I18nModel.model'=>'Institute','I18nModel.foreign_key'=>$institute['Institute']['id'],'I18nModel.field'=>'slug'),'fields'=>array('locale','content')));
      
        $UNIVERSAL_SLUG=array(      
                                    'en'=>FULL_BASE_URL.$this->webroot.$institute_info['eng'],
                                    'fr'=>FULL_BASE_URL.$this->webroot.(!empty($institute_info['fra'])?'fr/'.$institute_info['fra']:$institute_info['eng']),
                                    'es'=>FULL_BASE_URL.$this->webroot.(!empty($institute_info['spa'])?'es/'.$institute_info['fra']:$institute_info['eng']),
                                    'it'=>FULL_BASE_URL.$this->webroot.(!empty($institute_info['ita'])?'it/'.$institute_info['ita']:$institute_info['eng']),
                                    'de'=>FULL_BASE_URL.$this->webroot.(!empty($institute_info['gre'])?'de/'.$institute_info['ita']:$institute_info['eng']),
                                    'pt'=>FULL_BASE_URL.$this->webroot.(!empty($institute_info['por'])?'pt/'.$institute_info['ita']:$institute_info['eng']),
                                );
        $city_slug=$this->I18nModel->find('first',array('conditions'=>array('I18nModel.locale'=>$local_list[$local],'I18nModel.model'=>'Destination','I18nModel.field'=>'slug','I18nModel.foreign_key'=>$institute['Institute']['destination_id']),'fields'=>array('content')));
        $city_slug=$city_slug['I18nModel']['content'];
        $prefix=$this->prefix;
        $sufix=$this->sufix;
        $middle_slug=$this->middle_slug;
        $all_language=$this->all_language[ CakeSession::read("Language")];
        $this->set(compact('institute', 'language', 'country_name', 'city_name', 'school_name', 'accrediation_list', 'view', 'rating',
                'reviews', 'extra_fee', 'inst_courses','level','event','languages_list','currency_info','country_slug','city_slug','tooltip',
                'og_image','LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','LAYOUT_NEXT_TO_LOGO','UNIVERSAL_SLUG',
                'prefix','sufix','middle_slug','all_language','city_slug'
                ));
        
        $courese_category = $this->CourseSubcategory->find('list', array('fields' => array('id', 'title')));
        (natcasesort($courese_category));
        $this->set('courese_category', $courese_category);
        
          $accomodation_category = $this->Accomodation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accomodation_category));
        $this->set('accomodation_category', $accomodation_category);
        
        if($institute['Institute']['listing_type']==2){
            $this->autoRender = FALSE;
            $this->render('index_pre');
        }else{
            $this->autoRender = FALSE;
            $this->render('index');
        }
        
    }

    public function map() {
        $this->loadModel('Institute');
        $this->loadModel('City');
       /* $in = $this->Institute->find('all');
        foreach ($in as $i) {
            $this->Institute->id = $i['Institute']['id'];
            $slug1 = strtolower($this->hyphenize($i['Institute']['title']));
            $slug2 = $i['Destination']['slug'];
            $final_slug = $slug1 . '-' . $slug2;
            $this->Institute->saveField('slug', $final_slug);
        }
        $in2 = $this->Institute->find('all');
        debug($in2);
        /* $this->loadModel('Destination');
          $dest=$this->Destination->find('all');
          foreach($dest as $des){
          $this->Destination->id=$des['Destination']['id'];
          $slug=strtolower($this->hyphenize($des['Destination']['name']));
          $this->Destination->saveField('slug',$slug);
          }
          debug($in2); */
        /* $this->loadModel('Country');
          $dest=$this->Country->find('all');
          foreach($dest as $des){
          $this->Country->id=$des['Country']['id'];
          $slug=strtolower($this->hyphenize($des['Country']['name']));
          $this->Country->saveField('slug',$slug);
          }
          debug($this->Country->find('all')); */
        $contain=array('Currency'=>array('fields'=>array('currency_code')));
        $institute=$this->Institute->find('all',array('contain'=>$contain,'fields'=>array('min_price','max_price','id')));
        debug($institute);
        foreach($institute as $insti){
            $min_price=round($this->Institute->exchange_rate_convert($insti['Currency']['currency_code'],'EUR',$insti['Institute']['min_price']),2);
            $max_price=round($this->Institute->exchange_rate_convert($insti['Currency']['currency_code'],'EUR',$insti['Institute']['max_price']),2);
            //$price[]=array('min'=>$min_price,'max'=>$max_price);
            $this->Institute->id=$insti['Institute']['id'];
            $this->Institute->saveField('max_price',$max_price);
            $this->Institute->saveField('min_price',$min_price);
        }
         $institute=$this->Institute->find('all',array('contain'=>$contain,'fields'=>array('min_price','max_price','id')));
        debug($institute);
        exit;
    }

    public function hyphenize($string) {
        return
                ## strtolower(
                preg_replace(
                array('#[\\s-]+#', '#[^A-Za-z0-9\. -]+#'), array(''),
                ##     cleanString(
                urldecode($string)
                ##     )
                )
        ## )
        ;
    }

    /**
     * Purpose:Find all latest vied school
     * created on :6 oct 2014
     * created by: Abhishek Tripathi
     */
    public function latest_school() {
        $institute = array();
        $institutes=array();
        $school = (json_decode($this->request->data['school_id'], true));
        $institute = $this->Institute->get_latest_school($school);
       if(!empty($school)){
        foreach($school as $sch){
        foreach ($institute as $ins) {
            if($sch==$ins['Institute']['id']){
            $ins['Institute']['embassy_image'] = (!empty($ins['Institute']['thumbnail_image']) ? DISPLAY_INSTITUE_DIR . $ins['Institute']['id'] . '/thumbnail_img_' . $ins['Institute']['thumbnail_image'] : 'images/no-image.jpg');
            $ins['Institute']['average_rating'] = (!empty($ins['Institute']['average_rating']) && $ins['Institute']['average_rating'] != 0.0 ? round($ins['Institute']['average_rating'], PHP_ROUND_HALF_UP): 0);
            $ins['Institute']['rating_user'] = (!empty($ins['Institute']['rating_user']) ? $ins['Institute']['rating_user'] : 0);
            $ins['Institute']['min_price']=round($this->Institute->exchange_rate_convert('EUR', CakeSession::read('CURRENCY'),$ins['Institute']['min_price']),0);
            $ins['Institute']['min_price'] = (!empty($ins['Institute']['min_price']) && $ins['Institute']['min_price'] != null ? $ins['Institute']['min_price'] : 'NA');
           
            $institutes[] = $ins;
            }
        }
       }
       }
        echo json_encode(array_reverse($institutes));
        exit;
    }

    /**
     * Purpose:Find all recomended school
     * created on :6 oct 2014
     * created by: Abhishek Tripathi
     */
    public function recomended_school() {
        $institute = array();
        $institutes = array();
        $this->loadModel('CoursePrice');
        $language_id = $this->request->data['language_id'];
        $country_id = $this->request->data['country_id'];
        $destination_id = $this->request->data['city_id'];
        $option['Institute.id'] = array(
            'value' => $this->request->data['institute_id'],
            'condition' => 'not_equal'
        );

        $instittue = $this->CoursePrice->get_search($x = '', $y = '', $z = $destination_id, $w = '', $option);

        if (!empty($instittue)) {
            
        } else {
            $instittue = $this->CoursePrice->get_search($x = '', $y = $country_id, $z = '', $w = '', $option);
            if (!empty($instittue)) {
                
            } else {
                $instittue = $this->CoursePrice->get_search($x = $language_id, $y = '', $z = '', $w = '', $option);
            }
        }
        $count = 1;
        foreach ($instittue as $ins) {
            $institutes[] = $ins;
            $count++;
            if ($count > 8) {
                break;
            }
        }

        echo json_encode($institutes);

        exit;
    }

    public function view_pdf($id = null) {
        $this->loadModel('CourseType');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        $this->loadModel('Destination');
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->CourseType->recursive = -1;
        $course = $this->CourseType->find('first', array(
            'conditions' => array(
                'CourseType.id' => $id
            )
        ));
        $this->Institute->recursive = -1;
        $institute = $this->Institute->find('first', array(
            'conditions' => array(
                'Institute.id' => $course['CourseType']['institute_id']
            ),
            'fields' => array(
                'id',
                'title',
                'logo',
                'country_id',
                'destination_id',
                'slug'
            )
        ));
        $this->Country->recursive = -1;
        $country = $this->Country->find('first', array(
            'conditions' => array(
                'Country.id' => $institute['Institute']['country_id']
            ),
            'fields' => array(
                'id',
                'name'
            )
        ));
        $this->Destination->recursive = -1;
        $destination = $this->Destination->find('first', array(
            'conditions' => array(
                'Destination.id' => $institute['Institute']['destination_id']
            ),
            'fields' => array(
                'id',
                'name'
            )
        ));
        $this->CoursePrice->recursive = -1;
        $course_price = $this->CoursePrice->find('all', array(
            'conditions' => array(
                'AND' => array(
                    'CoursePrice.course_types_id' => $course['CourseType']['id'],
                    'CoursePrice.year' => date('Y')
                )
            )
        ));
        $this->Course->recursive = -1;
        $course_cat = $this->Course->find('first', array(
            'conditions' => array(
                'Course.id' => $course['CourseType']['course_id']
            ),
            'fields' => array(
                'id',
                'title'
            )
        ));
        $name = 'Course' . date('ymdhis');


        //----------------language_level-----------------------------------------------
        $this->set(compact('course', 'institute', 'country', 'destination', 'course_price', 'course_cat', 'name'));

        $this->layout = '/pdf/default';

        return $name . '.pdf';
    }
    
    
    
    public function previsualize($id=null){
        $this->layout='prvious';
        $this->loadModel('Facility');
        $this->loadModel('InstituteGallery');
        $this->loadModel('CourseType');
        $this->loadModel('Course');
        $this->loadModel('AccomodationType');
        $this->loadModel('AccomodationPrice');
        $this->loadModel('Accomodation');
        $this->loadModel('AccomodationTypeAccomodationFacilities');
        $this->loadModel('Country');
        $this->loadModel('Exam');
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('InstituteExam');
        $this->loadModel('Review');
        $name = $this->params['slug'];

        $institute =  $this->Institute->find('first',array('conditions'=>array('AND'=>array('Institute.id'=>$id,'Institute.previous'=>1))));
    
        
        //---------------------------set cookiew latest viewed school-----6 oct 2014------------------------//
        $arr = array();
        $arr = $this->Cookie->read('institute_id');
        if (count($arr)) {
            if (!in_array($institute['Institute']['id'], $arr)) {
                if (count($arr) >= 8) {
                    array_shift($arr);
                }

                array_push($arr, $institute['Institute']['id']);
            }
        } else {
            $arr[] = $institute['Institute']['id'];
        }
        $this->Cookie->write('institute_id', $arr, false, 3600 * 24 * 60);
        //$this->Cookie->delete('institute_id');
        //------------------------------------------------------------------------------------------------------------//

        $id = $institute['Institute']['id'];
        $language = $institute['Language']['title'];
        $country_name = $institute['Country']['name'];
        $city_name = $institute['Destination']['name'];
        $school_name = $institute['Institute']['title'];
        $country_slug=$institute['Country']['slug'];
        $city_slug=$institute['Destination']['slug'];
        $this->AccomodationTypeAccomodationFacilities->bindModel(array(
            'belongsTo' => array(
                'AccomodationFacility' => array(
                    'className' => 'AccomodationFacility',
                    'fields' => array(
                        'AccomodationFacility.title',
                        'AccomodationFacility.icon'
                    )
                )
            )
        ));

        $this->AccomodationType->bindModel(array(
            'hasMany' => array(
                'AccomodationTypeAccomodationFacilities' => array(
                    'className' => 'AccomodationTypeAccomodationFacilities',
                    'fields' => array(
                        'AccomodationTypeAccomodationFacilities.accomodation_facility_id'
                    )
                )
            )
        ));
        $this->Accomodation->bindModel(array(
            'hasMany' => array(
                'AccomodationType' => array(
                    'className' => 'AccomodationType',
                    'conditions' => array(
                        'AND' => array(
                            'institute_id' => $id,
                            'published' => 1
                        )
                    )
                )
            )
        ));
        $this->AccomodationType->unBindModel(array(
            'belongsTo' => array(
                'Institute'
            )
        ));
        $this->AccomodationPrice->unBindModel(array(
            'belongsTo' => array(
                'Institute'
            )
        ));
        $this->AccomodationType->recursive = 2;

        $accomodationtype = $this->Accomodation->find('all', array(
            'fields' => array(
                'Accomodation.id',
                'Accomodation.title',
                'Accomodation.slug'
            ),
            'recursive' => 5
        ));
        if (!empty($accomodationtype)) {
            //debug($accomodationtype);
            $this->set('accomodationtype', $accomodationtype);
        }

        $this->Course->bindModel(array(
            'hasMany' => array(
                'CourseType' => array(
                    'className' => 'CourseType',
                    'conditions' => array(
                        'AND' => array(
                            'institute_id' => $id,
                            'published' => 1
                        )
                    )
                )
            )
        ));

        $this->CourseType->unBindModel(array(
            'belongsTo' => array(
                'Institute'
            )
        ));
        $this->Course->recursive = 2;
        $coursetype = $this->Course->find('all');
        if (!empty($coursetype)) {

            $this->set('coursetype', $coursetype);
        }

        $facility = $this->Facility->find('list', array(
            'joins' => array(
                array(
                    'table' => 'institute_facilities',
                    'alias' => 'ifacility',
                    'type' => 'inner',
                    'foreignKey' => false,
                    'conditions' => array(
                        'ifacility.facility_id = Facility.id and ifacility.institute_id = ' . $id
                    )
                )
            ),
            'fields' => array(
                'Facility.title',
                'Facility.icon'
            )
        ));
        if (!empty($facility)) {
            $this->set('facility', $facility);
        }
        $institute_gallery = $this->InstituteGallery->find('list', array(
            'conditions' => array(
                'InstituteGallery.institute_id' => $id
            ),
            'fields' => array(
                'img'
            )
        ));
        if (!empty($institute_gallery)) {
            $this->set('institute_gallery', $institute_gallery);
        }
        $options['joins'] = array(
            array(
                'table' => 'institute_exams',
                'alias' => 'InstituteExam',
                'type' => 'inner',
                'conditions' => array(
                    'InstituteExam.exam_id = Exam.id && InstituteExam.institute_id =' . $id . ''
                )
            )
        );
        $exam = $this->Exam->find('list', $options);
        if (!empty($exam)) {

            $this->set('exam', $exam);
        }

        //----------------list of accredation ------------------------------
        $this->loadModel('Accreditation');
        $accrediation_list = $this->Accreditation->find('list', array(
            'fields' => array(
                'id',
                'image_name'
            )
        ));
        $view = 'school';

        //------------------list of rating----------------------------------

        $reviews = $this->Review->reviews($id, $this->request->clientIp());

        //----------------------student profile-------------
        //------------------List of courses related to institute select---------------------------------
        $inst_courses = $this->CourseType->find('all', array('conditions' => array('CourseType.institute_id' => $id), 'fields' => array('CourseType.id,CourseType.title')));

        $student_profile = json_decode($institute['Institute']['student_profile'], true);
        if (!empty($student_profile)) {
            $new_arr = array_merge($institute['Institute'], $student_profile);
            $institute ['Institute'] = $new_arr;
        }
        //----------------------extra fee---------------------------------
        $extra_fee = $this->InstituteExtraFee->find('all', array('conditions' => array('AND'=>array('InstituteExtraFee.institute_id' => $id,'InstituteExtraFee.published'=>1))));

        //---------------LanguageLevel------------------------------------
        $this->loadModel('LanguageLevel');
        $level = $this->LanguageLevel->find('all');
        
        //-------------------Events---------------------------------------
        $this->loadModel('Event');
         $event=$this->Event->find('all',array('conditions'=>array('Event.institute_id'=>$id),'order'=>'Event.start_date ASC'));
        
        //----------------------language-List-------------------------------------------
        $this->loadModel('Language');
        $languages_list = $this->Language->find('list', array('fields' => array('id', 'title')));
        
        //--------------------currency------------------------------------------------------
        $this->loadModel('Currency');
        $currency_info=$this->Currency->find('first',array('conditions'=>array('Currency.id'=>$institute['Institute']['currency_id']),'fields'=>array('name','currrency_symbol','currency_code')));
       
        //---------------------tootip----------------------------------------------------------
        $this->loadModel('Tooltip');
        $tooltip=$this->Tooltip->find('all');
       
        $LAYOUT_META_TITLE = '[school] [city] | Best price guarantee';
        $LAYOUT_META_DESCRIPTION = "Student reviews, free quote and online booking 24/7 with [school], [language] school in [country]. Best price guarantee or we'll refund the difference to you.";
        $search = array('[language]','[country]', '[city]','[school]');
        $replace_from = array($language, $country_name, $city_name,$institute['Institute']['title']);
        if(!empty($institute['Institute']['seo_detail'])){
            $seo=  json_decode($institute['Institute']['seo_detail'], true);
            if(!empty($seo['meta_title'])){
               $LAYOUT_META_TITLE=$seo['meta_title'] ;
            }
            if(!empty($seo['meta_description'])){
               $LAYOUT_META_TITLE=$seo['meta_description'] ;
            }
            
        }
        $LAYOUT_META_TITLE = str_replace($search, $replace_from, $LAYOUT_META_TITLE);
        $LAYOUT_META_DESCRIPTION = str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION);
        
        
       
        $this->set('institute_id', $id);
        $rating = $this->Review->rating($id);
        $og_image=SITE_URL.'uploads/institute/'.$institute['Institute']['id'].'/main_img_'.$institute['Institute']['main_img'];
        $this->set(compact('institute', 'language', 'country_name', 'city_name', 'school_name', 'accrediation_list', 'view', 'rating', 'reviews', 'extra_fee', 'inst_courses','level','event','languages_list','currency_info','country_slug','city_slug','tooltip','og_image','LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION'));
        $this->autoRender = FALSE;
        $this->render('index');
    }
    
    public function array_remove_by_value($array, $value)
        {
           return array_values(array_diff($array, array($value)));
        }

    public function image_repalce(){
        $this->loadModel('InstituteGallery');
        $dir = "uploads/institute/";
                
            // Open a directory, and read its contents
            if (is_dir($dir)){
              if ($dh = opendir($dir)){
                while (($file = readdir($dh)) !== false){
                    $ne='uploads/institute/'.$file.'/gallery';
                    unset($gallery);
                    if (is_dir($ne)){
                            if ($dhf = opendir($ne)){
                              while (($fileh = readdir($dhf)) !== false){

                                echo "filename:" . $fileh . "<br>";
                                if($fileh!='.' && $fileh!='..' && $fileh[0]!='V' && $fileh[0]!='L'){
                                $gallery[]=array('institute_id'=>$file,
                                  'img'=>$fileh
                                  );
                              }
                              }
                              
                             
                            }
                          }
                          $this->InstituteGallery->saveAll($gallery);
                  echo "filename:" . $file . "<br>";
                }
                closedir($dh);
              }
            }
            exit;
    }
    
    public function import_data(){
        $this->loadModel('Subject');
        $this->loadModel('I18nModel');
        $data=$this->Subject->find('list');
        //debug($data);exit;
        $fields=configure::read('language');
        foreach($data as $key=>$value){
            foreach($fields as $field){
                if($field=='title'){
                $arr=array(
                    'locale'=>'spa',
                    'model'=>'Language',
                    'foreign_key'=>$key,
                    'field'=>$field,
                    'content'=>$value,
                    
                );
                }else{
                    if($field=='slug'){
                         $arr=array(
                    'locale'=>'spa',
                    'model'=>'Language',
                    'foreign_key'=>$key,
                    'field'=>$field,
                    'content'=>$this->hyphenize($value),
                    
                );
                    }else{
                         $arr=array(
                    'locale'=>'spa',
                    'model'=>'Language',
                    'foreign_key'=>$key,
                    'field'=>$field,
                    'content'=>'',
                    
                );
                    }
                }
               //debug($arr);
                $this->I18nModel->create();
              $this->I18nModel->save(array('I18nModel'=>$arr));
            
                   
            }

            
        }
        debug($data);exit;
        }

}
