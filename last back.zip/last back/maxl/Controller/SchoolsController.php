<?php

/**
 * Project : Controller to save form submitted by schools
 * Author : Rupesh Sharma
 * Creation Date : 10 may 2014
 * Description : saving data from schools
 */
App::uses('Language', 'Admin.Model');
class SchoolsController extends AppController {

    var $uses = array(
        'Admin.Institute', 'CourseType', 'Destination', 'Country',
        'Language', 'Facility', 'InstituteFacility', 'Exam',
        'InstituteExam', 'Destination', 'Course','AccomodationType','InstituteExtraFee');
    
   

    function beforeFilter() {
        parent::beforeFilter();
        $this->layout = 'schoolform';
    }

        
        /**
         *Purpose:To get information of schools on search
         * created on:12 june 2014
         * @param:language id,destination id and weeks
         * @Author: Abhishek TRipathi 
         */
        
        public function search($language=null,$country=null,$city=null,$week=null){
        	debug($this->params);exit;
            $this->layout='default';
            $this->loadModel('CoursePrice');
            $this->loadModel('Course');
		    $this->loadModel('Destination');
			$school_info=array();
			
			//set search parament in variable
            $language=$language;
			$country_name=$country;
			
			$city_name=$city;
			 $this->Destination->bindModel(
                array('belongsTo' => array(
                        'Country' => array(
                            'className' => 'Country',
                            'foreignKey' => 'country_id'
                        )
                    )
                )
        );
			
            //--------------------------Language----------------------
            $language_info=$this->Language->find('first',array('conditions'=>array('Language.title'=>$language)));
			
            $language_id=$language_info['Language']['id'];
           //----------------------------Destination----------------------------------
		   	if($city==null && $country==null){
		   		   $Destination=$this->Destination->find('first',array('conditions'=>array('AND'=>array('Destination.name'=>$city,'Country.name'=>$country))));
		
								$destination_id=$Destination['Destination']['id'];
								$weeks=$week;
		            $country_id=$this->Destination->find('first',array('conditions'=>array('Destination.id'=>$destination_id),'fields'=>array('country_id')));
					$this->Country->recursive=-1;
		            $school_list=$this->Institute->get_school_list($country_id['Destination']['country_id']);
		            $this->set('school_list',$school_list);
					$country_name=$this->Country->find('first',array('conditions'=>array('Country.id'=>$country_id['Destination']['country_id']),'fields'=>array('name')));
					$country_name=$country_name['Country']['name'];
					$destination=$this->Destination->findById($destination_id);
					 $search=array('[language]','[country]','[number]');
					$replace_from=array($language,$country_name,count($school_info));
					
					$destination['Destination']['main_title']=str_replace($search, $replace_from, $destination['Destination']['main_title']);
					$destination['Destination']['sub_title1']=str_replace($search, $replace_from, $destination['Destination']['sub_title1']);
					$destination['Destination']['sub_title2']=str_replace($search, $replace_from, $destination['Destination']['sub_title2']);
					$destination['Destination']['image']="/files/destination/".$destination['Destination']['flag_image'];
					$this->set('destination_info',$destination);
			}
			else{
				    
		            $school_list=$this->Institute->get_school_list_lang($language_id);
		            $this->set('school_list',$school_list);
					$country_name='';
					 $search=array('[language]','[number]');
					 $replace_from=array($language,count($school_info));
					$destination['Destination']['main_title']=str_replace($search, $replace_from, $language_info['Language']['main_title']);
					$destination['Destination']['sub_title1']=str_replace($search, $replace_from, $language_info['Language']['sub_title1']);
					$destination['Destination']['sub_title2']=str_replace($search, $replace_from, $language_info['Language']['sub_title2']);
					$destination['Destination']['image']="/files/language/".$language_info['Language']['image'];
					$destination['Destination']['text_bottom']=$language_info['Language']['text_bottom'];
					$this->set('destination_info',$destination);
			}
		   
		    $this->Institute->recursive=1;
		
            $school_info=$this->CoursePrice->get_search($language_id,$destination_id,$weeks);
            if(isset($school_info)){
                $this->set('schools',$school_info);
            }
		
		
            /*set parameters*/
        
			
	       
            $this->set('country_name',$country_name);
            $this->set('language',$language); 
            $this->set('destination',$this->Country->get_country());
            $this->set('language_list',$this->Language->find('list', array('fields' => array('title','title'))));
            $this->set('courses_type',$this->Course->find('list',array('fields'=>array('id','title'))));
            $this->set('weeks',Configure::read('ARR_WEEKS'));
            
            //debug($school_list);exit;
        }
        
		
		 /**
 *Purpose:To get information  from ajax of schools on search
 * created on:24 june 2014
 * @param:language id,destination id and weeks
 * @Author: Abhishek TRipathi 
 */
         public function get_search_result(){
			 $this->layout="ajax";
			 $this->loadModel('CoursePrice');
             $this->loadModel('Course');
			 $this->loadModel('CourseType');
             $this->loadModel('Language');
             $language=$this->request->data['language'];
             $weeks=$this->request->data['weeks'];
			 $destination_id=$this->request->data['destination_id'];
             $language_id=$this->Language->find('first',array('conditions'=>array('Language.title'=>$language),'fields'=>array('id')));
             $language_id=$language_id['Language']['id'];
           
			 //$schools=$this->Institute->get_search($language_id,$destination_id,$weeks);
			 $school_info=array();
			$school_info=$this->CoursePrice->get_search($language_id,$destination_id,$weeks);
         
            if(isset($school_info)){
                $this->set('schools',$school_info);
            }
            $this->set('response',$school_info);
            $this->autoRender=false;
            $this->render('ajax');
			 }

			 /**
 *Purpose:To get 
 * created on:24 june 2014
 * @param:language id,destination id and weeks
 * @Author: Abhishek TRipathi 
 */ 
		 
       public function get_data()
          {
			$this->layout="ajax";
			$this->loadModel('Country');
			$this->Country->recursive=-1;
			$country=$this->Country->find('all');
			foreach($country as $count){
				$country_list[]=$count['Country'];
				}
			$this->set('response',$country_list);
			
			$this->autorender=false;
			$this->render('ajax');
			//$this->render->type('json');
	}	
		  
		  
	 
    
   /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function add_extra_fee($institute_id) {
        	$this->loadModel('Admin.Institute');
    	$this->layout="school_info";
		$this->set('institute_id',$institute_id);
        $errors = array();
        $add_errors = array();
            $this->loadModel('Currency');
        $error_flag = false;
        if (!empty($this->data)) {
            $data_arr = $this->data;
			
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;
          
           if($this->InstituteExtraFee->save($data_arr)){
           	$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			
            $this->redirect(array('controller' => 'Schools', 'action' => 'edit_form', $institute_id));
           }
				else{
						$this->Session->setFlash(__('Please try again.'), 'flash_success');
				}
				            
        }
           $currency_code=$this->Institute->find('first',array('conditions'=>array('Institute.id'=> $institute_id),'fields'=>array('currency_id')));
                    
                              $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$currency_code['Institute']['currency_id']),'fields' => array('currrency_symbol')));
                         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']); 
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
		//$this -> redirect($this -> referer());
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
    }
   /**
     * Purpose : Listing of Extra Fee
     * Created on : 16 May 2014
     * Author : Rupesh Sharma
     */
    function list_extra_fee($id) {
    	$this->layout="school_info";
		$this->set('institute_id',$id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );

        $result_arr = $this->paginate('InstituteExtraFee');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Extra Fee';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list_extra_fee');
    }
	
	   /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE for extra Fee
     * Created on : 9 May 2014
     * Author : Rupesh Sharma
     */
    function extra_fee_manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->InstituteExtraFee->deleteAll(array('InstituteExtraFee.id' => $ids), true);
                    $message = 'Deleted successfully.';
                }
                elseif($task == "featured")
                {
                        $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "1"), array('InstituteExtraFee.id' => $ids));
                        $message = 'Activated successfully.';
                }
                elseif($task == "unfeatured")
                {
                        $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "0"), array('InstituteExtraFee.id' => $ids));
                        $message = 'Inactivated successfully.';
                }
	elseif($task == "Duplicate")
                {
                	$instituteExtrafee_list=$this->InstituteExtraFee->find('all',array('conditions'=>array('InstituteExtraFee.id'=>$ids)));
					
					$instituteExtrafee_list2=Hash::remove($instituteExtrafee_list,'{n}.InstituteExtraFee.id');
			        $this->InstituteExtraFee->saveAll($instituteExtrafee_list2);
					$message = 'Dublicate successfully.';
                }


                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }
		  
	
	
 /**
 *Purpose:To edit school submission form 
 * created on:24 june 2014
 * @param:language id,destination id and weeks
 * @Author: Abhishek TRipathi 
 */	  
		  
		 public function edit_form($id=null){
       //------------mode check-----------------------
                  //   configure::write('debug',2);
                             $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('mode')));
       // debug($mode);exit;
        if($mode['Institute']['mode']==0){
            $this->redirect(array('controller'=>'Schools','action'=>'mode'));
        }
      $this->layout="school_info";
       if($this->params['action']=='edit_form'){
           $this->set('action',1);
       }
       
       $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Country');
        $this->loadModel('Language');
        $this->loadModel('Facility');
        $this->loadModel('Exam');
        $this->loadModel('Currency');
        $this->loadModel('Accreditation');
        $this->loadModel('Destination');
        $this->loadModel('InstituteExam');
        $this->loadModel('InstituteFacility');
        $this->loadModel('Event');
        $this->loadModel('Accomodation');
        
        $this->loadModel('CourseSubcategory');
        $this->set('view_title', 'Add Institute');
        $this->set('errors', $errors);
       
        $language_spoken=$this->Language->find('list',array('fields'=>array('id','title')));
        $this->set('spoken_language',$language_spoken);
        $day=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
        $this->set('day',$day);
        $data_arr = $this->Institute->find('first',array('conditions'=>array('AND'=>array('Institute.id'=>$id,'Institute.mode'=>1))));
       
        
         for ($i = 1; $i < 13; $i++) {
            $time[] = $i . ':00';
        }
        $this->set('time', $time);
  
         $next_year_date=array('31 August','30 september','31 October','30 November','31 December','31 january of next year');
                $this->set('next_year_date',$next_year_date);
               $accreditation = $this->Accreditation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accreditation));       
        $this->set('accreditation', $accreditation);
        if(isset($data_arr['Institute']['currency_id'])){  
                    $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$data_arr['Institute']['currency_id']),'fields' => array('currrency_symbol')));

		 if(!empty($currency_symbol)){
		 	
         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']);  
         }     
					else{
				$this->set('currency_symbol','&nbsp;');		
					}   
		}
        // json decode 
        if(isset($data_arr['Institute']['student_profile'])){
        $student_profile = json_decode($data_arr['Institute']['student_profile'], true);
        if (!empty($student_profile)) {
            $new_arr = array_merge($data_arr['Institute'], $student_profile);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		if(isset($data_arr['Institute']['enrollment'])){
        $enrollment = json_decode($data_arr['Institute']['enrollment'], true);
        if (!empty($enrollment)) {
            $new_arr = array_merge($data_arr['Institute'], $enrollment);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['invoice'])){
        $invoice = json_decode($data_arr['Institute']['invoice'], true);
        if (!empty($invoice)) {
            $new_arr = array_merge($data_arr['Institute'], $invoice);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		 if(isset($data_arr['Institute']['bank'])){
        $bank = json_decode($data_arr['Institute']['bank'], true);
        if (!empty($bank)) {
            $new_arr = array_merge($data_arr['Institute'], $bank);
            $data_arr = array('Institute' => $new_arr);
        }
        }
       if(isset($data_arr['Institute']['payment_detail'])){
        $payment = json_decode($data_arr['Institute']['payment_detail'], true);
        if (!empty($payment)) {
            $new_arr = array_merge($data_arr['Institute'], $payment);
            $data_arr = array('Institute' => $new_arr);
        }
	   }
         if(isset($data_arr['Institute']['commission'])){
        $commission = json_decode($data_arr['Institute']['commission'], true);
        if (!empty($commission)) {
            $new_arr = array_merge($data_arr['Institute'], $commission);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		 if(isset($data_arr['Institute']['recogination'])){
         $recogination = json_decode($data_arr['Institute']['recogination'], true);
        if (!empty($recogination)) {
            $new_arr = array_merge($data_arr['Institute'], $recogination);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		  if(isset($data_arr['Institute']['course_detail'])){
           $course = json_decode($data_arr['Institute']['course_detail'], true);
        if (!empty($course)) {
            $new_arr = array_merge($data_arr['Institute'], $course);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		  if(isset($data_arr['Institute']['accommodation_detail'])){
            $accommodation= json_decode($data_arr['Institute']['accommodation_detail'], true);
        if (!empty($accommodation)) {
            $new_arr = array_merge($data_arr['Institute'], $accommodation);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		    if(isset($data_arr['Institute']['spoken_languages'])){
             $spoken_languages= json_decode($data_arr['Institute']['spoken_languages'], true);
        if (!empty($spoken_languages)) {
            $new_arr = array_merge($data_arr['Institute'], $spoken_languages);
            $data_arr = array('Institute' => $new_arr);
        }
			}
			 if(isset($data_arr['Institute']['transfer_detail'])){
              $transfer= json_decode($data_arr['Institute']['transfer_detail'], true);
        if (!empty($transfer)) {
            $new_arr = array_merge($data_arr['Institute'], $transfer);
            $data_arr = array('Institute' => $new_arr);
        }
			 }
			  if(isset($data_arr['Institute']['seo_detail'])){
              $seo= json_decode($data_arr['Institute']['seo_detail'], true);
        if (!empty($seo)) {
            $new_arr = array_merge($data_arr['Institute'], $seo);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['visa_basic_detail'])){
         $visa_basic= json_decode($data_arr['Institute']['visa_basic_detail'], true);
        if (!empty($visa_basic)) {
            $new_arr = array_merge($data_arr['Institute'], $visa_basic);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
        $currency = $this->Currency->find('list', array('fields'=>array('id','currency_code')));
		
		//$res = Hash::flatten($currency);
        $this->set('currency', $currency);
	
        $event=$this->Event->find('all',array('conditions'=>array('Event.institute_id'=>$id)));
        $this->set('event',$event);
        $this->data = $data_arr;
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $destination = $this->Destination->find("list", array("conditions" => array("Destination.country_id" => $this->data["Institute"]["country_id"]), "fields" => array("id", "name")));
        $this->set('destination', $destination);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $selected_facility = $this->InstituteFacility->find('list', array('conditions' => array('InstituteFacility.institute_id' => $id), 'fields' => array('facility_id')));
        $this->set('selected_facility', $selected_facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $selected_exam = $this->InstituteExam->find('list', array('conditions' => array('InstituteExam.institute_id' => $id), 'fields' => array('exam_id')));
        $this->set('selected_exam', $selected_exam);
        //$this->render('edit_mode');
        //$this->autoRender = false;
        
           $courese_category = $this->CourseSubcategory->find('list', array('fields' => array('id', 'title')));
        (natcasesort($courese_category));
        $this->set('courese_category', $courese_category);
        
          $accomodation_category = $this->Accomodation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accomodation_category));
        $this->set('accomodation_category', $accomodation_category);
        
        
    /*----------------------------------------------------------------------------------------------------------*/    
        
              $cond_arr = array('CourseType.institute_id' => $id);
        $this->set('institute_id',$id);

        $this->CourseType->bindModel(
                array('belongsTo' => array(
                        'Course' => array(
                            'className' => 'Course',
                            'foreignKey' => 'course_id'
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
            $cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('CourseType.id' => 'desc')
        );

        $result_arr_course = $this->paginate('CourseType');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_course', 'ARR_FEATURED', 'view_title'));
        //$this->render('list_sub_course');
        
        
        /*-------------------------------------------------accomodation------------------------------------*/
        $cond_arr = array('AccomodationType.institute_id'=>$id);
		  $this->set('institute_id',$id);

		$this->AccomodationType->bindModel(
        array('belongsTo' => array(
	                'Accomodation' => array(
	                    'className' => 'Accomodation',
	                    'foreignKey' => 'accomodation_id',
	                    'fields' =>array('title')

	                )
	            )
	        )
	    );

		if( isset( $_GET['filter'] ) )
		{

			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$cond_arr = array_merge($cond_arr, array('AccomodationType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('AccomodationType.id' => 'desc'),
			'recursive' => 3
		);

		$result_arr_accomodation = $this->paginate('AccomodationType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		
		
		$this->set(compact('result_arr_accomodation', 'ARR_FEATURED', 'view_title'));
		
		//--------------------------------------------------------------fee-----------------------------------------------
			$this->layout="school_info";
		$this->set('institute_id',$id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );
      
        $result_arr_fee = $this->paginate('InstituteExtraFee');
		 //debug($result_arr_fee);exit;
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_fee', 'ARR_FEATURED', 'view_title'));
       //------------------------------------------------------------gallery--------------=================================
       $institute_id=$id;
       
        $this->set('institute_id',$institute_id);
    	$this->layout="school_info";
		
        $this->loadModel('InstituteGallery');
        //show gallery images
      
        $this->Upload = $this->Components->load('Upload');
        $upload_path = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/';
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        
        if (!empty($id)) {
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $id), array('InstituteGallery.institute_id' => $id. '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }
			
       
        }	
		  $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }
        
         if($data_arr['Institute']['listing_type']==2){
            $this->render('edit_form_premium');
             $this->autoRender = false;
         }else{
           // $this->render('edit_mode');
         }
         // $this->render('edit_mode');
       

   }
		  		 
   public function mode(){
      $this->layout="school_info";  
   }
   
       /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Abhishek Tripathi
     */
    function edit_extra_fee($institute_id, $id) {
        
           //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('mode')));
                           
                         if($mode['Institute']['mode']==0){
                            $this->redirect(array('controller'=>'Schools','action'=>'mode'));
                         }
            //------------mode check------------------------
        
         	$this->layout="school_info";
     	$this->loadModel('Admin.Institute');
        $this->set('institute_id', $institute_id);
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Currency');
        $this->InstituteExtraFee->id = $id;
        if (!empty($this->data)) {
            $data_arr = $this->data;
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;

            $this->InstituteExtraFee->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
           $this->redirect(array('controller' => 'Schools', 'action' => 'edit_form', $institute_id));
        }
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
        $selected_type = $this->InstituteExtraFee->find('list', array('conditions' => array('InstituteExtraFee.id' => $id), 'fields' => array('id')));
        $this->set('selected_type', $selected_type);
        $data_arr = $this->InstituteExtraFee->findById($id);
        $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $institute_id), 'fields' => array('currency_id')));
        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);
        $this->data = $data_arr;
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
        
       
    }
    
    
    
     public function edit_form_premium($id=null){
       //------------mode check-----------------------
                  //   configure::write('debug',2);
                             $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('mode')));
       // debug($mode);exit;
        if($mode['Institute']['mode']==0){
            $this->redirect(array('controller'=>'Schools','action'=>'mode'));
        }
      $this->layout="school_info";
       if($this->params['action']=='edit_form_premium'){
           $this->set('action',1);
       }
       
       $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Country');
        $this->loadModel('Language');
        $this->loadModel('Facility');
        $this->loadModel('Exam');
        $this->loadModel('Currency');
        $this->loadModel('Accreditation');
        $this->loadModel('Destination');
        $this->loadModel('InstituteExam');
        $this->loadModel('InstituteFacility');
        $this->loadModel('Event');
         $this->loadModel('Course');
          $this->loadModel('Accomodation');
        $this->set('view_title', 'Add Institute');
        $this->set('errors', $errors);
       
        $language_spoken=$this->Language->find('list',array('fields'=>array('id','title')));
        $this->set('spoken_language',$language_spoken);
        $day=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
        $this->set('day',$day);
        $data_arr = $this->Institute->find('first',array('conditions'=>array('AND'=>array('Institute.id'=>$id,'Institute.mode'=>1))));
       
        
         for ($i = 1; $i < 13; $i++) {
            $time[] = $i . ':00';
        }
        $this->set('time', $time);
  
         $next_year_date=array('31 August','30 september','31 October','30 November','31 December','31 january of next year');
                $this->set('next_year_date',$next_year_date);
               $accreditation = $this->Accreditation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accreditation));       
        $this->set('accreditation', $accreditation);
        if(isset($data_arr['Institute']['currency_id'])){  
                    $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$data_arr['Institute']['currency_id']),'fields' => array('currrency_symbol')));

		 if(!empty($currency_symbol)){
		 	
         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']);  
         }     
					else{
				$this->set('currency_symbol','&nbsp;');		
					}   
		}
        // json decode 
        if(isset($data_arr['Institute']['student_profile'])){
        $student_profile = json_decode($data_arr['Institute']['student_profile'], true);
        if (!empty($student_profile)) {
            $new_arr = array_merge($data_arr['Institute'], $student_profile);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		if(isset($data_arr['Institute']['enrollment'])){
        $enrollment = json_decode($data_arr['Institute']['enrollment'], true);
        if (!empty($enrollment)) {
            $new_arr = array_merge($data_arr['Institute'], $enrollment);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['invoice'])){
        $invoice = json_decode($data_arr['Institute']['invoice'], true);
        if (!empty($invoice)) {
            $new_arr = array_merge($data_arr['Institute'], $invoice);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		 if(isset($data_arr['Institute']['bank'])){
        $bank = json_decode($data_arr['Institute']['bank'], true);
        if (!empty($bank)) {
            $new_arr = array_merge($data_arr['Institute'], $bank);
            $data_arr = array('Institute' => $new_arr);
        }
        }
       if(isset($data_arr['Institute']['payment_detail'])){
        $payment = json_decode($data_arr['Institute']['payment_detail'], true);
        if (!empty($payment)) {
            $new_arr = array_merge($data_arr['Institute'], $payment);
            $data_arr = array('Institute' => $new_arr);
        }
	   }
         if(isset($data_arr['Institute']['commission'])){
        $commission = json_decode($data_arr['Institute']['commission'], true);
        if (!empty($commission)) {
            $new_arr = array_merge($data_arr['Institute'], $commission);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		 if(isset($data_arr['Institute']['recogination'])){
         $recogination = json_decode($data_arr['Institute']['recogination'], true);
        if (!empty($recogination)) {
            $new_arr = array_merge($data_arr['Institute'], $recogination);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		  if(isset($data_arr['Institute']['course_detail'])){
           $course = json_decode($data_arr['Institute']['course_detail'], true);
        if (!empty($course)) {
            $new_arr = array_merge($data_arr['Institute'], $course);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		  if(isset($data_arr['Institute']['accommodation_detail'])){
            $accommodation= json_decode($data_arr['Institute']['accommodation_detail'], true);
        if (!empty($accommodation)) {
            $new_arr = array_merge($data_arr['Institute'], $accommodation);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		    if(isset($data_arr['Institute']['spoken_languages'])){
             $spoken_languages= json_decode($data_arr['Institute']['spoken_languages'], true);
        if (!empty($spoken_languages)) {
            $new_arr = array_merge($data_arr['Institute'], $spoken_languages);
            $data_arr = array('Institute' => $new_arr);
        }
			}
			 if(isset($data_arr['Institute']['transfer_detail'])){
              $transfer= json_decode($data_arr['Institute']['transfer_detail'], true);
        if (!empty($transfer)) {
            $new_arr = array_merge($data_arr['Institute'], $transfer);
            $data_arr = array('Institute' => $new_arr);
        }
			 }
			  if(isset($data_arr['Institute']['seo_detail'])){
              $seo= json_decode($data_arr['Institute']['seo_detail'], true);
        if (!empty($seo)) {
            $new_arr = array_merge($data_arr['Institute'], $seo);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['visa_basic_detail'])){
         $visa_basic= json_decode($data_arr['Institute']['visa_basic_detail'], true);
        if (!empty($visa_basic)) {
            $new_arr = array_merge($data_arr['Institute'], $visa_basic);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
        $currency = $this->Currency->find('list', array('group'=>'Currency.currency_code','fields'=>array('id','currency_code')));
		
		//$res = Hash::flatten($currency);
        $this->set('currency', $currency);
	
        $event=$this->Event->find('all',array('conditions'=>array('Event.institute_id'=>$id)));
        $this->set('event',$event);
        $this->data = $data_arr;
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $destination = $this->Destination->find("list", array("conditions" => array("Destination.country_id" => $this->data["Institute"]["country_id"]), "fields" => array("id", "name")));
        $this->set('destination', $destination);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $selected_facility = $this->InstituteFacility->find('list', array('conditions' => array('InstituteFacility.institute_id' => $id), 'fields' => array('facility_id')));
        $this->set('selected_facility', $selected_facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $selected_exam = $this->InstituteExam->find('list', array('conditions' => array('InstituteExam.institute_id' => $id), 'fields' => array('exam_id')));
        $this->set('selected_exam', $selected_exam);
        
        $courese_category = $this->Course->find('list', array('fields' => array('id', 'title')));
        (natcasesort($courese_category));
        $this->set('courese_category', $courese_category);
        
          $accomodation_category = $this->Accomodation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accomodation_category));
        $this->set('accomodation_category', $accomodation_category);
        //$this->render('edit_mode');
        //$this->autoRender = false;
        
        
    /*----------------------------------------------------------------------------------------------------------*/    
        
              $cond_arr = array('CourseType.institute_id' => $id);
        $this->set('institute_id',$id);

        $this->CourseType->bindModel(
                array('belongsTo' => array(
                        'Course' => array(
                            'className' => 'Course',
                            'foreignKey' => 'course_id'
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
            $cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('CourseType.id' => 'desc')
        );

        $result_arr_course = $this->paginate('CourseType');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_course', 'ARR_FEATURED', 'view_title'));
        //$this->render('list_sub_course');
        
        
        /*-------------------------------------------------accomodation------------------------------------*/
        $cond_arr = array('AccomodationType.institute_id'=>$id);
		  $this->set('institute_id',$id);

		$this->AccomodationType->bindModel(
        array('belongsTo' => array(
	                'Accomodation' => array(
	                    'className' => 'Accomodation',
	                    'foreignKey' => 'accomodation_id',
	                    'fields' =>array('title')

	                )
	            )
	        )
	    );

		if( isset( $_GET['filter'] ) )
		{

			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$cond_arr = array_merge($cond_arr, array('AccomodationType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('AccomodationType.id' => 'desc'),
			'recursive' => 3
		);

		$result_arr_accomodation = $this->paginate('AccomodationType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		
		
		$this->set(compact('result_arr_accomodation', 'ARR_FEATURED', 'view_title'));
		
		//--------------------------------------------------------------fee-----------------------------------------------
			$this->layout="school_info";
		$this->set('institute_id',$id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );
      
        $result_arr_fee = $this->paginate('InstituteExtraFee');
		 //debug($result_arr_fee);exit;
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_fee', 'ARR_FEATURED', 'view_title'));
       //------------------------------------------------------------gallery--------------=================================
       $institute_id=$id;
       
        $this->set('institute_id',$institute_id);
    	$this->layout="school_info";
		
        $this->loadModel('InstituteGallery');
        //show gallery images
      
        $this->Upload = $this->Components->load('Upload');
        $upload_path = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/';
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        
        if (!empty($id)) {
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $id), array('InstituteGallery.institute_id' => $id. '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }
			
       
        }	
		  $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }

   }
		  

}
