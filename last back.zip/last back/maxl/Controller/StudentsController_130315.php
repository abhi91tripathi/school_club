<?php

/*
 * Name : Students Controller
 * Created : 29 Oct 2014
 * Purpose : To handle student's data
 * Author : Abhishek
 */

class StudentsController extends AppController {

    public $components = array('Uploader', 'Email');
    var $name = 'Students';
      public $helpers = array('Converter');

    /**
     * index method
     *
     * @return void
     */
    
    public function beforeFilter() {
        
        parent::beforeFilter();
      
        $this->layout = 'pay';
    }

    public function __setFlash($message = 'Invalid Request', $status = 'error') {
        if (!$this->request->is('ajax')) {
            $this->Session->setFlash(__($message), $status);
        }
    }

    /**
     * [register description]
     * @param  string $id [description]
     * @return [type]     [description]
     * @author Abhishek Agrawal
     * @since 29 Oct 2014
     */
    public function register($id = '', $success = '') {
        
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('Institute');
        if ($success == 'success') {
            $this->Session->setFlash(__('Your course is confirmed.'), 'flash_success'); //echo 'hey';die;
        }
                
        $this->Student->validate = $this->Student->validationSet['Form1'];
        if (isset($this->request->data) && !empty($this->request->data)) {
            
            $data_arr = $this->request->data;
            $this->set('data_arr', $data_arr);
             
            
       
            if (isset($this->request->data['Student']['next_step']) && $this->request->data['Student']['next_step'] == 'yes') {
                if ($this->request->is('post') && !empty($this->request->data)) {
          
                    //----------------get institute currency---------------------;
                    $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $id), 'fields' => array('Institute.currency_id')));
                    $this->loadModel('Currency');
                    $currency_code = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('Currency.currency_code')));



                    //----------------get institute currency---------------------;
                    $this->request->data['Student']['institute_id'] = $id;

                    $this->request->data['Student']['start_date'] = date('Y-m-d', strtotime($this->request->data['Student']['start_date']));

                    $this->request->data['Student']['end_date'] = date('Y-m-d', strtotime('+' . $this->request->data['Student']['no_of_weeks'] . " week", strtotime($this->request->data['Student']['start_date'])));
                    //pr($this->request->data);
                    //convert values
                    if (isset($this->request->data['Student']['reg_fee']) && $this->request->data['Student']['reg_fee'] != '') {
                        $reg_fee = $this->tofloat($this->request->data['Student']['reg_fee']);
                    }
                    if (isset($this->request->data['Student']['week_price']) && $this->request->data['Student']['week_price'] != '') {
                        $week_price = $this->tofloat($this->request->data['Student']['week_price']);
                    }
                    if (isset($this->request->data['Student']['accom_price']) && $this->request->data['Student']['accom_price'] != '') {
                        $accom_price =$this->tofloat($this->request->data['Student']['accom_price']);
                    }
                    if (isset($this->request->data['Student']['final_price']) && $this->request->data['Student']['final_price'] != '') {
                        $final_price = $this->tofloat($this->request->data['Student']['final_price']);
                    }
                    if (isset($this->request->data['Student']['bookMaterialFee']) && $this->request->data['Student']['bookMaterialFee'] != '') {
                        $bookMaterialFee = $this->tofloat($this->data['Student']['bookMaterialFee']);
                    }
                    if (isset($this->request->data['Student']['deposit_now']) && $this->request->data['Student']['deposit_now'] != '') {
                        $deposit_now =$this->tofloat($this->request->data['Student']['deposit_now']);
                    }
                    if (isset($this->request->data['Student']['accom_reg_price']) && $this->request->data['Student']['accom_reg_price'] != '') {
                        $accomodation_reg_price = $this->tofloat($this->request->data['Student']['accom_reg_price']);
                    }
                    if (isset($this->request->data['Student']['discount']) && $this->request->data['Student']['discount'] != '') {
                        $discount = ($this->request->data['Student']['discount']);
                    }
                   
                    $this->request->data['Student']['reg_fee'] = !empty($reg_fee) ? $reg_fee : 0;
                    $this->request->data['Student']['week_price'] = !empty($week_price) ? $week_price : 0;
                    $this->request->data['Student']['accom_price'] = !empty($accom_price) ? $accom_price : 0;
                    $this->request->data['Student']['final_price'] = !empty($final_price) ? $final_price : 0;
                    $this->request->data['Student']['bookMaterialFee'] = !empty($bookMaterialFee) ? $bookMaterialFee : 0;
                    $this->request->data['Student']['deposit_now'] = !empty($deposit_now) ? $deposit_now : 0;
                    $this->request->data['Student']['discount'] = !empty($discount) ? $discount : '';
                    $this->request->data['Student']['accom_reg_price']=!empty($accomodation_reg_price) ? $accomodation_reg_price : 0;
                    $this->request->data['Student']['currency']=$this->Session->read('CURRENCY');
                    
                    $extra_fee = $this->InstituteExtraFee->find('list', array('conditions' => array('AND' => array('InstituteExtraFee.institute_id' => $id, 'InstituteExtraFee.published' => 1,'InstituteExtraFee.type'=>0)), 'fields' => array('title', 'price')));
                    if ($extra_fee) {
                        foreach ($extra_fee as $key => $fee) {
                            $extra_fee_array[] = array('key' => $key,
                                'price' => $this->Institute->exchange_rate_convert($currency_code['Currency']['currency_code'], $this->Session->read('CURRENCY'), $fee)
                            );
                        }
                        $this->request->data['Student']['extra_fee'] = json_encode($extra_fee_array);
                    }
                    
                    $this->Student->set($this->request->data);
                    if ($this->Student->validates()) {
                        //Save the student data or online quote for course and return saved id
                      
                        $this->Student->saveAll();
                        $student_id = $this->Student->getLastInsertId();
                        $this->Session->write('PresentStudent.id', $student_id);
                        $this->Session->setFlash(__(''), 'flash_success');
                        $this->redirect(array('action' => 'pay', $id));
                    } else {
                        $this->Session->setFlash(__(''), 'error');
                    }
                }
            }
            
             if(!empty($this->request->data['Student']['mail_to'])){
                   
                   $this->Session->setFlash(__('Your mail has been send successfully'), 'flash_success');
                 $this->mail_to($this->request->data);
             }
        } elseif ($this->Session->check('PresentStudent.id')) {
            $student_id = $this->Session->read('PresentStudent.id');
            $this->request->data = $this->Student->find('first', array('conditions' => array('Student.id' => $student_id)));
         
            $data_arr = $this->request->data;
            $this->set('data_arr', $data_arr);
        }

        //get the online quote details
        $this->loadModel('CourseType');
        $inst_courses = $this->CourseType->find('list', array('conditions' => array('CourseType.institute_id' => $id), 'fields' => array('CourseType.title')));

        $this->loadModel('Institute');

        $this->Institute->id = $id;
        if (!$this->Institute->exists()) {
            $this->__setFlash(__('No Institute Found.'), 'error');
            $this->redirect($this->referer());
        }
        $this->Institute->recursive = -1;
        $institute = $this->Institute->find('first', array(
            'conditions' => array('Institute.id' => $id),
            'fields' => array('id', 'title', 'country_id', 'city', 'logo'),
            'contain' => array(
                'Country' => array('fields' => array('name', 'flag_image')),
                'Destination'=>array('fields'=>array('name')),
                'Currency'=>array('fields'=>array('name','currency_code','currrency_symbol'))
            )
        ));
       
        $this->set(compact('institute', 'inst_courses'));
        $LAYOUT_META_TITLE = 'Book your language course at the best price | Maxlanguages.com';
        $LAYOUT_META_DESCRIPTION = "Search, compare & book your language course abroad in schools worldwide. Best price guaranteed or we'll refund the difference to you.";
        $og_image=SITE_URL."img/og_image.jpeg";
        $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image'));   
        $this->set('id', $id);
    }

    /**
     * [register description]
     * @param  string $id [description]
     * @return [type]     [description]
     * @author Abhishek Agrawal
     * @since 30 Oct 2014
     */
    public function pay($id = ''){ 
           
        $this->loadModel('Institute');
        $this->Institute->id = $id;
        if (!$this->Institute->exists()) {
            $this->__setFlash(__('No Institute Found.'), 'error');
            $this->redirect($this->referer());
        }
        $preStudentId = $this->Session->read('PresentStudent.id');

        if (!($this->Session->check('PresentStudent.id')) || empty($preStudentId)) {
            $this->Session->setFlash(_('Please book for a course first.'), 'error');
            $this->redirect(array('action' => 'register', $id));
        }
        $this->Institute->recursive = -1;
        $institute = $this->Institute->find('first', array(
            'conditions' => array('Institute.id' => $id),
            'fields' => array('title', 'country_id', 'city', 'logo','id'),
            'contain' => array(
                'Country' => array('fields' => array('name', 'flag_image')),
                 'Destination' => array('fields' => array('name'))
            )
        ));
        $StudentDetail = $this->Student->find('first', array(
            'conditions' => array('Student.id' => $preStudentId),
            'contain' => array(
                'Institute' => array('fields' => array('title', 'city', 'country_id', 'logo')),
                'CourseType' => array('fields' => array('title')),
                'AccomodationType' => array('fields' => array('title')),
            )
        ));
        if (empty($StudentDetail)) {
            $this->Session->setFlash(__('Please book for a course first.'), 'error');
            $this->redirect(array('action' => 'register', $id));
        } else {
            $total_deposit = round($this->Institute->exchange_rate_convert('EUR', $this->Session->read('CURRENCY'), $StudentDetail['Student']['deposit_now']),2);
            $this->set('total_deposit', $total_deposit);
        }
        $currency=$StudentDetail['Student']['currency'];
        $this->set(compact('StudentDetail', 'institute','currency'));
        $this->Student->validate = $this->Student->validationSet['Form2'];
        $this->loadModel('Payment');
        $this->Payment->validate = $this->Payment->validationSet['Form2'];
        if ($this->request->is('post') && !empty($this->request->data)) {
           
            $this->Student->set($this->request->data);
            $this->Payment->set($this->request->data);
            if ($this->Student->validates()) {
                //Save the student data or online quote for course and return saved id

                if ($this->Payment->validates()) {

                    if (isset($this->request->data['Payment']['terms']) && $this->request->data['Payment']['terms'] == 1) {
                        $checked = true;
                    } else {
                        $checked = false;
                        $checkedMessage = __('You must accept terms and conditions');
                    }
                } else {
                    $checked = false;
                    $checkedMessage = __('Payment information is not filled properly');
                }
            } else {
                $checked = false;
                $checkedMessage = __('Please correct the errors');
            }
            if ($checked) {
                /* TODO Payment */

                /* CHANGE in request Data */
                if ($this->Session->read('PresentStudent.id')) {
                    $this->request->data['Student']['id'] = $preStudentId;
                }
                if (isset($this->request->data['Payment']) && !empty($this->request->data['Payment'])) {
                    $payment_vars = $this->request->data['Payment'];
                }
                $this->Student->set($this->request->data);
              
                if ($this->Student->save()) {
                     
                    $student_id = $this->Student->id;
                    $this->Session->write('PresentStudent.id', $student_id);
                    if ($this->request->data['Payment']['type'] == 2) {
                        $this->_payment();
                    }
                    if ($this->request->data['Payment']['type'] == 1) {
                        $this->redirect(array('controller' => 'Students', 'action' => 'credit_card', $student_id));
                    }
                    if($this->request->data['Payment']['type'] == 3){
                        $this->bank_transfer($student_id);
                    }
                    $this->Session->setFlash(__('All bank detail has been sent in your email'), 'flash_success');
                    $this->redirect(array('action' => 'confirm', $id));
                } else {
                    $this->Session->setFlash(__('Error while saving, Please try again.'), 'error');
                }
            } else {
                $this->Session->setFlash($checkedMessage, 'error');
            }
        }
         $this->__vars();
         $LAYOUT_META_TITLE = 'Book your language course at the best price | Maxlanguages.com';
         $LAYOUT_META_DESCRIPTION = "Search, compare & book your language course abroad in schools worldwide. Best price guaranteed or we'll refund the difference to you.";
         $og_image=SITE_URL."img/og_image.jpeg";
         $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image'));   
         $this->set('id', $id);
    }

    /**
     * [register description]
     * @param  string $id [description]
     * @return [type]     [description]
     * @author Abhishek Agrawal
     * @since 30 Oct 2014
     */
    public function confirm($id = '') {
        configure::write('debug',2);
        $student_id = $this->Session->read('PresentStudent.id');
        
            
        $this->loadModel('Institute');
        $this->Institute->id = $id;
        if (!$this->Institute->exists()) {
            $this->Session->setFlash(__('No Institute Found.'), 'flash_success');
            $this->redirect($this->referer());
        }
        $this->loadModel('Emergency');
        $student = $this->Student->find('first', array(
            'conditions' => array('Student.id' => $student_id),
                )
        );
        
        if (empty($student)) {
            $this->redirect(array('action' => 'pay', $id));
        }

        if (empty($student['Student']['paid_amount']) || $student['Student']['paid_amount'] != $student['Student']['deposit_eur']) {
            if($student['Student']['response']==4){
                  $this->Session->setFlash(__('We just sent you our bank details by email.'), 'flash_success');
            }
            else{
                    $this->Session->setFlash(__('Please pay the due amount.'), 'flash_success');
            }
        }
        $this->loadModel('Currency');
        $currency=$this->Currency->find('first',array('conditions'=>array('Currency.id'=>$student['Institute']['currency_id'])));
        $currency_name=$currency['Currency']['currency_name'];
        $this->set(compact('student','currency_name'));
      
        
        //pr($this->request->data);die;
        if ($this->request->is('post') && !empty($this->request->data)) {
            $this->request->data['Student']['id'] = $student_id;
            $this->request->data['Student']['image'] = $this->request->data['Student']['image'];
            
            $this->Student->set($this->request->data);
            $this->Emergency->set($this->request->data);

            $checkedMessage = '';
            if ($this->Student->validates()) {
                $checked = true;
               // $checkedMessage = __('Please correct the errors');
            } else {
                $checked = false;
                $checkedMessage = __('Please correct the errors');
            }
            //pr($this->Student->validationErrors);echo $checked;die;
            if ($checked) {
                
                /* TODO Payment */
                // Check if same course & industry & has paid a amount
                /* CHANGE in request Data */

                if ($this->Student->saveAll()) {
                    $student_id = $this->Student->id;
                    $this->Session->delete('PresentStudent.id');
                    $this->Session->setFlash(__('Your course is confirmed.'), 'flash_success'); //echo 'hey';die;
                    $this->redirect(array('action' => 'success'));
                }
            } else {
                
                $this->Session->setFlash($checkedMessage, 'error');
            }
        }

        $this->Institute->recursive = -1;
        $institute = $this->Institute->find('first', array(
            'conditions' => array('Institute.id' => $id),
            'fields' => array('title', 'country_id', 'city', 'logo'),
            'contain' => array(
                'Country' => array('fields' => array('name', 'flag_image'))
            )
                ));
      // $this->Session->setFlash(__('Invite or tell your friends before to go'), 'flash_success');
        
         $LAYOUT_META_TITLE = 'Book your language course at the best price | Maxlanguages.com';
          $LAYOUT_META_DESCRIPTION = "Search, compare & book your language course abroad in schools worldwide. Best price guaranteed or we'll refund the difference to you.";
         $og_image=SITE_URL."img/og_image.jpeg";
          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image'));                     
        
        
        $this->set(compact('institute'));
        
        $this->set('id', $id);
    }

    public function __getExpressUrl($amount = '', $edit = '') {
        if ($amount > 0) {
            App::uses('Paypal', 'Paypal.Lib');
            $paypal_config = array(
                'sandboxMode' => PAYPAL_sandbox,
                'nvpUsername' => PAYPAL_nvpUsername,
                'nvpPassword' => PAYPAL_nvpPassword,
                'nvpSignature' => PAYPAL_nvpSignature,
            );
            $this->Paypal = new Paypal($paypal_config);

            $return = Router::fullBaseUrl() . Router::url(array('action' => 'step_pay_express', 'controller' => 'students'));
            $cancel = Router::fullBaseUrl() . Router::url(array('action' => 'step_pay_cancel'));


            $order = array(
                'description' => 'Your purchase with Max-Lanugages',
                'currency' => 'EUR',
                'return' => $return,
                'cancel' => $cancel,
                'custom' => 'Your ',
                'items' => array(
                    0 => array(
                        'name' => "Competition's Price",
                        'description' => 'Amount to be paid for competition',
                        'tax' => 0.00,
                        // 'shipping' => 0.00,
                        'subtotal' => $amount,
                    ),
                )
            );
            try {
                return $this->Paypal->setExpressCheckout($order);
            } catch (Exception $e) {
                return false;
            }
        } else {
            return false;
        }
    }

    public function _uploadImage($file = '', $path) {
        $name = time() . '-' . $file['name'];
        $name = str_replace(' ', '_', $name);
        $path = ROOT . '/app/webroot' . $path . $name;
        list( $width, $height) = getimagesize($file['tmp_name']);
        if (move_uploaded_file($file['tmp_name'], $path))
            return $name;
    }

    public function __vars() {
        $genders = array('male' => 'Male', 'female' => 'Female');
        $payment_types = array(1 => 'Credit Card', 2 => 'Paypal',3=>'Bank Transfer');
        $this->set(compact('genders', 'payment_types'));
    }

    public function step_pay_express($type = false) {
         
        if (!empty($this->request->query)) {
          
            $token = $this->request->query['token'];
            $payerId = $this->request->query['PayerID'];
            $data['payer_id'] = $payerId;
            $data['token'] = $token;
            App::uses('Paypal', 'Paypal.Lib');
            $paypal_config = array(
                'sandboxMode' => PAYPAL_sandbox,
                'nvpUsername' => PAYPAL_nvpUsername,
                'nvpPassword' => PAYPAL_nvpPassword,
                'nvpSignature' => PAYPAL_nvpSignature,
            );
            $this->Paypal = new Paypal($paypal_config);
            $detail = $this->Paypal->getExpressCheckoutDetails($token);
                    $return = Router::fullBaseUrl() . Router::url(array('action' => 'step_pay_express', 'controller' => 'students'));
            $cancel = Router::fullBaseUrl() . Router::url(array('action' => 'step_pay_cancel'));
             
            $order = array(
                'description' => 'Your purchase with Max-Lanugages',
                'currency' => 'EUR',
                'return' => $return,
                'cancel' => $cancel,
                'custom' => 'Your ',
                'items' => array(
                    0 => array(
                        'name' => "Competition's Price",
                        'description' => 'Amount to be paid for competition',
                        'tax' => 0.00,
                        // 'shipping' => 0.00,
                        'subtotal' => $detail['AMT'],
                    ),
                )
            );
           $detail1 = $this->Paypal->DoExpressCheckoutPayment($order,$token,$payerId);
          
           
            // pr($detail);die;
            if ($detail['ACK'] === 'Success' && $detail['PAYERSTATUS'] === 'verified') {
                $job_count_d = $this->Student->find('count', array('conditions' => array('Student.paypal_token' => $detail['TOKEN'])));
                if ($job_count_d == 1) {
                    $job_d = $this->Student->find('first', array('conditions' => array('Student.paypal_token' => $detail['TOKEN'])));
                    // pr($job_d);die;
                    $this->Student->id = $job_d['Student']['id'];
                    $this->loadModel('Payment');
                    $pay_detl = $this->Payment->findByStudentId($job_d['Student']['id']);
                    $data = array();
                    if (!empty($pay_detl)) {
                        $data['Payment']['id'] = $pay_detl['Payment']['id'];
                    }

                    if (empty($pay_detl)) {
                        $data['Payment']['student_id'] = $job_d['Student']['id'];
                        $data['Payment']['amount'] = $detail['AMT'];
                        $data['Payment']['currency_code'] = $detail['CURRENCYCODE'];
                        $data['Payment']['status_message'] = $detail['ACK'];
                        $data['Payment']['type'] = 2;
                        $data['Payment']['paypal_token'] = $token;
                        $data['Payment']['all_detail'] = json_encode($detail1);
                        // pr($data);die;
                        $this->Payment->save($data);
                        if (empty($job_d['Student']['paid_amount']) || $job_d['Student']['paid_amount'] == 0) {
                            $this->Student->saveField('paid_amount', $detail['AMT']);
                            $this->Student->saveField('token', md5($data['Payment']['paypal_token']));
                            $this->Student->saveField('response',3);
                            //------------Approval mail to respective school and confirmation mail to student-------------------------
                            $this->mail($job_d['Student']['id'], md5($data['Payment']['paypal_token']));
                        }

                        $this->Session->setFlash(__(''), 'flash_success');
                        $this->redirect(array('controller' => 'students', 'action' => 'confirm', $job_d['Student']['institute_id']));
                    } else {
                        $this->Session->setFlash(__('Payment not successfull, Please try again.'), 'error');
                        $this->redirect(array('controller' => 'students', 'action' => 'pay', $job_d['Student']['institute_id']));
                    }
                }
            }
        }
    }

    /**
     * Payment Methods GOes here(PayPal and other)
     * @return [type] [description]
     */
    public function _payment() {
        $this->loadModel('Institute');
        if ($this->request->data['Payment']['type'] == 2) {
            $students = $this->Student->find('first', array('conditions' => array('Student.id' => $this->request->data['Student']['id'])));
             $this->Student->id=$this->request->data['Student']['id'];
             $deposit_eur=number_format($this->Institute->exchange_rate_convert($students['Student']['currency'],'EUR',$students['Student']['deposit_now']),2);
            
            $this->Student->saveField('deposit_eur',$deposit_eur);
            $this->Student->saveField('payment_type',2);
            $url_re = $this->__getExpressUrl($deposit_eur);
            $token = substr($url_re, strpos($url_re, '&token=') + 7);
            $this->Student->saveField('paypal_token', $token);
            $this->redirect($url_re);
        } else if ($this->request->data['Payment']['type'] == 1) {
            $this->Session->setFlash(__('We are working on it.'), 'error');
            echo __('We are working on it. Try only paypal at the moment.');
            die;
        }
        return true;
    }

    public function facebook_info() {
        pr($this->request->data);
        die;
        return true;
    }

    /**
     * Purpose: this function is upload user image
     * created on 21 july 2014
     * created by:Abhishek Tripathi
     * */
    public function upload() {
       
        if (isset($this->params->form['image_input'])) {
            $one = $this->params->form['image_input'];
            $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
            $path = 'files' . DS . 'payment' . DS;

            $thumbnails = Thumbnail::payment_image();
            $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
            $image_new_name = date('ydmhis');
            $this->Uploader->upload($one, $path . DS, $thumbnails, $image_new_name, $params);
            $response['image_name'] = $name;
            $response['path'] = FULL_BASE_URL . $this->webroot . 'files/payment/PAY-' . $name;
            echo json_encode($response);
            exit;
        }
    }

    /**
     * Purpose: Approval mail to school and confirmation mail to student
     * created on 22 july 2014
     * created by:Abhishek Tripathi
     * */
    public function mail($student = null, $token = null) {
        
        $this->loadModel('Student');
        $this->loadModel('Institute');

        $student_info = $this->Student->find('first', array('conditions' => array('Student.id' => $student)));
        $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
        $enrolment = json_decode($institute['Institute']['enrollment'], true);

        $this->loadModel('EmailTemplate');
        //------------mail to student-------------------------------------------------
        $srch_array = array("{{first_name}}" => $student_info['Student']['first_name'], "{{last_name}}" => $student_info['Student']['last_name'], "{{email}}" => $student_info['Student']['email'], "{{school_name}}" => $institute['Institute']['title']);
           $srch_array =$this->search_array($student_info,$token);
        $email_values = $this->EmailTemplate->getvalues('payment_confirmation', $srch_array,$srch_array);
        
        $to_emailid = $email_values['from_email'];
        $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
        $this->Email->to = $student_info['Student']['email'];
        $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
        $this->Email->sendAs = 'html';
        $this->Email->send($email_values['content']);
        $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");

        //----------mail to school for approval----------------------------------------
        /*$accept_link = FULL_BASE_URL . $this->webroot . 'Students/accept/' . $token;
        $reject_link = FULL_BASE_URL . $this->webroot . 'Students/reject/' . $token;
        $srch_array = array("{{school_name}}" => $institute['Institute']['title'], '{{accept_link}}' => $accept_link, '{{reject_link}}' => $reject_link);*/
        $srch_array =$this->search_array($student_info,$token);
        $email_values = $this->EmailTemplate->getvalues('School_approval', $srch_array,$srch_array);
        $to_emailid = $email_values['from_email'];
        $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
        $this->Email->to = $enrolment['enr_email'];
        $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
        $this->Email->sendAs = 'html';
        $this->Email->send($email_values['content']);
             $this->set_reminder_mail($student_info,'school');
        $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");


        return true;
    }

    /**
     * Purpose: School acceptance
     * created on 24 November 2014
     * created by:Abhishek Tripathi
     * */
    public function accept($token = null) {
        
        $this->loadModel('EmailTemplate');
        $student_info = $this->Student->find('first', array('conditions' => array('Student.token' => $token)));
        if ($student_info) {
            if($student_info['Student']['response']==3 ||$student_info['Student']['response']==5){
            $this->loadModel('Institute');
            $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
            $enrolment = json_decode($institute['Institute']['enrollment'], true);
            $this->Student->id = $student_info['Student']['id'];
            $this->Student->saveField('response', 1);
            $srch_array =$this->search_array($student_info);
            $email_values = $this->EmailTemplate->getvalues('acceptance_mail',$srch_array,$srch_array);
           
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $student_info['Student']['email'];
            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
            $this->Email->sendAs = 'html';
          $this->Email->send($email_values['content']);
           
            $this->set_reminder_mail($student_info,'student');
            
            $this->stop_reminder_mail($student_info);
            
            
            //school approval email
            $email_values = $this->EmailTemplate->getvalues('School_approval_confirmed', $srch_array,$srch_array);
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $enrolment['enr_email'];
            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
            $this->Email->sendAs = 'html';
            $this->Email->send($email_values['content']);
            
            
            $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");

            $this->Session->setFlash(__('Thank you! Your response has been successfully sent.'));
            }else{
              $this->Session->setFlash(__("Sorry, this booking has already been processed and you can't modify it anymore. Please contact us directly for more information."));  
            }
        } else {
            $this->Session->setFlash(__('Your Request token is wrong'));
        }
        $this->render('response');
    }

    /**
     * Purpose: School rejectance 
     * created on 24 November 2014
     * created by:Abhishek Tripathi
     * */
    public function reject($token = null) {
        $this->loadModel('EmailTemplate');
        $student_info = $this->Student->find('first', array('conditions' => array('Student.token' => $token)));
   

        if ($student_info) {
            
                 if($student_info['Student']['response']==3 || $student_info['Student']['response']==5){
            $this->loadModel('Institute');
            $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
            $enrolment = json_decode($institute['Institute']['enrollment'], true);
            $this->Student->id = $student_info['Student']['id'];
            $this->Student->saveField('response', 2);
            $this->cancel_payment($student_info['Student']['id']);
            $srch_array =$this->search_array($student_info);
            
            $email_values = $this->EmailTemplate->getvalues('rejection_mail', $srch_array,$srch_array);
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $student_info['Student']['email'];
            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
            $this->Email->sendAs = 'html';
            $this->Email->send($email_values['content']);
            $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
             $this->stop_reminder_mail($student_info);
            
            
            //school approval reject email
            $email_values = $this->EmailTemplate->getvalues('School_approval_rejected', $srch_array,$srch_array);
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $enrolment['enr_email'];
            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
            $this->Email->sendAs = 'html';
            $this->Email->send($email_values['content']);
           
            
            
            $this->Session->setFlash(__('Thank you! Your response has been successfully sent. '));
        }
                else{
                    $this->Session->setFlash(__("Sorry, this booking has already been processed and you can't modify it anymore. Please contact us directly for more information."));
                }
        } else {
            $this->Session->setFlash(__('Your Request token is wrong'));
        }
        $this->render('response');
    }

    /**
     * Purpose: Bank transfer
     * created on 24 November 2014
     * created by:Abhishek Tripathi
     * */
    public function credit_card($option = null) {
       $this->loadModel('Institute');
        $student_info = $this->Student->find('first', array('conditions' => array('Student.id' => $option)));
          $this->Student->id=$student_info['Student']['id'];
             $deposit_eur=round($this->Institute->exchange_rate_convert($student_info['Student']['currency'],'EUR',$student_info['Student']['deposit_now']),2);
            
            $this->Student->saveField('deposit_eur',$deposit_eur);
             $this->Student->saveField('payment_type',1);
             $student_final_info = $this->Student->find('first', array('conditions' => array('Student.id' => $option)));
       
        $this->set('student', $student_final_info);
    }

    /**
     * Purpose: payment_form
     * created on 24 November 2014
     * created by:Abhishek Tripathi
     * */
    public function payment_form() {
        App::import('Vendor', 'payment_form/Payment');
        
        $pay = new Payment();
        $lang = 'en';
        $form = $pay->get_formHtml_request($this->request->data, $lang);

        // REDIRECTION AUTOMATIQUE VERS PLATEFORME DE PAIEMENT SI DEBUG DESACTIVE
        // AFFICHAGE ET CONFIRMATION DU FORMULAIRE DE PAIEMENT AVANT REDIRECTION SI DEBUG ACTIVE
        @$conf_txt = parse_ini_file("conf.txt");
        if ($conf_txt['debug'] == 0) {
            echo $form;
        } else {
            echo (display_form($lang, $form));
        }
        exit;
    }

    public function return_info() {
        
        $detail = $this->request->query;
        
         $job_d = $this->Student->find('first', array('conditions' => array('Student.id' => $detail['vads_cust_id'])));
        
         if($detail['vads_result']==00) {
            
                $this->Student->id = $detail['vads_cust_id'];
                $this->loadModel('Payment');
                $pay_detl = $this->Payment->findById($detail['vads_trans_id']);
                $data = array();
                if (!empty($pay_detl)) {
                    $data['Payment']['id'] = $pay_detl['Payment']['id'];
                }
                   
                if (empty($pay_detl)) {
                   $this->Session->write('PresentStudent.id',$detail['vads_cust_id']);
                    $data['Payment']['student_id'] = $detail['vads_cust_id'];
                    $data['Payment']['amount'] = $detail['vads_amount']/100;
                    $data['Payment']['currency_code'] = 'EUR';
                    $data['Payment']['status_message'] = 'Payment sucessfully completed';
                    $data['Payment']['type'] = 1;
                    $data['Payment']['paypal_token'] = $detail['vads_trans_id'];
                    $data['Payment']['all_detail'] = json_encode($detail);
                    // pr($data);die;
                    $this->Payment->save($data);
                    if (empty($job_d['Student']['paid_amount']) || $job_d['Student']['paid_amount'] == 0) {
                        $this->Student->saveField('paid_amount', $detail['vads_amount']/100);
                        $this->Student->saveField('token', md5($detail['vads_cust_id']));
                        $this->Student->saveField('response', 3);
                        //------------Approval mail to respective school and confirmation mail to student-------------------------
                        $stas=$this->mail($detail['vads_cust_id'], md5($detail['vads_cust_id']));
                    }
                    //$this->Session->setFlash(__('You have successfully paid '), 'flash_success');
                    $this->redirect(array('controller' => 'Students', 'action' => 'confirm', $job_d['Student']['institute_id']));
                } else {
                    //$this->Session->setFlash(__('Payment not successfull, Please try again.'), 'error');
                    $this->redirect(array('controller' => 'Students', 'action' => 'pay', $job_d['Student']['institute_id']));
                }

                
        }
        else{
               $this->redirect(array('controller' => 'Students', 'action' => 'cancelled_url', $job_d['Student']['institute_id']));
        }
    }
    
    public function tofloat($num) {
    $dotPos = strrpos($num, '.');
    $commaPos = strrpos($num, ',');
    $sep = (($dotPos > $commaPos) && $dotPos) ? $dotPos :
        ((($commaPos > $dotPos) && $commaPos) ? $commaPos : false);
  
    if (!$sep) {
        return floatval(preg_replace("/[^0-9]/", "", $num));
    }

    return floatval(
        preg_replace("/[^0-9]/", "", substr($num, 0, $sep)) . '.' .
        preg_replace("/[^0-9]/", "", substr($num, $sep+1, strlen($num)))
    );
}

   
        //payment cancelation function
        public function cancel_payment($id=null){
            
            App::import('Vendor', 'payment_ws/classes/wsToolV3');
             $this->loadModel('Payment');
          
            $payment=$this->Payment->find('first',array('conditions'=>array('Payment.student_id'=>$id)));
             
            switch($payment['Payment']['type']){
                case 1:
                    $data=  json_decode($payment['Payment']['all_detail'],true);
                    $param=array();
                    $param['shopId']='27019106';
                    $param['transmissionDate']=date('d-m-Y h:i:s',strtotime($data['vads_trans_date']));
                    $param['transactionId']=$data['vads_trans_id'];
                    $param['sequenceNb']='1';
                    $param['ctxMode']='TEST';
                    $param['comment']='Test webservice';
                    $WS= new WS_API();
                    $WS->key='4441581736755411'; 
                    $response=$WS->cancel($param); 
                    $control_sign=array();
                    $control_sign=$WS->getResponse('cancel',$response);
                    return true;
                    break;
                case 2:
                    App::uses('Paypal', 'Paypal.Lib');
                    $paypal_config = array(
                        'sandboxMode' => PAYPAL_sandbox,
                        'nvpUsername' => PAYPAL_nvpUsername,
                        'nvpPassword' => PAYPAL_nvpPassword,
                        'nvpSignature' => PAYPAL_nvpSignature,
                    );
                    $this->Paypal = new Paypal($paypal_config);
                    $data=  json_decode($payment['Payment']['all_detail'],true);
                    
                    $refund = array(
                                'transactionId' =>$data['PAYMENTINFO_0_TRANSACTIONID'], 	// Original PayPal Transcation ID
                                'type' => 'Full', 			// Full, Partial, ExternalDispute, Other
                                'amount' => $data['PAYMENTINFO_0_AMT'], 						// Amount to refund, only required if Refund Type is Partial
                                'note' => 'Refund because we are nice',	// Optional note to customer
                                 'reference' => 'abc123', 				// Optional internal reference
                                'currency' => 'EUR'  					// Defaults to GBP if not provided
                        );
                    
                    $this->Paypal->refundTransaction($refund);
                    return true;
                    break;
                case 3:return true;
                    break;
                    
                    
            }
            
        }
        
        public function step_pay_cancel(){
                
        if (!empty($this->request->query)) {
           
            $token = $this->request->query['token'];
            
           
            $data['token'] = $token;
            App::uses('Paypal', 'Paypal.Lib');
            $paypal_config = array(
                'sandboxMode' => PAYPAL_sandbox,
                'nvpUsername' => PAYPAL_nvpUsername,
                'nvpPassword' => PAYPAL_nvpPassword,
                'nvpSignature' => PAYPAL_nvpSignature,
            );
            $this->Paypal = new Paypal($paypal_config);
                $detail = $this->Paypal->getExpressCheckoutDetails($token);
                $student= $this->Student->find('first', array('conditions' => array('Student.paypal_token' => $detail['TOKEN'])));
              if($student){
                        $this->Session->setFlash(__('Your Transaction not completed '), 'flash_success');
                        $this->redirect(array('controller' => 'students', 'action' => 'cancelled_url', $student['Student']['institute_id']));
              }
            
           
            
        }
        }
      
           //search array()==
    public function search_array($student_info,$token=null){
              
             $this->loadModel('Institute');
             $this->loadModel('Destination');
             
            $payment_type=  Configure::read('PAYMENT_TYPE');
            $response=  Configure::read('RESPONSE');
            $level=  Configure::read('new_level');
            $options=array('Yes', 'No', 'No preference');
            $accept_link = FULL_BASE_URL . $this->webroot . 'Students/accept/' . $token;
            $reject_link = FULL_BASE_URL . $this->webroot . 'Students/reject/' . $token;
            $PRIVIOUS=array('no'=>'No, I’ve never been to this school before.', 'yes'=>'Yes, I have already attended a course at this school.');
             $transfer=array('1'=>"No, I don't need transfer",'2'=>"Yes, I need transfer",'3'=>"I will decide later");
             
           $destination=$this->Destination->find('first',array('conditions'=>array('Destination.id'=>$student_info['Institute']['destination_id'])));  
             
            
            $this->loadModel('Currency');
            $currency=$this->Currency->find('first',array('conditions'=>array('Currency.currency_code'=>$student_info['Student']['currency'])));
            
            $currency_institute=$this->Currency->find('first',array('conditions'=>array('Currency.id'=>$student_info['Institute']['currency_id'])));
            
            $extra_fee_html='';
              $extra_fee_html_school='';
            if(!empty($student_info['Student']['extra_fee'])){
                $fees=  json_decode($student_info['Student']['extra_fee'],true);
               // debug($fees);exit;
                foreach($fees as $fee){
                    
                 $extra_fee_html.='<p>'.$fee["key"].': '.$currency["Currency"]["currrency_symbol"].number_format($fee["price"],2).'</p>';
                   
                }
            }
            if(!empty($student_info['Student']['extra_fee'])){
                $fees=  json_decode($student_info['Student']['extra_fee'],true);
               // debug($fees);exit;
                foreach($fees as $fee){
                    
                 $extra_fee_html_school.='<p>'.$fee["key"].': '.$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($fee["price"])),2).'</p>';
                   
                }
            }
            $course_reg_discount_key="";$course_reg_discount_value="";$course_dis_commision_key="";$course_dis_commision_dis_value="";
            $course_dis_key="";$course_dis_value="";$accomodatio_reg_discount_key='';$accomodatio_reg_discount_value='';$accommodation_dis_key='';$accommodation_dis_value='';
            $course_reg_discount_value_school_currency='';$course_dis_commision_dis_value_school_currency='';$course_dis_value_school_currency='';$accomodatio_reg_discount_value_school_currency='';
            $accommodation_dis_value_school_currency='';
            
            $discount_array=json_decode($student_info['Student']['discount'],true);
         
            foreach($discount_array as $discount){
                  if($discount['class']=='course_reg_discount'){
                      $course_reg_discount_key=$discount["key"];
                      $course_reg_discount_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_reg_discount_value=$discount["value"];
                      
                  }
                  if($discount['class']=='course_commision_discount'){
                       $course_dis_commision_key=$discount["key"];
                      $course_dis_commision_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_dis_commision_dis_value=$discount["value"];
                      
                  }
                   if($discount['class']=='course_discount_plan1'||$discount['class']=='course_discount_plan2'||$discount['class']=='course_discount_plan3'){
                       $course_dis_key=$discount["key"];
                      $course_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_dis_value=$discount["value"];
                      
                   }
                   if($discount['class']=='accommodation_reg_discount'){
                      $accomodatio_reg_discount_key=$discount["key"];
                      $accomodatio_reg_discount_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $accomodatio_reg_discount_value=$discount["value"];
                      }
                   if($discount['class']=='accommodation_discount')
                   {
                      $accommodation_dis_key=$discount["key"];
                      $accommodation_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $accommodation_dis_value=$discount["value"];
                   }
            }
           
          
            $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
            $enrolment = json_decode($institute['Institute']['enrollment'], true);
            $srch_array = array(
                    
                    "{{school_name}}"=>$student_info['Institute']['title'],
                    "{{payment_type}}" => $payment_type[$student_info['Payment']['type']],
                    "{{payment_status}}" => $response[$student_info['Student']['response']],
                    "{{first_name}}" => $student_info['Student']['first_name'],
                    "{{last_name}}"=> $student_info['Student']['last_name'],
                    "{{gender}}" => $student_info['Student']['gender'],
                    "{{date_of_birth}}" => $student_info['Student']['dob'],
                    "{{nationality}}" => $student_info['Student']['nationality'],
                    "{{student_phone}}" => $student_info['Student']['telephone'],
                    "{{student_address}}" => $student_info['Student']['address'], 
                    "{{post_code}}" => $student_info['Student']['postcode'], 
                    "{{city}}" => $student_info['Student']['city'], 
                    "{{country}}" => $student_info['Student']['country'],
                    "{{pasport_id}}" => $student_info['Student']['id_number'],
                    "{{payment_id}}" => $student_info['Payment']['id'], 
                    "{{booking_date}}" => date("j F Y", strtotime($student_info['Student']['created'])), 
                    "{{starting_date}}" => date("j F Y", strtotime($student_info['Student']['start_date'])), 
                    "{{duration}}" => $student_info['Student']['no_of_weeks'],  
                    "{{transfer}}" => $transfer[$student_info['Student']['transfer']], 
                    "{{comment}}" => $student_info['Student']['comment'],  
                    "{{course}}" => $student_info['CourseType']['title'], 
                    "{{course_registration_fee}}" =>$currency["Currency"]["currrency_symbol"]. $student_info['Student']['reg_fee'], 
                    "{{course_price}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['week_price'],  
                    "{{accommodation}}" => $student_info['AccomodationType']['title'],
                    "{{accommodation_registration_fee}}" =>$currency["Currency"]["currrency_symbol"]. $student_info['Student']['accom_reg_price'], 
                    "{{accommodation_price}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['accom_price'], 
                    "{{total}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['final_price'],  
                    "{{deposit_due_now}}" =>$currency["Currency"]["currrency_symbol"].$student_info['Student']['deposit_now'],
                    "{{emergency_name}}" => $student_info['Emergency']['name'], 
                    "{{emergency_email}}" => $student_info['Emergency']['email'], 
                    "{{emergency_phone}}" => $student_info['Emergency']['telephone'], 
                    "{{emergency_address}}" => $student_info['Emergency']['address'],
                    "{{emergency_post_code}}" => $student_info['Emergency']['postcode'],  
                    "{{emergency_city}}" => $student_info['Emergency']['city'], 
                    "{{emergency_country}}" => $student_info['Emergency']['country'], 
                    "{{school_logo}}" =>'<img src="'.FULL_BASE_URL.$this->webroot.'uploads/institute/'.$student_info['Institute']['id'].'/REV'.$student_info['Institute']['logo'].'">' ,
                    "{{accept_link}}" => $accept_link,
                    "{{reject_link}}" => $reject_link,
                    "{{booking_id}}"=>$student_info['Payment']['id'],
                    "{{terms_conditions}}"=>$student_info['Institute']['terms'],
                    "{{cancel_policiy}}"=>$student_info['Institute']['cancle_policiy'],
                    "{{extra_fee}}"=>$extra_fee_html,
                    "{{student_email}}"=>$student_info['Student']['email'],
                    "{{review_page_link}}"=>FULL_BASE_URL.$this->webroot.'Reviews/detail?institute='.$student_info['Institute']['slug'],
                    "{{school_email}}"=> $enrolment['enr_email'],
                    "{{language_level}}"=>($student_info['Student']['language_level']==-1?"I don't know":$level[$student_info['Student']['language_level']]),
                   
                    "{{thanks_page_comment}}"=>$student_info['Student']['comment_thank'],
                    "{{smoker}}"=>$options[$student_info['Student']['smoker']],
                    "{{children}}"=>$options[$student_info['Student']['childrens']],
                    "{{pets}}"=>$options[$student_info['Student']['pets']],
                    "{{special_diets}}"=>$options[$student_info['Student']['special_diets']],
                    "{{previously_attended}}"=>$PRIVIOUS[$student_info['Student']['previously_attended']],
                    "{{student_image}}"=>'<img src="'.$student_info['Student']['image'].'">',
                    "{{You didnt reply}}"=>"You didn't reply to this message...",
                    "{{course_reg_discount_key}}"=>$course_reg_discount_key,
                    "{{course_reg_discount_value}}"=>$course_reg_discount_value,
                    "{{course_dis_commision_key}}"=>$course_dis_commision_key,
                    "{{course_dis_commision_dis_value}}"=>$course_dis_commision_dis_value,
                    "{{course_dis_key}}"=>$course_dis_key,
                    "{{course_dis_value}}"=>$course_dis_value,
                    "{{accomodatio_reg_discount_key}}"=>$accomodatio_reg_discount_key,
                    "{{accomodatio_reg_discount_value}}"=>$accomodatio_reg_discount_value,
                    "{{accommodation_dis_key}}"=>$accommodation_dis_key,
                    "{{accommodation_dis_value}}"=>$accommodation_dis_value,
                
                
                    "{{course_reg_discount_value_school_currency}}"=>$course_reg_discount_value_school_currency,
                    "{{course_dis_commision_dis_value_school_currency}}"=>$course_dis_commision_dis_value_school_currency,
                    "{{course_dis_value_school_currency}}"=>$course_dis_value_school_currency,
                    "{{accomodatio_reg_discount_value_school_currency}}"=>$accomodatio_reg_discount_value_school_currency,
                    "{{accommodation_dis_value_school_currency}}"=>$accommodation_dis_value_school_currency,
                
                
                    "{{course_registration_fee_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['reg_fee'])),2), 
                    "{{course_price_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['week_price'])),2),
                    "{{accommodation_registration_fee_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['accom_reg_price'])),2),
                    "{{accommodation_price_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['accom_price'])),2),
                    "{{total_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"]. number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['final_price'])),2),
                    "{{deposit_due_now_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"]. number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['deposit_now'])),2),
                    "{{deposit_due_now_eur}}" => BASE_CURRENCY_SYMBOL.$student_info['Student']['deposit_eur'],
                    "{{school_website}}"=>$student_info['Institute']['website'],
                    "{{school_contact}}"=>$enrolment['enr_contact_name'],
                    "{{school_phone}}"=>$enrolment['enr_phone_no'],
                  
                    "{{extra_fee_price_school_currency}}"=>$extra_fee_html_school,
                    "{{school_city}}"=>$destination['Destination']['name']
                  );
            
         return $srch_array;
    }
    
    
     /**
     * Purpose: mail to admin
     * created on 31 december 2014
     * created by:Abhishek Tripathi
     * */
    public function mail_to($data=null){
      
         $this->loadModel('EmailTemplate');
         $this->loadModel('Institute');
         $this->loadModel('CourseType');
         $this->loadModel('AccomodationType');
         $school=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$data['Student']['institute_id']),'fields'=>array('id','title','logo','Institute.enrollment','slug')));
         $course=$this->CourseType->find('first',array('conditions'=>array('CourseType.id'=>$data['Student']['course_id']),'fields'=>array('id','title')));
         $accomodation=$this->AccomodationType->find('first',array('conditions'=>array('AccomodationType.id'=>$data['Student']['accomodation_id']),'fields'=>array('id','title')));
         if(!empty($data['Student']['discount'])){
             $discount=  json_decode($data['Student']['discount'],true);
         }
        
                    
         $html='';
                 $html.='<table>';
                 $html.='<tr><th>Name</th><th>Value</th></tr>';
                 $html.='<tr><td>School</td><td>'.(!empty($school['Institute']['title'])?$school['Institute']['title']:'').'</td></tr>';
                 $html.='<tr><td>Course</td><td>'.(!empty($course['CourseType']['title'])?$course['CourseType']['title']:'').'</td></tr>';
                 $html.='<tr><td>Duration</td><td>'.(!empty($data['Student']['no_of_weeks'])?$data['Student']['no_of_weeks'].'week(s)':'').'</td></tr>';
                 $html.='<tr><td>Start Date</td><td>'.(!empty($data['Student']['start_date'])?date('j F Y',  strtotime($data['Student']['start_date'])):'').'</td></tr>';
                 if(!empty($data['Student']['regfeePrice'])){
                     $html.='<tr><td>Course Registration fee</td><td>'.(!empty($data['Student']['regfeePrice'])?$data['Student']['regfeePrice']:'').'</td></tr>'; 
                 }
                    if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='course_reg_discount'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }
                 if(!empty($data['Student']['weekPrice'])){
                     $html.='<tr><td>Course Price</td><td>'.(!empty($data['Student']['weekPrice'])?$data['Student']['weekPrice']:'').'</td></tr>'; 
                 }
                 if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='course_commision_discount'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }
                  if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='course_discount_plan1'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }
                   if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='course_discount_plan2'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                                 }
                    }
                   if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='course_discount_plan3'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }   
                    if(!empty($data['Student']['extra_fee'] )){
                        $extra_fee=  json_decode($data['Student']['extra_fee'],true);
                        foreach($extra_fee as $fee){
                              $html.='<tr><td>'.$fee["key"].'</td><td>'.(!empty($fee["price"])?$fee["price"]:'').'</td></tr>'; 
                        }
                    }
                    
                      if(!empty($data['AccomodationType']['title'])){  
                 $html.='<tr><td>Accomodation</td><td>'.(!empty($accomodation['AccomodationType']['title'])?$accomodation['AccomodationType']['title']:'').'</td></tr>'; 
                      }
                 if(!empty($data['Student']['accom_reg_price'])){
                     $html.='<tr><td>Accommodation Registration fee</td><td>'.(!empty($data['Student']['accom_reg_price'])?$data['Student']['accom_reg_price']:'').'</td></tr>'; 
                 }
                  if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='accommodation_reg_discount'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }
                 if(!empty($data['Student']['accomPrice'])){
                     $html.='<tr><td>Accommodation</td><td>'.(!empty($data['Student']['accomPrice'])?$data['Student']['accomPrice']:'').'</td></tr>'; 
                 }   
                 if(isset($discount)){
                        foreach($discount as $dis){
                            if($dis['class']=='accommodation_discount'){
                                    $html.='<tr><td>'.$dis['key'].'</td><td>'.(!empty($dis['value'])?$dis['value']:'').'</td></tr>'; 
                                }
                             }
                    }
                   if(!empty($data['Student']['finalPrice'])){
                     $html.='<tr><td>tOTAL</td><td>'.(!empty($data['Student']['finalPrice'])?$data['Student']['finalPrice']:'').'</td></tr>'; 
                 }   
                 
                  if(!empty($data['Student']['deposit_now'])){
                     $html.='<tr><td>Due deposit now</td><td>'.(!empty($data['Student']['deposit_now'])?$data['Student']['deposit_now']:'').'</td></tr>'; 
                 }  
                 
                 $html.='</tabel>';
               
            $email_values['from_email']='abhishek.tripathi@xicom.biz';     
              
                $srch_array= array("{{Your_name}}" => $data['Student']['mail_name'], "{{email_id}}" =>$data['Student']['mail_to'],'{{url}}'=>FULL_BASE_URL.$this->webroot.$school['Institute']['slug']);
          
        
            $email_values = $this->EmailTemplate->getvalues('mail_to_friend', $srch_array,$srch_array);
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $data['Student']['mail_to'];
            $this->Email->subject =$email_values['subject'];
            $this->Email->sendAs = 'html';
            $this->Email->send($email_values['content'].'<br/>'.$html);
    }
    
     /**
     * Purpose:bank transfer
     * created on 2 january 2015
     * created by:Abhishek Tripathi
     * */
    public function bank_transfer($id=null){
        $this->loadModel('Student');
        $this->loadModel('Payment');
        $this->loadModel('Institute');
        $this->loadModel('EmailTemplate');
        $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
        $payment=array('Payment'=>array(
            'type'=>'3',
            'student_id'=>$id,
              
        ));
        $this->Payment->save($payment);
        $payment_id=$this->Payment->getLastInsertId();
        $this->Student->id=$id;
        $this->Student->saveField('response',4);
        $deposit_eur=round($this->Institute->exchange_rate_convert($student_info['Student']['currency'],'EUR',$student_info['Student']['deposit_now']),0);
        $this->Student->saveField('deposit_eur',$deposit_eur);
        $student_info_update=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
        $srch_array =$this->search_array($student_info_update);
        $email_values = $this->EmailTemplate->getvalues('bank_transfer', $srch_array,$srch_array);
            $to_emailid = $email_values['from_email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $student_info['Student']['email'];
            $this->Email->subject =$email_values['subject'];
            $this->Email->sendAs = 'html';
            $this->Email->send($email_values['content']);
            $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
            return $rss_arr;
            
    }
    
   public function cancelled_url($id=null){
      if($this->request->is('post')){
            $this->loadModel('EmailTemplate');
				
                                    $srch_array = array("{{name}}" => $this->data['name'], "{{email_id}}" => $this->data['email'],"{{subject}}" => 'ContactUs', "{{message}}" => $this->data['message']);
                                    $email_values = $this->EmailTemplate->getvalues('contact_us', $srch_array,$srch_array);

                                    $to_emailid = $email_values['from_email'];
                                    $this->Email->from = $this->data['name'].' <'.$this->data['email'].'>';
                                    $this->Email->to = $to_emailid;
                                    $this->Email->subject = $email_values['subject'];
                                    $this->Email->sendAs = 'html';
                                    $this->Email->send($email_values['content']);

                                    $this->Session->setFlash("Thank you for contacting ".SITENAME.". You will be hearing from us very soon.");
				
           
       }else{
           $this->Session->setFlash("We couldn't proceed with your payment.Please try again or contact us.");
       }
       
   }
  // -------------success page----------------   
    public function success(){
         $LAYOUT_META_TITLE = 'Book your language course at the best price | Maxlanguages.com';
          $LAYOUT_META_DESCRIPTION = "Search, compare & book your language course abroad in schools worldwide. Best price guaranteed or we'll refund the difference to you.";
         $og_image=SITE_URL."img/og_image.jpeg";
          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image'));   
    } 
    
  //-----------reminder mail set function ---------------------------

    public function set_reminder_mail($data=null,$to=null){
        if($to=='student'){
        $this->loadModel('AutoEmail');
        $today=date('d-m-Y');
        $mail_data=array('AutoEmail'=>array(
            'student_id'=>$data['Student']['id'],
            'institute_id'=>$data['Institute']['id'],
            'email_date'=>date('d-m-Y', strtotime('+1 day', strtotime($today))),
            'email_template'=>'review_mail_student',
            'status'=>1
         ));
        $this->AutoEmail->save($mail_data);
        }
        if($to=='school'){
             $this->loadModel('AutoEmail');
                $today=date('d-m-Y');
                $mail_data=array('AutoEmail'=>array(
                    'student_id'=>$data['Student']['id'],
                    'institute_id'=>$data['Institute']['id'],
                    'email_date'=>date('d-m-Y', strtotime('+3 day', strtotime($today))),
                    'email_template'=>'reminder_school',
                    'status'=>2
                 ));
                $this->AutoEmail->save($mail_data);
        }
        return true;
        
    }
    
    public function auto_mail(){
        Configure::write('debug',2);
       
       $this->loadModel('AutoEmail');
       $this->loadModel('School');
       $this->loadModel('EmailTemplate');
       
       
       $mail_list=$this->AutoEmail->find('all',array('conditions'=>array('AND'=>array('AutoEmail.email_date'=>date('d-m-Y'),'AutoEmail.status >'=>0))));

       foreach($mail_list as $mail){
           $this->loadModel('Stutdent');
           $this->AutoEmail->id=$mail['AutoEmail']['id'];
           $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$mail['AutoEmail']['student_id'])));
           $this->loadModel('Institute');
           $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
           $enrolment = json_decode($institute['Institute']['enrollment'], true);
             $srch_array =$this->search_array($student_info);
             if($mail['AutoEmail']['email_template']=='review_mail_student'){
                        $email_values = $this->EmailTemplate->getvalues('review_mail_student', $srch_array,$srch_array);
                        $to_emailid = $student_info['Student']['email'];
                                    $this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
                                    $this->Email->to = $to_emailid;
                                    $this->Email->subject = $email_values['subject'];
                                    $this->Email->sendAs = 'html';
                                    $this->Email->send($email_values['content']);
                             $this->AutoEmail->saveField('status',0)      ;  
             }
               if($mail['AutoEmail']['email_template']=='reminder_school'){
                    $email_values = $this->EmailTemplate->getvalues('reminder_school', $srch_array,$srch_array);
                        $to_emailid =$enrolment['enr_email'];
                                    $this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
                                    $this->Email->to = $to_emailid;
                                    $this->Email->subject = $email_values['subject'];
                                    $this->Email->sendAs = 'html';
                                    $this->Email->send($email_values['content']);
                                    $today=$mail['AutoEmail']['email_date'];
                    switch($mail['AutoEmail']['status']){
                        case 2:$next_daya=date('d-m-Y', strtotime('+1 day', strtotime($today)));
                            $this->AutoEmail->saveField('email_date',$next_daya);
                            $this->AutoEmail->saveField('status',4);
                            break;
                        case 4:$next_daya=date('d-m-Y', strtotime('+1 day', strtotime($today)));
                            $this->AutoEmail->saveField('email_date',$next_daya);
                            $this->AutoEmail->saveField('status',5);
                            break;
                        case 5:$next_daya=date('d-m-Y', strtotime('+1 day', strtotime($today)));
                            $this->AutoEmail->saveField('status',0);
                            
                        
                    }
               }
                $this->Session->setFlash("Thank you for contacting ".SITENAME.". You will be hearing from us very soon.");
       }
       
       exit;
       
       
      
    }
    
     public function stop_reminder_mail($data=null){
       $this->loadModel('Student');
       $this->loadModel('AutoEmail');
       $mail=$this->AutoEmail->find('first',array('conditions'=>array('AND'=>array('AutoEmail.student_id'=>$data['Student']['id'],'AutoEmail.institute_id'=>$data['Student']['institute_id'],'AutoEmail.email_template'=>'reminder_school'))));
      
       
       $this->AutoEmail->id=$mail['AutoEmail']['id'];
       $this->AutoEmail->saveField('status','0');
       return true;
       }
       
       
       public function test_mail($id=null){
           Configure::write('debug',2);
           $this->loadModel('EmailTemplate');
           $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
         
           $srch_array =$this->search_array($student_info);
      
           $email_values = $this->EmailTemplate->getvalues('bank_transfer', $srch_array,$srch_array);
                        $to_emailid = $student_info['Student']['email'];
                                    $this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
                                    $this->Email->to = 'abhishek.tripathi@xicom.biz';
                                    $this->Email->subject = $email_values['subject'];
                                    $this->Email->sendAs = 'html';
                                    $this->Email->send($email_values['content']);
                             $this->AutoEmail->saveField('status',0)   ;  
           
       }
    

}
