<?php
/**
 * Img180.com V 1.0
 * Purpose: FOR CONTACT US FORM
 * Author : Nitin
 * Created: 30 August, 2012
*/

class ContactUsController extends AppController 
{
	public $uses = array('ContactUs');
	public $components = array('Email');
	
	function beforeFilter()
	{
		parent::beforeFilter();
		//$this->Auth->allow(array('index'));
	}
	
	/**
	 * Purpose : TO dispaly contact us form & send mail
	 * Created on : 30-Sep-2013
	 * Author : Nitin
	*/
	function index()
	{
		$errors = '';
		$error_flag = false;
		$add_errors = array();

		if ($this->request->is('post'))
		{
			$this->ContactUs->set($this->data);

			
			
			
			if($this->ContactUs->validates() && !$error_flag)
			{
				//SENDING THE MAIL
				$this->loadModel('EmailTemplate');
				
				$srch_array = array("{{name}}" => $this->data['ContactUs']['fullname'], "{{email_id}}" => $this->data['ContactUs']['email_id'],"{{message}}" => $this->data['ContactUs']['message']);
				$email_values = $this->EmailTemplate->getvalues('contact_us', $srch_array);

				$to_emailid = $email_values['from_email'];
                                
				$this->Email->from = $this->data['ContactUs']['fullname'].' <'.$this->data['ContactUs']['email_id'].'>';
				$this->Email->to = $to_emailid;
				$this->Email->subject = $email_values['subject'];
				$this->Email->sendAs = 'html';
				$this->Email->send($email_values['content']);

				$this->Session->setFlash(__("Thank you for contacting ".SITENAME.". You will be hearing from us very soon."), 'flash_success');
				$this->redirect($this->referer());
			}
			else
			{
				$errors = $this->ContactUs->validationErrors;
				$errors = array_merge($errors, $add_errors);
			}
		}
                     $LAYOUT_META_TITLE = 'Contact | Maxlanguages.com';
                          $LAYOUT_META_DESCRIPTION = "We’re here to help you find the ideal language course as easily as possible! We'll get back to you as soon as we can.";
                          $og_image=SITE_URL."img/og_image.jpeg";
                          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image')); 
		$this->set(compact('errors', 'row_blk'));
	}
        
        /**
	 * Purpose : TO dispaly contact us form & send mail
	 * Created on : 30-Sep-2013
	 * Author : Nitin
	*/
	function discount()
	{
		$errors = '';
		$error_flag = false;
		$add_errors = array();
                
                

		if ($this->request->is('post'))
		{
			$this->ContactUs->set($this->data);
                        if($this->ContactUs->validates() && !$error_flag)
			{
				//SENDING THE MAIL
				$this->loadModel('EmailTemplate');
				
				$srch_array = array("{{name}}" => $this->data['ContactUs']['fullname'], "{{email_id}}" => $this->data['ContactUs']['email_id'],"{{message}}" => $this->data['ContactUs']['message']);
				$email_values = $this->EmailTemplate->getvalues('contact_us', $srch_array);
                                $to_emailid = $email_values['from_email'];
				$this->Email->from = $this->data['ContactUs']['fullname'].' <'.$this->data['ContactUs']['email_id'].'>';
				$this->Email->to = $to_emailid;
				$this->Email->subject = $email_values['subject'];
				$this->Email->sendAs = 'html';
				$this->Email->send($email_values['content']);
                                $this->Session->setFlash(__("Thank you for contacting ".SITENAME.". You will be hearing from us very soon."), 'flash_success');
				$this->redirect($this->referer());
			}
			else
			{
				$errors = $this->ContactUs->validationErrors;
				$errors = array_merge($errors, $add_errors);
			}
		}
                
               
                        $LAYOUT_META_TITLE = 'Contact | Maxlanguages.com';
                          $LAYOUT_META_DESCRIPTION = "We’re here to help you find the ideal language course as easily as possible! We'll get back to you as soon as we can.";
                          $og_image=SITE_URL."img/og_image.jpeg";
                          $this->set(compact('LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image')); 
                        $this->set(compact('errors', 'row_blk'));
	}
	
}	
