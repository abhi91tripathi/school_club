// Js for home page

$(document).ready(function () {



// on change of language selection

    $('#lang_input').on('change', function () {
        var name = $('#lang_input').val();
        get_destination(name);
    });
/// get destination on page load
    get_destination($('#lang_input').val());
    $(".select_search").select2();
    $("#destination_input").select2({
        formatResult: format,
        formatSelection: format,
        escapeMarkup: function (m) {
            return m;
        }

    });


$('#school_search').on('click', function () {
        // make custom url 
        var language = $('#lang_input').val().toLowerCase();
        var destination = $('#destination_input').val().toLowerCase();
        var week = $('#week_input').val();
        var slug=$('#site_language').val();
        
        if (destination == '' && week == '')
        {
          
            switch(slug){
                case 'fr':
                    var url = JS_SITE_URL+ 'cours-' + language+ '-etranger';
                break;
                case 'es':
                   var url = JS_SITE_URL+ 'cursos-' + language+ '-extranjero';
                break;
                case 'it':
                    var url = JS_SITE_URL+'corsi-' + language+'-estero';
                break;
                case 'de':
                    var url = JS_SITE_URL+'sprachkurs-'+language+'-ausland';
                break;
                case 'pt':
                    var url = JS_SITE_URL+ 'cursos-' + language+'-exterior';
                break;
                default:
                     var url = JS_SITE_URL+'learn-' + language + '-abroad';
                break;

            }
              $('#search_form').attr('action', url);
            
        }
        else {
            if (destination == '' && week != '')
            {
                switch(slug){
                    case 'fr':
                    var url = JS_SITE_URL+ 'cours-' + language+ '-etranger?week=' + week;
                break;
                case 'es':
                   var url = JS_SITE_URL+'cursos-' + language+ '-extranjero?week=' + week;
                break;
                case 'it':
                    var url = JS_SITE_URL+ 'corsi-' + language+'-estero?week=' + week;
                break;
                case 'de':
                    var url = JS_SITE_URL+'sprachkurs-'+language+'-ausland?week=' + week;
                break;
                case 'pt':
                    var url = JS_SITE_URL+ 'cursos-' + language+'-exterior?week=' + week;
                break;
                default:
                     var url = JS_SITE_URL+ 'learn-' + language + '-abroad?week=' + week;
                break;
            }
                $('#search_form').attr('action', url);
            }
            else {
                if (destination != '' && week != '') {
                     switch(slug){
                                    case 'fr':
                                        var url = JS_SITE_URL + 'cours-' + language + '-' + destination  + '?week=' + week;
                                    break;
                                    case 'es':
                                        var url = JS_SITE_URL + 'cursos-' + language + '-en-' + destination + '?week=' + week;
                                    break;
                                    case 'it':
                                       var url = JS_SITE_URL + 'corsi-' + language + '-in-' + destination + '?week=' + week;
                                    break;
                                    case 'de':
                                        var url = JS_SITE_URL + 'sprachkurs-' + language + '-in-' + destination + '?week=' + week;
                                    break;
                                    case 'pt':
                                        var url = JS_SITE_URL +'cursos-' + language + '-' + destination+ '?week=' + week;
                                    break;
                                    default:
                                       var url = JS_SITE_URL + 'learn-' + language + '-in-' + destination+ '?week=' + week;
                                    break;
                          
                             }
                   $('#search_form').attr('action', url);
                }

                else {
                    if (destination != '' && week == '') {
                  
                      switch(slug){
                                    case 'fr':
                                       var url = JS_SITE_URL + 'cours-' + language + '-ecoles-' + destination;
                                    break;
                                    case 'es':
                                        var url = JS_SITE_URL + 'cursos-' + language + '-en-' + destination;
                                    break;
                                    case 'it':
                                      var url = JS_SITE_URL + 'corsi-' + language + '-in-' + destination;
                                    break;
                                    case 'de':
                                       var url = JS_SITE_URL +'sprachkurs-' + language + '-in-' + destination;
                                    break;
                                    case 'pt':
                                    var url = JS_SITE_URL + 'cursos-' + language + '-em-' + destination;
                                    break;
                                    default:
                                       var url = JS_SITE_URL + 'learn-' + language + '-in-' + destination;
                                    break;
                          
                             }
                        $('#search_form').attr('action', url);
                    }
                }
            }
        }
        

    });


    $('.homeslider').bxSlider({
        minSlides: 1,
        maxSlides: 5,
        slideWidth: 219,
        slideMargin: 10,
        moveSlides: 1,
        pager: false,
        infiniteLoop: false
    });



    //latest_school();

});


// Purpose: get destination list 
function get_destination(language_name) {
    var name = language_name;
    $.post(JS_SITE_URL + 'Pages/get_destination', {language_name: name}, function (d) {

        $('#destination_input').html(d);
        //$('#select2-chosen-4').html('<?php echo __("Any Destination");?>');
    });
}


//Purpose:set flag on select input
//created by:Abhishek Tripathi
//created on:22/09/14

function format(state) {
    var originalOption = state.element;
  
    if ($(originalOption).data('foo') != '0') {
        var flag_name = $(originalOption).data('foo');

        return "<img class='flag' src='" + site_url + "files/country_flag/" + flag_name + "' alt='" + $(originalOption).data('foo') + "' width='20px'/>&nbsp;" + state.text;
    }
    else {
        return state.text;
    }
}









