//Purpose:Search page script
//created on:24 june 2014
//Author:Abhishek Tripathi

var school_list_reset = 0;
var language_list_reset = 0;
var destination_list_reset = 0;
var course_list_reset = 0;
var accomodation_reset = 0;
var student_per_list_rest = 0;
var accrediation_list_rest = 0;
var week_reset = 0;
var start_date_reset = 0
var price_reset = 0;
var sort_reset = 0;
var promo_reset = 0;
var reset_all = 0;
var review_list_reset = 0;






$(document).ready(function ()
{

    intial_data();

    if (promo == 1) {
        $('#discount_inpt').prop("checked", true)
        $('#discount_inpt').val(1);

        promo_reset = 1;
        reset_all_btn_visibility();
    }
    get_destination($('#language_list').val());

    (language.toLocaleLowerCase() == all_language) ? language_list_reset = 0 : language_list_reset = 1;

    reset_btn_visibility();
    //purpose:click on student per class check boxes
    $('.student_per').on('click', function () {
    });

    $(".selectsearch").select2();
    //price slider
    slider();

    $("container").click(function () {
        $('.slider-box').toggle();
    });

    $("#destination_input").select2({
        formatResult: format,
        formatSelection: format,
        escapeMarkup: function (m) {
            return m;
        }
    });
    /*-------------------search filter-------------------------*/
    $('#school_list').on('change', function () {
        school_list_reset = 1;
        reset_all_btn_visibility();
        school_filter();
    });

    $('#course_list').on('change', function () {
        course_list_reset = 1;
        reset_all_btn_visibility();
        school_filter();
    });
    $('#language_list').on('change', function () {
        var language_name = $('#language_list').val().toLowerCase();
        var url = JS_SITE_URL + prefix + '-' + language_name + '-' + sufix;
        window.location.href = url;
    });
    $('#destination_input').on('change', function () {
        url_change();
    })
    $('#accomoadtion_list').on('change', function () {
        accomodation_reset = 1;
        reset_all_btn_visibility();
        school_filter();
    })
    $('.student_per').on('click', function () {
        student_per_class();

    })
    $('.accredation_inp').on('click', function () {
        if ($(this).is(':checked')) {

            accredation.push($(this).val());
        }
        else {
            removeA(accredation, $(this).val());
        }
        school_filter();
    })
    $('#week_inpt').on('change', function () {
        week_on_change();


    });

    $('#sort_by').on('change', function () {
        if ($(this).val() == '') {
            sort_reset = 0;
            reset_all_btn_visibility();
        }
        else {
            sort_reset = 1;
            reset_all_btn_visibility();

        }
        student_per_class();
    });

    $('#price_filter').on('click', function () {
        school_filter();
    });
    $('#discount_inpt').on('click', function () {
        if ($(this).is(':checked'))
        {
            $(this).val(1);
            promo_reset = 1;
            reset_all_btn_visibility();
            school_filter();
        }
        else {
            $(this).val('');
            promo_reset = 0;
            reset_all_btn_visibility();
            school_filter();
        }
    });
    $('.review_sys').on('click', function () {
        review_per_school();
    });


    //--------------------reset event--------------------------------------
    $('.reset_btn').on('click', function () {
        var id = $(this).attr('id');
        switch (id) {
            case 'school_list_reset':
                if (school_list_reset == 0) {
                    return false;
                }
                else {
                    school_list_reset = 0;
                    reset_all_btn_visibility();

                }
                break;
            case 'course_list_reset':
                if (course_list_reset == 0) {
                    return false;
                }
                else {
                    course_list_reset = 0;
                    reset_all_btn_visibility();
                    // reset_btn_visibility();
                }
                break;
            case 'accomodation_reset':
                if (accomodation_reset == 0) {
                    return false;
                }
                else {
                    accomodation_reset = 0;
                    reset_all_btn_visibility();
                    //reset_btn_visibility();
                }
                break;

        }
        var reset_inpt = '#' + $(this).attr('reset_inpt');
        var reset_text_input = '#' + $(this).attr('reset_text_input');
        var reset_text = $(this).attr('reset_text');
        console.log(reset_text);

        $(reset_inpt).val('');
        console.log($(reset_inpt).val());
        $(reset_text_input).html(reset_text);
        school_filter();
    });

    $('.reset_btn_perclass').on('click', function () {
        if (student_per_list_rest == 0) {
            return false;
        }
        else {
            student_per_list_rest = 0;
            reset_all_btn_visibility();
            //reset_btn_visibility();
        }
        $(this).parent().parent().parent().find('input').attr('checked', false);
        max = '';

        school_filter();
    });
    $('.reset_btn_accredation').on('click', function () {
        if (accrediation_list_rest == 0) {
            return false;
        }
        else {
            accrediation_list_rest = 0;
            reset_all_btn_visibility();
            //reset_btn_visibility();
        }

        $(this).parent().parent().parent().find('input').attr('checked', false);
        accredation.length = 0;
        school_filter();
    });
    //---------------------------------reset destination----------------------
    $('.reset_btn_destination').on('click', function () {
        if (destination_list_reset == 0) {
            return false;
        }
        else {
            $('#destination_input').val('');
            url_change();
        }

    })
    $('#language_list_reset').on('click', function () {
        if (language_list_reset == 0) {
            return false;
        }
        else {
            $('#language_list').val(all_language);
            url_change();
        }
    })
    //-------------------------------------reset all setting-------------------------------

    $('.reset_all').on('click', function () {
        if (reset_all == 0) {

            return false;
        }
        else {
            var language=$('#language_list').find('option').first().val();
        
            $('#language_list').val(language);
            reset_secondry();
            url_change();
        }
    });

    //--------------------------------click on check box student per class 1 oct------------------

    $('.student_per').on('click', function () {
        student_per_list_rest = 0;
        for (var i = 1; i < 4; i++) {
            $('#student_per_' + i).is(':checked') ? student_per_list_rest = 1 : true;
        }
        reset_all_btn_visibility();
        reset_btn_visibility();


    })
    $('.accredation_inp').on('click', function () {
        accrediation_list_rest = 0;
        for (var i = 1; i <= accredation_count; i++) {
            $('#accredation_' + i).is(':checked') ? accrediation_list_rest = 1 : true;
        }
        reset_all_btn_visibility();
        reset_btn_visibility();


    });
    //----------------------------week reset----------------------1 oct 14-----------
    if (weeks != '') {
        week_reset = 1;
    }

    //----------------------------reset btn visibility-------------------1 oct 14-----------
    reset_all_btn_visibility();

    //-----------------------------reset review--------------------------18 oct-----------

    $('#review_list_rest').on('click', function () {

        if (review_list_reset == 0) {
            return false;
        }
        else {
            review_list_reset = 0;
            reset_all_btn_visibility();
            //reset_btn_visibility();
        }
        $(this).parent().parent().parent().find('input').attr('checked', false);
        review = '';

        school_filter();
    });



});



//Purpose:get data on load page
//created by:Abhishek Tripathi
//created on:19/09/14
function intial_data()
{


    $.post('Results/get_search_result', {
        language: language,
        country_id: country_id,
        destination_id: destination_id,
        weeks: weeks,
        promo: promo



    }, function (d) {
        $('.quote-overlay').hide();
        var parsed = JSON.parse(d);
        viewModel.name(parsed.list);

        intial_count = parsed.count;
        var sub_title1 = $('.sub_title1').html();
        var sub_title2 = $('.sub_title2').html();
        sub_title1 = sub_title1.replace('0', parsed.count);
        sub_title2 = sub_title2.replace('0', parsed.count);
        $('.sub_title1').html(sub_title1);
        $('.sub_title2').html(sub_title2);
        paginator();
        onMouseOver();
        // var pins=[];
        $.each(parsed.list, function (key, value)
        {
            var lat = [parsed.list[key]['lat'], parsed.list[key]['long'], parsed.list[key]['title'], parsed.list[key]['slug']];
            pins.push(lat);
        });
        //--map intialization--------
        initialize();
        // quick view initialization
        quick_view();

        //--------------reset_filter-----------
        $('.reset_btn_secondry').on('click', function () {
            reset_secondry();

        });
        $('.reset_all').on('click', function () {
            if (reset_all == 0) {

                return false;
            }
            else {
                $('#language_list').val('language');
                reset_secondry();
                url_change();
            }
        });

    });
}


//Purpose:get data by id
//created by:Abhishek Tripathi
//created on:19/09/14		
function data() {
    $.post('get_data_id', function (d) {
        var data = JSON.parse(d);
        var parsed = JSON.parse(d);
        viewModel.name(parsed);
    });
}

//Purpose:create model (knockout js)
//created by:Abhishek Tripathi
//created on:19/09/14 
var viewModel = {
    name: ko.observable(),
    locations: ko.observableArray([
    ])

};

ko.applyBindings(viewModel);


//Purpose:Paginator
//created by:Abhishek Tripathi
//created on:19/09/14

function paginator() {
    /* initiate the plugin */
    $("div.holder").jPages({
        containerID: "itemContainer",
        perPage: 15,
        startPage: 1,
        startRange: 1,
        midRange: 5,
        endRange: 1
    });
}

//Purpose:Hover card on mouse over
//created by:Abhishek Tripathi
//created on:19/09/14

function onMouseOver() {

    var hoverHTMLDemoAjax = '<div class="item-quick-detail"></div>';

    $(".mouser_hover").hovercard({
        detailsHTML: hoverHTMLDemoAjax,
        width: 450,
        cardImgSrc: 'http://ejohn.org/files/short.sm.jpg',
        onHoverIn: function () {
            // set your twitter id
            var id = $(this).parent().parent().attr('insti_id');


            $.ajax({
                url: 'Results/school_info/' + id,
                type: 'GET',
                dataType: 'json',
                beforeSend: function () {
                    $("#demo-cb-tweets").prepend('<p class="loading-text">Loading latesttweets...</p>');
                },
                success: function (data) {
                    $('.item-quick-detail').html(data);

                },
                complete: function () {
                    $('.loading-text').remove();
                }
            });

        }
    });
}



// Purpose: get destination list 
function get_destination(name) {


    $.post(JS_SITE_URL + 'Results/get_country_list/' + name, function (d)
    {
        $('#destination_input').html(d);
        $('#select2-chosen-8').html(all_destination);
        if (country_name != '') {
            if (city_name != '') {
                $('#destination_input').val(city_name + '-' + country_name);
                $('#select2-chosen-8').html(city_name);
            }
            else {
                $('#destination_input').val(country_name);
                $('#select2-chosen-8').html(country_name);
            }
            $('#select2-chosen-8').html() == all_destination ? destination_list_reset = 0 : destination_list_reset = 1;
            reset_all_btn_visibility();
            reset_btn_visibility();
        }
    });
}



//Purpose:set flag on select input
//created by:Abhishek Tripathi
//created on:22/09/14

function format(state) {
    var originalOption = state.element;

    if ($(originalOption).data('foo') != '0') {
        var flag_name = $(originalOption).data('foo');

        return "<img class='flag' src='" + site_url + "files/country_flag/" + flag_name + "' alt='" + $(originalOption).data('foo') + "' width='20px'/>&nbsp;" + state.text;
    }
    else {
        return state.text;
    }
}


//Purpose:set start date and end date
//created by:Abhishek Tripathi
//created on:22/09/14

$(function () {
    $("#startdate").datepicker({
        dateFormat: "dd-M-yy",
        minDate: 0,
        beforeShowDay: function (date) {
            return [date.getDay() == 1, ""]
        },
        onSelect: function (date) {
            if (weeks != '') {
                var week = weeks - 1;
                var calculteweek = 4 + 7 * week;

                var date2 = $('#startdate').datepicker('getDate');
                date2.setDate(date2.getDate() + calculteweek);
                $('#enddate').datepicker('setDate', date2);

                //sets minDate to dt1 date + 1
                $('#enddate').datepicker('option', 'minDate', date2);
                $('#enddate').datepicker('option', 'maxDate', date2);
                start_date_reset = 1;
                reset_all_btn_visibility();
                school_filter();
            }
            else {
                var date2 = $('#startdate').datepicker('getDate');
                date2.setDate(date2.getDate() + 4);
                $('#enddate').datepicker('option', 'minDate', date2);
                $('#enddate').datepicker('setDate', date2);
                var week = weeks_between($('#startdate').datepicker('getDate'), $('#enddate').datepicker('getDate'))
                weeks = week + 1;

                $('#select2-chosen-6').html(weeks + ' Weeks');
                start_date_reset = 1;
                reset_all_btn_visibility();
                school_filter();
            }
        }
    });
    $('#enddate').datepicker({
        dateFormat: "dd-M-yy",
        beforeShowDay: function (date) {
            return [date.getDay() == 5, ""]
        },
        onSelect: function (date) {
            var week = weeks_between($('#startdate').datepicker('getDate'), $('#enddate').datepicker('getDate'))
            weeks = week + 1;

            $('#select2-chosen-6').html(weeks + ' Weeks');
            school_filter();
        },
        onClose: function () {
            var dt1 = $('#startdate').datepicker('getDate');
            var dt2 = $('#enddate').datepicker('getDate');
            //check to prevent a user from entering a date below date of dt1
            if (dt2 <= dt1) {
                var minDate = $('#enddate').datepicker('option', 'minDate');
                $('#enddate').datepicker('setDate', minDate);
            }
        }
    });
})



//Purpose:get flag url
//created by:Abhishek Tripathi
//created on:22/09/14

function get_flag(country) {
    var country_name = country;
    $.post('Country/get_flag',
            {name: country_name},
    function (d) {
        var data = JSON.parse(d);
        return data;
    })


}

//Purpose:slider for budget range
//created by:Abhishek Tripathi
//created on:22/09/14

function slider() {
    $("#slider-range").slider({
        range: true,
        min: min_price,
        max: max_price,
        values: [min_price, max_price],
        slide: function (event, ui) {
            $("#amount1").val(ui.values[0]);
            $("#amount2").val(ui.values[1]);

            price_reset = 1;
            reset_all_btn_visibility();

        }
    });
    $("#amount1").val(min_price);
    $("#amount2").val(max_price);
}
//--------------------------------------filter function----------------------------------------
function school_filter() {
    var school_name = $('#school_list').val();
    var course_type = $('#course_list').val();
    if (course_type != null) {
        var newcourse = course_type.split(':');
        var main_course;
        var sub_course;

        if (newcourse != 0 && newcourse != null) {
            console.log(newcourse[1]);
            if (typeof (newcourse[1]) == 'undefined') {
                main_course = newcourse[0];
            }
            else {
                main_course = newcourse[1];
                sub_course = newcourse[0];
            }
        }
    }
    var accomodation_type = $('#accomoadtion_list').val();
    var sort_by = $('#sort_by').val();
    var date = $('#startdate').val();
    var mim_price_val = $('#amount1').val();
    var max_price_val = $('#amount2').val();
    var promo = $('#discount_inpt').val();
    $.post('Results/get_filter_data',
            {
                language_id: language_id,
                country_id: country_id,
                destination_id: destination_id,
                week: weeks,
                school_name: school_name,
                course_id: main_course,
                accomodation_id: accomodation_type,
                max_student: max,
                accredation: accredation,
                sort_by: sort_by,
                date: date,
                min_price: mim_price_val,
                max_price: max_price_val,
                promo: promo,
                review: review,
                sub_course: sub_course
            },
    function (d) {
        var data = JSON.parse(d);
        var parsed = JSON.parse(d);
        viewModel.name(parsed.list);

        var sub_title1 = $('.sub_title1').html();
        var sub_title2 = $('.sub_title2').html();
        sub_title1 = sub_title1.replace(intial_count, parsed.count);
        sub_title2 = sub_title2.replace(intial_count, parsed.count);
        intial_count = parsed.count;
        $('.sub_title1').html(sub_title1);
        $('.sub_title2').html(sub_title2);
        paginator();
        onMouseOver();
        pins.length = 0;
        $.each(parsed.list, function (key, value)
        {
            var lat = [parsed.list[key]['lat'], parsed.list[key]['long'], parsed.list[key]['title'], parsed.list[key]['slug']];
            pins.push(lat);
        });
        //--map intialization--------
        initialize();
        // quick view initialization
        quick_view();
        //--------------reset_filter-----------
        $('.reset_btn_secondry').on('click', function () {
            reset_secondry();

        });
        $('.reset_all').on('click', function () {
            if (reset_all == 0) {

                return false;
            }
            else {
                $('#language_list').val('language');
                reset_secondry();
                url_change();
            }
        });

    })

}
function student_per_class() {
    max = '';
    if ($('#student_per_1').is(':checked')) {

        max = $('#student_per_1').attr('max');
    }
    if ($('#student_per_2').is(':checked')) {

        max = $('#student_per_2').attr('max');
    }
    if ($('#student_per_3').is(':checked')) {

        max = $('#student_per_3').attr('max');
    }
    if ($('#student_per_4').is(':checked')) {

        max = $('#student_per_4').attr('max');
    }
    if ($('#student_per_5').is(':checked')) {

        max = $('#student_per_5').attr('max');
    }
    school_filter();
}


//--------------------------------------filter function----------------------------------------

function removeA(arr) {
    var what, a = arguments, L = a.length, ax;
    while (L > 1 && arr.length) {
        what = a[--L];
        while ((ax = arr.indexOf(what)) !== -1) {
            arr.splice(ax, 1);
        }
    }
    return arr;
}
//-------------------calculate week between two date-----------
function weeks_between(date1, date2) {
    // The number of milliseconds in one week
    var ONE_WEEK = 1000 * 60 * 60 * 24 * 7;
    // Convert both dates to milliseconds
    var date1_ms = date1.getTime();
    var date2_ms = date2.getTime();
    // Calculate the difference in milliseconds
    var difference_ms = Math.abs(date1_ms - date2_ms);
    // Convert back to weeks and return hole weeks
    return Math.floor(difference_ms / ONE_WEEK);
}

//-------------------change on week--------------------
function week_on_change() {
    var language = $('#language_list').val().toLowerCase();

    var week = $('#week_inpt').val();
    if (week != '') {
        if (country_name == '' && week != '')
        {
            var url = JS_SITE_URL + 'learn-' + language + '-abroad?week=' + week;
            window.location.href = url;
        }
        else {
            if (country_name != '' && week != '')
            {

                if (city_name != '') {
                    var url = JS_SITE_URL + 'learn-' + language + '-in-' + city_name.toLowerCase() + '-' + country_name.toLowerCase() + '?week=' + week;
                    window.location.href = url;
                }
                else {
                    var url = JS_SITE_URL + 'learn-' + language + '-in-' + country_name.toLowerCase() + '?week=' + week;
                    window.location.href = url;
                }
            }
        }
    }
    else
    {
        if (country_name == '')
        {
            var url = JS_SITE_URL + 'learn-' + language + '-abroad';
            window.location.href = url;
        }
        else {
            if (country_name != '')
            {

                if (city_name != '') {
                    var url = JS_SITE_URL + 'learn-' + language + '-in-' + city_name.toLowerCase() + '-' + country_name.toLowerCase();
                    window.location.href = url;
                }
                else {
                    var url = JS_SITE_URL + 'learn-' + language + '-in-' + country_name.toLowerCase();
                    window.location.href = url;
                }
            }
        }
    }
}

function url_change() {

    var language = $('#language_list').val().toLowerCase();

    if ($('#destination_input').val() != null) {
        var destination = $('#destination_input').val().toLowerCase();
    }
    else {
        var destination = '';
    }

    var week = $('#week_inpt').val();
    if (destination == '' && week == '')
    {
        var url = JS_SITE_URL + prefix + '-' + language + '-' + sufix;
        window.location.href = url;
    }
    else {
        if (destination == '' && week != '')
        {
            var url = JS_SITE_URL + prefix + '-' + language + '-' + sufix + '?week=' + week;
            window.location.href = url;
        }
        else {
            if (destination != '' && week != '') {
                var url = JS_SITE_URL + prefix + '-' + language + middle + destination + '?week=' + week;
                window.location.href = url;
            }

            else {
                if (destination != '' && week == '') {
                    var url = JS_SITE_URL + prefix + '-' + language + middle + destination;
                    window.location.href = url;
                }
            }
        }
    }
}

//-------------reset slider----------------------
function resetSlider() {
    var $slider = $("#slider-range");
    $slider.slider("values", 0, inti_min_price);
    $slider.slider("values", 1, inti_max_price);
    $("#amount1").val(inti_min_price);
    $("#amount2").val(inti_max_price);

}

//--------------------reset secondry-------------
function reset_secondry() {
    if ($('#week_inpt').val() == '') {
        $('#startdate').val('');
        $('#enddate').val('');
        $('#discount_inpt').attr('checked', false).val('');
        resetSlider();
        school_filter();
    }
    else {
        $('#week_inpt').val('');
        week_on_change();

    }


}
//---------------------reset btn disable-----------------------------

function reset_btn_visibility() {
    (school_list_reset != 0) ? $('#school_list_reset').removeClass('link_disable') : $('#school_list_reset').addClass('link_disable');
    (language_list_reset != 0) ? $('#language_list_reset').removeClass('link_disable') : $('#language_list_reset').addClass('link_disable');
    (destination_list_reset != 0) ? $('#destination_list_reset').removeClass('link_disable') : $('#destination_list_reset').addClass('link_disable');
    (course_list_reset != 0) ? $('#course_list_reset').removeClass('link_disable') : $('#course_list_reset').addClass('link_disable');
    (accomodation_reset != 0) ? $('#accomodation_reset').removeClass('link_disable') : $('#accomodation_reset').addClass('link_disable');
    (student_per_list_rest != 0) ? $('#student_per_list_rest').removeClass('link_disable') : $('#student_per_list_rest').addClass('link_disable');
    (accrediation_list_rest != 0) ? $('#accrediation_list_rest').removeClass('link_disable') : $('#accrediation_list_rest').addClass('link_disable');
    (review_list_reset != 0) ? $('#review_list_rest').removeClass('link_disable') : $('#review_list_rest').addClass('link_disable');
    (reset_all != 0) ? $('.reset_all').removeClass('link_disable') : $('.reset_all').addClass('link_disable');

}

//----------------------------------------reset all fields---------------------------------
function reset_all_btn_visibility() {

    if (school_list_reset == 1 || language_list_reset == 1 || destination_list_reset == 1 || course_list_reset == 1 || accomodation_reset == 1 || student_per_list_rest == 1 || accrediation_list_rest == 1 || week_reset == 1 || start_date_reset == 1 || price_reset == 1 || sort_reset == 1 || promo_reset == 1 || review_list_reset == 1) {

        reset_all = 1;

    }
    else {
        reset_all = 0;
    }
    reset_btn_visibility();
}
//----------------------------Quick view --1 oct 2014-----------
function quick_view() {
    $('.school_box').on('mouseover', function () {
        $(this).find('.hc-name').css('opacity', 1)

    });
    $('.school_box').on('mouseout', function () {
        $(this).find('.hc-name').css('opacity', 0, 'slow')

    });
}
/-------------------------------------------start rate custome binding--------------------------/
ko.bindingHandlers.rateit = {
    init: function (element, valueAccessor) {
        var local = ko.toJS(valueAccessor()),
                options = {};

        if (typeof local === 'number') {
            local = {
                value: local
            };
        }
        if (typeof local === 'float') {
            local = {
                value: local
            };
        }

        ko.utils.extend(options, ko.bindingHandlers.rateit.options);
        ko.utils.extend(options, local);

        $(element).rateit(options);
        //register an event handler to update the viewmodel when the view is updated.
        $(element).bind('rated', function (event, value) {
            var floa = parseFloat(value.toFixed(1));
            var observable = valueAccessor();
            if (ko.isObservable(observable)) {
                observable(floa);
            } else {
                if (observable.value !== undefined && ko.isObservable(observable.value)) {
                    observable.value(floa);
                }
            }
        });
    },
    update: function (element, valueAccessor) {
        var local = ko.toJS(valueAccessor());

        if (typeof local === 'number') {
            local = {
                value: local
            };
        }
        if (typeof local === 'float') {
            local = {
                value: local
            };
        }
        if (local.value !== undefined) {
            var floa = parseFloat(local.value.toFixed(1));
            $(element).rateit('value', floa);
        }

    },
    options: {
        //this section is to allow users to override the rateit defaults on a per site basis.
        //override by adding ko.bindingHandlers.rateit.options = { ... }
    }
};

/*-------------------------- review per school------------------------------------------*/

function review_per_school() {
    review = '';
    if ($('#review_school_1').is(':checked')) {

        review = $('#review_school_1').attr('min');
    }
    if ($('#review_school_2').is(':checked')) {

        review = $('#review_school_2').attr('min');
    }
    if ($('#review_school_3').is(':checked')) {

        review = $('#review_school_3').attr('min');
    }
    if ($('#review_school_4').is(':checked')) {

        review = $('#review_school_4').attr('min');
    }
    review_list_reset = 0;
    for (var i = 1; i < 4; i++) {
        $('#review_school_' + i).is(':checked') ? review_list_reset = 1 : true;
    }
    reset_all_btn_visibility();
    reset_btn_visibility();
    school_filter();
}



