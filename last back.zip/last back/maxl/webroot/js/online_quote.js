//Script for online quote section
$(function(){
	//Load data on page load after ajax function call
	$('#course_id,#language_level').on('change',function(){ 
		var course_id = $('#course_id').val();
		if(course_id!='')
		{
                    var language_level=$('#language_level').val();
                    if(language_level==0){
                        var beg=1;
                    }
                    else{
                        var beg=0;
                    }
                     var already_attend='no';
                     
                if($('#already_attendYes').is(':checked')){
                     already_attend='yes';
                }  
                
			get_date(course_id,beg,already_attend);
                        
		}
               
		else
		{
			$(".finalPrice").val('').html('-');
			$('.weekPrice').val('').html('-');
			$('.calPriceUSD,.calPriceEUR,deposit_now,deposit_now_eur').html('-');
			$('.startting_date_data').hide();
			$('#accomodation_id').html('Select Accomodation');
			$('#no_of_weeks').html('Select Week');
			$(".course_starting_date .start_date,#no_of_weeks,#accomodation_id").attr('disabled',true);
                        $('.extra_fee').html('');
                        $('.regfeePrice').html('-');
                      
		}
	});
	
	
	//Get the price after week change calling ajax function
	$('#no_of_weeks').on('change',function(){ 
            var language_level=$('#language_level').val();
                    if(language_level==0){
                        var beg=1;
                    }
                    else{
                        var beg=0;
                    }
		$('#accomodation_id').val('');
		if($('#start_date_val').val()==4)
		{
			var start_date = $('.startting_date_data .start_date').val();
                       
		}
		else
		{
			var start_date = $('.course_starting_date .start_date').val();
		}
		var week_val = $('#no_of_weeks').val();
		var course_id = $('#course_id').val();
		var accomodation_id = $('#accomodation_id').val();
                
                var already_attend='no';
                     
                if($('#already_attendYes').is(':checked')){
                     already_attend='yes';
                }
		get_price_by_quote(course_id,start_date,week_val,accomodation_id,beg,already_attend);
	});
	
	
	//Get the price after week change calling ajax function
	$('#accomodation_id').on('change',function(){ 
            var language_level=$('#language_level').val();
                    if(language_level==0){
                        var beg=1;
                    }
                    else{
                        var beg=0;
                    }
		var accomodation_id = $(this).val();
		var course_id = $('#course_id').val();
		var week_val = $('#no_of_weeks').val();
		if($('#start_date_val').val()==4)
		{
			var start_date = $('.startting_date_data .start_date').val();
		}
		else
		{
			var start_date = $('.course_starting_date .start_date').val();
		}
		
		    var already_attend='no';
                     
                if($('#already_attendYes').is(':checked')){
                     already_attend='yes';
                } 
		get_price_by_quote(course_id,start_date,week_val,accomodation_id,beg,already_attend);
		
	});
	
	//Script for Ask a question
	$('#frm_ask_ques').validate({
	 	errorPlacement: function(error, element) {
			error.appendTo( element.parent("label").parent("li") );
		}
	});
        
        //Script for Ask a question
	$('#email_to_friend').validate({
	 	errorPlacement: function(error, element) {
			error.appendTo( element.parent("label").parent("li") );
		}
	});
        
	$('.ready-book').on('click',function(){
		var name = $('.askName').val();
		var email = $('.askEmail').val();
		var message = $('.askMessage').val();
		var institute_id = $('.askinstitute').val();
                var type=$('.asktype').val();
		if($('#frm_ask_ques').valid())
		{
			send_online_question(name,email,message,institute_id,type);
		}
	})
        $('.ready-email').on('click',function(){
		
		
		if($('#email_to_friend').valid())
		{
                    var name = $('.username').val();
                    var email = $('.friendEmail').val();
			$('#mail_to').val(email);
                        $('#mail_name').val(name);
                        $('#myModal_email').modal('hide');
                        $('#frm_addedit').submit();
                        
		}
	})
})

//get the price using weeks
function get_price_by_quote(course_id,start_date,week_val,accomodation_id,setVal,setVal2,default_set)
{
    // var start_date=$('.start_date').val();
	$.ajax({
		url: JS_SITE_URL+'Ajax/get_price/',
		type: 'GET',
                cache:false,
		data:'course_id='+course_id+'&start_date='+start_date+'&week_val='+week_val+'&accomodation_id='+accomodation_id+'&beg='+setVal+'&setVal='+setVal2,
		beforeSend: function () {
			$('.quote-overlay').css('display','block');
		},
		success: function (data) {
			$('.quote-overlay').css('display','none');
			var rss = $.parseJSON(data);
			
			if(rss.msg=='success')
			{
                            //----------clear discount--------------
                            ///$('.discount_field').html('').hide();
				//Show Price
				
				$('.calPriceUSD').html(rss.price.CURRENT_CURRENCY);
				$('.calPriceEUR').html(rss.price.PAID_CURRENCY);
				$('.finalPrice').val(rss.price.CURRENT_CURRENCY).html(rss.price.CURRENT_CURRENCY);
				$('.weekPrice').val(rss.price.WEEK_PRICE).html(rss.price.WEEK_PRICE);
				$('.accomPrice').val(rss.price.ACCOM_PRICE).html(rss.price.ACCOM_PRICE);
				$('.accomregPrice').val(rss.price.ACCOM_REG_PRICE).html(rss.price.ACCOM_REG_PRICE);
				$('.deposit_now').val(rss.price.DEPOSIT_NOW).html(rss.price.DEPOSIT_NOW);
				$('.deposit_now_eur').val(rss.price.DEPOSIT_NOW_EUR).html(rss.price.DEPOSIT_NOW_EUR);
                                 $('#discount').val('');
				//$('.discount').val(rss.price.DISCOUNT_BY_ME).html(rss.price.DISCOUNT_BY_ME);
				
				if(default_set=='selected_value')
				{
                                   
					$('.start_date').val($('.start_date').attr('data-value'));
					$('#no_of_weeks').val($('#no_of_weeks').attr('data-value'));
					$('#accomodation_id').val($('#accomodation_id').attr('data-value'));
				}
                                
                                        //-----------------descount  append in html ---------
                                        if(rss.price.discount_arr.length>=1){
                                             
                                             $('#discount').val(JSON.stringify(rss.price.discount_arr));
                                            $.each(rss.price.discount_arr,function(key,value){
                                                
                                                $('.'+value.class).html('');
                                                $('.'+value.class).show();
                                               var html='';
                                                html+='<div class="courses-name">'+value.key+'</div>';
                                               html+='<div class="amount minus-value"> -&nbsp;'+value.value+'</div>';
                                                $('.'+value.class).append(html);
                                            });
                                        }
				
			}
		},
		complete: function () {
		   
		}
	});
}

//get the date
function get_date(course_id,setVal,setVal2)
{
    var start_date=$('.start_date').val();
	$.ajax({
			url: JS_SITE_URL+'Ajax/get_course_data/'+course_id+'/'+setVal,
			type: 'GET',
                        cache:false,
			data:{'course_id':course_id,'beg':setVal,'setval':setVal2,'start_date':start_date},
			beforeSend: function () {
				$('.quote-overlay').css('display','block');
			},
			success: function (data) {
				$('.quote-overlay').css('display','none');
				var rss = $.parseJSON(data);
				var minWeek;
				var maxWeek;
				if(rss.msg=='success')
				{
					//$('.calPriceUSD').html(rss.price.USD);
					//$('.calPriceEUR').html(rss.price.EUR);
					$('.finalPrice').val('').html('-');
					$('.weekPrice').val('').html('-');
					$('.accomPrice').val('').html('-');
					$('.accomregPrice').val('').html('-');
					$('.deposit_now').val('').html('-');
					$('.deposit_now_eur').val('').html('-');
					//$('.discount').val('').html('-');
				
					$('.calPriceUSD,.calPriceEUR').html('0.00');
					//Show date
					$('.course_starting_date,.startting_date_data').hide();
					$(".course_starting_date .start_date,#no_of_weeks,#accomodation_id").removeAttr('disabled');
					$('#start_date_val').val(rss.course_starting_date);
                                        $('#level_val').val($('#language_level').val());
                                        $('#discount').val('');
					if(rss.course_starting_date==1)
					{
						$('.course_starting_date').show();
						$(".course_starting_date .start_date").datepicker("destroy").val('');
						$(".course_starting_date .start_date").datepicker({
							dateFormat: "dd-M-yy",
							maxDate: "1y",
						});
						
					}
					else if(rss.course_starting_date==2)
					{
						$('.course_starting_date').show();
						$(".course_starting_date .start_date").datepicker("destroy").val('');
						$(".course_starting_date .start_date").datepicker({
							dateFormat: "dd-M-yy",
							minDate: 0,
							maxDate: "1y",
							beforeShowDay: function(date){ return [date.getDay() == 1,""]},
						});
						
					}
					else if(rss.course_starting_date==3)
					{
						$('.course_starting_date').show();
						$(".course_starting_date .start_date").datepicker("destroy").val('');
						$(".course_starting_date .start_date").datepicker({
							dateFormat: "dd-M-yy",
							minDate: 0,
							maxDate: "1y",
							 beforeShowDay: function(date) {
								var day = date.getDay();
								var day2 = date.getDate();
								return [(day == 1 && day2 <= 3), ''];   
							}
						});
					}
					else if(rss.course_starting_date==4)
					{
						$('.startting_date_data').show();
						if(rss.startting_date_data!='')
                                                $('.startting_date_data .start_date').html('');
						{
							split_data = (rss.startting_date_data).split(',');
							
							//course_date
							var drop_data='';
							
							$.each(split_data, function (index, value) {
                                                             var dateEntered = value;
 
                                                                var date = dateEntered.substring(0, 2);
                                                                var month = dateEntered.substring(3, 5);
                                                                var year = dateEntered.substring(6, 10);
                                                                var dateToCompare = new Date(year, month - 1, date);
                                                                var currentDate = new Date();
                                                                  if (dateToCompare > currentDate) {
								drop_data += '<option value="'+ value +'">' + value + '</option>';
                                                            }
							});
							$('.startting_date_data .start_date').append(drop_data);
						}
					}
					
					//show weeks
					if(rss.weeks!='')
					{
						$('#no_of_weeks').html('');
						var i;
						minVal = parseInt(rss.weeks.min_week);
						maxVal = parseInt(rss.weeks.max_week);
						$('#no_of_weeks').append('<option value="">Duration</option>');
						for (i = minVal; i <= maxVal; i++) {
							if(i==1){
                                                            $('#no_of_weeks').append('<option value="'+ i +'">' + i + ' week</option>');
                                                        }else{
							$('#no_of_weeks').append('<option value="'+ i +'">' + i + ' weeks</option>');
                                                    }
						}
					}
					
					//show accom0dation
					if(rss.accomodation!='')
					{
						var accomodation = rss.accomodation;
						$('#accomodation_id').html('');
						var i;
						$('#accomodation_id').append('<option value="">No accommodation</option><option value="">I will decide later</option>');
						$.each(accomodation, function (index, value) {
							$('#accomodation_id').append('<option value="'+ value.id +'">' + value.title + '</option>');
						});
						
					}
					
					//show accom0dation
					if(rss.schoolregFee!='')
					{
						$('.regfeePrice').val(rss.schoolregFee).html(rss.schoolregFee);
					
					}
					if(rss.total!='')
                                        {
                                            	
                                                $('.calPriceEUR').html(rss.total_eur);
                                                $('.deposit_now').html(rss.due_deposit);
                                                $('.deposit_now_eur').html(rss.due_deposit_eur);
                                                $('.finalPrice').html(rss.total); 
                                        }
                                        
					//show Books Material Price
					if(rss.bookMaterialFee!='')
					{
						$('.bookMaterialFee').val(rss.bookMaterialFee).html(rss.bookMaterialFee);
					}
					
					
					//Change event of start date
					
					if($('#start_date_val').val()==4)
					{
						//var start_date = $('.startting_date_data .start_date').val();
						$('.startting_date_data .start_date').on('change',function(){ 
						 var start_date = $(this).val();	
                                                    var week_val = $('#no_of_weeks').val();
							var course_id = $('#course_id').val();
							var accomodation_id = $('#accomodation_id').val();
                                                           var language_level=$('#language_level').val();
                                                                if(language_level==0){
                                                                    var beg=1;
                                                                }
                                                                else{
                                                                    var beg=0;
                                                                }
                                                                 var already_attend='no';

                                                            if($('#already_attendYes').is(':checked')){
                                                                 already_attend='yes';
                                                            }
							get_price_by_quote(course_id,start_date,week_val,accomodation_id,beg,already_attend);
						})
					}
					else
					{
						
						
						$('.course_starting_date .start_date').on('change',function(){ 
                                                    var start_date = $(this).val();
							var week_val = $('#no_of_weeks').val();
							var course_id = $('#course_id').val();
							var accomodation_id = $('#accomodation_id').val();
                                                               var language_level=$('#language_level').val();
                                                                    if(language_level==0){
                                                                        var beg=1;
                                                                    }
                                                                    else{
                                                                        var beg=0;
                                                                    }
                                                                     var already_attend='no';

                                                                if($('#already_attendYes').is(':checked')){
                                                                     already_attend='yes';
                                                                }
							get_price_by_quote(course_id,start_date,week_val,accomodation_id,beg,already_attend);
						})
					}
						
					//pre select field if select
					if(setVal!='')
					{
						$('.'+setVal).val($('.'+setVal).attr('data-value'));
					}
                                        
                                        if(rss.Extra_fee!=''){
                                            $('.extra_fee').html('')
                                            $('#extra_fee').val(JSON.stringify(rss.Extra_fee));
                                            $.each(rss.Extra_fee,function(key,value){
                                                var html='';
                                                        html+='<div class="list-row clearfix"><div class="courses-name">'+value.key+'</div>';
							 html+='<div class="amount bookMaterialFee">'+value.price+'</div></div>';
                                                 $('.extra_fee').append(html);        
                                            });
                                            
                                        }
                                        
                                        //-----------------descount  append in html ---------
                                        if(rss.discount_arr.length>=1){
                                            
                                          
                                            $('#discount').val(JSON.stringify(rss.discount_arr));
                                            $.each(rss.discount_arr,function(key,value){
                                                
                                                $('.'+value.class).html('');
                                                 $('.'+value.class).show();
                                               var html='';
                                               html+='<div class="courses-name">'+value.key+'</div>';
                                               html+='<div class="amount minus-value"> -&nbsp;'+value.value+'</div>';
                                               var discount_val={'key':value.key,'value':value.value};
                                              
                                                $('.'+value.class).append(html);
                                            });
                                            
                                            
                                        }
				}
			},
			complete: function () {
			   //$('.loading-text').remove();
			}
		});
}

//send online ask question
function send_online_question(askName,askEmail,askMessage,askinstitute,type)
{
	$.ajax({
		url: JS_SITE_URL+'Ajax/send_online_question/',
		type: 'GET',
                cache:false,
		data:'data[AskQuestion][name]='+askName+'&data[AskQuestion][email]='+askEmail+'&data[AskQuestion][message]='+askMessage+'&data[AskQuestion][institute_id]='+askinstitute+'&data[AskQuestion][type]='+type,
		beforeSend: function () {
			
		},
		success: function (data) {
			var rss = $.parseJSON(data);
			
			if(rss.msg=='success')
			{
				//Show Price
				$('.askName').val('').attr('placeholder','My Name');
				$('.askEmail').val('').attr('placeholder','My Email');
				$('.askMessage').val('').attr('placeholder','My Message');
				$('.ask_success').html(rss.message).show();
				close_ask_popup();
				
			}
		},
		complete: function () {
		   //$('.loading-text').remove();
		}
	});
}

//send online ask question
function send_to_mail(askName,askEmail,askMessage,askinstitute)
{
	$.ajax({
		url: JS_SITE_URL+'Students/send_to_email/',
		type: 'GET',
                cache:false,
		data:'data[AskQuestion][name]='+askName+'&data[AskQuestion][email]='+askEmail+'&data[AskQuestion][message]='+askMessage+'&data[AskQuestion][institute_id]='+askinstitute,
		beforeSend: function () {
			
		},
		success: function (data) {
			var rss = $.parseJSON(data);
			
			if(rss.msg=='success')
			{
				//Show Price
				$('.askName').val('').attr('placeholder','My Name');
				$('.askEmail').val('').attr('placeholder','My Email');
				$('.askMessage').val('').attr('placeholder','My Message');
				$('.ask_success').html(rss.message).show();
				close_ask_popup();
				
			}
		},
		complete: function () {
		   //$('.loading-text').remove();
		}
	});
}

function close_ask_popup()
{
	setTimeout(function(){
		$('.ask_success').fadeOut();
		$('#myModal').modal('hide');
		$('.ask_success').html('').hide();
	},5000);
	
}
$(function(){
    $('.already_attend').on('change',function(){
           var course_id = $('#course_id').val();
              var already_attend='no';
                     
                if($('#already_attendYes').is(':checked')){
                     already_attend='yes';
                } 
                
                $('#accomodation_id').val('');
		if($('#start_date_val').val()==4)
		{
			var start_date = $('.startting_date_data .start_date').val();
                       
		}
		else
		{
			var start_date = $('.course_starting_date .start_date').val();
		}
		var week_val = $('#no_of_weeks').val();
		var course_id = $('#course_id').val();
		var accomodation_id = $('#accomodation_id').val();
                var language_level=$('#language_level').val();
                    if(language_level==0){
                        var beg=1;
                    }
                    else{
                        var beg=0;
                    }
        
        
                        get_date(course_id,beg,already_attend,'selected_value');
			get_price_by_quote(course_id,start_date,week_val,accomodation_id,beg,already_attend,'selected_value');
    })
})
