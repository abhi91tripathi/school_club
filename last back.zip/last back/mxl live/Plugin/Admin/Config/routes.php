<?php
	Router::connect('/admin/', array('controller' => 'users', 'action' => 'dashboard', 'plugin'=>'Admin' ));