var http = location.protocol;
//var ajax_url = http + '//' + window.location.hostname + '/max_languages/website';

var ajax_url = site_url_noslh;
$(function(){
$('#check_all').click(function(event) {   		
        if(this.checked) {
            // Iterate each checkbox
            $(':checkbox').each(function() {
                this.checked = true;                        
            });
        }
        if(!this.checked) {
            // Iterate each checkbox
            $(':checkbox').each(function() {
                this.checked = false;                        
            });
        }
    });
});


function CheckUserAction(frm)
{
	var err=0;
	var total=0;
	var data=document.getElementsByName('list[]');
	var frm_obj = document.getElementById('task').form;
	
	for(var i=0; i < data.length; i++){
		if(data[i].checked)
			total++;
	}
	
	if(total==0)
	{
		document.getElementById("err_status").innerHTML="Please select record";
		err=1;
	}
	else if(document.getElementById('task').value=="")
	{
		
		document.getElementById("err_status").innerHTML="Please select an action";
		err=1;
	}	

	if(!err && (document.getElementById('task').value).toLowerCase()=="delete")
	{
		
		var conf = confirm("Do you really want to delete?");
	
		if(!conf)
		{
			err=1;
			document.getElementById("err_status").innerHTML="";
		}
	}
	
	if(err)
		return false;
		
}

function validate_chckbox_select(frm)
{
	var err=0;
	var total=0;
	var data=document.getElementsByName('list[]');
	
	for(var i=0; i < data.length; i++){
		if(data[i].checked)
			total++;
	}
	
	if(total==0)
	{
		document.getElementById("err_status").innerHTML="Please select record";
		err=1;
	}

	if(err)
		return false;
		
}

function checkAll(chobj)
	{
		frm = chobj.form;
		for(var i=0; i<frm.elements.length; i++)
		{
			if(frm.elements[i].type == "checkbox" && frm.elements[i].name != "checkall")
			{
				frm.elements[i].checked = chobj.checked;
			}
		}
	}



function CheckUserAction_dublicate(frm)
{
	var err=0;
	var total=0;
	var data=document.getElementsByName('list[]');
	var frm_obj = document.document.getElementsByClassName('task').form;
	
	for(var i=0; i < data.length; i++){
		if(data[i].checked)
			total++;
	}
	
	if(total==0)
	{
		document.getElementById("err_status").innerHTML="Please select record";
		err=1;
	}
	else if(document.document.getElementsByClassName('task').value=="")
	{
		
		document.getElementById("err_status").innerHTML="Please select an action";
		err=1;
	}	

	if(!err && (document.document.getElementsByClassName('task').value).toLowerCase()=="delete")
	{
		
		var conf = confirm("Do you really want to delete?");
	
		if(!conf)
		{
			err=1;
			document.getElementById("err_status").innerHTML="";
		}
	}
	
	if(err)
		return false;
		
}
function change_action(data){
  
    $('.task').val(data.value);
}