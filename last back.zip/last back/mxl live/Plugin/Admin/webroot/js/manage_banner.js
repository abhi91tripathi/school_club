$(document).ready(function()
{
	//to make all of upload button to image upload.
	upload_image($('.upload_image'));
	
	$('.validate').validate({ ignore: [] });
	var _URL = window.URL || window.webkitURL;
})

// To upload image
function upload_image($this)
{
	var btnUpload=$this;
	new AjaxUpload(btnUpload, {
			name: "image",
			//Name of the file input box
			action: ajax_url + '/admin/homepage_management/uploadimage?path=/app/Plugin/Admin/webroot/img/homepage_block_images/&width=1170&height=440',
			onSubmit: function(file, ext){
				if( ( ext=='png' ) || ( ext=='jpeg' ) || ( ext=='gif' ) || ( ext=='jpg' ) )
				{
					btnUpload.attr('disbaled','disabled');
					btnUpload.val('uploading....');
				}
				else
				{
					btnUpload.val('Upload Image');
					btnUpload.attr('disbaled',false);
					alert('Please uplaod a valid image');
					return false;
				}
			},
			onComplete: function(file, response){
				btnUpload.val('Upload Image');
				btnUpload.attr('disbaled',false);
				if(response==="upload_error")
				{
					alert("Some error occurred while uploading. Please try again.");
				}
				else
				{
					unlink_old_image(btnUpload.next('input[name=image]').val());
					var imgHtml = '<img src="' + ajax_url + '/admin/img/homepage_block_images/' + response + '" style="max-width: 1170px;" />';
					btnUpload.parent().parent().next().children('.imagepreview').html(imgHtml);
					btnUpload.next('.image_name_value').val(response);
				}
			}
		});
}

//To unlik the previous one after uploading the image
function unlink_old_image(image_name)
{
	if(image_name)
	{
		$.ajax({
			url: ajax_url + '/admin/homepage_management/unlink_old_image/' + image_name + '?path=/app/Plugin/Admin/webroot/img/homepage_block_images/'
		})
	}
}
