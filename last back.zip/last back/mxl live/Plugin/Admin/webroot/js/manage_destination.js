$(document).ready(function()
{
	//to make all of upload button to image upload.
	upload_image($('.upload_image'));
	
/*	$('#CountryAddForm').validate({
		ignore: ".ignore",
		rules: {
			'data[Destination][name]': {
				required: true,
				remote: {
					url: ajax_url + "/admin/destination/isexist",
					type: "post",
					data:{
						'data[Destination][id]': function(){ return $('#DestinationId').val() },
						'data[Destination][name]': function(){ return $('#DestinationName').val() },
						'data[Destination][country_id]': function(){ return $('#DestinationCountryId').val() }
					}
				 }
			},
			"data[Country][name]":{
				required: true,
				remote: {
					url: ajax_url + "/admin/destination/iscountry_exist",
					type: "post"
				 }
			}
		},
		messages: {
			'data[Destination][name]': {
				required: "This field is required",
				remote: "Destination is already exists in selected country"
			},
			'data[Country][name]': {
				required: "This field is required",
				remote: "Country is already exists."
			}
		},
		submitHandler : function(form){
			$.post(
				ajax_url + "/admin/destination/isexist",
				$(form).serialize(),
				function(resp){
					if('false' == resp)
					{
						$('label[for=DestinationName]').text('Destination is already exists in selected country').show();
					}
				}
			 );
		}
	});
	
	$('#CountryAddForm').submit(function()
	{		
		if(!$(this).valid())
		return false;
	})*/
	// for showing the add new country fields when user click on add new country link
	$('.add_new_country').click(function()
	{
		$('#DestinationCountryId').val('');
		$('#DestinationCountryId').addClass('ignore');
		$('.country_block').fadeIn('slow');
		$('.country_block input[type=text], .country_block input[type=hidden]').removeClass('ignore');
	})
	
	// for hide the add new country fields on change of the countries drop down
	$('#DestinationCountryId').change(function()
	{
		$('#DestinationCountryId').removeClass('ignore');
		$('.country_block').fadeOut('slow');
		$('.country_block input[type=text], .country_block input[type=hidden]').addClass('ignore');
	})
	
})

// To upload image
function upload_image($this)
{
	var btnUpload=$this;
	new AjaxUpload(btnUpload, {
			name: "image",
			//Name of the file input box
			action: ajax_url + '/admin/homepage_management/uploadimage?path=/app/Plugin/Admin/webroot/img/country_flags/&&width=200&&height=200',
			onSubmit: function(file, ext){
				if( ( ext=='png' ) || ( ext=='jpeg' ) || ( ext=='gif' ) || ( ext=='jpg' ))
				{
					btnUpload.attr('disbaled','disabled');
					btnUpload.val('uploading....');
				}
				else
				{
					btnUpload.val('Upload Image');
					btnUpload.attr('disbaled',false);
					alert('Please uplaod a valid image');
					return false;
				}
			},
			onComplete: function(file, response){
				btnUpload.val('Upload Image');
				btnUpload.attr('disbaled',false);
				if(response==="upload_error")
				{
					alert("Some error occurred while uploading. Please try again.");
				}
				else
				{
					unlink_old_image(btnUpload.next('input[name=image]').val());
					var imgHtml = '<img style="max-width:200px;" src="' + ajax_url + '/admin/img/country_flags/' + response + '" />';
					btnUpload.parent().parent().next().children('.imagepreview').html(imgHtml);
					btnUpload.next('.image_name_value').val(response);
				}
			}
		});
}

//To unlik the previous one after uploading the image
function unlink_old_image(image_name)
{
	if(image_name)
	{
		$.ajax({
			url: ajax_url + '/admin/homepage_management/unlink_old_image/' + image_name + '?path=/app/Plugin/Admin/webroot/img/country_flags/'
		})
	}
}
