$(document).ready(function()
{
	$('#LanguageAddForm').validate({
		ignore: ".ignore",
		rules: {
			"data[Language][title]":{
				required: true,
				remote: {
					url: ajax_url + "/admin/language/isexist",
					type: "post"
				 }
			}
		},
		messages: {
			'data[Language][title]': {
				required: "This field is required",
				remote: "Language is already exists."
			}
		}
	});
	
})
