//Purpose:price editor
//created on:28/05/14
//Author:Abhishek Tripathi

$(document).ready(function () {


 
    $('#get_chart_high').on('click', function () {
        var high_to = $('#high_to').val();
        var high_from = $('#high_from').val();
        var price = $('#high_price').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        range_diff++;
        if ($('#price_season').val() == 1)
        {
            for (var i = 1; i <= range_diff; i++)
            {
                $('#week_sch_high_' + count).find('.price_all_year').val(price);
                $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(price * count);
                count++;
            }
        }
        else {
            for (var i = 1; i <= range_diff; i++)
            {
                $('#week_sch_low_' + count).find('.price_all_year').val(price);
                $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(price * count);
                count++;
            }
        }
    });
    //    Purpose:price plan seclection
    //    created on:06/06/14
    //    Author:Abhishek tripathi
    $('.price_plan').on('click', function () {

        var action = $(this).val();
        switch (action)
        {
            case '1':
                plan_default_current=1;
                $('.high_low_list').hide();
                $('.all_year_list').show();
                $('#min_week').val('1');
                $('#max_week').val('52');
                $('.list').remove();
                get_chart();
                break;
            case '2':
                plan_default_current=2;
                $('.high_low_list').show();
                $('.all_year_list').hide();
                $('#min_week').val('1');
                $('#max_week').val('52');
                $('.list').remove();
                get_chart();
                break;

        }
    });


    //    Purpose:price edition on chart for all year
    //    created on:06/06/14
    //    Author:Abhishek tripathi

    $('.get_chart').on('click', function () {
        var high_to = $('#high_to_all').val();
        var high_from = $('#high_from_all').val();
        var price = $(this).parent().find('.price').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        range_diff++;
       
        for (var i = 1; i <= range_diff; i++)
        {
            $('#week_all_year_' + count).find('.price_all_year').val(price);
            $('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));

            count++;
        }
    })

  $('.price_all_year').on('keyup', function () {
        var data = $(this);
        var price = data.val();
        var week = data.parent().parent().find('.price_all_year_week').val();
        var pre_week=week-1;
       
        if(price_cal==0){
            $(this).parent().parent().find('.price_all_year_cumulative').val(Math.round(week * price));
        }else{
            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
            var val_current_week=$(this).parent().parent().find('.price_all_year').val()
            price_calculation(data);
        }
       
    });
    $('.price_all_year_cumulative').on('keyup', function () {
        var data = $(this);
        var price = data.val();
        var week = data.parent().parent().find('.price_all_year_week').val();
        var pre_week=week-1;
        if(price_cal==0){
          $(this).parent().parent().find('.price_all_year').val(Math.round(price / week));
        }else{
            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
            if(typeof(val_pre_week)=='undefined'){
            $(this).parent().parent().find('.price_all_year').val(Math.round(Math.round(price / week)));
            price_calculation($('#week_all_year_'+week));
        }else{
            $(this).parent().parent().find('.price_all_year').val(Math.round(price-$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val()));
            week=week++;
            price_calculation($('#week_all_year_'+week).find('.price_all_year_week'));
        }
    }
    });
    
    
    //    Purpose:copy price below table field
    //    created on:06/08/15
    //    Author:Abhishek tripathi

    $('.copy_price').on('click', function () {

        var data = $(this);
        var high_to = data.parent().find('.price_all_year_week').val();
        var high_from = $('#max_week').val();
        var price = data.parent().parent().find('.price_all_year').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        var type=data.attr('type');
        range_diff++;
       
        for (var i = 1; i <= range_diff; i++)
        {
            switch(type){
                case 'all':
                  
                    if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_all_year_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_all_year_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_all_year_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;}
                        else{
                             $('#week_all_year_' + count).find('.price_all_year').val(price);
                             $('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                           
                case  'high': 
                    
                    if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_high_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_sch_high_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_high_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_high_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                        }
                        else{
                             $('#week_sch_high_' + count).find('.price_all_year').val(price);
                             $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                           
                case  'low': 
                     if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_low_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_sch_low_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_low_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_low_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                        }
                        else{
                             $('#week_sch_low_' + count).find('.price_all_year').val(price);
                             $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                                
                            
            }
             count++;
        }
    });
    
    $('.copy_price_cumulative').on('click', function () {
        var data = $(this);
        var high_to = data.parent().parent().find('.price_all_year_week').val();
        var high_from = $('#max_week').val();
        var price = data.parent().parent().find('.price_all_year_cumulative').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        range_diff++;
        var type=data.attr('type');
      
        for (var i = 1; i <= range_diff; i++)
        {
            switch(type){
                case 'all':
                            $('#week_all_year_' + count).find('.price_all_year_cumulative').val(price);
                            $('#week_all_year_' + count).find('.price_all_year').val(Math.round(price / count));
                            break;
                case  'high': 
                            $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(price);
                            $('#week_sch_high_' + count).find('.price_all_year').val(Math.round(price /count));         
                            break;
                case  'low': 
                            $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(price);
                            $('#week_sch_low_' + count).find('.price_all_year').val(Math.round(price / count));         
                            break;         
                            
            }
           
            
            count++;
        }
    });

//    pupose:for creat chart on select max/min week
//    created on:6 june 2014,
//    Author: Abhishek Tripathi
$( "#enroll_date" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
       dateFormat: "yy-mm-dd",
       onClose: function( selectedDate ) {
           var dateFormat = $( "#enroll_date" ).val();
            var dateFormat = $.datepicker.formatDate('MM dd, yy', new Date(dateFormat));
            $('.enroll_date').html(dateFormat);
       }
      
    });
 $( "#starting_date_price_to" ).datepicker({
        defaultDate: "+1w",
        changeMonth: true,
        numberOfMonths: 1,
        dateFormat: "yy-mm-dd",
        onClose: function( selectedDate ) {
            var dateFormat = $( "#starting_date_price_to" ).val();
            var now=new Date(dateFormat);
            now.setDate(now.getDate()+14);
            var now_prev=new Date(dateFormat);
            now_prev.setDate(now_prev.getDate()-14);
            var dateFormat = $.datepicker.formatDate('MM dd, yy', new Date(dateFormat));
            var after_date= $.datepicker.formatDate('MM dd, yy', new Date(now));
            var pre_date= $.datepicker.formatDate('MM dd, yy', new Date(now_prev));
            $('.start_date').html(dateFormat);
            $('.after_start').html(after_date);
            $('.pre_start').html(pre_date);
        }
    });   
})


//    pupose:for creat chart on select max/min week
//    created on:6 june 2014,
//    Author: Abhishek Tripathi

function get_chart() {
    var min_week = $('#min_week').val();
    var max_week = $('#max_week').val();
        var currency=$('#currency_symbol').val();
    var dif = max_week - min_week;
    dif++;
    var count = min_week;
     var values = {};
    $.each($("form").serializeArray(), function (i, field) {
        values[field.name] = field.value;
    });

    {
        $('.list').remove();
        if ($('#AccomodationPricePlan1:checked').length > 0) {
           
            for (var i = 1; i <= dif; i++)
            {
                var val='';
                if(values['data[AccomodationPrice][price_chart][all_year_chart]['+count+']']){
                    val=values['data[AccomodationPrice][price_chart][all_year_chart]['+count+']'];
                }
                var val_cumulative='';
                if(values['data[AccomodationPrice][price_chart_cumulative][all_year_chart]['+count+']']){
                    val_cumulative=values['data[AccomodationPrice][price_chart_cumulative][all_year_chart]['+count+']'];
                }
                
                $('.allYear_chart_table').append('<tr class="list" id="week_all_year_' + count + '">\n\
                                                <td class="new-row">'+count+'</td>\n\
                                                <td><input class="price_all_year_week" type="hidden" value="'+count +'"><label>'+currency+'</label><input class="price_all_year" value="'+val+'" type="text" placeholder="12.00" name=data[AccomodationPrice][price_chart][all_year_chart][' + count + '] align="right" />\n\
                                                    <strong class="copy_price" type="all"><a>copy<br/>price </a></strong></td>\n\
                                                <td><label>'+currency+'</label><input class="price_all_year_cumulative" value="'+val_cumulative+'" type="text" name=data[AccomodationPrice][price_chart_cumulative][all_year_chart][' + count + '] align="right" />\n\
                                                  <strong class="copy_price_cumulative" type="all"><a>copy<br/>price </a></strong></td></tr>');  
                
                count++;
            }
            $.post(JS_SITE_URL + 'admin/Course/get_limit', {max: max_week, min: min_week}, function (d) {
                $('#high_to_all').html(d);
                $('#high_from_all').html(d);
            })
        }
        else {
            for (var i = 1; i <= dif; i++)
            {
                var val_high='';
                if(values['data[AccomodationPrice][price_chart][high_chart]['+count+']']){
                    val_high=values['data[AccomodationPrice][price_chart][high_chart]['+count+']'];
                }
                var val__high_cumulative='';
                if(values['data[AccomodationPrice][price_chart_cumulative][high_chart]['+count+']']){
                    val__high_cumulative=values['data[AccomodationPrice][price_chart_cumulative][high_chart]['+count+']'];
                }
                
                //-----------------------------
             var val_low='';    
                  if(values['data[AccomodationPrice][price_chart][low_chart]['+count+']']){
                    val_low=values['data[AccomodationPrice][price_chart][low_chart]['+count+']'];
                }
                var val__low_cumulative='';
                if(values['data[AccomodationPrice][price_chart_cumulative][low_chart]['+count+']']){
                    val__low_cumulative=values['data[AccomodationPrice][price_chart_cumulative][low_chart]['+count+']'];
                }
                
                $('.chart_high').append('<tr class="list" id="week_sch_high_' + count + '">\n\
                                                <td class="new-row">'+count+'</td>\n\
                                                <td><input class="price_all_year_week" type="hidden" value="'+count +'"><label>'+currency+'</label><input class="price_all_year"  value="'+val_high+'" type="text" placeholder="12.00" name="data[AccomodationPrice][price_chart][high_chart][' + count + ']" align="right" />\n\
                                                       <strong type="high" class="copy_price"><a>copy<br/>price </a></strong></td>\n\
                                                <td><label>'+currency+'</label><input class="price_all_year_cumulative" value="'+val__high_cumulative+'"  type="text" name="data[AccomodationPrice][price_chart_cumulative][high_chart][' + count + ']" align="right" />\n\
                                                <strong  type="high" class="copy_price_cumulative"><a>copy<br/>price </a></strong></td></tr>');

                 $('.chart_low').append('<tr class="list" id="week_sch_low_' + count + '">\n\
                                                <td class="new-row">'+count+'</td>\n\
                                                <td><input class="price_all_year_week" type="hidden" value="'+count +'"><label>'+currency+'</label><input class="price_all_year"  value="'+val_low+'" type="text" placeholder="12.00" name="data[AccomodationPrice][price_chart][low_chart][' + count + ']" align="right" />\n\
                                                        <strong type="low" class="copy_price"><a >copy<br/>price </a></strong></td>\n\
                                                <td><label>'+currency+'</label><input class="price_all_year_cumulative" value="'+val__low_cumulative+'"  type="text" name="data[AccomodationPrice][price_chart_cumulative][low_chart][' + count + ']" align="right" />\n\
                                                     <strong  type="low" class="copy_price_cumulative"><a>copy<br/>price </a></strong></td></tr>');
                
                
                count++;
            }
            $.post(JS_SITE_URL + 'admin/Course/get_limit', {max: max_week, min: min_week}, function (d) {
                $('#high_to').html(d);
                $('#high_from').html(d);
            })
        }

    }

    $('.price_all_year').on('keyup', function () {
         var data = $(this);
        var price = data.val();
        var week = data.parent().parent().find('.price_all_year_week').val();
        var pre_week=week-1;
       
        if(price_cal==0){
            $(this).parent().parent().find('.price_all_year_cumulative').val(Math.round(week * price));
        }else{
            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
            var val_current_week=$(this).parent().parent().find('.price_all_year').val()
            price_calculation(data);
        }
       
    });
    $('.price_all_year_cumulative').on('keyup', function () {
        var data = $(this);
        var price = data.val();
        var week = data.parent().parent().find('.price_all_year_week').val();
        var pre_week=week-1;
        if(price_cal==0){
          $(this).parent().parent().find('.price_all_year').val(Math.round(price / week));
        }else{
            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
            if(typeof(val_pre_week)=='undefined'){
            $(this).parent().parent().find('.price_all_year').val(Math.round(Math.round(price / week)));
            price_calculation($('#week_all_year_'+week));
        }else{
            $(this).parent().parent().find('.price_all_year').val(Math.round(price-$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val()));
            week=week++;
            price_calculation($('#week_all_year_'+week).find('.price_all_year_week'));
        }
    }
    });
    
    
    //    Purpose:copy price below table field
    //    created on:06/08/15
    //    Author:Abhishek tripathi

    $('.copy_price').on('click', function () {

        var data = $(this);
        var high_to = data.parent().find('.price_all_year_week').val();
        var high_from = $('#max_week').val();
        var price = data.parent().parent().find('.price_all_year').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        var type=data.attr('type');
        range_diff++;
       
        for (var i = 1; i <= range_diff; i++)
        {
            switch(type){
                case 'all':
                  
                    if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_all_year_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_all_year_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_all_year_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;}
                        else{
                             $('#week_all_year_' + count).find('.price_all_year').val(price);
                             $('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                           
                case  'high': 
                    
                    if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_high_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_sch_high_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_high_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_high_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                        }
                        else{
                             $('#week_sch_high_' + count).find('.price_all_year').val(price);
                             $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                           
                case  'low': 
                     if(price_cal==1){
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_low_'+pre_week).find('.price_all_year_cumulative').val();
                            $('#week_sch_low_'+week).find('.price_all_year').val(price);
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_low_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_low_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                        }
                        else{
                             $('#week_sch_low_' + count).find('.price_all_year').val(price);
                             $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));
                            //$('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price+$('#week_all_year_' + count-1).find('.price_all_year_cumulative').val()));
                            break;
                        }
                                
                            
            }
             count++;
        }
    });
    
    $('.copy_price_cumulative').on('click', function () {
        var data = $(this);
        var high_to = data.parent().parent().find('.price_all_year_week').val();
        var high_from = $('#max_week').val();
        var price = data.parent().parent().find('.price_all_year_cumulative').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        range_diff++;
        var type=data.attr('type');
        
        for (var i = 1; i <= range_diff; i++)
        {
            switch(type){
                case 'all':$('#week_all_year_' + count).find('.price_all_year_cumulative').val(price);
                            $('#week_all_year_' + count).find('.price_all_year').val(Math.round(price / count));
                            break;
                case  'high': 
                            $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(price);
                             $('#week_sch_high_' + count).find('.price_all_year').val(Math.round(price /count));         
                            break;
                case  'low': 
                            $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(price);
                             $('#week_sch_low_' + count).find('.price_all_year').val(Math.round(price / count));         
                            break;         
                            
            }
           count++;
        }
    });
    
}



//    pupose:for get limit of price editor
//    created on:9 june 2014,
//    Author: Abhishek Tripathi
function get_limit() {
    var min_week = $('#min_week').val();
    var max_week = $('#max_week').val();

    $.post(JS_SITE_URL + 'admin/Course/get_limit', {max: max_week, min: min_week}, function (d) {
        if ($('#CourseTypeCurrentYearPlan1').is(':checked')) {
            $('#high_to_all').html(d);
            $('#high_from_all').html(d);
        }
        if ($('#CourseTypeCurrentYearPlan2').is(':checked')) {
            $('#high_to').html(d);
            $('#high_from').html(d);
        }
    })
    var next_min_week = $('#next_min_week').val();
    var next_max_week = $('#next_max_week').val();
    $.post(JS_SITE_URL + 'admin/Course/get_limit', {max: next_max_week, min: next_min_week}, function (da) {
        if ($('#CourseTypeNextYearPlan1').is(':checked')) {
            $('#next_high_to_all').html(da);
            $('#next_high_from_all').html(da);
        }
        if ($('#CourseTypeNextYearPlan2').is(':checked')) {

            $('#next_high_to').html(da);
            $('#next_high_from').html(da);
        }
    })
}

function price_calculation(data){
       
        var high_to = data.parent().parent().find('.price_all_year_week').val();
     
        var high_from = $('#max_week').val();
        var price = data.parent().parent().find('.price_all_year_cumulative').val();
        var range_diff = high_from - high_to;
        var count = high_to;
        range_diff++;
        var type=data.parent().find('.copy_price').attr('type');
        for (var i = 1; i <= range_diff; i++)
        {
            switch(type){
                case 'all':var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_all_year_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_all_year_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                case  'high':
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_high_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_high_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_high_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                            
                case  'low': 
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_low_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_low_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                                break;
                            }
                            else{
                                    $('#week_sch_low_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
                            break;
                            
                            
            }
            count++;
        }
    
}

function on_change_cumulation(){
    var high_from =$('#min_week').val(),
            high_to=$('#max_week').val();
    
    var range_diff = high_to - high_from;

       
        var count = high_from;
        range_diff++;
           for (var i = 1; i <= range_diff; i++)
        {
          
            if(plan_default_current==1){
               
               if(price_cal==1){
              
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_all_year_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_all_year_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                        
                            }
                            else{
                                    $('#week_all_year_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
               }
               else{
           
                var price=$('#week_all_year_'+count).find('.price_all_year').val();
                      if(typeof(price)=='undefined'){
                             
                      }else{
                       $('#week_all_year_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));   
                      }
                      
               }
            }else{
       
            
            if(price_cal==1){
              
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_high_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_high_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                              
                            }
                            else{
                                    $('#week_sch_high_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
               }
               else{
       
                var price=$('#week_sch_high_'+count).find('.price_all_year').val();
                      if(typeof(price)=='undefined'){
                             
                      }else{
                       $('#week_sch_high_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));   
                      }
                      
               }
               
               if(price_cal==1){
         
                            var week = count;
                            var pre_week=week-1;
                            var val_pre_week=$('#week_sch_low_'+pre_week).find('.price_all_year_cumulative').val();
                            if(typeof(val_pre_week)=='undefined'){
                                val_pre_week=0;
                            }
                            var val_current_week=$('#week_sch_low_'+week).find('.price_all_year').val();
                            if(val_current_week==''){
                              
                            }
                            else{
                                    $('#week_sch_low_'+week).find('.price_all_year_cumulative').val(Math.round(parseInt(val_pre_week)+parseInt(val_current_week)));
                                }
               }
               else{
           
                    var price=$('#week_sch_low_'+count).find('.price_all_year').val();
                    if(typeof(price)=='undefined'){
                               
                    }else{
                       $('#week_sch_low_' + count).find('.price_all_year_cumulative').val(Math.round(price * count));   
                      }
                      
               }
        }
            
            count++;
        }
        
}

  

