<?php
App::uses('AppModel', 'Model');
/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class SpCoursePrice extends AppModel {
      public $useDbConfig = 'spanish';
      

public $useTable = 'course_prices';
/**
 * belongsTo associations
 *
 * @var array
 */
		public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'CourseTypes' => array(
			'className' => 'CourseTypes',
			'foreignKey' => 'course_types_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
			
		)
	);
}
