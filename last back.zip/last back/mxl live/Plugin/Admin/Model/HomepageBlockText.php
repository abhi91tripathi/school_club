<?php
/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for validate the home page block text.
*/
class HomepageBlockText extends AdminAppModel {
	
	public $validate = array(
			'title'=>array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'image' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'display_image_on' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			)
		);
	
}
