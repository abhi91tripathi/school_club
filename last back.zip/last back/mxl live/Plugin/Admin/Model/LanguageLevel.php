<?php

/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class LanguageLevel extends AdminAppModel {
	
  public $useTable = 'language_levels'; 



	}

                            	
	
	
?>
