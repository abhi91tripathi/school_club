<?php
App::uses('AdminAppModel', 'Model');
/**
 * AccomodationPrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class AccomodationPrice extends AdminAppModel {

/**
 * Use table
 *
 * @var mixed False or table name
 */
	public $useTable = 'accomodation_price';


	//The Associations below have been created with all possible keys, those that are not needed can be removed

/**
 * belongsTo associations
 *
 * @var array
 */
	public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'AccomodationType' => array(
			'className' => 'AccomodationType',
			'foreignKey' => 'accomodation_types_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
