<?php

/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class Review extends AdminAppModel {
	


public function afterSave($created,$options = array()){

	if($this->data['Review']['status']==1){ 
           $obj = ClassRegistry::init('Institute');
	   $old_rating_avg=$obj->find('first',array('conditions'=>array('Institute.id'=>$this->data['Review']['institute_id']),'fields'=>array('average_rating','rating_user')));
	   $fields=array('sum(Review.rating) as total');
	   $conditions=array('AND'=>array('Review.institute_id'=>$this->data['Review']['institute_id'],'Review.status'=>1));
	   $total_rating=$this->find('all',array('conditions'=>$conditions,'fields'=>$fields));
	   $total_user=$this->find('count',array('conditions'=>$conditions));
	   $avreage=(intval($total_rating[0][0]['total'])/intval($total_user));
            $obj->id=$this->data['Review']['institute_id'];
            $obj->saveField('average_rating',$avreage);
            $obj->saveField('rating_user',$total_user);
        }
            if($this->data['Review']['status']==0){ 
                    $obj = ClassRegistry::init('Institute');
                    $old_rating_avg=$obj->find('first',array('conditions'=>array('Institute.id'=>$this->data['Review']['institute_id']),'fields'=>array('average_rating','rating_user')));
                    $fields=array('sum(Review.rating) as total');
                    $conditions=array('AND'=>array('Review.institute_id'=>$this->data['Review']['institute_id'],'Review.status'=>1));
                    $total_rating=$this->find('all',array('conditions'=>$conditions,'fields'=>$fields));
                    $total_user=$this->find('count',array('conditions'=>$conditions));
                    if($total_user==0){
                        $avreage=0;
                    }else{
                    $avreage=(intval($total_rating[0][0]['total'])/intval($total_user));
                    }
                     $obj->id=$this->data['Review']['institute_id'];
                     $obj->saveField('average_rating',$avreage);
                     $obj->saveField('rating_user',$total_user);
            }
	
	}	 
public function beforeDelete($cascade = true){
   
    $review=$this->find('first',array('conditions'=>array('Review.id'=>$this->id)));
    $obj = ClassRegistry::init('Institute');
  if($review['Review']['status']==1){	   
    $old_rating_avg=$obj->find('first',array('conditions'=>array('Institute.id'=>$review['Review']['institute_id']),'fields'=>array('average_rating','rating_user')));
	   $fields=array('sum(Review.rating) as total');
	   $conditions=array('AND'=>array('Review.institute_id'=>$review['Review']['institute_id'],'Review.status'=>1));
	   $total_rating_old=$this->find('all',array('conditions'=>$conditions,'fields'=>$fields));
            
           $total_rating=($total_rating_old[0][0]['total']);
              
           $total_rating=($total_rating)-($review['Review']['rating']);
           
	   $total_user=$this->find('count',array('conditions'=>$conditions));
           $total_user=intval($total_user)-1;
	   $avreage=(intval($total_rating)/intval($total_user));
            $obj->id=$review['Review']['institute_id'];
            $obj->saveField('average_rating',$avreage);
            $obj->saveField('rating_user',$total_user);
  }
}

        public $belongsTo=array(
           'Institute'=>array(
              'className'=>'Institute',
              'foreignKey'=>'institute_id',
              'fields'=>array('title','id'),

           )

        );	

	}

                            	
	
	
?>
