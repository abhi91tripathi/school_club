<?php

/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class Rating extends AdminAppModel {
	
	

public $belongsTo=array(
   'Review'=>array(
      'className'=>'review',
      'foreignKey'=>'review_id',
    
     
   ),
   
);	

	}

                            	
	
	
?>
