<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/
class Institute extends AdminAppModel {
    public $useTable='institutes';
    
    public function afterSave($created, $options = array()) {
        //save data in different language database---------
                        //$new_ins=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$this->Institute->getLastInsertId())));
            /*if($created==TRUE){
        $sp_institute=ClassRegistry::init('SpInstitute');
                       $new_arr['SpInstitute'] = $this->data['Institute'];
                       $sp_institute->set($new_arr);
                       $sp_institute->save($new_arr);
            }*/
                      
                        
    }
    public $belongsTo=array(
	'Country'=>array(
	 'className'=>'Country',
	  'foreignKey'=>'country_id',
	  
	 ),
	 'Language'=>array(
	  'className'=>'Language',
	  'foreignkey'=>'language_id'
	 ),
	 'Destination'=>array(
	  'className'=>'Destination',
	  'foreignkey'=>'destination_id'
	 ),
        'Currency'=>array(
	  'className'=>'Currency',
	  'foreignkey'=>'currency_id'
	 )
	);
    
}
