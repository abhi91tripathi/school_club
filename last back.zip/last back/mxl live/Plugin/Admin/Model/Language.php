<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/
class Language extends AdminAppModel {
	
	public $validate = array(
			'title'=>array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'Thid field is required'
				),
				'unique' => array(
					'rule' => 'isUnique',
					'message' => 'Language is already exists.'
				)
			)
		);
             
	
}
