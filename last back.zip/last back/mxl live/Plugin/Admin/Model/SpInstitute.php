<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/
class SpInstitute extends AdminAppModel {
            public $useDbConfig = 'spanish';
         public $useTable='institutes';
    
}
