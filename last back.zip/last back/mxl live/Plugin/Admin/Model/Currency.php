<?php
/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is to validate Country.
*/
class Courrency extends AdminAppModel {
	
	public $validate = array(
			'currency_code'=>array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'This field is required'
				)
			),
			'currency_name' => array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'This field is required'
				)
			)
		);
}
