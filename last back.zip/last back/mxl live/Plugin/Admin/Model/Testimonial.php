<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is for the Testimonial and havin validation for testimonial
*/
class Testimonial extends AdminAppModel {
	
	public $validate = array(
			'title'=>array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'client_image' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'client_name' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'description' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			),
			'status' => array(
				'rule'=>'notEmpty',
				'message'=>'Thid field is required'
			)
		);
	
}
