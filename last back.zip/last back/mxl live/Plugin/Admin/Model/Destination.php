<?php

/**
 * Project: Max Languages
 * Author: Ritish
 * Created: 1 APR 2014
 * Description: This model is to validate the destination.
*/
class Destination extends AdminAppModel {
	
	public $validate = array(
			'name'=>array(
				'rule'=>'notEmpty',
				'message'=>'This field is required'
			),
			'country_id' => array(
				'notEmpty' => array(
					'rule'=>'notEmpty',
					'message'=>'This field is required'
				)
			)
		);
	
}
