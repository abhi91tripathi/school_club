<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class SpCourseType extends AppModel {
      public $useDbConfig = 'spanish';
         public $useTable='course_types';

/**
 * Display field
 *
 * @var string
 */
 /**
     * purpose: converter behaviour
     * @var type 
     */
    var $actsAs = array('Containable','Converter');

/**
 * belongsTo associations
 *
 * @var array
 */

	// aftersave function for finding max min price range of school-----------------------
	public function afterSave($created,$options = array()){
          
            
	 
	 $institute_id=$this->data['SpCourseType']['institute_id'];
	 $obj = ClassRegistry::init('SpCoursePrice');
	 $price_list=$obj->find('all',array('conditions'=>array('AND'=>array('SpCourseType.institute_id'=>$institute_id,'SpCourseType.year'=>date('Y'))),'fields'=>array('price_chart','year')));

	 
	 foreach($price_list as $price){
		 $list=json_decode($price['SpCoursePrice']['price_chart'],true);
		 if(!empty($list['all_year_chart'])){
		 $list_all_min[]=min((array_filter($list['all_year_chart'])));
		 $list_all_max[]=max((array_filter($list['all_year_chart'])));
	     }
	     else{
	     $list_all_min[]=min((array_filter($list['high_chart'])));
	     $list_all_min[]=min((array_filter($list['low_chart'])));
	     $list_all_max[]=max((array_filter($list['high_chart'])));
	     $list_all_max[]=max((array_filter($list['low_chart'])));
			 }
		 }

	  //$obj->id=$institute_id;
	  $insti=ClassRegistry::init('SpInstitute');
          $currency=$insti->find('first',array('conditions'=>array('SpInstitute.id'=>$this->data['SpCourseType']['institute_id']),'contain'=>'Currency'));
	  $insti->id=$institute_id;
          $min=round($this->exchange_rate_convert($currency['Currency']['currency_code'],'EUR',$currency['SpInstitute']['min_price']),2);
          $max=round($this->exchange_rate_convert($currency['Currency']['currency_code'],'EUR',$currency['SpInstitute']['max_price']),2);
	  $insti->saveField('max_price',$min);
	  $insti->saveField('min_price',$max);
	
	 }

}
