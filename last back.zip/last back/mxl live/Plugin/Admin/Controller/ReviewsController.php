<?php
/*
 * Name : Reviews
 * Created : 9 oct 2014
 * Purpose : Reviews controller
 * Author : Abhishek Tripathi
 */
class ReviewsController extends AdminAppController {

	public $components=array('Uploader');
function beforeFilter()
	{
		parent::beforeFilter();

	}

 /**
	  * Purpose: this function is upload user image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload(){
		 // debug($this->params);exit;
	  	       if(isset($this->params->form['image_input'])){
	  	   	 $one= $this->params->form['image_input'];
	    	     $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'review_user' . DS;
				// move_uploaded_file($one['tmp_name'], $path . $name);
				// $this->Resize = $this->Components->load('ImageResize');
				// $this->Resize->resize( $path.$name, '870', '320', $path.$name);
				 $thumbnails = Thumbnail::review_images();
				 $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
				 
				 $image_new_name = date('ydmhis');
				 $this->Uploader->upload($one, $path.DS, $thumbnails, $image_new_name, $params);		
				 $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/review_user/REV'.$name;
			     echo json_encode($response);exit; 
				
	  	       }
		}
 
	  			  
				
	  
public function review_list(){
	   $this->layout='default';
	     	$this->loadModel('Institute');
	$institute=$this->Institute->get_school_list_lang();
		$cond_arr = array();
		
		if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
                $cond_arr = array_merge($cond_arr, array('Review.' . $field_name . ' Like' => $value . '%'));
            }
        }
        //$this->Institute->recursive=-1;
		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:500),
			'order' => array('Review.created' => 'DESC')
		);

		$result_arr = $this->paginate('Review');
		
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		$view_title = 'Manage Review';
		$this->set(compact('result_arr', 'ARR_FEATURED', 'view_title','institute'));
		//	$this->render('list');
	}

public function add(){
  
	  	$this->loadModel('Institute');
	$institute=$this->Institute->get_school_list_lang();
	
	
	if($this->request->is('post'))
		{
			$this->request->data['Review']['created']=date("Y-m-d h:i:s", strtotime($this->request->data['Review']['created'])); 
                        $this->request->data['Review']['reffered']=1;
                        $this->request->data['Review']['status']=0;
			if($this->Review->save($this->request->data)){
				
				
			$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			$this->redirect(array('controller' => 'Reviews', 'action' => 'review_list'));
		}
			else{
			$this->Session->setFlash(__('Please try again.'), 'flash_success');
			$this->redirect(array('controller' => 'Reviews', 'action' => 'review_list'));
			}
		}
			$view_title = 'Manage Review';
			$rating_array=array('.5'=>.5,'1'=>1,'1.5'=>1.5,'2'=>2,'2.5'=>2.5,'3'=>3,'3.5'=>3.5,'4'=>4,'4.5'=>4.5,'5'=>5);
		
		$this->set(compact('rating_array'));
		$this->set(compact('institute','view_title','rating_array'));
			$this->render('edit');
	
	}	
	
	
	
public function edit($id=null){
	  	
	  	$this->loadModel('Institute');
	$institute=$this->Institute->get_school_list_lang();
	
	$this->set(compact('institute'));
	  	if($this->request->is('put'))
		{
			$data = $this->request->data;
			
			$this->Review->id=$id;
			$data['Review']['created']=date("Y-m-d h:i:s", strtotime($data['Review']['created'])); 
                        if(empty($data['Review']['reffered'])){
                              $data['Review']['reffered']=1;
                        }
			//debug($data);exit;
		    $this->Review->save($data);
		  
			$this->Session->setFlash('Review updated successfully');
		}
	          
			$this->data=$this->Review->find('first',array('conditions'=>array('Review.id'=>$id)));
		$this->loadModel('Rating');
		$rating_array=array('.5'=>.5,'1'=>1,'1.5'=>1.5,'2'=>2,'2.5'=>2.5,'3'=>3,'3.5'=>3.5,'4'=>4,'4.5'=>4.5,'5'=>5);
		
		$this->set(compact('rating_array'));
		
		
	  }	



/**
	 * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
	 * Created on : 6 May 2014
	 * Author : Rupesh Sharma
	*/
	function manage_actions()
	{
		if(count($this->params['data']))
		{
			$message = '';

			$ids = $this->params['data']['list'];
			
			if(!empty($ids))
			{
				$task = $this->params['data']['task'];

				if($task == "delete")
				{
					//$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));
					
					foreach($ids as $id){
                                            $review=$this->Review->find('first',array('conditions'=>array('Review.id'=>$id)));
                                            
                                            $this->Review->id=$review['Review']['id'];
                                            $this->Review->delete();
                                        }
					$message = 'Deleted successfully.';
				}
				elseif($task == "Published")
				{
					//$this->Review->updateAll(array('Review.status' => "1"), array('Review.id' => $ids));
                                        foreach($ids as $id){
                                            $review=$this->Review->find('first',array('conditions'=>array('Review.id'=>$id)));
                                            $review['Review']['status']=1;
                                            $this->Review->id=$review['Review']['id'];
                                            $this->Review->save($review);
                                        }
                                        
					$message = 'Published successfully.';
				}
				elseif($task == "unpublished")
				{
					//$this->Review->updateAll(array('Review.status' => "1"), array('Review.id' => $ids));
                                        foreach($ids as $id){
                                            $review=$this->Review->find('first',array('conditions'=>array('Review.id'=>$id)));
                                            $review['Review']['status']=0;
                                            $this->Review->id=$review['Review']['id'];
                                            $this->Review->save($review);
                                        }
					$message = 'Unpublished successfully.';
				}
               
				
				$this->Session->setFlash($message, 'flash_success');
			}

			$this->redirect($this->referer());
		}
		exit;
	}










}

?>
