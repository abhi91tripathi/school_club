<?php

/**
 * Project : img180.com
 * Author : Nitin
 * Creation Date : 16 Oct 2013
 * Description : FOR AD (add, edit & manage)
 */
CakePlugin::load('PhpExcel');

class InstituteController extends AdminAppController {

    public $helpers = array('PhpExcel.PhpExcel');
    var $name = 'Institute';
    var $uses = array('Admin.Institute', 'InstituteExtraFee');
    public $components=array('Uploader');

    function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->Allow( 'add_info', 'logo_upload', 'get_address','listing_type');
    }

    /**
     * Purpose : TO LIST THE AD
     * Created on : 14 April 2014
     * Author : Rupesh Sharma
     */
    function index() {
      
        $cond_arr = array();
     
        //show name of languages and country in amdin panel
        $this->loadModel('Language');
        $this->loadModel('Country');
        $this->loadModel('Destination');
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);

        $this->Institute->bindModel(
                array('belongsTo' => array(
                        'Language' => array(
                            'className' => 'Language',
                            'foreignKey' => 'language_id',
                            'fields' => array('title')
                        )
                    )
                )
        );
        $this->Institute->bindModel(
                array('belongsTo' => array(
                        'Country' => array(
                            'className' => 'Country',
                            'foreignKey' => 'country_id',
                            'fields' => array('name')
                        )
                    )
                )
        );
        $this->Institute->bindModel(
                array('belongsTo' => array(
                        'Destination' => array(
                            'className' => 'Destination',
                            'foreignKey' => 'destination_id',
                            'fields' => array('name')
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
                $cond_arr = array_merge($cond_arr, array('Institute.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('Institute.id' => 'desc'),
            'recursive' => 3
        );

        $result_arr = $this->paginate('Institute');
       
        $ARR_FEATURED = Configure::read('ARR_FEATURED');
        $view_title = 'Manage Schools';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));

        $this->render('list');
    }

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
     * Created on : 16 April 2014
     * Author : Rupesh Sharma
     * update :10 sep 2014 
     * updated by:Abhishek Tripathi
     */
    function manage_actions() {
  
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Institute', 'img', array('Institute.id' => $ids));
                    $this->Institute->bindModel(
                            array('hasMany' => array(
                            'Event' => array(
                                'className' => 'Event',
                                'dependent' => true
                            ),
                            'InstituteFacility' => array(
                                'className' => 'InstituteFacility',
                                'dependent' => true
                            ),
                            'InstituteExam' => array(
                                'className' => 'InstituteExam',
                                'dependent' => true
                            ),
                            'CourseType' => array(
                                'className' => 'CourseType',
                                'dependent' => true
                            ),
                            'AccomodationType' => array(
                                'className' => 'AccomodationType',
                                'dependent' => true
                            ),
                            'InstituteExtraFee' => array(
                                'className' => 'InstituteExtraFee',
                                'dependent' => true
                            ),
                            'InstituteGallery' => array(
                                'className' => 'InstituteGallery',
                                'dependent' => true
                            )
                        ),
                            ), false
                    );


                    //debug($this->Institute);

                    $this->Institute->deleteAll(array('Institute.id' => $ids), true, false);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->Institute->updateAll(array('Institute.published' => "'Yes'"), array('Institute.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->Institute->updateAll(array('Institute.published' => "'No'"), array('Institute.id' => $ids));
                 
                    $message = 'Inactivated successfully.';
                } elseif ($task == "Duplicate") {

                    $this->loadModel('CourseTypes');
                    $this->loadModel('CourseType');
                    $this->loadModel('CoursePrice');
                    $this->loadModel('AccomodationType');
                    $this->loadModel('AccomodationPrice');
                    $this->loadModel('InstituteExtraFee');
                    $this->loadModel('InstituteGallery');
                    $this->loadModel('Event');
                    $this->loadModel('InstituteFacility');
                    $this->loadModel('InstituteExam');
                    $this->loadModel('AccomodationTypeAccomodationFacility');
                    $this->Institute->bindModel(
                            array('hasMany' => array(
                                    'Event' => array(
                                        'className' => 'Event'
                                    ),
                                    'InstituteFacility' => array(
                                        'className' => 'InstituteFacility'
                                    ),
                                    'InstituteExam' => array(
                                        'className' => 'InstituteExam'
                                    ),
                                    'CourseType' => array(
                                        'className' => 'CourseType'
                                    ),
                                    'AccomodationType' => array(
                                        'className' => 'AccomodationType'
                                    ),
                                    'InstituteExtraFee' => array(
                                        'className' => 'InstituteExtraFee'
                                    ),
                                    'InstituteGallery' => array(
                                        'className' => 'InstituteGallery'
                                    )
                                ),
                            )
                    );
                    $this->CourseTypes->bindModel(
                            array('hasMany' => array(
                                    'CoursePrice' => array(
                                        'className' => 'CoursePrice'
                                    )
                                )
                            )
                    );
                    $this->AccomodationType->bindModel(
                            array('hasMany' => array(
                                    'AccomodationTypeAccomodationFacility' => array(
                                        'className' => 'AccomodationTypeAccomodationFacility'
                                    )
                                )
                            )
                    );
                    $this->CourseType->unBindModel(array('belongsTo' => array('Institute')));
                    $this->AccomodationType->unBindModel(array('belongsTo' => array('Institute')));
                    $this->Institute->recursive = 2;
                    $institute_list = $this->Institute->find('all', array('conditions' => array('Institute.id' => $ids)));

                    foreach ($institute_list as $institute) {
                        $old_institute_id = $institute['Institute']['id'];
                        $institute = Hash::remove($institute, 'Institute.id');
                        unset($institute_id);

                        $this->Institute->create();
                        $this->Institute->save($institute);
                        $institute_id = $this->Institute->getLastInsertId();
                        //debug($institute);exit;

                        $event = $institute['Event'];
                        $event = Hash::remove($event, '{n}.id');
                        $event = Hash::remove($event, '{n}.institute_id');
                        $event = Hash::insert($event, '{n}.institute_id', $institute_id);
                        $this->Event->saveAll($event);


                        $instituteFacilty = $institute['InstituteFacility'];
                        $instituteFacilty = Hash::remove($instituteFacilty, '{n}.id');
                        $instituteFacilty = Hash::remove($instituteFacilty, '{n}.institute_id');
                        $instituteFacilty = Hash::insert($instituteFacilty, '{n}.institute_id', $institute_id);
                        $this->InstituteFacility->saveAll($instituteFacilty);

                        $instituteExam = $institute['InstituteExam'];
                        $instituteExam = Hash::remove($instituteExam, '{n}.id');
                        $instituteExam = Hash::remove($instituteExam, '{n}.institute_id');
                        $instituteExam = Hash::insert($instituteExam, '{n}.institute_id', $institute_id);
                        $this->InstituteExam->saveAll($instituteExam);


                        //debug($instituteFacilty);exit;
                        foreach ($institute['CourseType'] as $course) {

                            $course = Hash::remove($course, 'id');

                            $course = Hash::remove($course, 'institute_id');
                            $course = Hash::insert($course, 'institute_id', $institute_id);
                            //debug($course);
                            unset($course_id);
                            $this->CourseType->create();
                            $this->CourseType->save($course);
                            $course_id = $this->CourseType->getLastInsertId();
                            $coursePrice = $course['CoursePrice'];

                            $coursePrice = Hash::remove($coursePrice, '{n}.id');
                            $coursePrice = Hash::remove($coursePrice, '{n}.course_types_id');
                            $coursePrice = Hash::remove($coursePrice, '{n}.institute_id');
                            $coursePrice = Hash::insert($coursePrice, '{n}.institute_id', $institute_id);
                            $coursePrice = Hash::insert($coursePrice, '{n}.course_types_id', $course_id);
                            //debug($coursePrice);
                            $this->CoursePrice->saveAll($coursePrice);
                        }
                        foreach ($institute['AccomodationType'] as $accomo) {

                            $accommodation = Hash::remove($accomo, 'id');

                            $accommodation = Hash::remove($accommodation, 'institute_id');
                            $accommodation = Hash::insert($accommodation, 'institute_id', $institute_id);
                            //debug($accommodation);
                            unset($Accommodation_id);
                            $this->AccomodationType->create();
                            $this->AccomodationType->save($accommodation);
                            $Accommodation_id = $this->AccomodationType->getLastInsertId();
                            $AccommodationPrice = $accomo['AccomodationPrice'];

                            $AccommodationPrice = Hash::remove($AccommodationPrice, '{n}.id');
                            $AccommodationPrice = Hash::remove($AccommodationPrice, '{n}.accomodation_types_id');
                            $AccommodationPrice = Hash::remove($AccommodationPrice, '{n}.institute_id');
                            $AccommodationPrice = Hash::insert($AccommodationPrice, '{n}.institute_id', $institute_id);
                            $AccommodationPrice = Hash::insert($AccommodationPrice, '{n}.accomodation_types_id', $Accommodation_id);
                            //debug($AccommodationPrice);
                            $this->AccomodationPrice->saveAll($AccommodationPrice);

                            $Accommodationfacility = $accomo['AccomodationTypeAccomodationFacility'];
                            $Accommodationfacility = Hash::remove($Accommodationfacility, '{n}.id');
                            $Accommodationfacility = Hash::remove($Accommodationfacility, '{n}.accomodation_type_id');

                            $Accommodationfacility = Hash::insert($Accommodationfacility, '{n}.accomodation_type_id', $Accommodation_id);
                            $this->AccomodationTypeAccomodationFacility->saveAll($Accommodationfacility);
                        }
                        foreach ($institute['InstituteExtraFee'] as $fee) {
                            $fee = Hash::remove($fee, 'id');
                            $fee = Hash::remove($fee, 'institute_id');
                            $fee = Hash::insert($fee, 'institute_id', $institute_id);
                            // debug($fee);

                            $this->InstituteExtraFee->create();
                            $this->InstituteExtraFee->save($fee);
                        }

                    }
                    $message = 'Duplicate successfully.';
                }
                elseif ($task == "link_active") {
                    $this->Institute->updateAll(array('Institute.mode' => "'1'"), array('Institute.id' => $ids));
                    $message = 'Activated successfully.';
                } 
                elseif ($task == "link_inactive") {
                    $this->Institute->updateAll(array('Institute.mode' => "'0'"), array('Institute.id' => $ids));
                    $message = 'Inactivated successfully.';
                }
                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }

    /**
     * Purpose : upload images
     * Input :	input field name
     * Created on : 17 April 2014
     * Author : Rupesh Sharma
     */
    function upload_image($field_name) {

        $this->Upload = $this->Components->load('Upload');
        $temp_upload_folder = $this->Session->read('temp_upload_folder');
        if ($this->params['action'] == 'edit') {
            $temp_upload_folder = $this->params['pass'][0];
        }
        $upload_path = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
        if ($upload_path && !file_exists($upload_path)) {
            $oldumask = umask(0);
            mkdir($upload_path, 0777);
            mkdir($upload_path . '/gallery/', 0777);
            // or even 01777 so you get the sticky bit set 
            umask($oldumask);
        }
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 1200;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        if ($this->Upload->do_upload($field_name)) {

            $imgdata_arr = $this->Upload->data();
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.M.width');
            $height = Configure::read('THUMB.M.height');
            $thumb_name = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/M_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name);
            return $imgdata_arr['file_name'];
        }
    }

    /**
     * Purpose : Add photo gallery to respective institute
     * Created on : 17 April 2014
     * Author : Rupesh Sharma
     */
    function gallery($institute_id) {
        $this->loadModel('InstituteGallery');
        $institute_id = $this->params->pass[0];
        $this->Upload = $this->Components->load('Upload');
        $dir_path = UPLOAD_INSTITUE_DIR . $institute_id;
        $upload_path = $dir_path . '/gallery/';
        if (!file_exists($upload_path)) {
            $this->make_dir($dir_path);
            $this->make_dir($dir_path . '/gallery');
        }
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        if (!empty($this->data['Institute']['institue_id'])) {
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $this->data['Institute']['institue_id']), array('InstituteGallery.institute_id' => $this->data['Institute']['institue_id'] . '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }
        }
        
        $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }
    }

    /**
     * Purpose : Add delete photo gallery pic to respective institute
     * Created on : 23 April 2014
     * Author : Rupesh Sharma
     */
    function delete($id) {
        $id = $this->params->pass[0];
        $this->loadModel('InstituteGallery');
        $image_info=$this->InstituteGallery->find('first',array('conditions'=>array('InstituteGallery.id'=>$id)));
        
        if($this->InstituteGallery->delete($id)){
            $del_path = UPLOAD_INSTITUE_DIR .$image_info['InstituteGallery']['institute_id']. '/gallery/' . $image_info['InstituteGallery']['img'];
                    $this->delete_file($del_path);
               $del_path = UPLOAD_INSTITUE_DIR .$image_info['InstituteGallery']['institute_id']. '/gallery/VS_' . $image_info['InstituteGallery']['img'];
                    $this->delete_file($del_path);  
                $del_path = UPLOAD_INSTITUE_DIR .$image_info['InstituteGallery']['institute_id']. '/gallery/L_' . $image_info['InstituteGallery']['img'];
                    $this->delete_file($del_path);
        }        
        
        
        $this->autoRender = false;
    }
    
    
    /**
     * Purpose : Add delete all photo gallery pic to respective institute
     * Created on : 23 April 2014
     * Author : Rupesh Sharma
     */
    function deleteall($id) {
            
        if($this->request->is('post') && $id==$this->request->data['institute_id']){
        $id = $this->params->pass[0];
        $this->loadModel('InstituteGallery');
        $arr=$this->InstituteGallery->find('list',array('conditions'=>array('InstituteGallery.institute_id'=>$this->request->data['institute_id']),'fields'=>array('id','img')));
        if($arr){
        foreach($arr as $key=>$value){
            $id_arr[]=$key;
        }
        $this->InstituteGallery->deleteAll(array('InstituteGallery.id' => $id_arr));
             $files = glob(UPLOAD_INSTITUE_DIR .$id. '/gallery/*'); // get all file names
                foreach($files as $file){ // iterate files
                  if(is_file($file))
                    unlink($file); // delete file
                }  
          
            $this->Session->setFlash('All images deleted successfully');
        }
        else{
             $this->Session->setFlash('Please try again');
        }
        
        $this->redirect($this->referer());
        }
        else
        {
             $this->Session->setFlash('You are doing something wrong');
        }
    }

    /**
     * Purpose : Get destination from country id
     * Created on : 30 April 2014
     * Author : Rupesh Sharma
     */
    function getDestination($id) {
        $this->loadModel('Destination');
        $destination = $this->Destination->find('list', array('conditions' => array('Destination.country_id' => $id), 'fields' => array('id', 'name'), 'order' => array('Destination.name ASC')));
        $html = "<option value='0'>Select Destination</option>";
        foreach ($destination as $key => $value) {
            $html .= "<option value='$key'>$value</option>";
        }
        echo $html;
        $this->autoRender = false;
    }

    /**
     * Purpose : Listing of Extra Fee
     * Created on : 16 May 2014
     * Author : Rupesh Sharma
     */
    function list_extra_fee($id) {
        $this->set('institute_id', $id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );

        $result_arr = $this->paginate('InstituteExtraFee');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Extra Fee';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list_extra_fee');
    }

    /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function add_extra_fee($institute_id) {
        $this->set('institute_id', $institute_id);
        $errors = array();
        $add_errors = array();
        $this->loadModel('Currency');
        $error_flag = false;
        if (!empty($this->data)) {
            $data_arr = $this->data;
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;

            $this->InstituteExtraFee->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'Institute', 'action' => 'list_extra_fee', $institute_id));
        }
        $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $institute_id), 'fields' => array('currency_id')));

        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
    }

    /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function edit_extra_fee($institute_id, $id) {
        $this->set('institute_id', $institute_id);
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Currency');
        $this->InstituteExtraFee->id = $id;
        if (!empty($this->data)) {
            $data_arr = $this->data;
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;

            $this->InstituteExtraFee->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'Institute', 'action' => 'list_extra_fee', $institute_id));
        }
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
        $selected_type = $this->InstituteExtraFee->find('list', array('conditions' => array('InstituteExtraFee.id' => $id), 'fields' => array('id')));
        $this->set('selected_type', $selected_type);
        $data_arr = $this->InstituteExtraFee->findById($id);
        $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $institute_id), 'fields' => array('currency_id')));
        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);
        $this->data = $data_arr;
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
        $this->render('add_extra_fee');
    }

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE for extra Fee
     * Created on : 9 May 2014
     * Author : Rupesh Sharma
     */
    function extra_fee_manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->InstituteExtraFee->deleteAll(array('InstituteExtraFee.id' => $ids), true);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "1"), array('InstituteExtraFee.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "0"), array('InstituteExtraFee.id' => $ids));
                    $message = 'Inactivated successfully.';
                } elseif ($task == "Duplicate") {
                    $instituteExtrafee_list = $this->InstituteExtraFee->find('all', array('conditions' => array('InstituteExtraFee.id' => $ids)));

                    $instituteExtrafee_list2 = Hash::remove($instituteExtrafee_list, '{n}.InstituteExtraFee.id');
                    $this->InstituteExtraFee->saveAll($instituteExtrafee_list2);
                    $message = 'Duplicate successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }

    /**
     *  Purpose:Add school information when user add school first time
     * Created on :28/05/14
     * input:fields
     * Author:Abhishek Tripathi
     */
    public function add_form() {
        configure::write('debug',0);
        if ($this->Session->check('temp_upload_folder')) {
            $this->Session->delete('temp_upload_folder');
        }
        $this->loadModel('Country');
        $this->loadModel('Language');
        $this->loadModel('Facility');
        $this->loadModel('Exam');
        $this->loadModel('Currency');
        $this->loadModel('Accreditation');
        $day = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
        $this->set('day', $day);
        for ($i = 1; $i < 13; $i++) {
            $time[] = $i . ':00';
        }
        $this->set('time', $time);


        $next_year_date = array('31 August', '30 september', '31 October', '30 November', '31 December', '31 january of next year');
        $this->set('next_year_date', $next_year_date);
        $currency = $this->Currency->find('list', array('fields' => array('id', 'currency_code')));
        $this->set('currency', $currency);
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $countries_location = $this->Country->find('list', array('fields' => array('name', 'name'), 'order' => array('Country.name ASC')));
        $this->set('countries_location', $countries_location);
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $accreditation = $this->Accreditation->find('list', array('fields' => array('id', 'title')));
        $this->set('accreditation', $accreditation);
        if ($this->request->is('post')) {
            $this->Institute->save($this->request->data);
            $old_dir = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
            $new_dir = UPLOAD_INSTITUE_DIR . $this->Institute->getLastInsertId() . '/';
            rename($old_dir, $new_dir);
            $this->Session->setFlash(__('Add successfully'));
            $this->redirect(array('controlller' => 'institue', 'action' => 'edit_mode', $this->Institute->getLastInsertId()));
        }
        $this->set('view_title', 'Add School');
        $this->render('edit_mode');
    }

    /**
     * Purpose :save school information 
     * created on :29/05/14
     * Author:Abhishek Tripathi
     */
    public function add_info() {
        $this->layout = 'ajax';
         ///configure::write('debug',0);

        
        $this->loadModel('Currency');
        $this->loadModel('Destination');
        $this->loadModel('Country');
        $this->loadModel('PremiumInstitute');
        $this->loadModel('InstituteType');

        switch ($this->request->data['action_title']) {
            case 'general_info':

                if (isset($this->request->data['Institute']['open_day'])) {
                    $this->request->data['Institute']['open_day'] = json_encode($this->request->data['Institute']['open_day']);
                }
                if (!empty($this->request->data['Institute']['institute_id'])) {

                    $this->Institute->id = $this->request->data['Institute']['institute_id'];
                    $destination = $this->Destination->find("first", array("conditions" => array("Destination.id" => $this->request->data["Institute"]["destination_id"]), "fields" => array("name")));
                    $country = $this->Country->find("first", array("conditions" => array("Country.id" => $this->request->data["Institute"]["country_id"]), "fields" => array("name")));
                    $this->request->data['Institute']['slug'] = $this->unique_slug($this->request->data['Institute']['title'], $this->request->data['Institute']['destination_id']);
                    if(!empty($this->request->data['Institute']['starting_date'])){ 
                    $this->request->data['Institute']['starting_date']= date("Y-m-d", strtotime($this->request->data['Institute']['starting_date']));
                     $this->request->data['Institute']['expiry_date']= date("Y-m-d", strtotime($this->request->data['Institute']['expiry_date']));
                    }
                    
                    
                    $this->Institute->save($this->request->data);
                   
                    if (isset($this->request->data['Institute']['event'])) {
                        $this->loadModel('Event');

                        $this->Event->deleteAll(array('Event.institute_id' => $this->request->data['Institute']['institute_id']), false);
                        foreach ($this->request->data['Institute']['event'] as $event) {
                            $events[] = array('institute_id' => $this->request->data['Institute']['institute_id'],
                                'start_date' => date("Y-m-d h:i:s", strtotime($event['date'])),
                                'title' => $event['title']
                            );
                        }

                        $this->Event->saveMany($events);
                    }
                    
                     /*thumbnail   image premium listing----*/
                     
                    $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $this->request->data['Institute']['institute_id']), 'fields' => array('currency_id')));
                    $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));

                    $response['id'] = $this->request->data['Institute']['institute_id'];
                    $response['currency_symbol'] = $currency_symbol['Currency']['currrency_symbol'];
                    //pr($response);

                    $this->set('response', $response);
                } else {

                    $destination = $this->Destination->find("first", array("conditions" => array("Destination.id" => $this->request->data["Institute"]["destination_id"]), "fields" => array("name")));
                    $country = $this->Country->find("first", array("conditions" => array("Country.id" => $this->request->data["Institute"]["country_id"]), "fields" => array("name")));


                    $this->request->data['Institute']['slug'] = $this->unique_slug($this->request->data['Institute']['title'], $this->request->data['Institute']['destination_id']);
                    if ($this->Institute->save($this->request->data)) {
                       
                        if ($this->Session->check('temp_upload_folder')) {
                            $temp_upload_folder = $this->Session->read('temp_upload_folder');
                        } else {
                            $temp_upload_folder = time();
                            $this->Session->write('temp_upload_folder', $temp_upload_folder);
                        }
                        $old_dir = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
                        $new_dir = UPLOAD_INSTITUE_DIR . $this->Institute->getLastInsertId() . '/';
                        rename($old_dir, $new_dir);
                        if (isset($this->request->data['Institute']['event'])) {
                            $this->loadModel('Event');
                            foreach ($this->request->data['Institute']['event'] as $event) {
                                $events[] = array('institute_id' => $this->Institute->getLastInsertId(),
                                    'start_date' => date("Y-m-d h:i:s", strtotime($event['date'])),
                                    'title' => $event['title']
                                );
                            }
                            $this->Event->saveMany($events);
                        }
                       $currency_code = $this->Institute->find('first', array('conditions' => array('Institute.id' => $this->Institute->getLastInsertId()), 'fields' => array('currency_id')));
                        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));

                        $response['id'] = $this->Institute->getLastInsertId();
                        $response['currency_symbol'] = $currency_symbol['Currency']['currrency_symbol'];
                       
                      
                        $this->set('response', $response);
                        
                      
                        
                        
                        
                    } else {
                        $this->set('response', 'fail');
                    }
                }
                break;
            case 'facility_info':
                $this->loadModel('InstituteFacility');

                if (count($this->request->data['Institute']['facility_id']) > 1) {

                    foreach ($this->request->data['Institute']['facility_id'] as $faci) {
                        $facility[] = array(
                            'institute_id' => $this->request->data['Institute']['institute_id'],
                            'facility_id' => $faci
                        );
                    }
                    $this->InstituteFacility->deleteAll(array('InstituteFacility.institute_id' => $this->request->data['Institute']['institute_id']), false);
                    $this->InstituteFacility->saveMany($facility);
                }
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                $this->Institute->save($this->request->data);


                $response['result'] = 'Success';
                $this->set('response', $response);


                break;
            case 'exam_info':
                $this->loadModel('InstituteExam');
                //debug(empty($this->request->data['Institute']['exam_id']));exit;
                if (!empty($this->request->data['Institute']['exam_id'])) {

                    foreach ($this->request->data['Institute']['exam_id'] as $faci) {
                        $exam[] = array(
                            'institute_id' => $this->request->data['Institute']['institute_id'],
                            'exam_id' => $faci
                        );
                    }
                    $this->InstituteExam->deleteAll(array('InstituteExam.institute_id' => $this->request->data['Institute']['institute_id']));
                    $this->InstituteExam->saveMany($exam);
                }
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                $this->Institute->save($this->request->data);

                $response['result'] = 'Success';
                $this->set('response', $response);
                break;
            case 'land_info':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
               
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'school_presentation':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
            if(!empty($this->request->data['Institute']['language_course_type'])){
                $this->request->data['Institute']['language_course_type']=  json_encode($this->request->data['Institute']['language_course_type']);
               
            }
            if(!empty( $this->request->data['Institute']['accommodation_type'])){
                
                $this->request->data['Institute']['accommodation_type']=  json_encode($this->request->data['Institute']['accommodation_type']);
            }
                
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'our_team':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                $this->request->data['Institute']['spoken_languages'] = json_encode($this->request->data['Institute']['spoken_languages']);
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'location_info':
                 if (isset($this->request->data['Institute']['open_day'])) {
                    $this->request->data['Institute']['open_day'] = json_encode($this->request->data['Institute']['open_day']);
                }
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    
                     if (isset($this->request->data['Institute']['event'])) {
                         $events=  explode(',', $this->request->data['Institute']['event']);
                       
                            $this->loadModel('Event');
                             $this->Event->deleteAll(array('Event.institute_id' => $this->request->data['Institute']['institute_id']), false);
                            foreach ($events as $event) {
                                $events_list[] = array('institute_id' =>$this->request->data['Institute']['institute_id'],
                                    'start_date' => date("Y-m-d h:i:s", strtotime($event)),
                                    'title' => 'public'
                                );
                            }
                            $this->Event->saveMany($events_list);
                        }
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'student_profile_info':

                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                $data_arr = $this->request->data;
                $student_profile = array(
                    'Students_Enrolled_Last_Year' => $data_arr['Institute']['Students_Enrolled_Last_Year'],
                    'Average_Number_Students_During_Year' => $data_arr['Institute']['Average_Number_Students_During_Year'],
                    'Average_Number_Students_During_High_Season' => $data_arr['Institute']['Average_Number_Students_During_High_Season'],
                    'Minimum_Student_Age' => $data_arr['Institute']['Minimum_Student_Age'],
                    'less_then_twenty' => $data_arr['Institute']['less_then_twenty'],
                    'twenty_twentyfour' => $data_arr['Institute']['twenty_twentyfour'],
                    'twentyfive_twentynine' => $data_arr['Institute']['twentyfive_twentynine'],
                    'thirty_thirtyfour' => $data_arr['Institute']['thirty_thirtyfour'],
                    'thirtyfive_thirtynine' => $data_arr['Institute']['thirtyfive_thirtynine'],
                    'Middle_East_Africa' => $data_arr['Institute']['Middle_East_Africa'],
                    'Central_South_America' => $data_arr['Institute']['Central_South_America'],
                    'Asia_Far_East' => $data_arr['Institute']['Asia_Far_East'],
                    'Central_Eastern_Europe' => $data_arr['Institute']['Central_Eastern_Europe'],
                    'Western_Europe' => $data_arr['Institute']['Western_Europe'],
                    'North_america' => $data_arr['Institute']['North_america']
                );
                $data_arr['Institute']['student_profile'] = json_encode($student_profile);

                if ($this->Institute->save($data_arr)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'first_day_info':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'activities_info':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'additional_info':
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'enrollment_info':

                $array['Institute']['enrollment'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'invoice_info':

                $array['Institute']['invoice'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'bank_info':

                $array['Institute']['bank'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'payment_info':
                $array['Institute']['payment_detail'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'commission_info':
                $array['Institute']['commission'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'term_info':

                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'visa_info':

                $this->request->data['Institute']['visa'] = json_encode($this->request->data['Institute']['visa']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'regional_pricing_info':

                $this->request->data['Institute']['regional_pricing'] = json_encode($this->request->data['Institute']['regional_pricing']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($this->request->data)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'recognation_info':
                $array['Institute']['recogination'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'accreditation_info':
                $array['Institute']['accreditation'] = json_encode($this->request->data['Institute']['accreditations_id']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                $this->Institute->save($this->request->data);
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'course_info':
                $array['Institute']['course_detail'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'accommodation_info':
                $array['Institute']['accommodation_detail'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'visa_basic_info':
                $array['Institute']['visa_basic_detail'] = json_encode($this->request->data['Institute']);
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            case 'seo_info':
                $array['Institute']['seo_detail'] = json_encode($this->request->data['Institute']);
                
                $this->Institute->id = $this->request->data['Institute']['institute_id'];
                if(empty($this->request->data['Institute']['overwrite_slug'])){
                
                    $this->request->data['Institute']['slug']=$this->unique_slug_overwrite($this->request->data['Institute']['institute_id']);
                    $this->Institute->save($this->request->data); 
                }
                else{
                     $this->request->data['Institute']['slug']=$this->request->data['Institute']['overwrite_slug'];
                }
                $this->Institute->save($this->request->data);
                if ($this->Institute->save($array)) {
                    $response['result'] = 'Success';
                    $this->set('response', $response);
                }
                break;
            
                    
        }

        //$this->render('ajax');
        echo json_encode($response);
        exit;
    }

    /**
     * purpose:Upload image
     * created:29/05/14
     * Author:Abhishek Tripathi
     */
    public function logo_upload() {

        $this->layout = "ajax";
         
    


            if ($this->Session->check('temp_upload_folder')) {
                $temp_upload_folder = $this->Session->read('temp_upload_folder');
            } else {
                $temp_upload_folder = time();
                $this->Session->write('temp_upload_folder', $temp_upload_folder);
            }

            $dir_path = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
            if (!file_exists($dir_path)) {
                $this->make_dir($dir_path);
                $this->make_dir($dir_path . '/gallery');
            }
           
            
           
            
            if(!empty($this->request->data['Institute']['institute_id'])){
            $temp_upload_folder = $this->request->data['Institute']['institute_id'];
            $this->Session->write('temp_upload_folder', $temp_upload_folder);
            }
            $path= UPLOAD_INSTITUE_DIR . $temp_upload_folder;
            $name = date('ydmhis');
           
            if(isset($this->params['form']['logo'])){
              $one= $this->params['form']['logo'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::logo_image();
            }
            if(isset($this->params['form']['our_team_image'])){
              $one= $this->params['form']['our_team_image'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::our_team_image();
            }
            if(isset($this->params['form']['embassy_image'])){
              $one= $this->params['form']['embassy_image'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::embassy_image();
            }
            if(isset($this->params['form']['brand_image'])){
              $one= $this->params['form']['brand_image'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::brand_image();
            }
            if(isset($this->params['form']['first_day_image'])){
              $one= $this->params['form']['first_day_image'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::first_day_image();
            }
            if(isset($this->params['form']['activities_social_image'])){
              $one= $this->params['form']['activities_social_image'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::activities_social_image();
            }
            if(isset($this->params['form']['main_img'])){
              $one= $this->params['form']['main_img'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::main_img_image();
            }
             if(isset($this->params['form']['thumb_nail'])){
              $one= $this->params['form']['thumb_nail'];  
              $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
              $thumbnails = Thumbnail::thumbnail_image();
            }
            
            
            
            $path= UPLOAD_INSTITUE_DIR . $temp_upload_folder;
            $name = date('ydmhis');
            
            $this->Uploader->upload($one, $path.DS, $thumbnails, $name, $params);
        
        
        
        $response['image_name'] = $name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION));
        $response['path'] = FULL_BASE_URL . $this->webroot . UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/' . $name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION));
        
        $this->set('response', $response);

        $this->autoRender = false;
        $this->render('ajax');
    }

    /**
     * Purpose:school edit form
     * created:29/05/14
     * Author:Abhishek Tripathi
     * parameter: institute id and it will return complete information
     */
    public function edit_form($id = null) {

        if ($this->params['action'] == 'edit_form') {
            $this->set('action', 1);
        }
        
       
          
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Country');
        $this->loadModel('Language');
        $this->loadModel('Facility');
        $this->loadModel('Exam');
        $this->loadModel('Currency');
        $this->loadModel('Accreditation');
        $this->loadModel('Destination');
        $this->loadModel('InstituteExam');
        $this->loadModel('InstituteFacility');
        $this->loadModel('Event');
        
        $this->loadModel('Accomodation');
        
        $this->loadModel('CourseSubcategory');
        $this->set('view_title', 'Add Institute');
        $this->set('errors', $errors);

        $language_spoken = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('spoken_language', $language_spoken);
        $day = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday');
        $this->set('day', $day);
        $data_arr = $this->Institute->findById($id);
        

        for ($i = 1; $i < 13; $i++) {
            $time[] = $i . ':00';
        }
        $this->set('time', $time);

        $next_year_date = array('31 August', '30 september', '31 October', '30 November', '31 December', '31 january of next year');
        $this->set('next_year_date', $next_year_date);
        $accreditation = $this->Accreditation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accreditation));
        $this->set('accreditation', $accreditation);

        $currency_symbol = $this->Currency->find('first', array('conditions' => array('Currency.id' => $data_arr['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
        $this->set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);
        // json decode 

        $student_profile = json_decode($data_arr['Institute']['student_profile'], true);

        if (!empty($student_profile)) {
            $new_arr = array_merge($data_arr['Institute'], $student_profile);
            $data_arr = array('Institute' => $new_arr);
        }

        $enrollment = json_decode($data_arr['Institute']['enrollment'], true);

        if (!empty($enrollment)) {
            $new_arr = array_merge($data_arr['Institute'], $enrollment);
            $data_arr = array('Institute' => $new_arr);
        }

        $invoice = json_decode($data_arr['Institute']['invoice'], true);
        if (!empty($invoice)) {
            $new_arr = array_merge($data_arr['Institute'], $invoice);
            $data_arr = array('Institute' => $new_arr);
        }
        $bank = json_decode($data_arr['Institute']['bank'], true);
        if (!empty($bank)) {
            $new_arr = array_merge($data_arr['Institute'], $bank);
            $data_arr = array('Institute' => $new_arr);
        }

        $payment = json_decode($data_arr['Institute']['payment_detail'], true);
        if (!empty($payment)) {
            $new_arr = array_merge($data_arr['Institute'], $payment);
            $data_arr = array('Institute' => $new_arr);
        }
        $commission = json_decode($data_arr['Institute']['commission'], true);
        if (!empty($commission)) {
            $new_arr = array_merge($data_arr['Institute'], $commission);
            $data_arr = array('Institute' => $new_arr);
        }
        $recogination = json_decode($data_arr['Institute']['recogination'], true);
        if (!empty($recogination)) {
            $new_arr = array_merge($data_arr['Institute'], $recogination);
            $data_arr = array('Institute' => $new_arr);
        }
        $course = json_decode($data_arr['Institute']['course_detail'], true);
        if (!empty($course)) {
            $new_arr = array_merge($data_arr['Institute'], $course);
            $data_arr = array('Institute' => $new_arr);
        }
        $accommodation = json_decode($data_arr['Institute']['accommodation_detail'], true);
        if (!empty($accommodation)) {
            $new_arr = array_merge($data_arr['Institute'], $accommodation);
            $data_arr = array('Institute' => $new_arr);
        }
        $spoken_languages = json_decode($data_arr['Institute']['spoken_languages'], true);
        if (!empty($spoken_languages)) {
            $new_arr = array_merge($data_arr['Institute'], $spoken_languages);
            $data_arr = array('Institute' => $new_arr);
        }
        $transfer = json_decode($data_arr['Institute']['transfer_detail'], true);
        if (!empty($transfer)) {
            $new_arr = array_merge($data_arr['Institute'], $transfer);
            $data_arr = array('Institute' => $new_arr);
        }
        $seo = json_decode($data_arr['Institute']['seo_detail'], true);
        if (!empty($seo)) {
            $new_arr = array_merge($data_arr['Institute'], $seo);
            $data_arr = array('Institute' => $new_arr);
        }

        $visa_basic = json_decode($data_arr['Institute']['visa_basic_detail'], true);
        if (!empty($visa_basic)) {
            $new_arr = array_merge($data_arr['Institute'], $visa_basic);
            $data_arr = array('Institute' => $new_arr);
        }
        
           $institute_id=$id;
       
        $this->set('institute_id',$institute_id);
        $this->set('id',$institute_id);

        $currency = $this->Currency->find('list', array('fields' => array('id', 'currency_code')));
        (natcasesort($currency));
        $this->set('currency', $currency);
        $event = $this->Event->find('all', array('conditions' => array('Event.institute_id' => $id)));
        $this->set('event', $event);

        $this->data = $data_arr;
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $countries_location = $this->Country->find('list', array('fields' => array('name', 'name')));
        $this->set('countries_location', $countries_location);

        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $destination = $this->Destination->find("list", array("conditions" => array("Destination.country_id" => $this->data["Institute"]["country_id"]), "fields" => array("id", "name")));
        $this->set('destination', $destination);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $selected_facility = $this->InstituteFacility->find('list', array('conditions' => array('InstituteFacility.institute_id' => $id), 'fields' => array('facility_id')));
        $this->set('selected_facility', $selected_facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $selected_exam = $this->InstituteExam->find('list', array('conditions' => array('InstituteExam.institute_id' => $id), 'fields' => array('exam_id')));
        $this->set('selected_exam', $selected_exam);
        
        $courese_category = $this->CourseSubcategory->find('list', array('fields' => array('id', 'title')));
        (natcasesort($courese_category));
        $this->set('courese_category', $courese_category);
        
          $accomodation_category = $this->Accomodation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accomodation_category));
        $this->set('accomodation_category', $accomodation_category);
        
         //------------------------------------------------------------gallery--------------=================================
         $institute_id=$id;
       
        $this->set('institute_id',$institute_id);
        $this->set('id',$institute_id);
    	
		
        $this->loadModel('InstituteGallery');
        //show gallery images
      
        $this->Upload = $this->Components->load('Upload');
        $upload_path = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/';
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        
        if (!empty($id)) {
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $id), array('InstituteGallery.institute_id' => $id. '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }
			
       
        }	
		  $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }
       /*-----------------------------------------------------------------------gallery----------------------*/
        
 
         
         if($data_arr['Institute']['listing_type']==2){
            $this->render('edit_mode_premium');
         }else{
            $this->render('edit_mode');
         }
         // $this->render('edit_mode');
        $this->autoRender = false;
    }

    /**
     * Purpose:export xls sheet 
     * created on :23 june 2014
     * Author:Abhishek Tripathi
     */
    public function export($id = null) {
        if ($id == null) {
				
            $data_list = $this->Institute->find('all');
         
        
        
            foreach ($data_list as $data) {
				
				     
                $data['Institute']['country_id']=$data['Country']['name'];
                $data['Institute']['language_id']=$data['Language']['title'];
                $data['Institute']['destination_id']=$data['Destination']['name'];
                 $data['Institute']['url']=FULL_BASE_URL.$this->webroot.$data['Institute']['slug'];
                
				
                $commission = json_decode($data['Institute']['commission'], true);
                if (!empty($commission)) {
                    $new_arr = array_merge($data['Institute'], $commission);
                    $data = array('Institute' => $new_arr);
                }
                $invoice = json_decode($data['Institute']['invoice'], true);
                if (!empty($invoice)) {
                    $new_arr = array_merge($data['Institute'], $invoice);
                    $data = array('Institute' => $new_arr);
                }
                $enrollment = json_decode($data['Institute']['enrollment'], true);
                if (!empty($enrollment)) {
                    $new_arr = array_merge($data['Institute'], $enrollment);
                    $data = array('Institute' => $new_arr);
                }
                $seo = json_decode($data['Institute']['seo_detail'], true);
                if (!empty($seo)) {
                    $new_arr = array_merge($data['Institute'], $seo);
                    $data = array('Institute' => $new_arr);
                }
					 

                $data_arr[] = $data;
                
                
            }
            $this->set('models', $data_arr);
        } else {
            $data_list = $this->Institute->find('all', array('conditions' => array('Institute.id' => $id)));
		
            foreach ($data_list as $data) {
                $commission = json_decode($data['Institute']['commission'], true);
                if (!empty($commission)) {
                    $new_arr = array_merge($data['Institute'], $commission);
                    $data = array('Institute' => $new_arr);
                }
                $invoice = json_decode($data['Institute']['invoice'], true);
                if (!empty($invoice)) {
                    $new_arr = array_merge($data['Institute'], $invoice);
                    $data = array('Institute' => $new_arr);
                }
                $enrollment = json_decode($data['Institute']['enrollment'], true);
                if (!empty($enrollment)) {
                    $new_arr = array_merge($data['Institute'], $enrollment);
                    $data = array('Institute' => $new_arr);
                }
                $seo = json_decode($data['Institute']['seo_detail'], true);
                if (!empty($seo)) {
                    $new_arr = array_merge($data['Institute'], $seo);
                    $data = array('Institute' => $new_arr);
                }
                $data_arr[] = $data;
            }

            $this->set('models', $data_arr);
        }
    }

    /**
     * Purpose:remove events from ajax request
     * created on :23 july 2014
     * Author:Abhishek Tripathi
     */
    public function remove_event() {
        if ($this->request->is('Post')) {
            $this->loadModel('Event');
            $this->Event->id = $this->request->data['id'];
            if ($this->Event->Delete()) {
                echo 'success';
                exit;
            } else {
                echo 'error';
                exit;
            }
        }
    }

    public function get_address() {

        $lat = $this->request->data['lat']; //latitude
        $lng = $this->request->data['long']; //longitude

        $url = 'http://maps.googleapis.com/maps/api/geocode/json?latlng=' . trim($lat) . ',' . trim($lng) . '&sensor=false';
        $json = @file_get_contents($url);
        $data = json_decode($json);
        $status = $data->status;
        if ($status == "OK") {
            //debug($data->results[0]->address_components[4]->long_name);exit;
            $response['add'] = $data->results[0]->formatted_address;
            $response['lat'] = $lat;
            $response['lng'] = $lng;
            $add_data = explode(',', $response['add']);
            $count = count($add_data) - 1;


            $response['country'] = ltrim($add_data[$count]);
            $response['city'] = ltrim($add_data[$count - 1]);
//$response['country']=(isset($data->results[0]->address_components[5]->long_name)?$data->results[0]->address_components[5]->long_name:'0');
            echo json_encode($response);
            exit;
        } else {
            //debug('try');
        }
    }

    /**
     * Purpose : Get destination from country name
     * Created on : 30 April 2014
     * Author : Rupesh Sharma
     */
    function getDestination_name($name, $city) {
        $this->loadModel('Country');
        $country_id = $this->Country->find('first', array('condition' => array('name' => $name)));
        $this->loadModel('Destination');
        $destination = $this->Destination->find('list', array('conditions' => array('Destination.country_id' => $country_id['Country']['id']), 'fields' => array('id', 'name')));
        $html = "<option value='0'>Select Destination</option>";
        foreach ($destination as $key => $value) {
            $html .= "<option value='$value' " . (($value == $city) ? 'selected' : '') . ">$value</option>";
        }
        echo $html;
        $this->autoRender = false;
    }

    public function copyDirectory($source, $dest, $excludeSvnFolders = true) {
        $sourceHandle = opendir($source);
        //debug($source);exit;
        if (!$sourceHandle) {
            echo 'failed to copy directory: failed to open source ' . $source;
            return false;
        }

        while ($file = readdir($sourceHandle)) {
            if ($file == '.' || $file == '..')
                continue;
            if ($excludeSvnFolders && $file == '.svn')
                continue;

            if (is_dir($source . '/' . $file)) {
                if (!file_exists($dest . '/' . $file)) {
                    $this->make_dir($dest);
                    $this->make_dir($dest . '/gallery');
                    // mkdir($dest . '/' . $file, 777);
                }
                self::copyDirectory($source . '/' . $file, $dest . '/' . $file);
            } else {
                copy($source . '/' . $file, $dest . '/' . $file);
            }
        }



        return true;
    }

    /**
     * Purpose : make unique slug for schoo
     * Created on : 27/9/14
     * Author : Abhishek TRipathi
     */
    public function unique_slug($title, $city_id) {
        $this->loadModel('Destination');

        $destination = $this->Destination->find('first', array('conditions' => array('Destination.id' => $city_id)));
        $slug1 = strtolower($this->hyphenize($title));
        $slug2 = $destination['Destination']['slug'];

        $slug = $slug1. '-' .$slug2;
        return $slug;
    }
    
    
    /**
     * Purpose : make unique slug in overwrite
     * Created on : 27/9/14
     * Author : Abhishek TRipathi
     */
    public function unique_slug_overwrite($id=null) {
        $this->loadModel('Destination');
        $this->loadModel('Institute');
        $institute=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('Institute.id','Institute.slug','Institute.title','Institute.destination_id')));

        $destination = $this->Destination->find('first', array('conditions' => array('Destination.id' => $institute['Institute']['destination_id'])));
        $slug1 = strtolower($this->hyphenize($institute['Institute']['title']));
        $slug2 = $destination['Destination']['slug'];

        $slug = $slug1. '-' .$slug2;
        return $slug;
    }
    
    

    public function hyphenize($string) {
        return
                ## strtolower(
                preg_replace(
                array('#[\\s-]+#', '#[^A-Za-z0-9\. -]+#'), array('-', ''),
                ##     cleanString(
                urldecode($string)
                ##     )
                )
        ## )
        ;
    }
    
    
    
    
    public function listing_type(){
        if($this->request->is('post')){
            $this->Institute->id=$this->request->data['id'];
            $this->Institute->saveField('listing_type',$this->request->data['value']);
            echo 'success';exit;
        }
    }

}

?>
