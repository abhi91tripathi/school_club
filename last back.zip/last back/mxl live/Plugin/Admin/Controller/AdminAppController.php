<?php

App::uses('AppController', 'Controller');

class AdminAppController extends AppController {
	public $theme = 'Admin';
	public $components = array(
		'Session',
		'Auth' => array(
			'loginAction' => array(
				'controller' => 'users',
				'action' => 'login',
				'plugin' => 'admin'
			),						
			'loginRedirect' => array('controller' => 'users', 'action' => 'dashboard'),
			'logoutRedirect' => array('controller' => 'users', 'action' => 'login')	
		),
		'ImageResize'
	);
	
		public function beforeFilter(){
		parent::beforeFilter();
		$this->loadModel('Setting');
		$settings=$this->Setting->find('first');
		//debug($settings);exit;
		$this->set('settings',$settings);
                $this->Setting->useDbConfig = 'spanish';
		
	}
	
	/*
	 * Name: uploadimage
	 * Purpose: TO upload the hompage block image via ajax
	 * Created: 2 apr 2014
	 * Author: Ritish
	 */
	function uploadimage()
	{
		$name = time() . '-' . $_FILES['image']['name'];
		$name = str_replace(' ','_',$name);
		$path = ROOT . $_GET['path'] . $name;
		list( $width, $height) = getimagesize($_FILES['image']['tmp_name']);
		if( move_uploaded_file( $_FILES['image']['tmp_name'], $path) )
		{
			//$this->ImageResize->resize($path, $_GET['width'], $_GET['height']);
			echo $name; exit;
		}
		else
		{
			die('upload_error');
		}
	}
	
	/*
	 * Name: unlink_old_image
	 * Purpose: To unlik the previous one after uploading the image
	 * Created: 2 apr 2014
	 * Author: Ritish
	 */
	function unlink_old_image($name = Null)
	{
		if($name)
		{
			$path = ROOT . $_GET['path'] . $name;
			unlink($path);
		}
		exit;
	}

	/*
	 * Name: get_lat_long
	 * Purpose: get lat,long from address
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_lat_long($location_url)
	{

		$curl = curl_init();
		curl_setopt_array($curl, array(
		    CURLOPT_RETURNTRANSFER => 1,
		    CURLOPT_URL => $location_url,
		    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
		));
		$resp = curl_exec($curl);
		$res_array = json_decode($resp,true);
		curl_close($curl);
		if(isset($res_array['results']['0']['geometry']['location']['lat']) && isset($res_array['results']['0']['geometry']['location']['lng']))
		{
			$lat = $res_array['results']['0']['geometry']['location']['lat'];
            $lng = $res_array['results']['0']['geometry']['location']['lng'];
			$location = array($lat,$lng);
			return $location;
			
		}
		else
		{
			$location = array("15.493","73.818");
			return $location;
		}

	}


	/*
	 * Name: get_slug
	 * Purpose: get slug from name
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_slug($string)
	{
		$string = strtolower($string);
		$replace=array(' ','&','$');
		$slug = str_replace($replace, '-', $string);
		$slug = preg_replace('#[^\w()/.%\-&]#','',$slug);
		return $slug;
	}
	
	/*
	 * Name: get_unique_slug
	 * Purpose: get unique slug if its already exists in table
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_unique_slug($string)
	{
		$unique_slug=$string.'_'.mt_rand(1111,9999);
		return $unique_slug;
	}
        
        /*
	 * Name: local conversion
	 * Purpose: change the site language
	 * Created: 20 nov 2014
	 * Author: Abhishek Tripathi
	 */
        public function conversion($lang=null){
            switch($lang){
                case 'EMGLISH':$this->Session->write('language',$lang);
                    break;
                 case 'SPANISH':$this->Session->write('language',$lang);
                    break;
                 case 'FRENCH':$this->Session->write('language',$lang);
                    break;
                 case 'RUSSIAN':$this->Session->write('language',$lang);
                    break;
            }
             echo 'success';
                exit;
        }
        /*
	 * Name:slug
	 * Purpose: change the site language
	 * Created: 28 dece 2014
	 * Author: Abhishek Tripathi
	 */
          public function hyphenize($string) {
        return
                ## strtolower(
                preg_replace(
                array('#[\\s-]+#', '#[^A-Za-z0-9\. -]+#'), array(''),
                ##     cleanString(
                urldecode($string)
                ##     )
                )
        ## )
        ;
    }
}
