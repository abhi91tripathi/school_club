<?php
/**
 * Name : Facilities Controller
 * Created : 3 Apr 2014
 * Purpose : To manage the languages.
 * Author : Ritish
 */ 
class FacilitiesController extends AdminAppController
{
	public $name = 'facilities';
	public $uses = array('Admin.Facility');
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
	}
	
	/**
	 * Name : Index
	 * Purpose : For language listing
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function index($id=null)
	{
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->Facility->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected facilities deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Facility.' . $field_name . ' Like' => $value . '%'));
			}
		}
		if($id)
		{
			$edit_lang = $this->Facility->find('first', array('conditions' => array('Facility.id' => $id), 'fields' => array('id','title','icon')));
			$this->set('edit_lang',$edit_lang);
		}
		
		$this->paginate = array('order' => 'id desc','limit' => 10);
		$facilities = $this->paginate('Facility', $conditions);
		$this->set('facilities',$facilities);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new Facility
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function add()
	{
		if($this->request->is('post'))
		{
			$data = $this->data;
			if($this->Facility->save($data))
			{
				$this->Session->setFlash('Facility saved successfully');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('The Facility could not be saved. Please, try again.'));
			}
		}
	}
	
	/**
	 * Name : Edit
	 * Purpose : To edit the Facility
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function edit($id = null)
	{
		if($this->request->is('post'))
		{
			$this->add();
		}
		$edit_facility = $this->Facility->find('first', array('conditions' => array('Facility.id' => $id)));
		$this->set('edit_facility', $edit_facility);
		$this->render('add');
	}
}
