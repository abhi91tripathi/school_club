<?php
/*
 * Name : Reviews
 * Created : 9 oct 2014
 * Purpose : Reviews controller
 * Author : Abhishek Tripathi
 */
CakePlugin::load('PhpExcel');

class PaymentController extends AdminAppController {
    	public $components=array('Uploader','Email');
        
        public $helpers = array('PhpExcel.PhpExcel','Converter');
	function beforeFilter()
	{
          // configure::write('debug',2);
		parent::beforeFilter();
                
	}
		  
	public function index()
	{
            
            $this->loadModel('Institute');
            $this->loadModel('Destination');
            
            $destination=$this->Destination->find('list',array('fields'=>array('id','name')));
            $institute=$this->Institute->get_school_list_lang();
		$this->layout='default';
		$cond_arr = array();
		$this->loadModel('Student');
		$this->Payment->bindModel(array(
				'belongsTo' => array(
						'Student' => array(
								'class' => 'Student',
								'foreignKey' => 'student_id',
						)
				)
		), false);
		$this->loadModel('Student');
		if (!empty($_GET['filter']['first_name'])) 
		{
                   $cond_arr = array_merge($cond_arr, array('Student.first_name Like' => $_GET['filter']['first_name'] . '%'));
		}
                if (!empty($_GET['filter']['last_name'])) 
		{
                   $cond_arr = array_merge($cond_arr, array('Student.last_name Like' => $_GET['filter']['last_name'] . '%'));
		}
                if (!empty($_GET['filter']['email'])) 
		{
                   $cond_arr = array_merge($cond_arr, array('Student.email' => $_GET['filter']['email']));
		}
                if (!empty($_GET['filter']['institute_id'])) 
		{
                   $cond_arr = array_merge($cond_arr, array('Student.institute_id' => $_GET['filter']['institute_id']));
		}
               
		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('Student.created' => 'DESC')
		);
		$result_arr = $this->paginate('Student');
		
		$view_title = 'Transaction Management';
		$this->set(compact('result_arr','view_title','institute','destination'));
	}
	
	public function view($id=null)
	{
             $this->loadModel('Student');
            $this->loadModel('Institute');
            $this->loadModel('CourseType');
            $this->loadModel('AccomodationType');
		$this->layout='default';
		$cond_arr = array();
		$this->loadModel('Student');
		 $contain=array('Institute'=>array('fields'=>array('Institute.title')),'Payment','Emergency','CourseType','AccomodationType');
		$this->paginate = array(
			'conditions' => array('Student.id'=>$id),
                         'contain'=>$contain,
			'limit'=>1
		);
		$result_arr = $this->paginate('Student');
		
		$view_title = 'Student Online Quote';
		$this->set(compact('result_arr','view_title'));
	}
	/**
	 * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
	 * Created on : 6 May 2014
	 * Author : Rupesh Sharma
	*/
	function manage_actions()
	{
          
            $this->loadModel('Student');
           
		if(count($this->params['data']))
		{
			$message = '';

			$ids = $this->params['data']['list'];
			
			if(!empty($ids))
			{
				$task = $this->params['data']['task'];

				if($task == "delete")
				{
					$this->Student->deleteAll(array('Student.id' => $ids), true);
					$message = 'Deleted successfully.';
				}
                                if($task=="cancel"){
                                    foreach ($ids as $id){
                                        $x = $this->reject($id);
                                        
                                    }
                                   $message = 'Canceled successfully.';
                                }
                                if($task=="accept"){
                                    foreach ($ids as $id){
                                        $this->accept($id);
                                    }
                                   $message = 'Canceled successfully.';
                                }
				$this->Session->setFlash($message, 'flash_success');
			}

		}
		$this->redirect($this->referer());
	}
        
        /**
	  * Purpose:Edit student infomation
	  * created on 22 novemember 2014
	  * created by:Abhishek Tripathi
	  **/
        public function edit($id=null){
            
            $this->loadModel('Student');
            $this->loadModel('Institute');
            $this->loadModel('CourseType');
            $this->loadModel('AccomodationType');
            $this->loadModel('Emergency');
           $institute=$this->Institute->get_school_list_lang();
           $courses=$this->CourseType->find('list',array('conditions'=>array('CourseType.published'=>1),'fields'=>array('id','title')));
           $accomodation=$this->AccomodationType->find('list',array('conditions'=>array('AccomodationType.published'=>1),'fields'=>array('id','title')));
            
            if($this->request->is('put')){
               
                $this->Student->id=$id;
                if($this->Student->save($this->request->data)){
                    $this->Emergency->id=$this->request->data['Emergency']['id'];
                    $this->Emergency->save($this->request->data['Emergency']);
                    $this->Session->setFlash(__('Successfully completed'), 'flash_success');
                    $this->redirect(array('controller'=>'Payment','action'=>'index'));
                }
                else{
                    $this->Session->setFlash(__('SSorry please try again'), 'error');
                }
            }
            $contain=array('Institute'=>array('fields'=>array('Institute.title')),'Payment','Emergency','CourseType','AccomodationType');
            $this->data=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id),'contain'=>$contain));
            $currency=$this->data['Student']['currency'];
            $this->set(compact('institute','courses','accomodation','currency'));
             $this->render('add');
        }
        
         /**
	  * Purpose: acceptance by site admin
	  * created on 24 November 2014
	  * created by:Abhishek Tripathi
	  **/
        public function accept($id=null){
            $this->loadModel('EmailTemplate');
            $this->loadModel('Student');
            $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
            if($student_info){
                $this->loadModel('Institute');
                $institute=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$student_info['Student']['institute_id']),'fields'=>array('Institute.title','Institute.enrollment')));
                $enrolment=  json_decode($institute['Institute']['enrollment'],true);
                $this->Student->id=$student_info['Student']['id'];
                $this->Student->saveField('response',1);
                $srch_array =$this->search_array($student_info);
				$email_values = $this->EmailTemplate->getvalues('acceptance_mail', $srch_array,$srch_array);
                               
				$to_emailid = $email_values['from_email'];
				$this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
				$this->Email->to = $student_info['Student']['email'];
				$this->Email->subject = str_replace('{{school_name}}',$institute['Institute']['title'],$email_values['subject']);
				$this->Email->sendAs = 'html';
				$this->Email->send($email_values['content']);
				$rss_arr = array('msg'=>'success','message'=>"Thank you! We'll get back to you shortly.");
                                
                                $this->set_reminder_mail($student_info,'student');
                                 $this->stop_reminder_mail($student_info);
                                 
                                 
                            //school approval email
                            $email_values = $this->EmailTemplate->getvalues('School_approval_confirmed', $srch_array,$srch_array);
                            $to_emailid = $email_values['from_email'];
                            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
                            $this->Email->to = $enrolment['enr_email'];
                            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
                            $this->Email->sendAs = 'html';
                             if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    $this->Email->cc =array($email_values['cci']);                                }                                }                                }
                            $this->Email->send($email_values['content']);
                
                $this->Session->setFlash(__('Your Request is accepted sucessfully'));
               $this->redirect(array('controller'=>'Payment','action'=>'index'));
            }
            else{
                $this->Session->setFlash(__('Your Request token is wrong'));
                $this->redirect(array('controller'=>'Payment','action'=>'index'));
            }
       
        }
        
        /**
	  * Purpose: School rejectance  by site admin
	  * created on 24 November 2014
	  * created by:Abhishek Tripathi
	  **/
        public function reject($id=null){
            $this->loadModel('EmailTemplate');
            $this->loadModel('Student');
         
            
            $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
            
            if($student_info){
                $this->loadModel('Institute');
                $institute=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$student_info['Student']['institute_id']),'fields'=>array('Institute.title','Institute.enrollment')));
                $enrolment=  json_decode($institute['Institute']['enrollment'],true);
                $this->Student->id=$student_info['Student']['id'];
                $this->Student->saveField('response',2);
                $this->cancel_payment($student_info['Student']['id']);
                $srch_array =$this->search_array($student_info);
               
				$email_values = $this->EmailTemplate->getvalues('rejection_mail', $srch_array,$srch_array);
                               
				$to_emailid = $email_values['from_email'];
				$this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
				$this->Email->to = $student_info['Student']['email'];
				$this->Email->subject = str_replace('{{school_name}}',$institute['Institute']['title'],$email_values['subject']);
				$this->Email->sendAs = 'html';
                                                             if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    $this->Email->cc =array($email_values['cci']);                                }                                }                                }

				$this->Email->send($email_values['content']);
				$rss_arr = array('msg'=>'success','message'=>"Thank you! We'll get back to you shortly.");
                                 $this->stop_reminder_mail($student_info);
                                 
                                 $this->stop_reminder_mail($student_info);
            
            
                            //school approval reject email
                            $email_values = $this->EmailTemplate->getvalues('School_approval_rejected', $srch_array,$srch_array);
                            $to_emailid = $email_values['from_email'];
                            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
                            $this->Email->to = $enrolment['enr_email'];
                            $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
                            $this->Email->sendAs = 'html';
                            
                             if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    $this->Email->cc =array($email_values['cci']);                                }                                }                                }
                            $this->Email->send($email_values['content']);
                 $this->Session->setFlash(__('Canceled successfully'));
                  $this->redirect(array('controller'=>'Payment','action'=>'index'));
            }
            else{
                $this->Session->setFlash(__('Your Request token is wrong'));
                $this->redirect(array('controller'=>'Payment','action'=>'index'));
            }
          
        }
        
        
        public function export($id=null){
            
            $this->loadModel('Student');
            $this->loadModel('Institute');
            
            $student=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
            
            $payment_type=  Configure::read('PAYMENT_TYPE');
            $response=  Configure::read('RESPONSE');
            $level=  Configure::read('new_level');
            $options=array('Yes', 'No', 'No preference');
           
            
                 $key_booking=array('School name','Payment type','Status','Pictures','Gender','First name','Last Name','Email','Date of birth','Nationality','Phone','Address','Postcode','City','Country'
                ,'Passport or ID number','ID','Booking date','Did you already attend a course at this school in the same city?','Language level?','Starting date','Duration','Transfer','Comments'
               );
               
              $value_booking=array(
                 (!empty($student['Institute']['title'])?$student['Institute']['title']:''),
                 (!empty($student['Payment']['type'])?$payment_type[$student['Payment']['type']]:''),
                 $response[$student['Student']['response']], 
                 (!empty($student['Student']['image'])?$student['Student']['image']:''), 
                  (!empty($student['Student']['gender'])?$student['Student']['gender']:''),
                 (!empty($student['Student']['first_name'])?$student['Student']['first_name']:''),
                 (!empty($student['Student']['last_name'])?$student['Student']['last_name']:''),
                 (!empty($student['Student']['email'])?$student['Student']['email']:''),
                 (!empty($student['Student']['dob'])?$student['Student']['dob']:''), 
                 (!empty($student['Student']['nationality'])?$student['Student']['nationality']:''), 
                 (!empty($student['Student']['telephone'])?$student['Student']['telephone']:''), 
                 (!empty($student['Student']['address'])?$student['Student']['address']:''),
                 (!empty($student['Student']['postcode'])?$student['Student']['postcode']:''),  
                 (!empty($student['Student']['city'])?$student['Student']['city']:''),  
                 (!empty($student['Student']['country'])?$student['Student']['country']:''),  
                
                 (!empty($student['Student']['id_number'])?$student['Student']['id_number']:''),  
                 (!empty($student['Payment']['id'])?$student['Payment']['id']:''),  
                 (!empty($student['Student']['created'])?$student['Student']['created']:''),
                 (!empty($student['Student']['previously_attended'])?$student['Student']['previously_attended']:''),
                 ($student['Student']['language_level']!=-1?$level[$student['Student']['language_level']]:"I'dont know"), 
                 (!empty($student['Student']['start_date'])?$student['Student']['start_date']:''), 
                 (!empty($student['Student']['no_of_week'])?$student['Student']['no_of_week']:''),
                 (!empty($student['Student']['transfer'])?$student['Student']['transfer']:''), 
                 (!empty($student['Student']['comment'])?$student['Student']['comment']:''),  
              ) ;
              
            $value_total_price=array();
            $ket_total_price=array();
              if(!empty($student['CourseType']['title'])){
                        array_push($ket_total_price,'Courses'); 
                        $value_total_price[]=$student['CourseType']['title'];
              }
             
             if(!empty($student['Student']['discount'])){
                 $discount=  json_decode($student['Student']['discount'],true);
             }
            
             if(!empty($student['Student']['reg_fee']) && $student['Student']['reg_fee']!=0){
                        array_push($ket_total_price,'Registration fee');
                        $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',$student['Student']['reg_fee']),2);
                    }
                foreach($discount as $dis){
                  if($dis['class']=='course_reg_discount'){
                        array_push($ket_total_price,$dis['key']);
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2);
                    }
                }
            
                    if(!empty($student['Student']['week_price']) && $student['Student']['week_price']!=0){
                        array_push($ket_total_price,'Courses price');
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',$student['Student']['week_price']),2);                        
                    }
              
                   foreach($discount as $dis){  
                    if($dis['class']=='course_commision_discount'){
                         array_push($ket_total_price,$dis['key']);
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                    }
               }
                 foreach($discount as $dis){  
                    if($dis['class']=='course_discount_plan1'){
                         array_push($ket_total_price,$dis['key']);
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                    }
               }
               foreach($discount as $dis){  
                    if($dis['class']=='course_discount_plan13'){
                         array_push($ket_total_price,$dis['key']);
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                    }
               }
               
                   foreach($discount as $dis){  
                    if($dis['class']=='course_discount_plan2'){
                         array_push($ket_total_price,$dis['key']);
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                    }
               }
               if(!empty($student['Student']['extra_fee'])){
                 $extra_fee=  json_decode($student['Student']['extra_fee'],true);
                 foreach($extra_fee as $fee){
                         array_push($ket_total_price,$fee['key']);
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($fee['price'])),2); 
                         
                 }
             }
             
             
               
                if(!empty($student['AccomodationType']['title'])){
                    array_push($ket_total_price,'Accommodation');
                     $value_total_price[]=$student['AccomodationType']['title'];
         
                   
                     if(!empty($student['Student']['accom_reg_price']) && $student['Student']['accom_reg_price']!=0){
                        array_push($ket_total_price,'Registration fee');
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',$student['Student']['accom_reg_price']),2); 
                    }
                foreach($discount as $dis){
                     if($dis['class']=='accommodation_reg_discount'){
                         array_push($ket_total_price,$dis['key']);
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                         
                    }
                         }    
                    if(!empty($student['Student']['accom_price']) && $student['Student']['accom_price']!=0){
                        array_push($ket_total_price,'Accommodation');
                          $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',$student['Student']['accom_price']),2);
                    }
                         foreach($discount as $dis){
                    if($dis['class']=='accommodation_discount'){
                         array_push($ket_total_price,$dis['key']);
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($dis['value'])),2); 
                    }
                 }
                }
                
               if(!empty($student['Student']['final_price']) && $student['Student']['final_price']!=0){
                   array_push($ket_total_price,'TOTAL');
                         $value_total_price[]=BASE_CURRENCY.number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',$student['Student']['final_price']),2);
               }
               if(!empty($student['Student']['deposit_eur']) && $student['Student']['deposit_eur']!=0){
                   array_push($ket_total_price,'DEPOSIT DUE NOW');
                         $value_total_price[]=BASE_CURRENCY.$student['Student']['deposit_eur'];
               }
             
             $ket_emergency=array('Name','Email','Phone','Address','Postcode','City','Country');
             $value_emergence=array($student['Emergency']['name'],$student['Emergency']['email'],$student['Student']['telephone'],$student['Emergency']['address'],$student['Emergency']['city'],$student['Emergency']['country']);
             $ket_preference=array('Smoker','Children','Pets','Special Diets','Comments');
             $value_preference=array(
                 (!empty($student['Student']['smoker'])?$options[$student['Student']['smoker']]:''),
                 (!empty($student['Student']['childrens'])?$options[$student['Student']['childrens']]:''),
                 (!empty($student['Student']['pets'])?$options[$student['Student']['pets']]:''),
                 (!empty($student['Student']['special_diets'])?$options[$student['Student']['special_diets']]:''),
                 (!empty($student['Student']['comments'])?$options[$student['Student']['comments']]:''),);
             
             
             $all_key=(array_merge($key_booking,$ket_total_price,$ket_emergency,$ket_preference));
             $all_value=array_merge($value_booking,$value_total_price,$value_emergence,$value_preference);
            $this->set(compact('school','all_key','all_value'));
        }
        
        
        //payment cancelation function
        public function cancel_payment($id=null){
         
           
            $payment=$this->Payment->find('first',array('conditions'=>array('Payment.student_id'=>$id)));
            if($payment) {
            switch($payment['Payment']['type']){
                case 1:
                    $data=  json_decode($payment['Payment']['all_detail'],true);
                
                    $param=array();
                    $param['shopId']='27019106';
                    $param['transmissionDate']=date('d-m-Y h:i:s',strtotime($data['vads_trans_date']));
                    $param['transactionId']=$data['vads_trans_id'];
                    $param['sequenceNb']='1';
                    $param['ctxMode']='TEST';
                    $param['comment']='Test webservice';
                     
                    App::import('Vendor', 'payment_ws/classes/wsToolV3');
                    $WS= new WS_API();
                    $WS->key='4441581736755411'; 
                    $response=$WS->cancel($param); 
                    $control_sign=array();
                    return true;
                    
                    //$control_sign=$WS->getResponse('cancel',$response);
                    break;
                case 2:
                    App::uses('Paypal', 'Paypal.Lib');
                    $paypal_config = array(
                        'sandboxMode' => PAYPAL_sandbox,
                        'nvpUsername' => PAYPAL_nvpUsername,
                        'nvpPassword' => PAYPAL_nvpPassword,
                        'nvpSignature' => PAYPAL_nvpSignature,
                    );
                    $this->Paypal = new Paypal($paypal_config);
                    $data=  json_decode($payment['Payment']['all_detail'],true);
                   
                    $refund = array(
                                'transactionId' => $data['PAYMENTINFO_0_TRANSACTIONID'], 	// Original PayPal Transcation ID
                                'type' => 'Full', 			// Full, Partial, ExternalDispute, Other
                                'amount' => $data['PAYMENTINFO_0_AMT'], 						// Amount to refund, only required if Refund Type is Partial
                                'note' => 'Refund because we are nice',	// Optional note to customer
                                 'reference' => 'abc123', 				// Optional internal reference
                                'currency' => 'EUR'  					// Defaults to GBP if not provided
                        );
                    
                    $this->Paypal->refundTransaction($refund);
                    break;
                case 3:
                    break;
                    
                    
            
            }
            }
            
            return true;
            
        }
   //payment creation function
        public function create(){
            $this->loadModel('Institute');
            $institute=$this->Institute->get_school_list_lang();
            if($this->request->is('post')){
                
                $this->redirect(array('controller'=>'Students','action'=>'register',$this->request->data['Institute']['id'],'plugin' => false,'admin' => false,));
                
            }
            $view_title = 'Choose School';
            $this->set(compact('institute','view_title'));
        }
        
        
           /**
     * Purpose: this function is upload user image
     * created on 21 july 2014
     * created by:Abhishek Tripathi
     * */
    public function upload() {
        
        if (isset($this->params->form['image_input'])) {
            $one = $this->params->form['image_input'];
            $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
            $path = 'files' . DS . 'payment' . DS;

            $thumbnails = Thumbnail::payment_image();
            $params = array('size' => REVIEW_MAX_IMAGE_SIZE);
            $image_new_name = date('ydmhis');
            $this->Uploader->upload($one, $path . DS, $thumbnails, $image_new_name, $params);
            $response['image_name'] = $name;
            $response['path'] = FULL_BASE_URL . $this->webroot . 'files/payment/PAY-' . $name;
            echo json_encode($response);
            exit;
        }
    }

    //cancled payment
    public function cancle_request($id=null){
        $this->loadModel('Student');
        $this->loadModel('EmailTemplate');
        $student_info=$this->Student->find('first',array('conditions'=>array('Student.id'=>$id)));
         if($student_info){
             $this->Student->id=$student_info['Student']['id'];
             $this->Student->saveField('response',0);
             $this->cancel_payment($student_info['Student']['id']);
             $this->loadModel('Institute');
                $institute=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$student_info['Student']['institute_id']),'fields'=>array('Institute.title','Institute.enrollment')));
                $enrolment=json_decode($institute['Institute']['enrollment'],true);
                $srch_array =$this->search_array($student_info);
				$email_values = $this->EmailTemplate->getvalues('cancelation_mail', $srch_array,$srch_array);
                                $to_emailid = $email_values['from_email'];
				$this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
				$this->Email->to = $student_info['Student']['email'];
				$this->Email->subject = str_replace('{{school_name}}',$institute['Institute']['title'],$email_values['subject']);
				$this->Email->sendAs = 'html';
				$this->Email->send($email_values['content']);
                                
                //mail to school
                                $srch_array =$this->search_array($student_info);
				$email_values = $this->EmailTemplate->getvalues('cancelation_mail_school', $srch_array,$srch_array);
                                $to_emailid = $email_values['from_email'];
				$this->Email->from = $email_values['from_email'].' <'.$email_values['from_email'].'>';
				$this->Email->to = $enrolment['enr_email'];
				$this->Email->subject = str_replace('{{school_name}}',$institute['Institute']['title'],$email_values['subject']);
				$this->Email->sendAs = 'html';
				$this->Email->send($email_values['content']);
                                
                                $this->stop_reminder_mail($student_info);
                                
				$rss_arr = array('msg'=>'success','message'=>"Thank you! We'll get back to you shortly.");
                $this->Session->setFlash(__('Canceled successfully'));
                   
                $this->redirect(array('controller' => 'Payment', 'action' => 'index'));
             
         }else{
                $this->Session->setFlash(__('Invalid student '), 'error');
                $this->redirect(array('controller' => 'Payment', 'action' => 'index'));
         }
    }
    
          
           //search array()==
    public function search_array($student_info,$token=null){
             $this->loadModel('Institute');
             $this->loadModel('Destination');
             
            $payment_type=  Configure::read('PAYMENT_TYPE');
            $response=  Configure::read('RESPONSE');
            $level=  Configure::read('new_level');
            $options=array('Yes', 'No', 'No preference');
            $accept_link = FULL_BASE_URL . $this->webroot . 'Students/accept/' . $token;
            $reject_link = FULL_BASE_URL . $this->webroot . 'Students/reject/' . $token;
            $PRIVIOUS=array('no'=>'No, I’ve never been to this school before.', 'yes'=>'Yes, I have already attended a course at this school.');
             $transfer=array('1'=>"No, I don't need transfer",'2'=>"Yes, I need transfer",'3'=>"I will decide later");
             
           $destination=$this->Destination->find('first',array('conditions'=>array('Destination.id'=>$student_info['Institute']['destination_id'])));  
             
            
            $this->loadModel('Currency');
            $currency=$this->Currency->find('first',array('conditions'=>array('Currency.currency_code'=>$student_info['Student']['currency'])));
            
            $currency_institute=$this->Currency->find('first',array('conditions'=>array('Currency.id'=>$student_info['Institute']['currency_id'])));
            
            $extra_fee_html='';
              $extra_fee_html_school='';
            if(!empty($student_info['Student']['extra_fee'])){
                $fees=  json_decode($student_info['Student']['extra_fee'],true);
               // debug($fees);exit;
                foreach($fees as $fee){
                    
                 $extra_fee_html.='<p>'.$fee["key"].': '.$currency["Currency"]["currrency_symbol"].number_format($fee["price"],2).'</p>';
                   
                }
            }
            if(!empty($student_info['Student']['extra_fee'])){
                $fees=  json_decode($student_info['Student']['extra_fee'],true);
               // debug($fees);exit;
                foreach($fees as $fee){
                    
                 $extra_fee_html_school.='<p>'.$fee["key"].': '.$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($fee["price"])),2).'</p>';
                   
                }
            }
            $course_reg_discount_key="";$course_reg_discount_value="";$course_dis_commision_key="";$course_dis_commision_dis_value="";
            $course_dis_key="";$course_dis_value="";$accomodatio_reg_discount_key='';$accomodatio_reg_discount_value='';$accommodation_dis_key='';$accommodation_dis_value='';
            $course_reg_discount_value_school_currency='';$course_dis_commision_dis_value_school_currency='';$course_dis_value_school_currency='';$accomodatio_reg_discount_value_school_currency='';
            $accommodation_dis_value_school_currency='';
            
            $discount_array=json_decode($student_info['Student']['discount'],true);
         
            foreach($discount_array as $discount){
                  if($discount['class']=='course_reg_discount'){
                      $course_reg_discount_key=$discount["key"];
                      $course_reg_discount_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_reg_discount_value=$discount["value"];
                      
                  }
                  if($discount['class']=='course_commision_discount'){
                       $course_dis_commision_key=$discount["key"];
                      $course_dis_commision_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_dis_commision_dis_value=$discount["value"];
                      
                  }
                   if($discount['class']=='course_discount_plan1'||$discount['class']=='course_discount_plan2'||$discount['class']=='course_discount_plan3'){
                       $course_dis_key=$discount["key"];
                      $course_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $course_dis_value=$discount["value"];
                      
                   }
                   if($discount['class']=='accommodation_reg_discount'){
                      $accomodatio_reg_discount_key=$discount["key"];
                      $accomodatio_reg_discount_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $accomodatio_reg_discount_value=$discount["value"];
                      }
                   if($discount['class']=='accommodation_discount')
                   {
                      $accommodation_dis_key=$discount["key"];
                      $accommodation_dis_value_school_currency=$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($discount["value"])),2);
                      $accommodation_dis_value=$discount["value"];
                   }
            }
           
          
            $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
            $enrolment = json_decode($institute['Institute']['enrollment'], true);
            $srch_array = array(
                    "{{school_name}}"=>$student_info['Institute']['title'],
                    "{{payment_type}}" => $payment_type[$student_info['Payment']['type']],
                    "{{payment_status}}" => $response[$student_info['Student']['response']],
                    "{{first_name}}" => $student_info['Student']['first_name'],
                    "{{last_name}}"=> $student_info['Student']['last_name'],
                    "{{gender}}" => $student_info['Student']['gender'],
                    "{{date_of_birth}}" => $student_info['Student']['dob'],
                    "{{nationality}}" => $student_info['Student']['nationality'],
                    "{{student_phone}}" => $student_info['Student']['telephone'],
                    "{{student_address}}" => $student_info['Student']['address'], 
                    "{{post_code}}" => $student_info['Student']['postcode'], 
                    "{{city}}" => $student_info['Student']['city'], 
                    "{{country}}" => $student_info['Student']['country'],
                    "{{pasport_id}}" => $student_info['Student']['id_number'],
                    "{{payment_id}}" => $student_info['Payment']['id'], 
                    "{{booking_date}}" => date("j F Y", strtotime($student_info['Student']['created'])), 
                    "{{starting_date}}" => date("j F Y", strtotime($student_info['Student']['start_date'])), 
                    "{{duration}}" => $student_info['Student']['no_of_weeks'],  
                    "{{transfer}}" => $transfer[$student_info['Student']['transfer']], 
                    "{{comment}}" => $student_info['Student']['comment'],  
                    "{{course}}" => $student_info['CourseType']['title'], 
                    "{{course_registration_fee}}" =>$currency["Currency"]["currrency_symbol"]. $student_info['Student']['reg_fee'], 
                    "{{course_price}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['week_price'],  
                    "{{accommodation}}" => $student_info['AccomodationType']['title'],
                    "{{accommodation_registration_fee}}" =>$currency["Currency"]["currrency_symbol"]. $student_info['Student']['accom_reg_price'], 
                    "{{accommodation_price}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['accom_price'], 
                    "{{total}}" => $currency["Currency"]["currrency_symbol"].$student_info['Student']['final_price'],  
                    "{{deposit_due_now}}" =>$currency["Currency"]["currrency_symbol"].$student_info['Student']['deposit_now'],
                    "{{emergency_name}}" => $student_info['Emergency']['name'], 
                    "{{emergency_email}}" => $student_info['Emergency']['email'], 
                    "{{emergency_phone}}" => $student_info['Emergency']['telephone'], 
                    "{{emergency_address}}" => $student_info['Emergency']['address'],
                    "{{emergency_post_code}}" => $student_info['Emergency']['postcode'],  
                    "{{emergency_city}}" => $student_info['Emergency']['city'], 
                    "{{emergency_country}}" => $student_info['Emergency']['country'], 
                    "{{school_logo}}" =>'<img src="'.FULL_BASE_URL.$this->webroot.'uploads/institute/'.$student_info['Institute']['id'].'/REV'.$student_info['Institute']['logo'].'">' ,
                    "{{accept_link}}" => $accept_link,
                    "{{reject_link}}" => $reject_link,
                    "{{booking_id}}"=>$student_info['Payment']['id'],
                    "{{terms_conditions}}"=>$student_info['Institute']['terms'],
                    "{{cancel_policiy}}"=>$student_info['Institute']['cancle_policiy'],
                    "{{extra_fee}}"=>$extra_fee_html,
                    "{{student_email}}"=>$student_info['Student']['email'],
                    "{{review_page_link}}"=>FULL_BASE_URL.$this->webroot.'Reviews/detail?institute='.$student_info['Institute']['slug'],
                    "{{school_email}}"=> $enrolment['enr_email'],
                    "{{language_level}}"=>($student_info['Student']['language_level']==-1?"I don't know":$level[$student_info['Student']['language_level']]),
                   
                    "{{thanks_page_comment}}"=>$student_info['Student']['comment_thank'],
                    "{{smoker}}"=>$options[$student_info['Student']['smoker']],
                    "{{children}}"=>$options[$student_info['Student']['childrens']],
                    "{{pets}}"=>$options[$student_info['Student']['pets']],
                    "{{special_diets}}"=>$options[$student_info['Student']['special_diets']],
                    "{{previously_attended}}"=>$PRIVIOUS[$student_info['Student']['previously_attended']],
                    "{{student_image}}"=>'<img src="'.$student_info['Student']['image'].'">',
                    "{{You didnt reply}}"=>"You didn't reply to this message...",
                    "{{course_reg_discount_key}}"=>$course_reg_discount_key,
                    "{{course_reg_discount_value}}"=>$course_reg_discount_value,
                    "{{course_dis_commision_key}}"=>$course_dis_commision_key,
                    "{{course_dis_commision_dis_value}}"=>$course_dis_commision_dis_value,
                    "{{course_dis_key}}"=>$course_dis_key,
                    "{{course_dis_value}}"=>$course_dis_value,
                    "{{accomodatio_reg_discount_key}}"=>$accomodatio_reg_discount_key,
                    "{{accomodatio_reg_discount_value}}"=>$accomodatio_reg_discount_value,
                    "{{accommodation_dis_key}}"=>$accommodation_dis_key,
                    "{{accommodation_dis_value}}"=>$accommodation_dis_value,
                
                    "{{course_reg_discount_value_school_currency}}"=>$course_reg_discount_value_school_currency,
                    "{{course_dis_commision_dis_value_school_currency}}"=>$course_dis_commision_dis_value_school_currency,
                    "{{course_dis_value_school_currency}}"=>$course_dis_value_school_currency,
                    "{{accomodatio_reg_discount_value_school_currency}}"=>$accomodatio_reg_discount_value_school_currency,
                    "{{accommodation_dis_value_school_currency}}"=>$accommodation_dis_value_school_currency,
                
                
                    "{{course_registration_fee_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['reg_fee'])),2), 
                    "{{course_price_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['week_price'])),2),
                    "{{accommodation_registration_fee_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['accom_reg_price'])),2),
                    "{{accommodation_price_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"].number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['accom_price'])),2),
                    "{{total_school_currency}}" => $currency_institute["Currency"]["currrency_symbol"]. number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['final_price'])),2),
                    "{{deposit_due_now_school_currency}}" =>$currency_institute["Currency"]["currrency_symbol"]. number_format($this->Institute->exchange_rate_convert($currency["Currency"]["currency_code"],$currency_institute['Currency']['currency_code'],$this->tofloat($student_info['Student']['deposit_now'])),2),
                    "{{deposit_due_now_eur}}" => BASE_CURRENCY_SYMBOL.$student_info['Student']['deposit_eur'],
                    "{{school_website}}"=>$student_info['Institute']['website'],
                    "{{school_contact}}"=>$enrolment['enr_contact_name'],
                    "{{school_phone}}"=>$enrolment['enr_phone_no'],
                  
                    "{{extra_fee_price_school_currency}}"=>$extra_fee_html_school,
                    "{{school_city}}"=>$destination['Destination']['name']
                  );
            
         return $srch_array;
    }
    
    
      /**
     * Purpose:admin can validate bank transfer
     * created on 2 january 2015
     * created by:Abhishek Tripathi
     * */
    public function validate_payemt($id=null){
                $this->loadModel('Student');
                $student_info=$this->Student->find('first',array('conditions'=>array('AND'=>array('Student.id'=>$id,'Student.response'=>4))));
                if($student_info){
                    $this->Student->id=$id;
                    $this->Student->saveField('paid_amount',$student_info['Student']['deposit_eur']);
                    $this->Student->saveField('response',5);
                    $token=  md5(date('ymdhis'));
                    $this->Student->saveField('token',$token);
                    $this->mail($id,$token);
                    $this->Session->setFlash(__('Payment validated successfully'), 'error');
                    $this->redirect(array('controller'=>'Payment','action'=>'index'));
                }
                else{
                    $this->Session->setFlash(__('Invalid request '), 'error');
                    $this->redirect(array('controller'=>'Payment','action'=>'index'));
                }
    }
        
    /**
     * Purpose: Approval mail to school and confirmation mail to student
     * created on 22 july 2014
     * created by:Abhishek Tripathi
     * */
    public function mail($student = null, $token = null) {
        
        $this->loadModel('Student');
        $this->loadModel('Institute');

        $student_info = $this->Student->find('first', array('conditions' => array('Student.id' => $student)));
        $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $student_info['Student']['institute_id']), 'fields' => array('Institute.title', 'Institute.enrollment')));
        $enrolment = json_decode($institute['Institute']['enrollment'], true);
        $this->loadModel('EmailTemplate');
        //------------mail to student-------------------------------------------------
        $srch_array = array("{{first_name}}" => $student_info['Student']['first_name'], "{{last_name}}" => $student_info['Student']['last_name'], "{{email}}" => $student_info['Student']['email'], "{{school_name}}" => $institute['Institute']['title']);
        $srch_array =$this->search_array($student_info,$token);
        $email_values = $this->EmailTemplate->getvalues('payment_confirmation', $srch_array,$srch_array);
        $to_emailid = $email_values['from_email'];
        $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
        $this->Email->to = $student_info['Student']['email'];
        $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
        $this->Email->sendAs = 'html';
         if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    $this->Email->cc =array($email_values['cci']);                                }                                }                                }
        $this->Email->send($email_values['content']);
        $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");

        //----------mail to school for approval----------------------------------------
        
        $srch_array =$this->search_array($student_info,$token);
        $email_values = $this->EmailTemplate->getvalues('School_approval', $srch_array,$srch_array);
        $to_emailid = $email_values['from_email'];
        $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
        $this->Email->to = $enrolment['enr_email'];
        $this->Email->subject = str_replace('{{school_name}}', $institute['Institute']['title'], $email_values['subject']);
        $this->Email->sendAs = 'html';
         if(!empty($email_values['cci'])){                                    if(!empty($email_values['cci'])){                                    $this->Email->cc =array($email_values['cci']);                                }                                }
        $this->Email->send($email_values['content']);
        $this->set_reminder_mail($student_info,'school');
        $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
        return true;
    }
    
   //-----------reminder mail set function ---------------------------

    public function set_reminder_mail($data=null,$to=null){
        if($to=='student'){
        $this->loadModel('AutoEmail');
        $today=date('d-m-Y');
        $mail_data=array('AutoEmail'=>array(
            'student_id'=>$data['Student']['id'],
            'institute_id'=>$data['Institute']['id'],
            'email_date'=>date('d-m-Y', strtotime('+1 day', strtotime($today))),
            'email_template'=>'review_mail_student',
            'status'=>1
         ));
        $this->AutoEmail->save($mail_data);
        }
        elseif($to=='school'){
             $this->loadModel('AutoEmail');
                $today=date('d-m-Y');
                $mail_data=array('AutoEmail'=>array(
                    'student_id'=>$data['Student']['id'],
                    'institute_id'=>$data['Institute']['id'],
                    'email_date'=>date('d-m-Y', strtotime('+3 day', strtotime($today))),
                    'email_template'=>'reminder_school',
                    'status'=>2
                 ));
                $this->AutoEmail->save($mail_data);
        }
        
        return true;
        
    }
                
    
    public function stop_reminder_mail($data=null){
       $this->loadModel('Student');
       $this->loadModel('AutoEmail');
       $mail=$this->AutoEmail->find('first',array('conditions'=>array('AND'=>array('AutoEmail.student_id'=>$data['Student']['id'],'AutoEmail.institute_id'=>$data['Student']['institute_id']))));
       $this->AutoEmail->id=$mail['AutoEmail']['id'];
       $this->AutoEmail->saveField('status','0');
       return true;
       }
       
    public function export_all_payment(){
       
        $this->loadModel('Student');
        $this->loadModel('Payment');
        $this->loadModel('Institute');
        $payment_type=  Configure::read('PAYMENT_TYPE');
            $response=  Configure::read('RESPONSE');
        
        $contain=array('Payment'=>array('fields'=>array('*')),
            'Institute'=>array(
            'fields'=>array('Institute.title','Institute.slug')
        ));
        $students=$this->Student->find('all',array('contain'=>$contain,'fields'=>array('first_name','last_name','city','start_date','no_of_weeks','deposit_eur','final_price','response','email','nationality','currency')));
        foreach($students as $student){
            if($student['Payment']['id']!=null){
            $payment_array[]=array(
                'id'=>$student['Payment']['id'],
                'booking_date'=>date('jS \of F Y',strtotime($student['Payment']['created'])),
                'student_name'=>$student['Student']['first_name'].' '.$student['Student']['first_name'],
                'school_name'=>$student['Institute']['title'],
                'city'=>$student['Student']['city'],
                'starting_date'=>date('jS \of F Y',strtotime($student['Student']['start_date'])),
                'duration'=>$student['Student']['no_of_weeks'],'week(s)',
                'deposit'=>$student['Student']['deposit_eur'].'€',
                'total'=>number_format($this->Institute->exchange_rate_convert($student['Student']['currency'],'EUR',Getfloat($student['Student']['final_price'])),2).'€',
                'payment'=>$payment_type[$student['Payment']['type']],
                'status'=>$response[$student['Student']['response']],
                'student_email'=>$student['Student']['email'],
                'nationality'=>$student['Student']['nationality']
            );
            }
        }
        
        
        $this->set('models',$payment_array);
        
     
            
    }   
    
    // get float value------
    
     public function tofloat($num) {
    $dotPos = strrpos($num, '.');
    $commaPos = strrpos($num, ',');
    $sep = (($dotPos > $commaPos) && $dotPos) ? $dotPos :
        ((($commaPos > $dotPos) && $commaPos) ? $commaPos : false);
  
    if (!$sep) {
        return floatval(preg_replace("/[^0-9]/", "", $num));
    }

    return floatval(
        preg_replace("/[^0-9]/", "", substr($num, 0, $sep)) . '.' .
        preg_replace("/[^0-9]/", "", substr($num, $sep+1, strlen($num)))
    );
}
    
}

?>
