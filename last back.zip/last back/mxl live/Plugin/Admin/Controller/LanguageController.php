<?php
/**
 * Name : Language Controller
 * Created : 3 Apr 2014
 * Purpose : To manage the languages.
 * Author : Ritish
 */ 
class LanguageController extends AdminAppController
{
	public $name = 'language';
	public $uses = array('Admin.Language');
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
		$this->Auth->allow('isexist');
	}
	
	/**
	 * Name : Index
	 * Purpose : For language listing
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function index($id=null)
	{
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->Language->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected languages deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Language.' . $field_name . ' Like' => $value . '%'));
			}
		}
		if($id)
		{
			$edit_lang = $this->Language->find('first', array('conditions' => array('Language.id' => $id), 'fields' => array('id','title')));
			$this->set('edit_lang',$edit_lang);
		}
		$this->paginate = array('order' => 'id desc','limit' => ADMIN_NUM_PER_PAGE);
		$languages = $this->paginate('Language', $conditions);	
		$this->set('languages',$languages);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new language
	 * Created : 3 Apr 2014
	 * Author : Ritish
	 */ 
	public function add()
	{
		if($this->request->is('post'))
		{
			$data = $this->data;
			if($this->Language->save($data))
				$this->Session->setFlash('Language saved successfully');
			else
				$this->Session->setFlash(__('The Language could not be saved. Please, try again.'));
			$this->redirect(array('action'=>'index'));
		}
	}


	
	/**
	 * Purpose: isexist function is call through ajax to check if the language is already exist or not.
	 * inputs: Language title in post
	 * outputs: if exists then return false else true
	 * Created: 3 Apr 2013
	 * Author: Ritish
	 */ 
	 function isexist()
	 {
		if($this->data['Language']['title'])
		{
			$lang_exist_cnt = $this->Language->find('count', array('conditions' => array('Language.title' => trim( $this->data['Language']['title'] ))));
			if($lang_exist_cnt > 0)
				die('false');	
		}
		die('true');
	 }
	 
	 	 /**
	  * Purpose: this function is upload banner image and flag image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload(){
	  	       if(isset($this->params->form['embassy_image'])){
	  	       	 $one= $this->params->form['embassy_image'];
	    	     $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'language' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				 $this->Resize = $this->Components->load('ImageResize');
				 $this->Resize->resize( $path.$name, '870', '320', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/language/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
			  
				
	  }
	  
	  public function edit($id=null){
	  	
	  	if($this->request->is('put'))
		{
			$data = $this->request->data;
			$this->Language->id=$id;
		    $this->Language->save($data);
			$this->Session->setFlash('Language updated successfully');
		}
	
			$this->data=$this->Language->find('first',array('conditions'=>array('Language.id'=>$id)));
		
		$this->render('add');
		
	  }
         
       
}
