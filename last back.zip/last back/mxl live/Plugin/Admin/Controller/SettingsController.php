<?php
/**
 * Name : Setting Controller
 * Created : 10 Nov 2013
 * Purpose : Default Setting controller
 * Author : Prakhar Johri
 */ 
class SettingsController extends AdminAppController
{
	public $name = 'Settings';
	public $uses = array('Settings');

	public $paginate = array ('limit' => 10);		
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
		$this->Auth->allow('register');
	}	
			
	/**
	* Purpose : basic site settings 
	* Inputs: id , data inpost
	* Output : data save message
	* Author: Prakhar Johri
	* Created On : 8 Nov 2013
	**/
	public function site_setting() 
	{				
		if ($this->request->is('post') || $this->request->is('put')) 
		{
			$data = $this->request->data;
			
			$value = json_encode($this->request->data);
			$data_arr['value'] = $value;
			$data_arr['id'] = $data['Settings']['id'];
			$data_arr['logo']=$data['Settings']['logo'];
			
			if ($this->Settings->save($data_arr)) 
			{
				$this->Session->setFlash(__('Settings page is saved'));
				$this->redirect(array('action' => 'site_setting'));
			} 
			else 
			{
				$this->Session->setFlash(__('Error saving page, please check again.'));
			}
		} 
		else 
		{
			$settings = $this->Settings->findByKey('site_setting');	
			$setting_data = json_decode($settings['Settings']['value'],true);
			
			$this->request->data = $setting_data;
		}
		$this->set('page', 'edit');
		$this->render('add');
	}
	
	  	 /**
	  * Purpose: this function is upload site logo image
	  * created on 25 august 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload_logo(){
	  	      //   debug($this->params);exit;
	  	       	 $one= $this->params->form['embassy_image'];
	    	     $name =date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'settings' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				 // $this->Resize = $this->Components->load('ImageResize');
				 //$this->Resize->resize( $path.$name, '46', '28', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/settings/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
}

?>
