<?php
/**
 * Name : Accreditation Controller
 * Created : 3 june 2014
 * Purpose : To manage the accreditations.
 * Author : Abhishek Tripathi
 */ 
class AccreditationsController extends AdminAppController
{
	public $name = 'accreditations';
	public $uses = array('Admin.Accreditation');
        public $components=array('Uploader');
		
	public function beforeFilter()
	{
		//Set auth model Admin
		 parent::beforeFilter();
		$this->Auth->authenticate = array(
			'Form' => array('userModel' => 'Admin')
		);
	}
	
	/**
	 * Name : Index
	 * Purpose : For Accreditation listing
	 * Created : 3 june 2014
	 * Author : Abhishek Tripathi
	 */ 
	public function index($id=null)
	{
		if(isset($this->request->data['option']) && !empty($this->request->data['option']))
		{
			switch($this->request->data['option'])
			{
				case "delete":
					$this->Accreditation->deleteAll(array('id' => $this->request->data['ids']));
					$this->Session->setFlash(__('Selected Accreditations deleted sucessfully'));
				break;
			}
		}
		$conditions = array();
		if( isset( $_GET['filter'] ) )
		{
			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$conditions = array_merge($conditions, array('Accreditation.' . $field_name . ' Like' => $value . '%'));
			}
		}
		if($id)
		{
			$edit_lang = $this->Accreditation->find('first', array('conditions' => array('Accreditation.id' => $id), 'fields' => array('id','title','icon')));
			$this->set('edit_lang',$edit_lang);
		}
		
		$this->paginate = array('order' => 'id desc','limit' => ADMIN_NUM_PER_PAGE);
		$Accreditations = $this->paginate('Accreditation', $conditions);
		$this->set('Accreditations',$Accreditations);
	}
	
	/**
	 * Name : Add
	 * Purpose : To add new Accreditation
	 * Created : 3 june 2014
	 * Author : Abhishek Tripathi
	 */ 
	public function add()
	{

		
		if($this->request->is('post'))
		{
			$data = $this->data;
			if($this->Accreditation->save($data))
			{
				$this->Session->setFlash('Accreditation saved successfully');
				$this->redirect(array('action'=>'index'));
			}
			else
			{
				$this->Session->setFlash(__('The Accreditation could not be saved. Please, try again.'));
			}
		}
	}
	
	/**
	 * Name : Edit
	 * Purpose : To edit the Accreditation
	 * Created : 3 june 2014
	 * Author : Abhishek Tripathi
	 */ 
	public function edit($id = null)
	{

		if($this->request->is('post'))
		{
			$this->add();
		}
		$edit_Accreditation = $this->Accreditation->find('first', array('conditions' => array('Accreditation.id' => $id)));
		$this->set('edit_Accreditation', $edit_Accreditation);
		$this->render('add');
	}
	
	   
   /**
    * Purpose:upload accreditation image 
    * created on :11 june 2014
    * Author:Abhishek Tripathi
    */
   public function upload_accreditation_image(){
       $this->layout = "ajax"; 
       $one= $this->params['form']['logo'];
         $name = date('ydmhis');
       $path='uploads'.DS.'accreditation'.DS;
       $thumbnails = Thumbnail::logo_image();
				$params = array('size' => REVIEW_MAX_IMAGE_SIZE);
				 
				$image_new_name = 'color_'.date('ydmhis');
				$this->Uploader->upload($one, $path.DS, $thumbnails, $image_new_name, $params);
				
                                $extention= pathinfo($one['name'], PATHINFO_EXTENSION);
				 switch(strtolower($extention)){
				 	case 'gif': $image=imagecreatefromgif($path.'REVcolor_'.$name.'.'.  strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 imagefilter($image,IMG_FILTER_GRAYSCALE);
								 imagegif($image,$path.'REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 break;
					case 'jpg': $image=imagecreatefromjpeg($path.'REVcolor_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 imagefilter($image,IMG_FILTER_GRAYSCALE);
								 imagejpeg($image,$path.'REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 break;
                                        case 'jpg': $image=imagecreatefromjpeg($path.'REVcolor_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 imagefilter($image,IMG_FILTER_GRAYSCALE);
								 imagejpeg($image,$path.'REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 break;                     
					case 'jpeg': $image=imagecreatefromjpeg($path.'REVcolor_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 imagefilter($image,IMG_FILTER_GRAYSCALE);
								 imagejpeg($image,$path.'REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 break;			 
					case 'png': $image=imagecreatefrompng($path.'REVcolor_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 imagefilter($image,IMG_FILTER_GRAYSCALE);
								 imagepng($image,$path.'REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION)));
								 break;			 			 
					
				 }
				
       
       
       $response['image_name']='REVgray_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION));
       $response['path']=$path.'REVcolor_'.$name.'.'.strtolower(pathinfo($one['name'], PATHINFO_EXTENSION));
       $this->set('response',$response);
       echo json_encode($response);
       exit;
    }
}
