<?php
/*
 * Name : Reviews
 * Created : 9 oct 2014
 * Purpose : Reviews controller
 * Author : Abhishek Tripathi
 */
class AskQuestionController extends AdminAppController {
	function beforeFilter()
	{
		parent::beforeFilter();
	}
		  
	public function index()
	{
           
		$this->layout='default';
		$cond_arr = array('AskQuestion.type'=>0);
		$this->AskQuestion->bindModel(array(
				'belongsTo' => array(
						'Institute' => array(
								'class' => 'Institute',
								'foreignKey' => 'institute_id',
								'fields'=>'title'
						)
				)
		));
		$this->loadModel('AskQuestion');
		if (isset($_GET['filter'])) 
		{
			$fields = array_filter($_GET['filter']);
			foreach ($fields as $field_name => $value) 
			{
				$cond_arr = array_merge($cond_arr, array('AskQuestion.' . $field_name . ' Like' => $value . '%'));
			}
		}
		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:500),
			'order' => array('AskQuestion.created' => 'DESC')
		);
             
		$result_arr = $this->paginate('AskQuestion');
		$view_title = 'Ask a question';
		$this->set(compact('result_arr','view_title'));
	}
	
	/**
	 * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
	 * Created on : 6 May 2014
	 * Author : Rupesh Sharma
	*/
	function manage_actions()
	{
		if(count($this->params['data']))
		{
			$message = '';

			$ids = $this->params['data']['list'];
			
			if(!empty($ids))
			{
				$task = $this->params['data']['task'];

				if($task == "delete")
				{
					$this->AskQuestion->deleteAll(array('AskQuestion.id' => $ids), true);
					$message = 'Deleted successfully.';
				}
				
				$this->Session->setFlash($message, 'flash_success');
			}

			$this->redirect($this->referer());
		}
		exit;
	}
        
        function view($id=null){
           
                $this->loadModel('Institute');
                 $institute=$this->Institute->get_school_list_lang();
		$this->layout='default';
		$cond_arr = array();
	
		
		$this->paginate = array(
			'conditions' => array('AskQuestion.id'=>$id),
                        
			'limit'=>1
		);
		$result_arr = $this->paginate('AskQuestion');
		
		$view_title = 'Detail';
		$this->set(compact('result_arr','view_title','institute'));
        }
        
        
        public function request_school()
	{
		$this->layout='default';
                $this->loadModel('Institute');
		$cond_arr = array('AskQuestion.type'=>1);
		$this->AskQuestion->bindModel(array(
				'belongsTo' => array(
						'Institute' => array(
								'class' => 'Institute',
								'foreignKey' => 'institute_id',
								'fields'=>'title'
						)
				)
		));
		$this->loadModel('AskQuestion');
		if (isset($_GET['filter'])) 
		{
			$fields = array_filter($_GET['filter']);
			foreach ($fields as $field_name => $value) 
			{
				$cond_arr = array_merge($cond_arr, array('AskQuestion.' . $field_name . ' Like' => $value . '%'));
			}
                       
		}
		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('AskQuestion.created' => 'DESC')
		);
                $institute_list=$this->Institute->find('list',array('fields'=>array('Institute.id','Institute.title')));
                natcasesort($institute_list);
		$result_arr = $this->paginate('AskQuestion');
		$view_title = 'Request to school';
		$this->set(compact('result_arr','view_title','institute_list'));
	}
}

?>
