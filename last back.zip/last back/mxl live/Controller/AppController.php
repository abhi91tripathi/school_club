<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

	var $components = array('Session','RequestHandler','Paginator','ImageResize','Cookie');
	var $helpers = array('Session','Html','Form','Paginator', 'Xicom');

	public function beforefilter(){
          
            
                 clearCache();
          	$this->loadModel('Setting');
                $this->loadModel('App');
		$settings = $this->Setting->find('first');
		//debug($settings);exit;
		$this->set('settings',$settings);
		$latest_school = $this->Cookie->read('institute_id');
                //$this->set('latest_school',$latest_school);
                
                if(!$this->Session->check('CURRENCY')){
           
                  $ip = $_SERVER['REMOTE_ADDR'];
                  $country = geoip_country_code3_by_name($ip);
                  $country=(!empty($country)?$country:'EUR');
                    
                   // debug($details);exit;  
                  $this->loadModel('Currency');
                  $currency=$this->Currency->find('first',array('conditions'=>array('Currency.iso_alpha2'=>$country),'fields'=>array('Currency.currrency_symbol','Currency.currency_code')));
                    if($currency){
                           $this->Session->write('CURRENCY',$currency['Currency']['currency_code']);
                            $this->Session->write('CURRENCY_SYMBOL',$currency['Currency']['currrency_symbol']);
                    }
                    else{
                       $this->Session->write('CURRENCY','EUR');
                          $this->Session->write('CURRENCY_SYMBOL','€'); 
                    }
                    
                    
                }
                $this->loadModel('Cms');
                $cms_pages=$this->Cms->find('list',array('conditions'=>array('Cms.footer-link'=>1),'fields'=>array('Cms.url_key','Cms.page_name')));
                $this->loadModel('DiscountContent');
                $discount_content=$this->DiscountContent->find('all');
                
                
                //-------------tootip-------------
                $this->loadModel('Tooltip');
                $tooltip=$this->Tooltip->find('all');
                
                //-------------Google Site Search-----------------------------------------
                $this->loadModel('SiteSearch');
                $site_search=$this->SiteSearch->find('all');
                $this->set(compact('latest_school','cms_pages','tooltip','discount_content','site_search'));

	}


	/**
	 * Purpose : delete file
	 * Input :	delete path
	 * Created on : 21 April 2014
	 * Author : Rupesh Sharma
	*/
	public function delete_file($del_path)
	{
		unlink($del_path);
	}


	/**
	 * Purpose : make dir
	 * Input :	die path
	 * Created on : 21 April 2014
	 * Author : Rupesh Sharma
	*/
	public function make_dir($dir_path)
	{
		mkdir($dir_path, 0777);
	}

		/*
	 * Name: uploadimage
	 * Purpose: TO upload the hompage block image via ajax
	 * Created: 2 apr 2014
	 * Author: Ritish
	 */
	function uploadimage()
	{
		$name = time() . '-' . $_FILES['image']['name'];
		$name = str_replace(' ','_',$name);
		$path = ROOT . $_GET['path'] . $name;
		list( $width, $height) = getimagesize($_FILES['image']['tmp_name']);
		if( move_uploaded_file( $_FILES['image']['tmp_name'], $path) )
		{
			//$this->ImageResize->resize($path, $_GET['width'], $_GET['height']);
			echo $name; exit;
		}
		else
		{
			die('upload_error');
		}
	}

	/*
	 * Name: unlink_old_image
	 * Purpose: To unlik the previous one after uploading the image
	 * Created: 2 apr 2014
	 * Author: Ritish
	 */
	function unlink_old_image($name = Null)
	{
		if($name)
		{
			$path = ROOT . $_GET['path'] . $name;
			unlink($path);
		}
		exit;
	}

	/*
	 * Name: get_lat_long
	 * Purpose: get lat,long from address
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_lat_long($location_url)
	{
		$curl = curl_init();
		curl_setopt_array($curl, array(
		    CURLOPT_RETURNTRANSFER => 1,
		    CURLOPT_URL => $location_url,
		    CURLOPT_USERAGENT => 'Codular Sample cURL Request'
		));
		$resp = curl_exec($curl);
		$res_array = json_decode($resp,true);
		curl_close($curl);
		if(isset($res_array['results']['0']['geometry']['location']['lat']) && isset($res_array['results']['0']['geometry']['location']['lng']))
		{
			$lat = $res_array['results']['0']['geometry']['location']['lat'];
            $lng = $res_array['results']['0']['geometry']['location']['lng'];
			$location = array($lat,$lng);
			return $location;
		}
		else
		{
			$location = array("15.493","73.818");
			return $location;
		}
	}


	/*
	 * Name: get_slug
	 * Purpose: get slug from name
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_slug($string)
	{
		$string = strtolower($string);
		$slug = str_replace(' ', '-', $string);
		$slug = preg_replace('#[^\w()/.%\-&]#','',$slug);
		return $slug;
	}

	/*
	 * Name: get_unique_slug
	 * Purpose: get unique slug if its already exists in table
	 * Created: 17 april 2014
	 * Author: Rupesh Sharma
	 */

	public function get_unique_slug($string)
	{
		$unique_slug = $string.'_'.mt_rand(1111,9999);
		return $unique_slug;
	}
        
        public function conversion($currency_code=null){
            if($currency_code!=null)
            {
                $this->Session->delete('Language');
                $this->Session->write('Language',$currency_code);
                
                
                echo 'success';
                exit;
            }
        }
}
