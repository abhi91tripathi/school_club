<?php

class ResultsController extends AppController {

    public $components = array('RequestHandler');

    function beforeFilter() {
        parent::beforeFilter();
        //$this->Auth->allow(array('index'));
    }

    public function language() {
        $this->layout = 'default';
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->loadModel('Destination');
        $this->loadModel('Language');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        $this->LoadModel('Accomodation');
        //
        if (!empty($this->request->data['promo'])) {
            $this->set('promo', 1);
        } else {
            $this->set('promo', 0);
        }
        $school_info = array();
        /* ----default content of page-------------------- */
        $main_title = 'Learn [language] abroad';
        $sub_title1 = '[language] language courses';
        $sub_title2 = 'Showing [number] [language] schools worldwide';
        $LAYOUT_META_TITLE = ' [language] courses abroad | Best price guarantee';
        $LAYOUT_META_DESCRIPTION = "Compare [language] schools worldwide, browse language courses reviews and book at the best price or we'll refund the difference to you.";
        $LAYOUT_META_KEYWORDS = '';
        $BNNER_alt = '[language] immersion';
        //explode url and find the lan=guage and set in a variable
        $url_data = explode('-', $this->params['language']);
        $language = ucwords($url_data[0]);
        $this->set('language_name', $language);
        //-------------------country set------------------
        $country_name = '';
        $country_id = '';
        $this->set('country_id', $country_id);
        //------------week parameter-----------------------
        if (isset($this->params->query['week'])) {
            $weeks = $this->params->query['week'];
            $this->set('week', $weeks);
        } else {
            $weeks = '';
            $this->set('week', $weeks);
        }
        //------------------destination-------------------
        $destination_id = '';
        $this->set('destination_id', $destination_id);
        //--------------------------Language id----------------------
        $language_info = $this->Language->find('first', array('conditions' => array('Language.title' => $language)));
        if ($language != 'Language') {
            if (!$language_info) {
                throw new InternalErrorException('Something went worng');
            }
        }
        if ($language_info) {
            $language_id = $language_info['Language']['id'];
        } else {
            $main_title = ' Learn a language abroad';
            $sub_title1 = 'English, Spanish, French courses, and many other languages';
            $sub_title2 = 'Showing [number] language schools worldwide';
            $LAYOUT_META_TITLE = 'Language courses abroad | Best price guarantee';
            $LAYOUT_META_DESCRIPTION = "Compare language schools worldwide, browse language courses reviews and book at the best price or we'll refund the difference to you.";
            $language_id = '';
        }
        $this->set('language_id', $language_id);
        //----------------------------Destination----------------------------------

        if (!empty($language_info['Language']['main_title'])) {
            $main_title = $language_info['Language']['main_title'];
        }
        if (!empty($language_info['Language']['sub_title1'])) {
            $sub_title1 = $language_info['Language']['sub_title1'];
        }
        if (!empty($language_info['Language']['sub_title2'])) {
            $sub_title2 = $language_info['Language']['sub_title2'];
        }
        if (!empty($language_info['Language']['meta_tags'])) {
            $LAYOUT_META_TITLE = $language_info['Language']['meta_tags'];
        }
        if (!empty($language_info['Language']['meta_description'])) {
            $LAYOUT_META_DESCRIPTION = $language_info['Language']['meta_description'];
        }
        $school_list = $this->Institute->get_school_list_lang($language_id);
        natcasesort($school_list);
        $this->set('school_list', $school_list);
        $country_name = '';
        $search = array('[language]', '[number]');
        $replace_from = array($language, count($school_info));
        $destination['Destination']['main_title'] = str_replace($search, $replace_from, $main_title);
        $destination['Destination']['sub_title1'] = str_replace($search, $replace_from, $sub_title1);
        $destination['Destination']['sub_title2'] = str_replace($search, $replace_from, $sub_title2);
        $LAYOUT_META_TITLE = str_replace($search, $replace_from, $LAYOUT_META_TITLE);
        $LAYOUT_META_DESCRIPTION = str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION);
        if (empty($language_id)) {
            $this->loadModel('HomepageBanner');
            $home_block = $this->HomepageBanner->find('first');
            $destination['Destination']['image'] = "/admin/img/homepage_block_images/" . $home_block['HomepageBanner']['image'];
            $destination['Destination']['text_bottom'] = '';
        } else {
            $destination['Destination']['image'] = "/files/language/" . $language_info['Language']['image'];
            $destination['Destination']['text_bottom'] = $language_info['Language']['text_bottom'];
        }
        $destination['Destination']['alt'] = str_replace($search, $replace_from, $BNNER_alt);
        $this->set('destination_info', $destination);
        $this->Institute->recursive = 1;

        //$school_info=$this->CoursePrice->get_search($language_id,$destination_id,$weeks);

        if (isset($school_info)) {
            $this->set('schools', $school_info);
        }

        /* -----------set meta---------------------------- */
        $this->set('city_name', '');
        $this->set('country_name', $country_name);
        $this->set('language', $language);
        $this->set('destination', $this->Country->get_country());
        $this->set(compact('LAYOUT_META_TITLE', 'LAYOUT_META_DESCRIPTION'));
        $ARR_LANGUAGES1 = array(
            'language' => 'Any Language',
            'English' => 'English',
            'Spanish' => 'Spanish',
            'French' => 'French',
            'Italian' => 'Italian',
            'German' => 'German',
            '----------------------------------'
        );
        $lanuage_ids = $this->Institute->find('list', array('conditions' => array('Institute.published' => 'Yes'), 'fields' => array('Institute.language_id')));
        $ARR_LANGUAGES2 = $this->Language->find('list', array('conditions' => array('id' => $lanuage_ids), 'fields' => array('title', 'title')));
        $language_list = array_merge($ARR_LANGUAGES1, $ARR_LANGUAGES2);
        $this->set('language_list', $language_list);
        $school = array();
        foreach ($school_list as $key => $school_id) {
            $school[] = $key;
        }
        $contain3 = array(
            'CourseType' => array(
                'fields' => array('course_id')
            ),
            'AccomodationType' => array(
                'fields' => array('accomodation_id')
            ),
            'Currency' => array(
                'fields' => array('currency_code')
            )
        );
        $school_info = $this->Institute->find('all', array('conditions' => array('Institute.id' => $school), 'contain' => $contain3, 'fields' => array('accreditation', 'min_price', 'max_price', 'language_course_type')));
        $accredation_list = $this->accredation_list($school_info);
        $course_list = $this->course_list($school_info);
        $accomodation_list = $this->accomoadtion_list($school_info);
        $price_range = $this->price_range($school_info);
        $og_image = FULL_BASE_URL . $this->webroot . $destination['Destination']['image'];
        $this->set('og_image', $og_image);
        $this->set('price_range', $price_range);
        $this->set('courses_type', $course_list);
        $this->set('accreditation_list', $accredation_list);
        $this->set('accomodation_type', $accomodation_list);
        $this->set('weeks', Configure::read('ARR_WEEKS'));
        $this->autoRender = false;
        $this->render('search');
    }

    public function country() {
        //debug($this->params);exit;
        $this->layout = 'default';
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->loadModel('Destination');
        $this->loadModel('Language');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        $this->LoadModel('Accomodation');

        /* ----default content of page-------------------- */
        $main_title = 'Learn [language] in [country]';
        $sub_title1 = ' [language] language courses in [country]';
        $sub_title2 = 'Showing [number] [language] schools in [country]';
        $LAYOUT_META_TITLE = '[language] courses in [country] | Best price guarantee';
        $LAYOUT_META_DESCRIPTION = " Compare [language] schools in [country], browse language courses reviews and book at the best price or we'll refund the difference to you";
        $LAYOUT_META_KEYWORDS = '';
        $BNNER_alt = '[language] immersion  [country]';
        $school_info = array();
        //explode url and find the lan=guage and set in a variable
        $url_data = explode('-in-', $this->params['language']);
        $language = ucwords($url_data[0]);
        $this->set('language_name', $language);
        //-------------------country set------------------
        $country_name = $url_data[1];
        //------------week parameter-----------------------
        if (isset($this->params->query['week'])) {
            $weeks = $this->params->query['week'];
            $this->set('week', $weeks);
        } else {
            $weeks = '';
            $this->set('week', $weeks);
        }
        //------------------destination-------------------
        $destination_id = '';
        $this->set('destination_id', $destination_id);
        //--------------------------Page content get----------------------

        $country_info = $this->Country->find('first', array('conditions' => array('Country.slug' => $url_data[1])));
        if (!$country_info) {
            throw new InternalErrorException('Something went worng');
        }
        $country_id = $country_info['Country']['id'];
        $this->set('country_id', $country_id);
        //---------------------------------language id set-----------------------------------------------------
        $language_info = $this->Language->find('first', array('conditions' => array('Language.title' => $url_data[0])));
        if ($language_info) {
            $language_id = $language_info['Language']['id'];
        } else {
            $language_id = '';
        }
        $this->set('language_id', $language_id);
        //----------------------------Destination----------------------------------
        if (!empty($country_info['Country']['main_title'])) {
            $main_title = $country_info['Country']['main_title'];
        }
        if (!empty($country_info['Country']['sub_title1'])) {
            $sub_title1 = $country_info['Country']['sub_title1'];
        }
        if (!empty($country_info['Country']['sub_title2'])) {
            $sub_title2 = $country_info['Country']['sub_title2'];
        }
        if (!empty($country_info['Country']['meta_tags'])) {
            $LAYOUT_META_TITLE = $country_info['Country']['meta_tags'];
        }
        if (!empty($country_info['Country']['meta_description'])) {
            $LAYOUT_META_DESCRIPTION = $country_info['Country']['meta_description'];
        }

        $school_list = $this->Institute->get_school_list_lang($language_id, $country_id);
        natcasesort($school_list);
        $this->set('school_list', $school_list);
        $country_name = $country_info['Country']['name'];
        $search = array('[language]', '[number]', '[country]');
        $replace_from = array($language, count($school_info), $country_name);
        $destination['Destination']['main_title'] = str_replace($search, $replace_from, $main_title);
        $destination['Destination']['sub_title1'] = str_replace($search, $replace_from, $sub_title1);
        $destination['Destination']['sub_title2'] = str_replace($search, $replace_from, $sub_title2);
        $LAYOUT_META_TITLE = str_replace($search, $replace_from, $LAYOUT_META_TITLE);
        $LAYOUT_META_DESCRIPTION = str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION);
        $destination['Destination']['image'] = "/files/country_banner/" . $country_info['Country']['banner_image'];
        $destination['Destination']['flag_image'] = "/files/country_flag/" . $country_info['Country']['flag_image'];
        $destination['Destination']['text_bottom'] = $country_info['Country']['text_bottom'];
        $destination['Destination']['alt'] = str_replace($search, $replace_from, $BNNER_alt);
        $this->set('destination_info', $destination);
        $this->Institute->recursive = 1;
        /* set parameters */
        $this->set('city_name', '');
        $this->set('country_slug', $country_info['Country']['slug']);
        $this->set('country_name', $country_name);
        $this->set('language', $language);
        $this->set('destination', $this->Country->get_country());
        $ARR_LANGUAGES1 = array(
            'language' => 'Language',
            'English' => 'English',
            'Spanish' => 'Spanish',
            'French' => 'French',
            'Italian' => 'Italian',
            'German' => 'German',
            '----------------------------------'
        );
        $lanuage_ids = $this->Institute->find('list', array('conditions' => array('Institute.published' => 'Yes'), 'fields' => array('Institute.language_id')));
        $ARR_LANGUAGES2 = $this->Language->find('list', array('conditions' => array('id' => $lanuage_ids), 'fields' => array('title', 'title')));
        $language_list = array_merge($ARR_LANGUAGES1, $ARR_LANGUAGES2);
        $this->set('language_list', $language_list);
        foreach ($school_list as $key => $school_id) {
            $school[] = $key;
        }
        $contain3 = array(
            'CourseType' => array(
                'fields' => array('course_id')
            ),
            'AccomodationType' => array(
                'fields' => array('accomodation_id')
            )
        );
        //$school_info = $this->Institute->find('all', array('conditions' => array('Institute.id' => $school), 'contain' => $contain3, 'fields' => array('accreditation')));
        $school_info = $this->Institute->find('all', array('conditions' => array('Institute.id' => $school), 'contain' => $contain3, 'fields' => array('accreditation', 'min_price', 'max_price', 'language_course_type')));
        $accredation_list = $this->accredation_list($school_info);
        $this->set('accreditation_list', $accredation_list);
        $accomodation_list = $this->accomoadtion_list($school_info);
        $this->set('accomodation_type', $accomodation_list);
        $price_range = $this->price_range($school_info);
        $this->set('price_range', $price_range);
        $course_list = $this->course_list($school_info);
        $this->set('courses_type', $course_list);

        $og_image = FULL_BASE_URL . $this->webroot . $destination['Destination']['image'];

        $this->set(compact('LAYOUT_META_TITLE', 'LAYOUT_META_DESCRIPTION', 'og_image'));

        $this->set('promo', 0);
        $this->set('weeks', Configure::read('ARR_WEEKS'));
        $this->autoRender = false;
        $this->render('search');
    }

    public function city() {
        //debug($this->params);exit;
        $this->layout = 'default';
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->loadModel('Destination');
        $this->loadModel('Language');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        $this->LoadModel('Accomodation');
        /* ----default content of page-------------------- */
        $main_title = 'Learn [language] in [city]';
        $sub_title1 = '[language] language courses in [city]';
        $sub_title2 = 'Showing [number] [language] school(s) in [city]';

        $LAYOUT_META_TITLE = '[language] courses in [city] | Best price guarantee';
        $LAYOUT_META_DESCRIPTION = " Compare [language] schools in [city], browse language courses reviews and book at the best price or we'll refund the difference to you.";
        $LAYOUT_META_KEYWORDS = '';
        $BNNER_alt = '[language] immersion [city] [country]';
        $school_info = array();
        //explode url and find the lan=guage and set in a variable
        $url_data = explode('-in-', $this->params['language']);

        $language = ucwords($url_data[0]);
        $this->set('language_name', $language);
        //-------------------country set------------------
        $country_name = ucwords($url_data[1]);


        //------------week parameter-----------------------
        if (isset($this->params->query['week'])) {
            $weeks = $this->params->query['week'];
            $this->set('week', $weeks);
        } else {
            $weeks = '';
            $this->set('week', $weeks);
        }
        //------------------destination-------------------
        $sub_url_data = explode('-', $url_data[1]);
        $desitnation_info = $this->Destination->find('first', array('conditions' => array('Destination.slug' => ($sub_url_data[0]))));
        if (!$desitnation_info) {
            throw new InternalErrorException('Something went worng');
        }

        $destination_id = $desitnation_info['Destination']['id'];
        $this->set('destination_id', $destination_id);


        //--------------------------Page content get----------------------
        $country_info = $this->Country->find('first', array('conditions' => array('Country.slug' => ucwords($sub_url_data[1])), 'fields' => array('id', 'name', 'flag_image', 'slug')));
        $country_id = $country_info['Country']['id'];
        $this->set('country_id', $country_id);


        //---------------------------------language id set-----------------------------------------------------
        $language_info = $this->Language->find('first', array('conditions' => array('Language.title' => $url_data[0])));
        if ($language_info) {
            $language_id = $language_info['Language']['id'];
        } else {
            $language_id = '';
        }
        $this->set('language_id', $language_id);
        //----------------------------Destination----------------------------------
        if (!empty($desitnation_info['Destination']['main_title'])) {
            $main_title = $desitnation_info['Destination']['main_title'];
        }
        if (!empty($desitnation_info['Destination']['sub_title1'])) {
            $sub_title1 = $desitnation_info['Destination']['sub_title1'];
        }
        if (!empty($desitnation_info['Destination']['sub_title2'])) {
            $sub_title2 = $desitnation_info['Destination']['sub_title2'];
        }
        if (!empty($desitnation_info['Destination']['meta_tags'])) {
            $LAYOUT_META_TITLE = $desitnation_info['Destination']['meta_tags'];
        }
        if (!empty($desitnation_info['Destination']['meta_description'])) {
            $LAYOUT_META_DESCRIPTION = $desitnation_info['Destination']['meta_description'];
        }

        $school_list = $this->Institute->get_school_list_lang($language_id, $country_id, $destination_id);
        natcasesort($school_list);
        $this->set('school_list', $school_list);
        $country_name = $country_info['Country']['name'];
        $search = array('[language]', '[number]', '[country]', '[city]');
        $replace_from = array($language, count($school_info), $country_name, $desitnation_info['Destination']['name']);
        $destination['Destination']['main_title'] = str_replace($search, $replace_from, $main_title);
        $destination['Destination']['sub_title1'] = str_replace($search, $replace_from, $sub_title1);
        $destination['Destination']['sub_title2'] = str_replace($search, $replace_from, $sub_title2);
        $LAYOUT_META_TITLE = str_replace($search, $replace_from, $LAYOUT_META_TITLE);
        $LAYOUT_META_DESCRIPTION = str_replace($search, $replace_from, $LAYOUT_META_DESCRIPTION);

        $destination['Destination']['image'] = "/files/destination/" . $desitnation_info['Destination']['image'];
        $destination['Destination']['flag_image'] = "/files/country_flag/" . $country_info['Country']['flag_image'];
        $destination['Destination']['text_bottom'] = $desitnation_info['Destination']['text_bottom'];
        $destination['Destination']['alt'] = str_replace($search, $replace_from, $BNNER_alt);
        $this->set('destination_info', $destination);


        $this->Institute->recursive = 1;

        /* set parameters */
        $this->set('city_name', $desitnation_info['Destination']['name']);
        $this->set('country_name', $country_name);
        $this->set('country_slug', $country_info['Country']['slug']);
        $this->set('language', $language);
        $this->set('destination', $this->Country->get_country());
        $ARR_LANGUAGES1 = array(
            'language' => 'Language',
            'English' => 'English',
            'Spanish' => 'Spanish',
            'French' => 'French',
            'Italian' => 'Italian',
            'German' => 'German',
            '----------------------------------'
        );
        $lanuage_ids = $this->Institute->find('list', array('conditions' => array('Institute.published' => 'Yes'), 'fields' => array('Institute.language_id')));
        $ARR_LANGUAGES2 = $this->Language->find('list', array('conditions' => array('id' => $lanuage_ids), 'fields' => array('title', 'title')));
        $language_list = array_merge($ARR_LANGUAGES1, $ARR_LANGUAGES2);
        $this->set('language_list', $language_list);
        foreach ($school_list as $key => $school_id) {
            $school[] = $key;
        }
        $contain3 = array(
            'CourseType' => array(
                'fields' => array('course_id')
            ),
            'AccomodationType' => array(
                'fields' => array('accomodation_id')
            )
        );
        //$school_info = $this->Institute->find('all', array('conditions' => array('Institute.id' => $school), 'contain' => $contain3, 'fields' => array('accreditation')));
        $school_info = $this->Institute->find('all', array('conditions' => array('Institute.id' => $school), 'contain' => $contain3, 'fields' => array('accreditation', 'min_price', 'max_price', 'language_course_type')));
        $accredation_list = $this->accredation_list($school_info);
        $this->set('accreditation_list', $accredation_list);
        $course_list = $this->course_list($school_info);
        $accomodation_list = $this->accomoadtion_list($school_info);
        $this->set('accomodation_type', $accomodation_list);
        $this->set('courses_type', $course_list);
        $price_range = $this->price_range($school_info);
        $og_image = FULL_BASE_URL . $this->webroot . $destination['Destination']['image'];
        $this->set('price_range', $price_range);
        $this->set('weeks', Configure::read('ARR_WEEKS'));
        $this->set(compact('LAYOUT_META_TITLE', 'LAYOUT_META_DESCRIPTION', '$og_image'));
        $this->set('promo', 0);

        $this->autoRender = false;
        $this->render('search');
    }

    /**
     * Purpose:To get information  from ajax of schools on search
     * created on:24 june 2014
     * @param:language id,destination id and weeks
     * @Author: Abhishek TRipathi 
     */
    public function get_search_result() {
        $this->layout = "ajax";
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->loadModel('CourseType');
        $this->loadModel('Language');
        $language = $this->request->data['language'];
        $weeks = $this->request->data['weeks'];
        $country_id = $this->request->data['country_id'];
        $destination_id = $this->request->data['destination_id'];
        $language_id = $this->Language->find('first', array('conditions' => array('Language.title' => $language), 'fields' => array('id')));
        if ($language_id) {
            $language_id = $language_id['Language']['id'];
        }
        //$schools=$this->Institute->get_search($language_id,$destination_id,$weeks);
        $option = array();
        $school_info = array();
        if (!empty($this->request->data['promo']) && $this->request->data['promo'] == 1) {
            $option['Institute.discount_available'] = array('value' => $this->request->data['promo'], 'condition' => 'equal');
        }
        $school_info = $this->CoursePrice->get_search($language_id, $country_id, $destination_id, $weeks, $option);
        // $school_info['count']=count($school_info);
        if (isset($school_info)) {
            $this->set('schools', $school_info);
        }
        $response['list'] = $school_info;
        $response['count'] = count($school_info);
        $this->set('response', $response);
        $this->autoRender = false;
        $this->render('ajax');
    }

    /**
     * Purpose:Its for school preview
     * created on:19 sep 14
     * @param:institute id
     * @Author: Abhishek TRipathi 
     */
    public function school_info($id = null) {

        $this->loadModel('Institute');

        $info = $this->Institute->get_info_id($id);
        $accredation_image = $this->get_accredation_images($info['Institute']['accreditation']);
        if (!empty($info['Institute']['min_price'])) {

            $min_price = $info['Institute']['min_price'];
        } else {
            $min_price = 'NA';
        }

        $wdget = '';
        $wdget.='
                       <div class="head">';
        if ($info["Institute"]["listing_type"] != 2) {
            $wdget.='<div class="price-range">
										From
										<span> ' . $this->Session->read('CURRENCY_SYMBOL') . $min_price . '</span>
										Per Week
									</div>';
        }

        $wdget.='                	<h3>' . $info["Institute"]["title"] . '</h3>
                           		<div class="location">
										 <img src="' . SITE_URL . '/files/country_flag/' . $info["Country"]["flag_image"] . '" width="50px;">
									 <span>' . $info["Destination"]["name"] . '</span>
									</div>
								</div>	
									<div class="images-sec">
										
										<div class="imgs">';
        foreach ($info['InstituteGallery'] as $image) {
            $wdget.='<img src="' . DISPLAY_INSTITUE_DIR . $info["Institute"]["id"] . '/gallery/' . $image["img"] . '">';
        }
        $wdget.='</div>
											<div class="text">
												
												' . $asd = substr($info["Institute"]["about_embassy"], 0, 500) . '
												<a class="see-all-link" href="' . SITE_URL . $info["Institute"]["slug"] . '">More details</a>';
        if ($info["Institute"]["listing_type"] != 2) {
            $wdget.='<div class="btn-row">';
            $wdget.="<a class='want-qutoe' href='" . SITE_URL . $info['Institute']['slug'] . "#online_quote_sec'>I Want a Quote</a>";
            $wdget.="<a class='ready-book sky-blue' href='" . SITE_URL . "Students/register/" . $info['Institute']['id'] . "'>I'm Ready to book</a>
													<p>Best price guarantee or we’ll refund you the difference</p>
												</div>";
        }
        else{
            $wdget.='	<br><br><br>	';
        }
        $wdget.='		</div>
											
							</div>';

        echo json_encode($wdget);
        exit;
    }

    /**
     * Purpose:get country list for select bar
     * created on:19 sep 14
     * @Author: Abhishek Tripathi 
     */
    public function get_country_list($name = null) {
        $this->loadModel('Language');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        configure::write('debug', 2);
        $this->loadModel('Country');
        $language_name = $name;

        if ($language_name == 'language') {

            $countries_list = $this->Institute->get_country_id();
            $destination_list = $this->Institute->get_destination_id();
            $html = '<option   data-foo="0" value=""> Please choose any language</option>';
        } else {
            $language_id = $this->Language->get_language_id($language_name);
            $countries_list = $this->Institute->get_country_id($language_id);
            $destination_list = $this->Institute->get_destination_id($language_id);
            $html = '<option   data-foo="0" value="">'.__("Any Destination").'</option>';
            if (count($countries_list)) {

                $destination_list = $this->Country->get_country($countries_list, $destination_list);

                foreach ($destination_list as $value) {
                    $html.='<option data-foo="' . $value['Country']['flag_image'] . '" class="country-name-opt" label="' . strtolower($value['Country']['name']) . '" value="' . strtolower($value['Country']['slug']) . '"><b><img src="' . SITE_URL . '/files/country_flag/' . $value['Country']['flag_image'] . '" width="20px">' . $value['Country']['name'] . '</b>';
                    foreach ($value['Destination'] as $destination) {
                        $html.='<option data-foo="0" value="' . strtolower($destination['slug']) . '-' . strtolower($value['Country']['slug']) . '">&nbsp;&nbsp;&nbsp;' . $destination['name'] . '</option>';
                    }
                    $html.='</option>';
                }
            }
        }
        echo $html;
        exit;
    }

    /**
     * Purpose:get filter data
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function get_filter_data() {
        if ($this->request->is('post')) {
            $this->loadModel('CoursePrice');
            $this->loadModel('Institute');
            $language_id = $this->request->data['language_id'];
            $country_id = $this->request->data['country_id'];
            $destination_id = $this->request->data['destination_id'];

            $weeks = $this->request->data['week'];
            $option = array();
            $course=array();
            $order = '';
            if (!empty($this->request->data['school_name'])) {
                $option['Institute.id'] = array('value' => $this->request->data['school_name'], 'condition' => 'equal');
            }
            if (!empty($this->request->data['course_id'])) {
                $course['CourseType.course_id'] = array('value' => $this->request->data['course_id'], 'condition' => 'equal');
            }
            if (!empty($this->request->data['accomodation_id'])) {
                $option['AccomodationType.accomodation_id'] = array('value' => $this->request->data['accomodation_id'], 'condition' => 'equal');
            }
            if (!empty($this->request->data['max_student'])) {
                $option['CourseType.class_size'] = array('value' => $this->request->data['max_student'], 'condition' => 'greater');
            }
            if (!empty($this->request->data['sort_by'])) {
                $order = $this->request->data['sort_by'];
            }
            if (!empty($this->request->data['date'])) {
                $option['CourseType.course_starting_date'] = array('value' => 2, 'condition' => 'equal');
            }
            if (!empty($this->request->data['min_price'])) {
                $this->request->data['min_price'] = round($this->Institute->exchange_rate_convert($this->Session->read('CURRENCY'), 'EUR', $this->request->data['min_price']));
                $option['Institute.min_price'] = array('value' => $this->request->data['min_price'], 'condition' => 'lessequal');
            }
            if (!empty($this->request->data['max_price'])) {
                $this->request->data['max_price'] = round($this->Institute->exchange_rate_convert($this->Session->read('CURRENCY'), 'EUR', $this->request->data['max_price']));
                $option['Institute.max_price'] = array('value' => $this->request->data['max_price'], 'condition' => 'greaterequal');
            }
            if (!empty($this->request->data['promo']) && $this->request->data['promo']!=0) {
                $option['Institute.discount_available'] = array('value' => $this->request->data['promo'], 'condition' => 'equal');
            }
            if (!empty($this->request->data['review'])) {
                $option['Institute.rating_user'] = array('value' => $this->request->data['review'], 'condition' => 'lessequal');
            }
            
            if (!empty($this->request->data['sub_course'])) {
                $course['Institute.sub_course'] = array('value' => $this->request->data['sub_course'], 'condition' => 'equal');
            }
            $school_info = array();
            $school_info = $this->CoursePrice->get_search($language_id, $country_id, $destination_id, $weeks, $option, $order,$course);
            // $school_info['count']=count($school_info);
            if (isset($school_info)) {
                $this->set('schools', $school_info);
            }

            if (!empty($this->request->data['accredation'])) {
                $filter['list'] = $school_info;
                $filter['accredation'] = $this->request->data['accredation'];

                $school_info = $this->accerdation_filter($filter);
            }
            if (!empty($this->request->data['sub_course'])) {
                $filter['list'] = $school_info;
                $filter['sub_course'] = $this->request->data['sub_course'];

                $school_info = $this->subcourse_filter($filter);
            }
            if (!empty($this->request->data['accomodation_id'])) {
                $filter['list'] = $school_info;
                $filter['accommodation'] = $this->request->data['accomodation_id'];

                $school_info = $this->accomodation_filter($filter);
            }
            $response['list'] = $school_info;
            $response['count'] = count($school_info);
            $this->set('response', $response);
            $this->autoRender = false;
            $this->render('ajax');
        }
    }

    /**
     * Purpose:accredation filter
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function accerdation_filter($filter) {
        $list = array();

        if (!empty($filter['accredation'])) {
            $accredation = $filter['accredation'];
            foreach ($filter['list'] as $data) {

                $acc = json_decode($data['accreditation']);
                if (!empty($acc)) {
                    foreach ($accredation as $accre) {
                        if (in_array($accre, $acc)) {
                            $list[] = $data;
                            break;
                        }
                    }
                }
            }
        } else {
            
        }
        $response = $list;
        return $response;
    }
    
    
    
    

    /**
     * Purpose:accredation list
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function accredation_list($school_info) {
        //debug($school_info);exit;
        $array1 = array();
        $array2 = array();
        $output = array();
        $list = array();
        foreach ($school_info as $school) {
            $array2 = json_decode($school['Institute']['accreditation'], true);

            if (!empty($array2)) {

                $output = array_merge($array1, $array2);
                $array1 = $output;
            }
        }
        $accreditation_ids = array_unique($output);
        $this->loadModel('Accreditation');
        $list = $this->Accreditation->find('list', array('conditions' => array('Accreditation.id' => $accreditation_ids), 'fields' => array('id', 'title')));
        //debug($list);exit;
        natcasesort($list);
        return $list;
    }

    /**
     * Purpose:course type list
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function course_list($school_info) {

        $course_list = array();
        $list = array();
        $subcatecory_list = array();
        foreach ($school_info as $school) {
            if (!empty($school['Institute']['language_course_type'])) {
                $list = json_decode($school['Institute']['language_course_type'], true);
                if (!empty($list)) {

                    $subcatecory_list = array_merge($list, $subcatecory_list);
                }
            }
            foreach ($school['CourseType'] as $course) {

                $list_course[] = $course['course_id'];
            }
        }
        $this->loadModel('Course');
        $this->Course->bindModel(array(
            'hasMany' => array(
                'CourseSubcategory' => array(
                    'className' => 'CourseSubcategory',
                    'foreignKey' => 'course_id',
                    'conditions' => array(
                        'CourseSubcategory.id' => array_unique($subcatecory_list)
                    )
                )
            )
        ));
        $contain = array('CourseSubcategory');
        if(empty($subcatecory_list)){
            $course_list = $this->Course->find('all', array('conditions' => array('Course.id' => array_unique($list_course))));
        }else{
            $course_list = $this->Course->find('all', array('conditions' => array('Course.id' => array_unique($list_course)), 'contain' => $contain));
        }
        

        return $course_list;
    }

    /**
     * Purpose:accomodation type list
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function accomoadtion_list($school_info) {

        $accomodation_list = array();
        $list = array();
        foreach ($school_info as $school) {
            foreach ($school['AccomodationType'] as $accomodation) {

                $list[] = $accomodation['accomodation_id'];
            }
        }
        $this->loadModel('Accomodation');
        $accomodation_list = $this->Accomodation->find('list', array('conditions' => array('Accomodation.id' => array_unique($list))));
        return $accomodation_list;
    }

    /**
     * Purpose:accomodation type list
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function price_range($school_info) {

        $list = array();
        $this->loadModel('Institute');
        // debug($school_info);exit;
        $list_max = array(0);
        ;

        foreach ($school_info as $school) {
            foreach ($school as $price) {
                //debug($price);exit;
                if ((!empty($price['min_price'])) && (!empty($price['max_price']))) {
                    $list_min[] = $price['min_price'];
                    $list_max[] = $price['max_price'];
                }
            }
        }

        if (empty($list_min)) {
            $list_min = array(0);
        }

        $list = array('min_price' => round($this->Institute->exchange_rate_convert('EUR', $this->Session->read('CURRENCY'), min($list_min))), 'max_price' => round($this->Institute->exchange_rate_convert('EUR', $this->Session->read('CURRENCY'), max($list_max))));
        return $list;
    }

    public function get_accredation_images($accredation) {
        $this->loadModel('Accreditation');
        $list = $this->Accreditation->find('list', array('fields' => array('id', 'image_name')));
        $count = 0;
        $html = '';
        $acc = json_decode($accredation, true);
        // debug($list);exit;
        if (!empty($acc)) {
            foreach ($acc as $value) {

                if (!empty($list[$value])) {
                    $count++;
                    $html.="<div class='cimg'><img src='" . SITE_URL . "uploads/accreditation/" . $list[$value] . "'></div>";
                }
                if ($count >= 3)
                    break;
            }
        }
        return $html;
    }

    /**
     * Purpose:accomodation type list
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function test() {
        $nae = 'college of international education -cie-oxford';
        $ad = array('--', ',', '.', '(', ')');
        $nae = preg_replace('/\s\s+/', '-', $nae);
        $name = strtolower(str_replace($ad, '-', $nae));
        $name = strtolower(str_replace($ad, '-', $name));
        debug(($nae));
        exit;
    }

    public function view_pdf($id = null) {
        configure::write('debug', 0);
        $this->loadModel('CourseType');
        $this->loadModel('Institute');
        $this->loadModel('Country');
        $this->loadModel('Destination');
        $this->loadModel('CoursePrice');
        $this->loadModel('Course');
        $this->CourseType->recursive = -1;
        $course = $this->CourseType->find('first', array('conditions' => array('CourseType.id' => $id)));
        // debug($course);
        $this->Institute->recursive = -1;
        $institute = $this->Institute->find('first', array('conditions' => array('Institute.id' => $course['CourseType']['institute_id']), 'fields' => array('id', 'title', 'logo', 'country_id', 'destination_id', 'slug')));
        $this->Country->recursive = -1;
        $country = $this->Country->find('first', array('conditions' => array('Country.id' => $institute['Institute']['country_id']), 'fields' => array('id', 'name')));
        $this->Destination->recursive = -1;
        $destination = $this->Destination->find('first', array('conditions' => array('Destination.id' => $institute['Institute']['destination_id']), 'fields' => array('id', 'name')));
        $this->CoursePrice->recursive = -1;
        $course_price = $this->CoursePrice->find('all', array('conditions' => array('AND' => array('CoursePrice.course_types_id' => $course['CourseType']['id'], 'CoursePrice.year' => date('Y')))));
        $this->Course->recursive = -1;
        $course_cat = $this->Course->find('first', array('conditions' => array('Course.id' => $course['CourseType']['course_id']), 'fields' => array('id', 'title')));
        if (!empty($course['CourseType']['course_available'])) {
            if ($course['CourseType']['course_available'] == 1) {
                $course['CourseType']['course_available'] = 'All Year';
            } else {
                $data = json_decode($course['CourseType']['course_available_data'], true);
                $course['CourseType']['course_available'] = "From " . $data['from'] . ' to ' . $data['to'];
            }
        }

        if (!empty($course['CourseType']['course_starting_date'])) {
            if ($course['CourseType']['course_starting_date'] == 4) {
                $course['CourseType']['course_starting_date'] = $course['CourseType']['startting_date_data'];
            } else {
                $data = Configure::read('STARTING_DATE');
                $key = $course['CourseType']['course_starting_date'];
                $key--;
                $course['CourseType']['course_starting_date'] = $data[$key];
            }
        }
        if (!empty($course['CourseType']['course_starting_beginer_date'])) {
            if ($course['CourseType']['course_starting_beginer_date'] == 4) {
                $course['CourseType']['course_starting_beginer_date'] = $course['CourseType']['beginner_date_data'];
            } else {
                $data2 = Configure::read('STARTING_DATE');
                $key = $course['CourseType']['course_starting_beginer_date'];
                $key--;

                $course['CourseType']['course_starting_beginer_date'] = $data2[$key];
            }
        }
        if (!empty($course['CourseType']['lesson_schedule'])) {
            ($schedule_data = json_decode($course['CourseType']['lesson_schedule'], true));
            ($lesson_schedule_dat = json_decode($course['CourseType']['lesson_schedule_data'], true));
            $schedule = '';
            if (in_array(1, $schedule_data)) {
                $schedule.='At Morning from:- ' . $lesson_schedule_dat['morning_time']['from'] . ' to ' . $lesson_schedule_dat['morning_time']['from'] . '<br/>';
            }
            if (in_array(1, $schedule_data)) {
                $schedule.='At Afternoon:- from ' . $lesson_schedule_dat['afternoon_time']['from'] . ' to ' . $lesson_schedule_dat['afternoon_time']['from'] . '<br/>';
            }
            if (in_array(1, $schedule_data)) {
                $schedule.='other: ' . $lesson_schedule_dat['other'];
            }
            $course['CourseType']['lesson_schedule'] = $schedule;
        }
        if (isset($course['CourseType']['level_required'])) {
            $level = Configure::read('level');
            //debug($level);exit;
            $key = $course['CourseType']['level_required'];
            $course['CourseType']['level_required'] = $level[$key];
        }
        if (isset($course['CourseType']['get_certificate'])) {
            ($course['CourseType']['get_certificate'] == 1 ? $course['CourseType']['get_certificate'] = 'Yes' : $course['CourseType']['get_certificate'] = 'No');
        }
        if (!empty($course['CourseType']['image'])) {
            $course['CourseType']['image'] = ROOT . '/app/webroot/files/course_image/' . $course['CourseType']['image'];
        } else {
            $course['CourseType']['image'] = ROOT . '/app/webroot/images/gallary.jpg';
        }
        if (!empty($institute['Institute']['logo'])) {
            $institute['Institute']['logo'] = ROOT . '/app/webroot/uploads/institute/' . $institute['Institute']['id'] . '/' . $institute['Institute']['logo'];
        } else {
            $institute['Institute']['logo'] = ROOT . '/app/webroot/images/no-image.jpg';
        }
        // debug($course_price);exit; 
        $currency = '&euro;';
        $this->set(compact('course', 'institute', 'country', 'destination', 'course_price', 'course_cat', 'currency'));

        $this->layout = '/pdf/default';
        $this->render();
    }

    public function post() {
        if ($this->request->is('post')) {
            debug($this->request->data);
            exit;
        }
    }
    
    
     /**
     * Purpose:subcourse filter
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function subcourse_filter($filter) {
        $list = array();
      
        if (!empty($filter['sub_course'])) {
            $subcourse = $filter['sub_course'];
          
            foreach($filter['list'] as $data){
                 
                     $sub=  json_decode($data['language_course_type']);
                      //debug($sub);
                if(!empty($sub)){
                    
               
                   
                    if(in_array($subcourse,$sub)){
                        $list[]=$data;
                    }
                }
            }
            
        } else {
            
        }

        $response = $list;
        return $response;
    }
   
    
    
     /**
     * Purpose:accommdation filter
     * created on:22 sept 14
     * @Author: Abhishek Tripathi 
     */
    public function accomodation_filter($filter) {
        $list = array();
      
        if (!empty($filter['accommodation'])) {
            $accommodation = $filter['accommodation'];
         
            foreach($filter['list'] as $data){
                 if($data['listing_type']==2){
                     $accomo=  json_decode($data['accommodation_type'],true);
                         if(!empty($accomo) && in_array($accommodation, $accomo)){
                             $list[]=$data;
                         }
                 }
                 else{
                     $list[]=$data;
                 }
            }
            
        } else {
            
        }

        $response = $list;
        return $response;
    }

}
