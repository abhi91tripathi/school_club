<?php

/**
 * Project: Img180.com
 * Author : Nitin
 * Creation Date : 28th Nov
 * Description : File Contains Controller Class for Cms Controller
 * 
 * Modified By: Nitin
 */
class CmsController extends AppController
{

	var $name = 'Cms';
	var $uses = array('Cms');

	function beforeFilter()
	{
		parent::beforeFilter();
	}

	/**
	 * Purpose : TO SHOW CMS PAGES IF THEY EXIST IN THE DATABASE ELSE TO SHOW THEIR VIEW
	 * Created on : 1-Oct-2013
	 * Author : Nitin
	 */
	function index($page_name)
	{
		//$this->layout = 'fancybox';
		$result_arr = $this->Cms->find('first', array('conditions' => array('Cms.url_key' => $page_name)));
		if (!empty($result_arr['Cms']))
		{
			$row = $result_arr['Cms'];
			
			$this->set('LAYOUT_META_TITLE', $row['meta_title']);
			$this->set('LAYOUT_META_KEYWORDS', $row['meta_keywords']);
			$this->set('LAYOUT_META_DESCRIPTION', $row['meta_description']);
			$this->set('row', $row);
			$this->render('index');
		}
		else
		{
			$this->render($page_name);
		}
	}

	/**
	 * Purpose : TO SHOW MESSAGES
	 * Created on : 1-Oct-2013
	 * Author : Nitin
	 */
	function show_msg()
	{
		$title = $this->Session->read('errthk_heading');
		$message = $this->Session->read('errthk_message');
		
		if(!$message)
		{
			$this->redirect('/');
		}
		
		$this->Session->delete('errthk_heading');
		$this->Session->delete('errthk_message');
		
		
		$this->set('title', $title);
		$this->set('message', $message);
	}

}
