<?php

/**
 * Project : Controller to save form submitted by schools
 * Author : Rupesh Sharma
 * Creation Date : 10 may 2014
 * Description : saving data from schools
 */
App::uses('Language', 'Admin.Model');
class SchoolsController extends AppController {

    var $uses = array(
        'Institute', 'CourseType', 'Destination', 'Country',
        'Language', 'Facility', 'InstituteFacility', 'Exam',
        'InstituteExam', 'Destination', 'Course','AccomodationType','InstituteExtraFee');
    
   

    function beforeFilter() {
        parent::beforeFilter();
        $this->layout = 'schoolform';
    }

    /**
     * Purpose : TO LIST THE AD
     * Created on : 14 April 2014
     * Author : Rupesh Sharma
     */
    function index() {

        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
    }

    /**
     * Purpose : save school info
     * Created on : 21 April 2014
     * Author : Rupesh Sharma
     */
    public function school_info() {
        if (!empty($this->data)) {

            $data_arr = $this->data;

            //to create temporary folder for institute
            if ($this->Session->check('temp_upload_folder')) {
                $temp_upload_folder = $this->Session->read('temp_upload_folder');
            } else {
                $temp_upload_folder = time();
                $this->Session->write('temp_upload_folder', $temp_upload_folder);
            }
            $dir_path = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
            if (!file_exists($dir_path)) {
                $this->make_dir($dir_path);
                $this->make_dir($dir_path . '/gallery');
            }

            $destination = $this->Destination->find("first", array("conditions" => array("Destination.id" => $data_arr["Institute"]["destination_id"]), "fields" => array("name")));
            $country = $this->Country->find("first", array("conditions" => array("Country.id" => $data_arr["Institute"]["country_id"]), "fields" => array("name")));
            //get lat,long from address
            if (!empty($country) && !empty($destination)) {
                $location_url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . $data_arr['Institute']['title'] . ',' . $destination['Destination']['name'] . ',' . $data_arr['Institute']['pin'] . ',' . $data_arr['Institute']['city'] . ',' . $country['Country']['name'] . '&sensor=true';
                $location_url = str_replace(' ', '_', $location_url);
                $lat_lng = $this->get_lat_long($location_url);
                $data_arr['Institute']['lat'] = $lat_lng[0];
                $data_arr['Institute']['long'] = $lat_lng[1];
            }
            //get slug from name
            $slug = $this->get_slug($data_arr['Institute']['title']);
            $conditions = array("Institute.slug" => $slug);
            $count = $this->Institute->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['Institute']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['Institute']['slug'] = $slug;
            }

            //convert student profile data into json

            $student_profile = array(
                'Students_Enrolled_Last_Year' => $data_arr['Institute']['Students_Enrolled_Last_Year'],
                'Average_Number_Students_During_Year' => $data_arr['Institute']['Average_Number_Students_During_Year'],
                'Average_Number_Students_During_High_Season' => $data_arr['Institute']['Average_Number_Students_During_High_Season'],
                'Minimum_Student_Age' => $data_arr['Institute']['Minimum_Student_Age'],
                'less_then_twenty' => $data_arr['Institute']['less_then_twenty'],
                'twenty_twentyfour' => $data_arr['Institute']['twenty_twentyfour'],
                'twentyfive_twentynine' => $data_arr['Institute']['twentyfive_twentynine'],
                'thirty_thirtyfour' => $data_arr['Institute']['thirty_thirtyfour'],
                'thirtyfive_thirtynine' => $data_arr['Institute']['thirtyfive_thirtynine'],
                'fourty_fourtyfour' => $data_arr['Institute']['fourty_fourtyfour'],
                'fourtyfive_fourtynine' => $data_arr['Institute']['fourtyfive_fourtynine'],
                'fifty_fiftyfour' => $data_arr['Institute']['fifty_fiftyfour'],
                'fiftyfive_fiftynine' => $data_arr['Institute']['fiftyfive_fiftynine'],
                'less_then_sixty' => $data_arr['Institute']['less_then_sixty'],
                'Middle_East_Africa' => $data_arr['Institute']['Middle_East_Africa'],
                'Central_South_America' => $data_arr['Institute']['Central_South_America'],
                'Asia_Far_East' => $data_arr['Institute']['Asia_Far_East'],
                'Central_Eastern_Europe' => $data_arr['Institute']['Central_Eastern_Europe'],
                'Western_Europe' => $data_arr['Institute']['Western_Europe']
            );
            $data_arr['Institute']['student_profile'] = json_encode($student_profile);

            //UPLOADING main image
            if (!empty($_FILES['logo']['name'])) {
                $data_arr['Institute']['logo'] = $this->upload_image('logo');
            }
            if (!empty($_FILES['main_img']['name'])) {
                $data_arr['Institute']['main_img'] = $this->upload_image('main_img');
            }
            if (!empty($_FILES['brand_image']['name'])) {
                $data_arr['Institute']['brand_image'] = $this->upload_image('brand_image');
            }
            if (!empty($_FILES['location_image']['name'])) {
                $data_arr['Institute']['location_image'] = $this->upload_image('location_image');
            }
            if (!empty($_FILES['embassy_image']['name'])) {
                $data_arr['Institute']['embassy_image'] = $this->upload_image('embassy_image');
            }
            if (!empty($_FILES['our_team_image']['name'])) {
                $data_arr['Institute']['our_team_image'] = $this->upload_image('our_team_image');
            }

            if (!empty($_FILES['image_for_first_day']['name'])) {
                $data_arr['Institute']['image_for_first_day'] = $this->upload_image('image_for_first_day');
            }
            if (!empty($_FILES['activities_social_image']['name'])) {
                $data_arr['Institute']['activities_social_image'] = $this->upload_image('activities_social_image');
            }

            $this->Institute->set($data_arr);
            if ($this->Institute->validates()) {

                $this->Institute->save($data_arr);

                //saved facility
                $institute_id = $this->Institute->getLastInsertID();
                if (!empty($data_arr['Institute']['facility_id'])) {
                    $institute_facility;
                    foreach ($data_arr['Institute']['facility_id'] as $key => $value) {
                        $institute_facility[] = array('institute_id' => $institute_id, 'facility_id' => $value);
                    }
                    $this->InstituteFacility->saveMany($institute_facility);
                }

                //saved exams
                if (!empty($data_arr['Institute']['exam_id'])) {
                    $institute_exam;
                    foreach ($data_arr['Institute']['exam_id'] as $key => $value) {
                        $institute_exam[] = array('institute_id' => $institute_id, 'exam_id' => $value);
                    }
                    $this->InstituteExam->saveMany($institute_exam);
                }
                $old_dir = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
                $new_dir = UPLOAD_INSTITUE_DIR . $this->Institute->getLastInsertId() . '/';
                rename($old_dir, $new_dir);
                $this->Session->setFlash(__('Added successfully.'), 'flash_success');
                $this->redirect(array('controller' => 'schools', 'action' => 'sub_courses_list', $institute_id));
            } else {
                $errors = $this->Institute->validationErrors;
                $errors = array_merge($errors, $add_errors);
            }
        }
        $this->autoRender = false;
    }

    /**
     * Purpose : save school courses
     * Created on : 21 April 2014
     * Author : Rupesh Sharma
     */
    public function school_courses($institute_id) {

        $courses = $this->Course->find('list');
        $this->set('courses', $courses);
        if (!empty($this->data)) {
            $data_arr = $this->data;
            //get slug from name
            $slug = $this->get_slug($data_arr['CourseType']['title']);
            $conditions = array("CourseType.slug" => $slug);
            $count = $this->CourseType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['CourseType']['slug'] = $slug;
            }
            $data_arr['CourseType']['institute_id'] = $institute_id;
            if (!empty($_FILES['pdf']['name'])) {
                $data_arr['CourseType']['pdf'] = $this->upload_file($institute_id, 'pdf');
            }
            //json encode
            if (!empty($data_arr['Price'])) {
                $filtered_array = array_filter($data_arr['Price']);
                $data_arr['Price'] = $filtered_array;
                $price_chart_assoc = array();
                $price_chart_count = count($data_arr['Price']) / 2;
                for ($i = 0; $i < $price_chart_count; $i++) {
                    $price_chart_assoc[] = array($data_arr['Price']['w_' . $i] => $data_arr['Price']['p_' . $i]);
                }
                $price_chart = json_encode($price_chart_assoc);
                $data_arr['CourseType']['price_chart'] = $price_chart;
            }

            //json encode starting dates
            $starting_dates = array('starting_date_first_line' => $data_arr['CourseType']['starting_date_first_line'], 'starting_date_second_line' => $data_arr['CourseType']['starting_date_second_line']);
            $data_arr['CourseType']['starting_dates'] = json_encode($starting_dates);
            //json encode lesson Schedule
            $lesson_schedule = array('lesson_schedule_first_line' => $data_arr['CourseType']['lesson_schedule_first_line'], 'lesson_schedule_second_line' => $data_arr['CourseType']['lesson_schedule_second_line']);
            $data_arr['CourseType']['lesson_schedule'] = json_encode($lesson_schedule);

            $this->CourseType->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'schools', 'action' => 'accomodation', $institute_id));
        }
    }

    /**
     * Purpose : save school accomodation
     * Created on : 23 April 2014
     * Author : Rupesh Sharma
     */
    public function accomodation($institute_id) {
        $this->loadModel('Accomodation');
        $this->loadModel('AccomodationFacility');
        $this->loadModel('AccomodationType');
        $this->loadModel('AccomodationTypeAccomodationFacility');
        if (!empty($this->data)) {
            $data_arr = $this->data;
            //get slug from name
            $slug = $this->get_slug($data_arr['AccomodationType']['title']);
            $conditions = array("AccomodationType.slug" => $slug);
            $count = $this->AccomodationType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['AccomodationType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['AccomodationType']['slug'] = $slug;
            }
            $data_arr['AccomodationType']['institute_id'] = $institute_id;
            if (!empty($_FILES['pdf']['name'])) {
                $data_arr['AccomodationType']['pdf'] = $this->upload_file($institute_id, 'pdf');
            }
            //json encode
            if (!empty($data_arr['Price'])) {
                $filtered_array = array_filter($data_arr['Price']);
                $data_arr['Price'] = $filtered_array;
                $price_chart_assoc = array();
                $price_chart_count = count($data_arr['Price']) / 2;
                for ($i = 0; $i < $price_chart_count; $i++) {
                    $price_chart_assoc[] = array($data_arr['Price']['w_' . $i] => $data_arr['Price']['p_' . $i]);
                }
                $price_chart = json_encode($price_chart_assoc);
                $data_arr['AccomodationType']['price_chart'] = $price_chart;
            }

            $this->AccomodationType->save($data_arr);
            //saved facility
            $accomodation_type_id = $this->AccomodationType->getLastInsertID();
            if (!empty($data_arr['AccomodationType']['facility_id'])) {
                $institute_facility;
                foreach ($data_arr['AccomodationType']['facility_id'] as $key => $value) {
                    $institute_facility[] = array('accomodation_type_id' => $accomodation_type_id, 'accomodation_facility_id' => $value);
                }
                $this->AccomodationTypeAccomodationFacility->saveMany($institute_facility);
            }
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'schools', 'action' => 'gallery', $institute_id));
        }
        $courses = $this->Accomodation->find('list');
        $this->set('courses', $courses);
        $facility = $this->AccomodationFacility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
    }

    /**
     * Purpose : save school gallery
     * Created on : 23 April 2014
     * Author : Rupesh Sharma
     */
    public function gallery($institute_id) {
    	   $this->set('institute_id',$institute_id);
    	$this->layout="school_info";
		
        $this->loadModel('InstituteGallery');
        //show gallery images
        $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }
        $this->Upload = $this->Components->load('Upload');
		
		$dir_path= UPLOAD_INSTITUE_DIR . $institute_id;
        $upload_path = $dir_path. '/gallery/';
		 if (!file_exists($upload_path)) {
                $this->make_dir($dir_path);
                $this->make_dir($dir_path . '/gallery');
            }
      
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 1200;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        if (!empty($this->data['Institute']['institue_id'])) {
        	
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $this->data['Institute']['institue_id']), array('InstituteGallery.institute_id' => $this->data['Institute']['institue_id'] . '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }

            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            //$this->redirect(array('controller' => 'schools', 'action' => 'extra_fee', $institute_id));
        }
    }

    /**
     * Purpose : Add delete photo gallery pic to respective institute
     * Created on : 23 April 2014
     * Author : Rupesh Sharma
     */
    function delete($id) {
        $id = $this->params->pass[0];
        $this->loadModel('InstituteGallery');
        $this->InstituteGallery->delete($id);
        $this->autoRender = false;
    }

     /**
     * Purpose : Listing of Extra Fee
     * Created on : 16 May 2014
     * Author : Rupesh Sharma
     */
    function list_extra_fee($id) {
    	$this->layout="school_info";
		$this->set('institute_id',$id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );

        $result_arr = $this->paginate('InstituteExtraFee');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Extra Fee';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list_extra_fee');
    }

    /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function add_extra_fee($institute_id) {
    	$this->layout="school_info";
		$this->set('institute_id',$institute_id);
        $errors = array();
        $add_errors = array();
            $this->loadModel('Currency');
        $error_flag = false;
        if (!empty($this->data)) {
            $data_arr = $this->data;
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;

            $this->InstituteExtraFee->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'Schools', 'action' => 'list_extra_fee', $institute_id));
        }
           $currency_code=$this->Institute->find('first',array('conditions'=>array('Institute.id'=> $institute_id),'fields'=>array('currency_id')));
                    
                              $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$currency_code['Institute']['currency_id']),'fields' => array('currrency_symbol')));
                         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']); 
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
    }

    /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     */
    function edit_extra_fee($institute_id, $id) {
    	$this->layout="school_info";
		$this->set('institute_id',$institute_id);
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Currency');
        $this->InstituteExtraFee->id = $id;
        if (!empty($this->data)) {
            $data_arr = $this->data;
            $data_arr['InstituteExtraFee']['institute_id'] = $institute_id;

            $this->InstituteExtraFee->save($data_arr);
            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
            $this->redirect(array('controller' => 'Schools', 'action' => 'list_extra_fee', $institute_id));
        }
        $type = array('0' => 'Compulsary', '1' => 'Optional');
        $this->set('type', $type);
        $selected_type = $this->InstituteExtraFee->find('list', array('conditions' => array('InstituteExtraFee.id' => $id), 'fields' => array('id')));
        $this->set('selected_type', $selected_type);
        $data_arr = $this->InstituteExtraFee->findById($id);
        
                $currency_code=$this->Institute->find('first',array('conditions'=>array('Institute.id'=> $institute_id),'fields'=>array('currency_id')));
                    
                              $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$currency_code['Institute']['currency_id']),'fields' => array('currrency_symbol')));
                         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']); 
        $this->data = $data_arr;
        $this->set('view_title', 'Add Extra Fee');
        $this->set('errors', $errors);
        $this->render('add_extra_fee');
    }

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE for extra Fee
     * Created on : 9 May 2014
     * Author : Rupesh Sharma
     */
    function extra_fee_manage_actions() {
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

                    $this->InstituteExtraFee->deleteAll(array('InstituteExtraFee.id' => $ids), true);
                    $message = 'Deleted successfully.';
                }
                elseif($task == "featured")
                {
                        $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "1"), array('InstituteExtraFee.id' => $ids));
                        $message = 'Activated successfully.';
                }
                elseif($task == "unfeatured")
                {
                        $this->InstituteExtraFee->updateAll(array('InstituteExtraFee.published' => "0"), array('InstituteExtraFee.id' => $ids));
                        $message = 'Inactivated successfully.';
                }
	elseif($task == "dublicate")
                {
                	$instituteExtrafee_list=$this->InstituteExtraFee->find('all',array('conditions'=>array('InstituteExtraFee.id'=>$ids)));
					
					$instituteExtrafee_list2=Hash::remove($instituteExtrafee_list,'{n}.InstituteExtraFee.id');
			        $this->InstituteExtraFee->saveAll($instituteExtrafee_list2);
					$message = 'Dublicate successfully.';
                }


                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }
    /**
     * Purpose : upload images
     * Input :	input field name
     * Created on : 17 April 2014
     * Author : Rupesh Sharma
     */
    function upload_image($field_name) {


        $this->Upload = $this->Components->load('Upload');
        $temp_upload_folder = $this->Session->read('temp_upload_folder');
        if ($this->params['action'] == 'edit') {
            $temp_upload_folder = $this->params['pass'][0];
        }
        $config['upload_path'] = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 1200;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        if ($this->Upload->do_upload($field_name)) {

            $imgdata_arr = $this->Upload->data();
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.S.width');
            $height = Configure::read('THUMB.S.height');
            $thumb_name = UPLOAD_INSTITUE_DIR . $temp_upload_folder . '/M_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name);
            return $imgdata_arr['file_name'];
        }
    }

    /**
     * Purpose : upload pdf file
     * Input :	input field name
     * Created on : 7 may 2014
     * Author : Rupesh Sharma
     */
    function upload_file($institute_id, $field_name) {

        $this->Upload = $this->Components->load('Upload');
        $config['upload_path'] = UPLOAD_INSTITUE_DIR . $institute_id . '/';
        $config['allowed_types'] = 'pdf';
        $config['max_size'] = 1200;
        $config['encrypt_name'] = false;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        if ($this->Upload->do_upload($field_name)) {

            $filedata_arr = $this->Upload->data();
            return $filedata_arr['file_name'];
        }
    }

    /**
     * Purpose : Get destination from country id
     * Created on : 30 April 2014
     * Author : Rupesh Sharma
     */
    function getDestination($id) {
        $destination = $this->Destination->find('list', array('conditions' => array('Destination.country_id' => $id), 'fields' => array('id', 'name')));
        $html = "<option value='0'>Select Destination</option>";
        foreach ($destination as $key => $value) {
            $html .= "<option value='$key'>$value</option>";
        }
        echo $html;
        $this->autoRender = false;
    }

    /**
     * Purpose : Edit the school information
     * Created on :27 May 2014
     * Author : Abhishek Tripathi
     */
    public function edit($id = null) {
     $errors = array();
		$add_errors = array();
		$error_flag = false;
                $this->set('school_id',$id);
		$this->Institute->id = $id;
		$this->loadModel('Country');
		$this->loadModel('Destination');
		$this->loadModel('Language');
		$this->loadModel('Facility');
		$this->loadModel('InstituteFacility');
		$this->loadModel('Exam');
		$this->loadModel('InstituteExam');
                $this->loadModel('InstituteExam');
		if(!empty($this->data))
		{

			$data_arr = $this->data;
			$destination = $this->Destination->find("first",array("conditions"=>array("Destination.id"=>$data_arr["Institute"]["destination_id"]),"fields" =>array("name")));
			$country = $this->Country->find("first",array("conditions"=>array("Country.id"=>$data_arr["Institute"]["country_id"]),"fields" =>array("name")));
			//get lat,long from address
			$location_url = 'https://maps.googleapis.com/maps/api/geocode/json?address='.$data_arr['Institute']['title'].','.$destination['Destination']['name'].','.$data_arr['Institute']['pin'].','.$data_arr['Institute']['city'].','.$country['Country']['name'].'&sensor=true';
			$location_url = str_replace(' ', '_', $location_url);
			$lat_lng = $this->get_lat_long($location_url);
				$data_arr['Institute']['lat'] = $lat_lng[0];
				$data_arr['Institute']['long'] = $lat_lng[1];

			//get slug from name
			$slug = $this->get_slug($data_arr['Institute']['title']);
			$conditions = array("Institute.slug" => $slug);
			$count = $this->Institute->find('count', array('conditions' => $conditions));
			if($count != 0)
			{
				$data_arr['Institute']['slug'] = $this->get_unique_slug($slug);
			}
			else
			{
				$data_arr['Institute']['slug'] = $slug;
			}

			//convert student profile data into json

			$student_profile =array(
										'Students_Enrolled_Last_Year'=>$data_arr['Institute']['Students_Enrolled_Last_Year'],
										'Average_Number_Students_During_Year'=>$data_arr['Institute']['Average_Number_Students_During_Year'],
										'Average_Number_Students_During_High_Season'=>$data_arr['Institute']['Average_Number_Students_During_High_Season'],
										'Minimum_Student_Age'=>$data_arr['Institute']['Minimum_Student_Age'],
										'less_then_twenty'=>$data_arr['Institute']['less_then_twenty'],
										'twenty_twentyfour'=>$data_arr['Institute']['twenty_twentyfour'],
										'twentyfive_twentynine'=>$data_arr['Institute']['twentyfive_twentynine'],
										'thirty_thirtyfour'=>$data_arr['Institute']['thirty_thirtyfour'],
										'thirtyfive_thirtynine'=>$data_arr['Institute']['thirtyfive_thirtynine'],
										'fourty_fourtyfour'=>$data_arr['Institute']['fourty_fourtyfour'],
										'fourtyfive_fourtynine'=>$data_arr['Institute']['fourtyfive_fourtynine'],
										'fifty_fiftyfour'=>$data_arr['Institute']['fifty_fiftyfour'],
										'fiftyfive_fiftynine'=>$data_arr['Institute']['fiftyfive_fiftynine'],
										'less_then_sixty'=>$data_arr['Institute']['less_then_sixty'],
										'Middle_East_Africa'=>$data_arr['Institute']['Middle_East_Africa'],
										'Central_South_America'=>$data_arr['Institute']['Central_South_America'],
										'Asia_Far_East'=>$data_arr['Institute']['Asia_Far_East'],
										'Central_Eastern_Europe'=>$data_arr['Institute']['Central_Eastern_Europe'],
										'Western_Europe'=>$data_arr['Institute']['Western_Europe']
									);
			$data_arr['Institute']['student_profile'] = json_encode($student_profile);

			//UPLOADING main image
			if(!empty($_FILES['logo']['name']))
			{
				$data_arr['Institute']['logo'] = $this->upload_image('logo');
			}
			if(!empty($_FILES['main_img']['name']))
			{
				$data_arr['Institute']['main_img'] = $this->upload_image('main_img');
			}
			if(!empty($_FILES['brand_image']['name']))
			{
				$data_arr['Institute']['brand_image'] = $this->upload_image('brand_image');
			}
			if(!empty($_FILES['location_image']['name']))
			{
				$data_arr['Institute']['location_image'] = $this->upload_image('location_image');
			}
			if(!empty($_FILES['embassy_image']['name']))
			{
				$data_arr['Institute']['embassy_image'] = $this->upload_image('embassy_image');
			}
			if(!empty($_FILES['our_team_image']['name']))
			{
				$data_arr['Institute']['our_team_image'] = $this->upload_image('our_team_image');
			}
	
            if(!empty($_FILES['image_for_first_day']['name']))
			{
				$data_arr['Institute']['image_for_first_day'] = $this->upload_image('image_for_first_day');
			}
			if(!empty($_FILES['activities_social_image']['name']))
			{
				$data_arr['Institute']['activities_social_image'] = $this->upload_image('activities_social_image');
			}
			$this->Institute->set($data_arr);
			if($this->Institute->validates())
			{
				
				
				$this->Institute->save($data_arr);
				//update facility
				if(!empty($data_arr['Institute']['facility_id']))
				{
					$this->InstituteFacility->deleteAll(array('InstituteFacility.institute_id' => $id), false);
					foreach ($data_arr['Institute']['facility_id'] as $key => $value) 
					{
						$institute_facility[] = array('institute_id' => $id,'facility_id' => $value);
					}
					$this->InstituteFacility->saveMany($institute_facility);
				}
				//update exam
				if(!empty($data_arr['Institute']['exam_id']))
				{
					$this->InstituteExam->deleteAll(array('InstituteExam.institute_id' => $id), false);
					foreach ($data_arr['Institute']['exam_id'] as $key => $value) 
					{
						$institute_exam[] = array('institute_id' => $id,'exam_id' => $value);
					}
					$this->InstituteExam->saveMany($institute_exam);
				}

				$this->Session->setFlash(__('Updated successfully.'), 'flash_success');
				//$this->redirect(array('controller' => 'S', 'action' => 'edit',$id));
			}
			else
			{
				$errors = $this->Institute->validationErrors;
				$errors = array_merge($errors, $add_errors);
			}
		}
		$action = $this->params['action'];
		$this->set('action',$action);
		$this->set('view_title', 'Add Institute');
		$this->set('errors', $errors);
		$data_arr = $this->Institute->findById($id);

		// json decode 

		$student_profile = json_decode($data_arr['Institute']['student_profile'],true);
		if(!empty($student_profile))
		{
			$new_arr = array_merge($data_arr['Institute'],$student_profile);
			$data_arr = array('Institute'=>$new_arr);	
		}
		
		
		$this->data = $data_arr;
		$countries = $this->Country->find('list',array('fields' => array('id','name')));
		$this->set('countries',$countries);
		$selected_country = $this->Country->find('list',array('conditions'=>array('Country.id' => $this->data['Institute']['country_id']),'fields'=>array('id')));
		$this->set('selected_country',$selected_country);
		$languages = $this->Language->find('list',array('fields' => array('id','title')));
		$this->set('languages',$languages);
		$destination = $this->Destination->find("list",array("conditions"=>array("Destination.country_id"=>$this->data["Institute"]["country_id"]),"fields" =>array("id","name")));
		$this->set('destination',$destination);
		$selected_destination = $this->Destination->find("list",array("conditions"=>array("Destination.id"=>$this->data["Institute"]["destination_id"]),"fields" =>array("id")));
		$this->set('selected_destination',$selected_destination);
		$selected_language = $this->Language->find('list',array('conditions'=>array('Language.id' => $this->data['Institute']['language_id']),'fields'=>array('id')));
		$this->set('selected_language',$selected_language);
		$facility = $this->Facility->find('list',array('fields' => array('id','title')));
		$this->set('facility',$facility);
		$selected_facility = $this->InstituteFacility->find('list',array('conditions' =>array('InstituteFacility.institute_id' => $id),'fields' => array('facility_id')));
		$this->set('selected_facility',$selected_facility);
		$exam = $this->Exam->find('list',array('fields' => array('id','title')));
		$this->set('exam',$exam);
		$selected_exam = $this->InstituteExam->find('list',array('conditions' =>array('InstituteExam.institute_id' => $id),'fields' => array('exam_id')));
		$this->set('selected_exam',$selected_exam);
		
                
                /*------------------course_type---------------*/
                    
                  
                
    }
    /**
     * Purpose : Cousrse List of the school
     * Created on :27 May 2014
     * Author : Abhishek Tripathi
     */
    
    public function sub_courses_list($id=null){
        $this->layout="schoolform";
        $this->set('school_id',$id);
        $cond_arr = array('CourseType.institute_id'=>$id);

		$this->CourseType->bindModel(
        array('belongsTo' => array(
	                'Course' => array(
	                    'className' => 'Course',
	                    'foreignKey' => 'course_id'

	                )
	            )
	        )
	    );

		if( isset( $_GET['filter'] ) )
		{

			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('CourseType.id' => 'desc')
		);

		$result_arr = $this->paginate('CourseType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		
		$view_title = 'Manage Courses';
		$this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
		
    }

     /**
     * Purpose : Editsub course infomation of the school 
     * Created on :27 May 2014
     * Author : Abhishek Tripathi
     */
    
    public function edit_sub_course($institute_id,$id)
	{
        $this->set('school_id',$institute_id);
		$errors = array();
		$this->CourseType->id = $id;
		$add_errors = array();
		$error_flag = false;
		$this->loadModel('Course');
		if(!empty($this->data))
		{
			$data_arr = $this->data;
			//json encode
			if(!empty($data_arr['Price']))
			{
				$filtered_array = array_filter($data_arr['Price']);
				$data_arr['Price'] = $filtered_array;
				$price_chart_assoc = array();
				$price_chart_count = count($data_arr['Price'])/2;
				for ($i=0; $i <$price_chart_count ; $i++) { 
					$price_chart_assoc[] = array($data_arr['Price']['w_'.$i] => $data_arr['Price']['p_'.$i]);
				}
				$price_chart = json_encode($price_chart_assoc);
				$data_arr['CourseType']['price_chart'] = $price_chart;
			}
			
			//get slug from name
			$slug = $this->get_slug($data_arr['CourseType']['title']);
			$conditions = array("CourseType.slug" => $slug);
			$count = $this->CourseType->find('count', array('conditions' => $conditions));
			if($count != 0)
			{
				$data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
			}
			else
			{
				$data_arr['CourseType']['slug'] = $slug;
			}
			$data_arr['CourseType']['institute_id'] = $institute_id;
			if(!empty($_FILES['pdf']['name']))
			{
				$data_arr['CourseType']['pdf'] = $this->upload_file($institute_id,'pdf');
			}
			//json encode starting dates
			$starting_dates = array('starting_date_first_line' => $data_arr['CourseType']['starting_date_first_line'],'starting_date_second_line'=>$data_arr['CourseType']['starting_date_second_line']);
			$data_arr['CourseType']['starting_dates'] = json_encode($starting_dates);
			//json encode lesson Schedule
			$lesson_schedule = array('lesson_schedule_first_line' => $data_arr['CourseType']['lesson_schedule_first_line'],'lesson_schedule_second_line'=>$data_arr['CourseType']['lesson_schedule_second_line']);
			$data_arr['CourseType']['lesson_schedule'] = json_encode($lesson_schedule);
			$this->CourseType->save($data_arr);
			$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			//$this->redirect(array('controller' => 'course', 'action' => 'list_sub_course',$institute_id));
		}
		$action = $this->params['action'];
		$this->set('action',$action);
		$data_arr= $this->CourseType->findById($id);
		
		//json decode price chart
		if(!empty($data_arr['CourseType']['price_chart']))
		{
			$price_chart = json_decode($data_arr['CourseType']['price_chart'],true);
			$price_chart_count = count($price_chart);
			$data_arr['CourseType']['price_chart_count'] = $price_chart_count;
			$data_arr['Price'] = $price_chart;
			
		}
		//json decode starting dates
		if(!empty($data_arr['CourseType']['starting_dates']))
		{
			$starting_dates = json_decode($data_arr['CourseType']['starting_dates'],true);
			if(!empty($starting_dates))
			{
				$data_arr['CourseType'] = array_merge($data_arr['CourseType'],$starting_dates);
			}
			
		}
		//json decode lesson schedule
		if(!empty($data_arr['CourseType']['lesson_schedule']))
		{
			
			$lesson_schedule = json_decode($data_arr['CourseType']['lesson_schedule'],true);

			if(!empty($lesson_schedule))
			{
				$data_arr['CourseType'] = array_merge($data_arr['CourseType'],$lesson_schedule);
			}

		}

		$this->data = $data_arr;
		$courses = $this->Course->find('list');
		$this->set('courses',$courses);
		$selected_course = array($this->data['CourseType']['course_id']);
		$this->set('selected_course',$selected_course);
		$this->set('view_title', 'Add Course');
		$this->set('errors', $errors);	
		//$this->render('add_sub_course');
	}
        
         
     /**
     * Purpose : List of accomodation of the school 
     * Created on :27 May 2014
     * Author : Abhishek Tripathi
     */
        function list_sub_accomodation($id=null)
	{
                $this->set('school_id',$id);
		$cond_arr = array('AccomodationType.institute_id'=>$id);

		$this->AccomodationType->bindModel(
        array('belongsTo' => array(
	                'Accomodation' => array(
	                    'className' => 'Accomodation',
	                    'foreignKey' => 'accomodation_id',
	                    'fields' =>array('title')

	                )
	            )
	        )
	    );

		if( isset( $_GET['filter'] ) )
		{

			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$cond_arr = array_merge($cond_arr, array('AccomodationType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('AccomodationType.id' => 'desc'),
			'recursive' => 3
		);

		$result_arr = $this->paginate('AccomodationType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		
		$view_title = 'Manage Sub Accomodation';
		$this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
		$this->render('list_sub_accomodation');
	}
        /**
     * Purpose : Edit sub accomodation of the school 
     * Created on :27 May 2014
     * Author : Abhishek Tripathi
     */
        function edit_sub_accomodation($institute_id,$id)
	{
                    $this->set('school_id',$institute_id);
		$errors = array();
		$this->AccomodationType->id = $id;
		$add_errors = array();
		$error_flag = false;
		$this->loadModel('Accomodation');
		$this->loadModel('AccomodationFacility');
		$this->loadModel('AccomodationTypeAccomodationFacility');
		if(!empty($this->data))
		{
			$data_arr = $this->data;
			//json encode
			if(!empty($data_arr['Price']))
			{
				$filtered_array = array_filter($data_arr['Price']);
				$data_arr['Price'] = $filtered_array;
				$price_chart_assoc = array();
				$price_chart_count = count($data_arr['Price'])/2;
				for ($i=0; $i <$price_chart_count ; $i++) { 
					$price_chart_assoc[] = array($data_arr['Price']['w_'.$i] => $data_arr['Price']['p_'.$i]);
				}
				$price_chart = json_encode($price_chart_assoc);
				$data_arr['AccomodationType']['price_chart'] = $price_chart;
			}
			//get slug from name
			$slug = $this->get_slug($data_arr['AccomodationType']['title']);
			$conditions = array("AccomodationType.slug" => $slug);
			$count = $this->AccomodationType->find('count', array('conditions' => $conditions));
			if($count != 0)
			{
				$data_arr['AccomodationType']['slug'] = $this->get_unique_slug($slug);
			}
			else
			{
				$data_arr['AccomodationType']['slug'] = $slug;
			}
			$data_arr['AccomodationType']['institute_id'] = $institute_id;
			if(!empty($_FILES['pdf']['name']))
			{
				$data_arr['AccomodationType']['pdf'] = $this->upload_file($institute_id,'pdf');
			}
			$this->AccomodationType->save($data_arr);
			//saved facility
			$accomodation_type_id = $this->AccomodationType->getLastInsertID();
			if(!empty($data_arr['AccomodationType']['facility_id']))
			{
				$this->AccomodationTypeAccomodationFacility->deleteAll(array('AccomodationTypeAccomodationFacility.accomodation_type_id' => $id), false);
				foreach ($data_arr['AccomodationType']['facility_id'] as $key => $value) {
						$institute_facility[] = array('accomodation_type_id' => $id,'accomodation_facility_id' => $value);
					}
				$this->AccomodationTypeAccomodationFacility->saveMany($institute_facility);
			}
			$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			//$this->redirect(array('controller' => 'accomodation', 'action' => 'list_sub_accomodation',$institute_id));
		}
		$action = $this->params['action'];
		$this->set('action',$action);
		$data_arr= $this->AccomodationType->findById($id);
		
		//json decode
		if(!empty($data_arr['AccomodationType']['price_chart']))
		{
			$price_chart = json_decode($data_arr['AccomodationType']['price_chart'],true);
			$price_chart_count = count($price_chart);
			$data_arr['AccomodationType']['price_chart_count'] = $price_chart_count;
			$data_arr['Price'] = $price_chart;
			
		}

		$this->data = $data_arr;
		$courses = $this->Accomodation->find('list');
		$this->set('courses',$courses);
		$selected_course = array($this->data['AccomodationType']['accomodation_id']);
		$this->set('selected_course',$selected_course);
		$facility = $this->AccomodationFacility->find('list',array('fields' => array('id','title')));
		$this->set('facility',$facility);
		$selected_facility = $this->AccomodationTypeAccomodationFacility->find('list',array('conditions' =>array('AccomodationTypeAccomodationFacility.accomodation_type_id' => $id),'fields' => array('accomodation_facility_id')));
		$this->set('selected_facility',$selected_facility);
		$this->set('view_title', 'Add Course');
		$this->set('errors', $errors);	
		//$this->render('add_sub_accomodation');
	}   
        
       /**
     * Purpose : Add sub course of the school 
     * Created on :28 May 2014
     * Author : Abhishek Tripathi
     */   
     public function add_sub_course($institute_id=null){
         $errors = array();
		$add_errors = array();
		$error_flag = false;
		$this->loadModel('Course');
              
		if(!empty($this->data))
		{
			$data_arr = $this->data;
			//get slug from name
			$slug = $this->get_slug($data_arr['CourseType']['title']);
			$conditions = array("CourseType.slug" => $slug);
			$count = $this->CourseType->find('count', array('conditions' => $conditions));
			if($count != 0)
			{
				$data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
			}
			else
			{
				$data_arr['CourseType']['slug'] = $slug;
			}
			$data_arr['CourseType']['institute_id'] = $institute_id;
			if(!empty($_FILES['pdf']['name']))
			{
				$data_arr['CourseType']['pdf'] = $this->upload_file($institute_id,'pdf');
			}
			//json encode
			if(!empty($data_arr['Price']))
			{
				$filtered_array = array_filter($data_arr['Price']);
				$data_arr['Price'] = $filtered_array;
				$price_chart_assoc = array();
				$price_chart_count = count($data_arr['Price'])/2;
				for ($i=0; $i <$price_chart_count ; $i++) { 
					$price_chart_assoc[] = array($data_arr['Price']['w_'.$i] => $data_arr['Price']['p_'.$i]);
				}
				$price_chart = json_encode($price_chart_assoc);
				$data_arr['CourseType']['price_chart'] = $price_chart;
			}

			//json encode starting dates
			$starting_dates = array('starting_date_first_line' => $data_arr['CourseType']['starting_date_first_line'],'starting_date_second_line'=>$data_arr['CourseType']['starting_date_second_line']);
			$data_arr['CourseType']['starting_dates'] = json_encode($starting_dates);
			//json encode lesson Schedule
			$lesson_schedule = array('lesson_schedule_first_line' => $data_arr['CourseType']['lesson_schedule_first_line'],'lesson_schedule_second_line'=>$data_arr['CourseType']['lesson_schedule_second_line']);
			$data_arr['CourseType']['lesson_schedule'] = json_encode($lesson_schedule);
		
                        $this->CourseType->save($data_arr);
			$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			$this->redirect(array('controller' => 'School', 'action' => 'sub_courses_list',$institute_id));
		}
		$courses = $this->Course->find('list');
		$this->set('courses',$courses);
		$this->set('view_title', 'Add Course');
		$this->set('errors', $errors);	
     }  
        /**
     * Purpose : Add sub accomodation of the school 
     * Created on :28 May 2014
     * Author : Abhishek Tripathi
     */
     public function add_sub_accomodation($institute_id)
	{
		$errors = array();
		$add_errors = array();
		$error_flag = false;
		$this->loadModel('Accomodation');
		$this->loadModel('AccomodationFacility');
		$this->loadModel('AccomodationTypeAccomodationFacility');
		if(!empty($this->data))
		{
			$data_arr = $this->data;
			//get slug from name
			$slug = $this->get_slug($data_arr['AccomodationType']['title']);
			$conditions = array("AccomodationType.slug" => $slug);
			$count = $this->AccomodationType->find('count', array('conditions' => $conditions));
			if($count != 0)
			{
				$data_arr['AccomodationType']['slug'] = $this->get_unique_slug($slug);
			}
			else
			{
				$data_arr['AccomodationType']['slug'] = $slug;
			}
			$data_arr['AccomodationType']['institute_id'] = $institute_id;
			if(!empty($_FILES['pdf']['name']))
			{
				$data_arr['AccomodationType']['pdf'] = $this->upload_file($institute_id,'pdf');
			}
			//json encode
			if(!empty($data_arr['Price']))
			{
				$filtered_array = array_filter($data_arr['Price']);
				$data_arr['Price'] = $filtered_array;
				$price_chart_assoc = array();
				$price_chart_count = count($data_arr['Price'])/2;
				for ($i=0; $i <$price_chart_count ; $i++) { 
					$price_chart_assoc[] = array($data_arr['Price']['w_'.$i] => $data_arr['Price']['p_'.$i]);
				}
				$price_chart = json_encode($price_chart_assoc);
				$data_arr['AccomodationType']['price_chart'] = $price_chart;
			}

			$this->AccomodationType->save($data_arr);
			//saved facility
			$accomodation_type_id = $this->AccomodationType->getLastInsertID();
			if(!empty($data_arr['AccomodationType']['facility_id']))
			{
				$institute_facility;
				foreach ($data_arr['AccomodationType']['facility_id'] as $key => $value) {
						$institute_facility[] = array('accomodation_type_id' => $accomodation_type_id,'accomodation_facility_id' => $value);
					}
				$this->AccomodationTypeAccomodationFacility->saveMany($institute_facility);
			}
			$this->Session->setFlash(__('Added successfully.'), 'flash_success');
			$this->redirect(array('controller' => 'Schools', 'action' => 'list_sub_accomodation',$institute_id));
		}
		$courses = $this->Accomodation->find('list');
		$this->set('courses',$courses);
		$facility = $this->AccomodationFacility->find('list',array('fields' => array('id','title')));
		$this->set('facility',$facility);
		$this->set('view_title', 'Add Course');
		$this->set('errors', $errors);	
	
	}
      
        /**
         *Purpose:To get information of schools on search
         * created on:12 june 2014
         * @param:language id,destination id and weeks
         * @Author: Abhishek TRipathi 
         */
        
        public function search($language=null,$country=null,$city=null,$week=null){
        	debug($this->params);exit;
            $this->layout='default';
            $this->loadModel('CoursePrice');
            $this->loadModel('Course');
		    $this->loadModel('Destination');
			$school_info=array();
			
			//set search parament in variable
            $language=$language;
			$country_name=$country;
			
			$city_name=$city;
			 $this->Destination->bindModel(
                array('belongsTo' => array(
                        'Country' => array(
                            'className' => 'Country',
                            'foreignKey' => 'country_id'
                        )
                    )
                )
        );
			
            //--------------------------Language----------------------
            $language_info=$this->Language->find('first',array('conditions'=>array('Language.title'=>$language)));
			
            $language_id=$language_info['Language']['id'];
           //----------------------------Destination----------------------------------
		   	if($city==null && $country==null){
		   		   $Destination=$this->Destination->find('first',array('conditions'=>array('AND'=>array('Destination.name'=>$city,'Country.name'=>$country))));
		
								$destination_id=$Destination['Destination']['id'];
								$weeks=$week;
		            $country_id=$this->Destination->find('first',array('conditions'=>array('Destination.id'=>$destination_id),'fields'=>array('country_id')));
					$this->Country->recursive=-1;
		            $school_list=$this->Institute->get_school_list($country_id['Destination']['country_id']);
		            $this->set('school_list',$school_list);
					$country_name=$this->Country->find('first',array('conditions'=>array('Country.id'=>$country_id['Destination']['country_id']),'fields'=>array('name')));
					$country_name=$country_name['Country']['name'];
					$destination=$this->Destination->findById($destination_id);
					 $search=array('[language]','[country]','[number]');
					$replace_from=array($language,$country_name,count($school_info));
					
					$destination['Destination']['main_title']=str_replace($search, $replace_from, $destination['Destination']['main_title']);
					$destination['Destination']['sub_title1']=str_replace($search, $replace_from, $destination['Destination']['sub_title1']);
					$destination['Destination']['sub_title2']=str_replace($search, $replace_from, $destination['Destination']['sub_title2']);
					$destination['Destination']['image']="/files/destination/".$destination['Destination']['flag_image'];
					$this->set('destination_info',$destination);
			}
			else{
				    
		            $school_list=$this->Institute->get_school_list_lang($language_id);
		            $this->set('school_list',$school_list);
					$country_name='';
					 $search=array('[language]','[number]');
					 $replace_from=array($language,count($school_info));
					$destination['Destination']['main_title']=str_replace($search, $replace_from, $language_info['Language']['main_title']);
					$destination['Destination']['sub_title1']=str_replace($search, $replace_from, $language_info['Language']['sub_title1']);
					$destination['Destination']['sub_title2']=str_replace($search, $replace_from, $language_info['Language']['sub_title2']);
					$destination['Destination']['image']="/files/language/".$language_info['Language']['image'];
					$destination['Destination']['text_bottom']=$language_info['Language']['text_bottom'];
					$this->set('destination_info',$destination);
			}
		   
		    $this->Institute->recursive=1;
		
            $school_info=$this->CoursePrice->get_search($language_id,$destination_id,$weeks);
            if(isset($school_info)){
                $this->set('schools',$school_info);
            }
		
		
            /*set parameters*/
        
			
	       
            $this->set('country_name',$country_name);
            $this->set('language',$language); 
            $this->set('destination',$this->Country->get_country());
            $this->set('language_list',$this->Language->find('list', array('fields' => array('title','title'))));
            $this->set('courses_type',$this->Course->find('list',array('fields'=>array('id','title'))));
            $this->set('weeks',Configure::read('ARR_WEEKS'));
            
            //debug($school_list);exit;
        }
        
 /**
 *Purpose:To get information  from ajax of schools on search
 * created on:24 june 2014
 * @param:language id,destination id and weeks
 * @Author: Abhishek TRipathi 
 */
         public function get_search_result(){
			 $this->layout="ajax";
			 $this->loadModel('CoursePrice');
             $this->loadModel('Course');
			 $this->loadModel('CourseType');
             $this->loadModel('Language');
             $language=$this->request->data['language'];
             $weeks=$this->request->data['weeks'];
			 $destination_id=$this->request->data['destination_id'];
             $language_id=$this->Language->find('first',array('conditions'=>array('Language.title'=>$language),'fields'=>array('id')));
             $language_id=$language_id['Language']['id'];
           
			 //$schools=$this->Institute->get_search($language_id,$destination_id,$weeks);
			 $school_info=array();
			$school_info=$this->CoursePrice->get_search($language_id,$destination_id,$weeks);
         
            if(isset($school_info)){
                $this->set('schools',$school_info);
            }
            $this->set('response',$school_info);
            $this->autoRender=false;
            $this->render('ajax');
			 }
		 
		 
		 
		 
		 
       public function get_data()
          {
			$this->layout="ajax";
			$this->loadModel('Country');
			$this->Country->recursive=-1;
			$country=$this->Country->find('all');
			foreach($country as $count){
				$country_list[]=$count['Country'];
				}
			$this->set('response',$country_list);
			
			$this->autorender=false;
			$this->render('ajax');
			//$this->render->type('json');
	}	
		  
		  
		  
 public function edit_form($id=null){
      $this->layout="school_info";
       if($this->params['action']=='edit_form'){
           $this->set('action',1);
       }
       
       $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Country');
        $this->loadModel('Language');
        $this->loadModel('Facility');
        $this->loadModel('Exam');
        $this->loadModel('Currency');
        $this->loadModel('Accreditation');
        $this->loadModel('Destination');
        $this->loadModel('InstituteExam');
        $this->loadModel('InstituteFacility');
        $this->loadModel('Event');
        $this->set('view_title', 'Add Institute');
        $this->set('errors', $errors);
       
        $language_spoken=$this->Language->find('list',array('fields'=>array('id','title')));
        $this->set('spoken_language',$language_spoken);
        $day=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
        $this->set('day',$day);
        $data_arr = $this->Institute->findById($id);
        
         for ($i = 1; $i < 13; $i++) {
            $time[] = $i . ':00';
        }
        $this->set('time', $time);
  
         $next_year_date=array('31 August','30 september','31 October','30 November','31 December','31 january of next year');
                $this->set('next_year_date',$next_year_date);
               $accreditation = $this->Accreditation->find('list', array('fields' => array('id', 'title')));
        (natcasesort($accreditation));       
        $this->set('accreditation', $accreditation);
        if(isset($data_arr['Institute']['currency_id'])){  
                    $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$data_arr['Institute']['currency_id']),'fields' => array('currrency_symbol')));

		 if(!empty($currency_symbol)){
		 	
         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']);  
         }     
					else{
				$this->set('currency_symbol','&nbsp;');		
					}   
		}
        // json decode 
        if(isset($data_arr['Institute']['student_profile'])){
        $student_profile = json_decode($data_arr['Institute']['student_profile'], true);
        if (!empty($student_profile)) {
            $new_arr = array_merge($data_arr['Institute'], $student_profile);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		if(isset($data_arr['Institute']['enrollment'])){
        $enrollment = json_decode($data_arr['Institute']['enrollment'], true);
        if (!empty($enrollment)) {
            $new_arr = array_merge($data_arr['Institute'], $enrollment);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['invoice'])){
        $invoice = json_decode($data_arr['Institute']['invoice'], true);
        if (!empty($invoice)) {
            $new_arr = array_merge($data_arr['Institute'], $invoice);
            $data_arr = array('Institute' => $new_arr);
        }
        }
		 if(isset($data_arr['Institute']['bank'])){
        $bank = json_decode($data_arr['Institute']['bank'], true);
        if (!empty($bank)) {
            $new_arr = array_merge($data_arr['Institute'], $bank);
            $data_arr = array('Institute' => $new_arr);
        }
        }
       if(isset($data_arr['Institute']['payment_detail'])){
        $payment = json_decode($data_arr['Institute']['payment_detail'], true);
        if (!empty($payment)) {
            $new_arr = array_merge($data_arr['Institute'], $payment);
            $data_arr = array('Institute' => $new_arr);
        }
	   }
         if(isset($data_arr['Institute']['commission'])){
        $commission = json_decode($data_arr['Institute']['commission'], true);
        if (!empty($commission)) {
            $new_arr = array_merge($data_arr['Institute'], $commission);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		 if(isset($data_arr['Institute']['recogination'])){
         $recogination = json_decode($data_arr['Institute']['recogination'], true);
        if (!empty($recogination)) {
            $new_arr = array_merge($data_arr['Institute'], $recogination);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
		  if(isset($data_arr['Institute']['course_detail'])){
           $course = json_decode($data_arr['Institute']['course_detail'], true);
        if (!empty($course)) {
            $new_arr = array_merge($data_arr['Institute'], $course);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		  if(isset($data_arr['Institute']['accommodation_detail'])){
            $accommodation= json_decode($data_arr['Institute']['accommodation_detail'], true);
        if (!empty($accommodation)) {
            $new_arr = array_merge($data_arr['Institute'], $accommodation);
            $data_arr = array('Institute' => $new_arr);
        }
		  }
		    if(isset($data_arr['Institute']['spoken_languages'])){
             $spoken_languages= json_decode($data_arr['Institute']['spoken_languages'], true);
        if (!empty($spoken_languages)) {
            $new_arr = array_merge($data_arr['Institute'], $spoken_languages);
            $data_arr = array('Institute' => $new_arr);
        }
			}
			 if(isset($data_arr['Institute']['transfer_detail'])){
              $transfer= json_decode($data_arr['Institute']['transfer_detail'], true);
        if (!empty($transfer)) {
            $new_arr = array_merge($data_arr['Institute'], $transfer);
            $data_arr = array('Institute' => $new_arr);
        }
			 }
			  if(isset($data_arr['Institute']['seo_detail'])){
              $seo= json_decode($data_arr['Institute']['seo_detail'], true);
        if (!empty($seo)) {
            $new_arr = array_merge($data_arr['Institute'], $seo);
            $data_arr = array('Institute' => $new_arr);
        }
        }
         if(isset($data_arr['Institute']['visa_basic_detail'])){
         $visa_basic= json_decode($data_arr['Institute']['visa_basic_detail'], true);
        if (!empty($visa_basic)) {
            $new_arr = array_merge($data_arr['Institute'], $visa_basic);
            $data_arr = array('Institute' => $new_arr);
        }
		 }
        $currency = $this->Currency->find('list', array('group'=>'Currency.currency_code','fields'=>array('id','currency_code')));
		
		//$res = Hash::flatten($currency);
        $this->set('currency', $currency);
	
        $event=$this->Event->find('all',array('conditions'=>array('Event.institute_id'=>$id)));
        $this->set('event',$event);
        $this->data = $data_arr;
        $countries = $this->Country->find('list', array('fields' => array('id', 'name')));
        $this->set('countries', $countries);
        $languages = $this->Language->find('list', array('fields' => array('id', 'title')));
        $this->set('languages', $languages);
        $destination = $this->Destination->find("list", array("conditions" => array("Destination.country_id" => $this->data["Institute"]["country_id"]), "fields" => array("id", "name")));
        $this->set('destination', $destination);
        $facility = $this->Facility->find('list', array('fields' => array('id', 'title')));
        $this->set('facility', $facility);
        $selected_facility = $this->InstituteFacility->find('list', array('conditions' => array('InstituteFacility.institute_id' => $id), 'fields' => array('facility_id')));
        $this->set('selected_facility', $selected_facility);
        $exam = $this->Exam->find('list', array('fields' => array('id', 'title')));
        $this->set('exam', $exam);
        $selected_exam = $this->InstituteExam->find('list', array('conditions' => array('InstituteExam.institute_id' => $id), 'fields' => array('exam_id')));
        $this->set('selected_exam', $selected_exam);
        //$this->render('edit_mode');
        //$this->autoRender = false;
        
        
    /*----------------------------------------------------------------------------------------------------------*/    
        
              $cond_arr = array('CourseType.institute_id' => $id);
        $this->set('institute_id',$id);

        $this->CourseType->bindModel(
                array('belongsTo' => array(
                        'Course' => array(
                            'className' => 'Course',
                            'foreignKey' => 'course_id'
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
            $cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('CourseType.id' => 'desc')
        );

        $result_arr_course = $this->paginate('CourseType');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_course', 'ARR_FEATURED', 'view_title'));
        //$this->render('list_sub_course');
        
        
        /*-------------------------------------------------accomodation------------------------------------*/
        $cond_arr = array('AccomodationType.institute_id'=>$id);
		  $this->set('institute_id',$id);

		$this->AccomodationType->bindModel(
        array('belongsTo' => array(
	                'Accomodation' => array(
	                    'className' => 'Accomodation',
	                    'foreignKey' => 'accomodation_id',
	                    'fields' =>array('title')

	                )
	            )
	        )
	    );

		if( isset( $_GET['filter'] ) )
		{

			$fields = array_filter($_GET['filter']);
			foreach($fields as $field_name => $value)
			{
				$cond_arr = array_merge($cond_arr, array('AccomodationType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this->paginate = array(
			'conditions' => $cond_arr,
			'limit' => (!empty($this->passedArgs['count'])?$this->passedArgs['count']:ADMIN_NUM_PER_PAGE),
			'order' => array('AccomodationType.id' => 'desc'),
			'recursive' => 3
		);

		$result_arr_accomodation = $this->paginate('AccomodationType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		
		
		$this->set(compact('result_arr_accomodation', 'ARR_FEATURED', 'view_title'));
		
		//--------------------------------------------------------------fee-----------------------------------------------
			$this->layout="school_info";
		$this->set('institute_id',$id);
        $cond_arr = array('InstituteExtraFee.institute_id' => $id);
        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('InstituteExtraFee.id' => 'desc')
        );

        $result_arr_fee = $this->paginate('InstituteExtraFee');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        
        $this->set(compact('result_arr_fee', 'ARR_FEATURED', 'view_title'));
       //------------------------------------------------------------gallery--------------=================================
       $institute_id=$id;
       
        $this->set('institute_id',$institute_id);
    	$this->layout="school_info";
		
        $this->loadModel('InstituteGallery');
        //show gallery images
      
        $this->Upload = $this->Components->load('Upload');
        $upload_path = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/';
        $config['upload_path'] = $upload_path;
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = 3000;
        $config['encrypt_name'] = true;
        $config['is_image'] = 1;
        $this->Upload->initializes($config);
        $data['InstituteGallery']['institute_id'] = $institute_id . '999999';
        if ($this->Upload->do_upload('file')) {

            $imgdata_arr = $this->Upload->data();
            $data['InstituteGallery']['img'] = $imgdata_arr['file_name'];
            $this->InstituteGallery->set($data);
            $this->InstituteGallery->save($data);
            //thumbnail generate
            $this->Resize = $this->Components->load('ImageResize');
            $source_image = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/' . $imgdata_arr['file_name'];
            $width = Configure::read('THUMB.VS.width');
            $height = Configure::read('THUMB.VS.height');
            $thumb_name_VS = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/VS_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_VS);
            $width = Configure::read('THUMB.L.width');
            $height = Configure::read('THUMB.L.height');
            $thumb_name_L = UPLOAD_INSTITUE_DIR . $institute_id . '/gallery/L_' . $imgdata_arr['file_name'];
            $arr = $this->Resize->resize($source_image, $width, $height, $thumb_name_L);
        }
        
        if (!empty($id)) {
            $this->InstituteGallery->updateAll(
                    array('InstituteGallery.institute_id' => $id), array('InstituteGallery.institute_id' => $id. '999999')
            );
            $delete_id = $this->InstituteGallery->find('list', array('fields' => array('InstituteGallery.img', 'InstituteGallery.institute_id'), 'conditions' => array('InstituteGallery.institute_id like' => '%999999')));
            if (!empty($delete_id)) {
                $this->InstituteGallery->deleteAll(array('InstituteGallery.institute_id' => $delete_id), false);
                foreach ($delete_id as $key => $value) {
                    $del_path = UPLOAD_INSTITUE_DIR . substr($value, 0, -6) . '/gallery/' . $key;
                    $this->delete_file($del_path);
                }
            }
			
       
        }	
		  $institute_images = $this->InstituteGallery->find('list', array('conditions' => array('institute_id' => $institute_id), 'fields' => array('img')));
        if (isset($institute_images)) {
            $this->set('institute_images', $institute_images);
        }

   }

  

}
