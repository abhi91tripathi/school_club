<?php
/*
 * Name : Homes
 * Created : 3 Apr 2013
 * Purpose : Homepage controller
 * Author : Ritish
 */ 
class CoursesController extends AppController {
	
	var $name = 'Courses';
	    var $uses = array('Course', 'Admin.CourseType','Admin.Institute');
	
	  /**
     * Purpose : Listing of sub courses   
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function list_sub_course($id) {
    	$this->layout="school_info";
         //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$institute_id),'fields'=>array('mode')));
                   
                         if($mode['Institute']['mode']==1){
                        
            //------------mode check------------------------
        $cond_arr = array('CourseType.institute_id' => $id);
        $this->set('institute_id',$id);
                  

        $this->CourseType->bindModel(
                array('belongsTo' => array(
                        'Course' => array(
                            'className' => 'Course',
                            'foreignKey' => 'course_id'
                        )
                    )
                )
        );

        if (isset($_GET['filter'])) {

            $fields = array_filter($_GET['filter']);
            foreach ($fields as $field_name => $value) {
            $cond_arr = array_merge($cond_arr, array('CourseType.' . $field_name . ' Like' => $value . '%'));
            }
        }

        $this->paginate = array(
            'conditions' => $cond_arr,
            'limit' => (!empty($this->passedArgs['count']) ? $this->passedArgs['count'] : ADMIN_NUM_PER_PAGE),
            'order' => array('CourseType.id' => 'desc')
        );

        $result_arr = $this->paginate('CourseType');
        $ARR_FEATURED = Configure::read('ARR_FEATURED');

        $view_title = 'Manage Courses';
        $this->set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
        $this->render('list_sub_course');
                         }
        else{
             $this->autoRender = false;
         $this->render('/Schools/mode');
        }
        
        
    }
 /**
     * Purpose : add sub course for institue
     * Created on : 6 may 2014
     * Author : Rupesh Sharma
     * updated on:9 june 2014
     * by:Abhishek Tripathi
     */
    function add_sub_course($institute_id) {
    	 
           $this->layout="school_info";
              //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$institute_id),'fields'=>array('mode')));
                   
                         if($mode['Institute']['mode']==1){
                        
            //------------mode check------------------------
             $this->set('institute_id',$institute_id);
        $errors = array();
        $add_errors = array();
        $error_flag = false;
        $this->loadModel('Course');
        $this->loadModel('CoursePrice');
        $this->loadModel('Institute');
        $this->loadModel('Currency');
        
                   
        
           $current_year=date('Y');
           $this->set('current_year',$current_year);
        if (!empty($this->data)) {

            $data_arr = $this->data;
            
            //debug($this->request->data);exit;
            //get slug from name
            $slug = $this->get_slug($data_arr['CourseType']['title']);
            $conditions = array("CourseType.slug" => $slug);
            $count = $this->CourseType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['CourseType']['slug'] = $slug;
            }
            $data_arr['CourseType']['institute_id'] = $institute_id;

            $data_arr['CourseType']['lesson_schedule_data'] = json_encode($this->request->data['CourseType']['lesson_schedule_data']);
            $data_arr['CourseType']['course_available_data'] = json_encode($this->request->data['CourseType']['course_available_data']);
            $data_arr['CourseType']['lesson_schedule'] = json_encode($this->request->data['CourseType']['lesson_schedule']);
            $data_arr['CourseType']['group_course'] = json_encode($this->request->data['CourseType']['group']);



            if($this->CourseType->save($data_arr))
            {
                 $current_price_list=array('CoursePrice'=>array(
                'institute_id'=>$institute_id,
                'course_types_id'=>$this->CourseType->getlastInsertId(),
                'price_chart'=>json_encode($data_arr['CourseType']['current_year']['price_chart']),
                'plan'=>$data_arr['CourseType']['current_year']['plan'],
                'min_no_course'=>$data_arr['CourseType']['current_year']['min_no_course'],
                'max_no_course'=>$data_arr['CourseType']['current_year']['max_no_course'],
                'year'=>$current_year,
             
                
            ));
               $this->CoursePrice->create();
               $this->CoursePrice->save($current_price_list);
                 
				
			 if(isset($this->request->data['save'])){
				$this->redirect(array('controller'=>'Courses','action'=>'edit_sub_course',$institute_id,$this->CourseType->getLastInsertId()));
                 $this->Session->setFlash(__('Save successfully.'), 'flash_success');
			}
			else{
				$this->redirect(array('controller'=>'Schools','action'=>'edit_form',$institute_id.'#manage_course'));
			            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
			}
			}
            else{
			  $this->Session->setFlash(__('Sorry please try again'), 'flash_success');
              $this->redirect(array('controller' => 'Courses', 'action' => 'add_sub_course', $institute_id));	
				}
           
        }
        $next_year_date = array('31 August', '30 september', '31 October', '30 November', '31 December', '31 january of next year');
        $this->set('next_year_date', $next_year_date);
        $level = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advance', 'Proficient', 'All level');
        $this->set('level', $level);
        
                $currency_code=$this->Institute->find('first',array('conditions'=>array('Institute.id'=> $institute_id),'fields'=>array('currency_id')));
                              $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$currency_code['Institute']['currency_id']),'fields' => array('currrency_symbol')));
                         $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']);          
       
         
        $courses = $this->Course->find('list');
        $this->set('courses', $courses);
			 for($i=1;$i<=52;$i++){$week[$i]=$i;}
		 $this->set('week',$week);
        $this->set('view_title', 'Add Course');
        $this->set('errors', $errors);
                         }
        else{
           $this->autoRender = false;
         $this->render('/Schools/mode');
    }
    }


/**
     * Purpose : FOR ADMIN to edit sub course information
     * Created on : 9 june 2014
     * Author : Abhishek Tripathi
     */
    public function edit_sub_course($instituted, $id) {
     
        $this->layout="school_info";
        
                  //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$instituted),'fields'=>array('mode')));
                         
                         if($mode['Institute']['mode']==1){
                         
            //------------mode check------------------------
        
	$this->set('institute_id',$instituted);
        $errors = array();
        $this->CourseType->id = $id;
        $add_errors = array();
        $error_flag = false;
      
   
        
        $this->loadModel('Admin.CoursePrice');
        $this->loadModel('Admin.Institute');
        $this->loadModel('Currency');
        
                         
            $current_year=date('Y');
            $last_year=date('Y',  strtotime('-1 years'));
            $nextyear=date('Y',  strtotime('+1 years'));
            $this->set('current_year',$current_year);
            $this->set('last_year',$last_year);
            $this->set('next_year',$nextyear);
        if (!empty($this->data)) {
     
            $this->CourseType->id = $id;
            $data_arr = $this->data;
 
            
            if((!empty($data_arr['CourseType']['current_year']['plan'])) && (!empty($data_arr['CourseType']['current_year']['plan'])) &&(!empty($data_arr['CourseType']['current_year']['plan'])) ){
            $current_price_list=array('CoursePrice'=>array(
                'institute_id'=>$instituted,
                'course_types_id'=>$id,
                'price_chart'=>json_encode($data_arr['CourseType']['current_year']['price_chart']),
                'plan'=>$data_arr['CourseType']['current_year']['plan'],
                'min_no_course'=>$data_arr['CourseType']['current_year']['min_no_course'],
                'max_no_course'=>$data_arr['CourseType']['current_year']['max_no_course'],
                'year'=>$current_year,
            ));
            $this->CoursePrice->deleteAll(array('CoursePrice.Institute_id'=>$instituted,'CoursePrice.course_types_id'=>$id,'CoursePrice.year'=>$current_year));
              if($current_year_price=$this->get_price_year($current_year,$instituted,$id))
            {
             $this->CoursePrice->id= $current_year_price;
             $this->CoursePrice->save($current_price_list);
            }
            else{
               $this->CoursePrice->create();
               $this->CoursePrice->save($current_price_list); 
            }
            }
            if((!empty($data_arr['CourseType']['last_year']['plan'])) && (!empty($data_arr['CourseType']['last_year']['plan'])) &&(!empty($data_arr['CourseType']['last_year']['plan'])) ){
            $last_price_list=array('CoursePrice'=>array(
                'institute_id'=>$instituted,
                'course_types_id'=>$id,
                'price_chart'=>json_encode($data_arr['CourseType']['last_year']['price_chart']),
                'plan'=>$data_arr['CourseType']['last_year']['plan'],
                'min_no_course'=>$data_arr['CourseType']['last_year']['min_no_course'],
                'max_no_course'=>$data_arr['CourseType']['last_year']['max_no_course'],
                'year'=>$last_year,
            ));
               $this->CoursePrice->deleteAll(array('CoursePrice.Institute_id'=>$instituted,'CoursePrice.course_types_id'=>$id,'CoursePrice.year'=>$last_year));
               if($last_year_price=$this->get_price_year($last_year,$instituted,$id))
            {
             $this->CoursePrice->id= $last_year_price;
             $this->CoursePrice->save($last_price_list);
            }
            else{
                $this->CoursePrice->create();
                $this->CoursePrice->save($last_price_list); 
            }
             }
            
              if((!empty($data_arr['CourseType']['next_year']['plan'])) && (!empty($data_arr['CourseType']['next_year']['plan'])) &&(!empty($data_arr['CourseType']['next_year']['plan'])) ){
                $next_price_list=array('CoursePrice'=>array(
                'institute_id'=>$instituted,
                'course_types_id'=>$id,
                'price_chart'=>json_encode($data_arr['CourseType']['next_year']['price_chart']),
                'plan'=>$data_arr['CourseType']['next_year']['plan'],
                'min_no_course'=>$data_arr['CourseType']['next_year']['min_no_course'],
                'max_no_course'=>$data_arr['CourseType']['next_year']['max_no_course'],
                'year'=>$nextyear
                
            ));
              $this->CoursePrice->deleteAll(array('CoursePrice.Institute_id'=>$instituted,'CoursePrice.course_types_id'=>$id,'CoursePrice.year'=>$nextyear));
            if($next_year_price=$this->get_price_year($nextyear,$instituted,$id))
            {
             $this->CoursePrice->id= $next_year_price;
             $this->CoursePrice->save($next_price_list);
            }
            else{
                 $this->CoursePrice->create();
               $this->CoursePrice->save($next_price_list); 
            }
              }
            
          //get slug from name
            $slug = $this->get_slug($data_arr['CourseType']['title']);
            $conditions = array("CourseType.slug" => $slug);
            $count = $this->CourseType->find('count', array('conditions' => $conditions));
            if ($count != 0) {
                $data_arr['CourseType']['slug'] = $this->get_unique_slug($slug);
            } else {
                $data_arr['CourseType']['slug'] = $slug;
            }
            $data_arr['CourseType']['institute_id'] = $instituted;

            $data_arr['CourseType']['lesson_schedule_data'] = json_encode($this->request->data['CourseType']['lesson_schedule_data']);
            $data_arr['CourseType']['course_available_data'] = json_encode($this->request->data['CourseType']['course_available_data']);
            $data_arr['CourseType']['lesson_schedule'] = json_encode($this->request->data['CourseType']['lesson_schedule']);
           
           if(isset($this->request->data['CourseType']['Discount'])){
            $data_arr['CourseType']['discount'] = json_encode($this->request->data['CourseType']['Discount']);
            }
            $data_arr['CourseType']['group_course'] = json_encode($this->request->data['CourseType']['group']);



            $this->CourseType->save($data_arr);
			if(isset($this->request->data['save'])){
				$this->redirect(array('controller'=>'Courses','action'=>'edit_sub_course',$instituted,$id));
                 $this->Session->setFlash(__('Save successfully.'), 'flash_success');
			}
			else{
				$this->redirect(array('controller'=>'Schools','action'=>'edit_form',$instituted));
			            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
			}
						
        }
        $data_arr = $this->CourseType->findById($id);
        
        $level = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advance', 'Proficient', 'All level');
        $this->set('level', $level);
        $lesson_schedule_data['lesson_schedule_data'] = json_decode($data_arr['CourseType']['lesson_schedule_data'], true);
        if (!empty($lesson_schedule_data)) {
            $new_arr = array_merge($data_arr['CourseType'], $lesson_schedule_data);
            $data_arr = array('CourseType' => $new_arr);
        }
        $course_available['course_available_data'] = json_decode($data_arr['CourseType']['course_available_data'], true);

        if (!empty($course_available)) {
            $new_arr = array_merge($data_arr['CourseType'], $course_available);
            $data_arr = array('CourseType' => $new_arr);
        }
        $price_chart['price_chart'] = json_decode($data_arr['CourseType']['price_chart'], true);

        if (!empty($price_chart)) {
            $new_arr = array_merge($data_arr['CourseType'], $price_chart);
            $data_arr = array('CourseType' => $new_arr);
        }
        
        $group_course['group'] = json_decode($data_arr['CourseType']['group_course'], true);
        if (!empty($group_course)) {
            $new_arr = array_merge($data_arr['CourseType'], $group_course);
            $data_arr = array('CourseType' => $new_arr);
        }
        $lesson_schedule['lesson_schedule'] = json_decode($data_arr['CourseType']['lesson_schedule'], true);
        if (!empty($lesson_schedule)) {
            $new_arr = array_merge($data_arr['CourseType'], $lesson_schedule);
            $data_arr = array('CourseType' => $new_arr);
        }
        $this->CoursePrice->recursive=-1;
        $course_price_lists=$this->CoursePrice->find('all',array('conditions'=>array('AND'=>array('CoursePrice.institute_id'=>$instituted,'CoursePrice.course_types_id'=>$id))));
        foreach($course_price_lists as $course_price_list){
            if($last_year==$course_price_list['CoursePrice']['year']){
                $course_price_list['CoursePrice']['price_chart']=  json_decode( $course_price_list['CoursePrice']['price_chart'],true);
            $data_arr['CourseType']['last_year']=$course_price_list['CoursePrice'];
            }
            if($current_year==$course_price_list['CoursePrice']['year']){
                $course_price_list['CoursePrice']['price_chart']=  json_decode( $course_price_list['CoursePrice']['price_chart'],true);
             $data_arr['CourseType']['current_year']=$course_price_list['CoursePrice'];    
            }
            if($nextyear==$course_price_list['CoursePrice']['year']){
                $course_price_list['CoursePrice']['price_chart']=  json_decode( $course_price_list['CoursePrice']['price_chart'],true);
             $data_arr['CourseType']['next_year']=$course_price_list['CoursePrice'];    
            }
        }
        
                $currency_code=$this->Institute->find('first',array('conditions'=>array('Institute.id'=> $instituted)));
              
                $currency_symbol=$this->Currency->find('first', array('conditions'=>array('Currency.id'=>$currency_code['Institute']['currency_id']),'fields' => array('currrency_symbol')));
                $this->set('currency_symbol',$currency_symbol['Currency']['currrency_symbol']);          
        $this->data = $data_arr;
        $courses = $this->Course->find('list');
        $this->set('courses', $courses);
        $selected_course = array($this->data['CourseType']['course_id']);
        $this->set('selected_course', $selected_course);
        $this->set('view_title', 'Add Course');
		 for($i=1;$i<=52;$i++){$week[$i]=$i;}
		 $this->set('week',$week);
        $this->set('errors', $errors);
        $this->render('add_sub_course');
    }
    else{
         $this->autoRender = false;
         $this->render('/Schools/mode');
    }
        
    }
  /**
     * Purpose:get price list id
     * created on:16 june 2014
     * created by:Abhishek Tripathi
  	**/
  public function get_price_year($year=null,$institute_id=null,$course_id=null){
      $this->loadModel('CoursePrice');
	 
   
     $year=$this->CoursePrice->find('first',array('conditions'=>array('AND'=>array('CoursePrice.year'=>$year,'CoursePrice.institute_id'=>$institute_id,'CoursePrice.course_types_id'=>$course_id)),'fields'=>array('id')));
   
    if($year){
        return $year['CoursePrice']['id'];
    }
    else{
        return FALSE;
    }
}

    /**
     * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
     * Created on : 6 May 2014
     * Author : Rupesh Sharma
     */
    function sub_course_manage_actions() {
    //debug($this->data);exit;
    $this->loadModel('CourseType');
        if (count($this->params['data'])) {
            $message = '';

            $ids = $this->params['data']['list'];

            if (!empty($ids)) {
                $task = $this->params['data']['task'];

                if ($task == "delete") {
                    //$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));
                     
                    $this->CourseType->deleteAll(array('CourseType.id' => $ids), true);
                    $message = 'Deleted successfully.';
                } elseif ($task == "featured") {
                    $this->CourseType->updateAll(array('CourseType.published' => "1"), array('CourseType.id' => $ids));
                    $message = 'Activated successfully.';
                } elseif ($task == "unfeatured") {
                    $this->CourseType->updateAll(array('CourseType.published' => "0"), array('CourseType.id' => $ids));
                    $message = 'Inactivated successfully.';
                }
				elseif($task == "Duplicate")
                {
                	$this->loadModel('CoursePrice');
                $course_list=$this->CourseType->find('all',array('conditions'=>array('CourseType.id'=>$ids)));
				     
					 //debug($course_list);
					 
					   foreach($course_list as $course)
					{
						$old_course_id=$course['CourseType']['id'];
						$course=Hash::remove($course,'CourseType.id');
						unset($course_id);
						$this->CourseType->save($course);
						$course_id=$this->CourseType->getLastInsertId();
						$this->CoursePrice->recursive=-1;
						$coursePrice=$this->CoursePrice->find('all',array('conditions'=>array('CoursePrice.course_types_id'=>$old_course_id)));
						//debug($coursePrice);exit;
						 foreach($coursePrice as $price){
						 	$price=Hash::remove($price,'CoursePrice.id');
							$price=Hash::remove($price,'CoursePrice.course_types_id');
							$price=Hash::insert($price,'CoursePrice.course_types_id',$course_id); 
							$this->CoursePrice->create();
							$this->CoursePrice->save($price);
						 }
						//debug($price);exit;
				    	}
					$message = 'Duplicate successfully.';
                }

                $this->Session->setFlash($message, 'flash_success');
            }

            $this->redirect($this->referer());
        }
        exit;
    }
	/**
	  * Purpose: this function is upload course image
	  * created on 21 july 2014
	  * created by:Abhishek Tripathi
	  **/
	  public function upload(){
		 // debug($this->params);exit;
	  	       if(isset($this->params->form['course_image'])){
	  	       	 $one= $this->params->form['course_image'];
	    	     $name = date('ydmhis') . '.' . pathinfo($one['name'], PATHINFO_EXTENSION);
			 	 $path = 'files' . DS . 'course_image' . DS;
				 move_uploaded_file($one['tmp_name'], $path . $name);
				// $this->Resize = $this->Components->load('ImageResize');
				// $this->Resize->resize( $path.$name, '870', '320', $path.$name);
			     $response['image_name'] = $name;
			     $response['path'] = FULL_BASE_URL . $this->webroot .'files/course_image/' . $name;
			     echo json_encode($response);exit; 
				
	  	       }
			  
				
	  }
}
