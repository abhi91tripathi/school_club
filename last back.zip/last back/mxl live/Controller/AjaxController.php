<?php

App::uses('AppController', 'Controller');
/*
 * This Controller used for handle Ajax calls from diffrent files and locations 
 * Initially no model is used bind lazy models as per particular requirement of the method
 * created 26 May 2014
 */

class AjaxController extends AppController {

    public $layout = 'ajax';
    public $autoRender = false;
    public $components = array('Email');

    /*
     * call beforeFilter of AppController
     */

    public function beforeFilter() {
        parent::beforeFilter();
    }

    /*
     * Function to get the course data
     */

    public function get_course_data() {

        $rss_arr = array();
        $rss_arr['msg'] = 'error';
        $this->loadModel('Institute');
        $this->loadModel('CourseType');
        $this->loadModel('AccomodationType');
        $this->loadModel('AccomodationPrice');
        $this->loadModel('Accomodation');
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('Currency');
        $discount_arrya = array();
        //-----------------discount array --------------------------
        $discount_arrya = array();
        if (isset($this->request->query) && !empty($this->request->query)) {
            $course_id = $this->request->query['course_id'];
            $coursetype = $this->CourseType->find('first', array('conditions' => array('CourseType.id' => $course_id)));
            if (!empty($coursetype)) {
                //get the instutue data
                $institueData = array();
                if (!empty($coursetype['Institute']['course_detail']) && $coursetype['Institute']['course_detail'] != '') {
                    //Get the course details
                    $institueData = json_decode($coursetype['Institute']['course_detail'], true);
                    //Get the commission on course details
                    $commissionsData = json_decode($coursetype['Institute']['commission'], true);
                }
                //get the commission registration price 
                $courseComReg = (isset($commissionsData['com_registration_fee']) ? $commissionsData['com_registration_fee'] : 0);

                //get the discount % on commission registration price
                $courseComReg_dis = (isset($commissionsData['com_registration_fee_dis']) ? $commissionsData['com_registration_fee_dis'] : 0);
                $rss_arr['msg'] = 'success';
                $rss_arr['due_deposit'] = 0;

                //start to get the institute currency
                $currency_id = !empty($coursetype['Institute']['currency_id']) ? $coursetype['Institute']['currency_id'] : 0;
                $this->loadModel('Currency');
                $currency_name = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_id), 'fields' => array('Currency.currency_code')));
                $currency_name = $currency_name['Currency']['currency_code'];
                //end
                //get the school registration price
                $institueData = array();
                $rss_arr['schoolregFee'] = 0;
                if (!empty($coursetype['Institute']['course_detail']) && $coursetype['Institute']['course_detail'] != '') {
                    $institueData = json_decode($coursetype['Institute']['course_detail'], true);
                    $rss_arr['schoolregFee'] = (!empty($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0);
                    if ($this->request->query['setval'] == 'no') {
                        $rss_arr['schoolregFee'] = $rss_arr['schoolregFee'];
                    } else {
                        $rss_arr['schoolregFee'] = 0;
                    }
                    $rss_arr['total'] = $rss_arr['schoolregFee'];
                }
                //Course date
                if ($this->request->query['beg'] == 0) {
                    $rss_arr['course_starting_date'] = $coursetype['CourseType']['course_starting_date'];
                    $rss_arr['startting_date_data'] = $coursetype['CourseType']['startting_date_data'];
                } else {
                    $rss_arr['course_starting_date'] = $coursetype['CourseType']['course_starting_beginer_date'];
                    $rss_arr['startting_date_data'] = $coursetype['CourseType']['beginner_date_data'];
                }
                //Course weeks
                $rss_arr['weeks'] = array();
                if (!empty($coursetype['CoursePrice'])) {
                    $coursePrices = $coursetype['CoursePrice'];
                    $this->loadModel('CoursePrice');
                    $this->CoursePrice->recursive = -1;

                    $price_list = $this->CoursePrice->find('first', array('conditions' => array('CoursePrice.course_types_id' => $coursetype['CourseType']['id'], 'CoursePrice.starting_date <=' => date('Y-m-d'))));

                    foreach ($price_list as $coursePrice) {
                        $rss_arr['weeks']['min_week'] = $coursePrice['min_no_course'];
                        $rss_arr['weeks']['max_week'] = $coursePrice['max_no_course'];
                    }
                }
                //-------------registration feee----------------------------------------
                if (isset($courseComReg) && $courseComReg != '') {
                    if ($this->request->query['setval'] == 'no') {
                        $institueData['inscription_fee'] = $institueData['inscription_fee'];
                    } else {
                        $institueData['inscription_fee'] = 0;
                    }

                    if (isset($courseComReg_dis) && $courseComReg_dis != '') {
                        $courseComReg = $courseComReg - $courseComReg_dis;

                        $discount_arrya[] = array(
                            'class' => 'course_reg_discount',
                            'key' => $courseComReg_dis . '% discount',
                            'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg_dis / 100), 2));

                        $rss_arr['total'] = $rss_arr['total'] - ((!empty($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg_dis) / 100;
                    }
                }
                $rss_arr['due_deposit'] = (((isset($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg) / 100);
                //School accomdations
                $rss_arr['accomodation'] = array();
                $accomodationtype = $this->AccomodationType->find('all', array('fields' => array('AccomodationType.id', 'AccomodationType.title'), 'conditions' => array('AccomodationType.institute_id' => $coursetype['CourseType']['institute_id'],'AccomodationType.published'=>1)));
                if (!empty($accomodationtype)) {
                    $i = 0;
                    foreach ($accomodationtype as $accomodation) {
                        $rss_arr['accomodation'][$i]['id'] = $accomodation['AccomodationType']['id'];
                        $rss_arr['accomodation'][$i]['title'] = $accomodation['AccomodationType']['title'];
                        $i++;
                    }
                }
                //Extrafee option----------
                $rss_arr['Extra_fee'] = array();
                $extra_fee = $this->InstituteExtraFee->find('all', array('conditions' => array('AND' => array('InstituteExtraFee.institute_id' => $coursetype['CourseType']['institute_id'], 'InstituteExtraFee.published' => 1))));

                if (!empty($extra_fee)) {
                    foreach ($extra_fee as $fee) {
                        if ($fee['InstituteExtraFee']['type'] == 0) {
                            $fee_array[] = array('key' => $fee['InstituteExtraFee']['title'],
                                'price' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $fee['InstituteExtraFee']['price']), 2));
                            $rss_arr['total'] = $rss_arr['total'] + $fee['InstituteExtraFee']['price'];
                        }
                    }
                    if (isset($fee_array)) {
                        $rss_arr['Extra_fee'] = $fee_array;
                    }
                }
            }
        }
        if (!empty($rss_arr['total'])) {
            $rss_arr['due_deposit_eur'] = '&euro;' . number_format($this->Institute->exchange_rate_convert($currency_name, 'EUR', $rss_arr['due_deposit']), 2);
            $real_currency = $this->Currency->find('first', array('conditions' => array('Currency.id' => $coursetype['Institute']['currency_id'])));
            $rss_arr['total_eur'] = $real_currency['Currency']['currrency_symbol'] . number_format($this->Institute->exchange_rate_convert($this->Session->read('CURRENCY'), $real_currency['Currency']['currency_code'], $rss_arr['total']), 2);
        }
        $rss_arr['schoolregFee'] = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $institueData['inscription_fee']), 2);
        $rss_arr['total'] = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $rss_arr['total'], 2));
        $rss_arr['due_deposit'] = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $rss_arr['due_deposit']), 2);
        $rss_arr['discount_arr'] = $discount_arrya;

        //-------------
        echo json_encode($rss_arr);
        die;
    }

    /*
     * Function to calculate the price
     */

    public function get_price() {
        $rss_arr = array('msg' => 'failure');
        $this->loadModel('Institute');
        $this->loadModel('CourseType');
        $this->loadModel('AccomodationType');
        $this->loadModel('AccomodationPrice');
        $this->loadModel('Accomodation');
        $this->loadModel('InstituteExtraFee');
        $this->loadModel('Currency');
        $this->loadModel('CoursePrice');
        configure::write('debug', 2);
        //define the variables
        //----discount_array-----------
        $discount_arrya = array();
        $disscount_less_weekPrice = '';

        $USD = $EUR = $week_price = $price = $high_season_from = $high_season_to = $deposit_due = $accom_price = $discount_by_me = $discount_val = $discount_val_school = 0;

        if (isset($this->request->query) && !empty($this->request->query)) {
            //get the parameter by calling ajax function

            $course_id = !empty($this->request->query['course_id']) ? $this->request->query['course_id'] : 0;
            $week_val = !empty($this->request->query['week_val']) ? $this->request->query['week_val'] : 0;
            $start_date = !empty($this->request->query['start_date']) ? $this->request->query['start_date'] : 0;
            $accomodation_id = !empty($this->request->query['accomodation_id']) ? $this->request->query['accomodation_id'] : 0;
            //Condition for course and week not empty
            if ($course_id != '') {
                //get the course data
                $contain = array(
                    'Institute',
                    'CoursePrice' => array(
                        'conditions' => array(
                            'CoursePrice.starting_date <=' => date('Y-m-d')
                        ), 'limit' => 1, 'order' => array('CoursePrice.starting_date DESC',)
                    )
                );
                $coursetype = $this->CourseType->find('first', array('conditions' => array('CourseType.id' => $course_id), 'contain' => $contain));

                //start to get the institute currency
                $currency_id = !empty($coursetype['Institute']['currency_id']) ? $coursetype['Institute']['currency_id'] : 0;
                $this->loadModel('Currency');
                $currency_name = $this->Currency->find('first', array('conditions' => array('Currency.id' => $currency_id), 'fields' => array('Currency.currency_code')));
                $currency_name = $currency_name['Currency']['currency_code'];
                //end
                //get the instutue data
                $institueData = array();
                if (!empty($coursetype['Institute']['course_detail']) && $coursetype['Institute']['course_detail'] != '') {
                    //Get the course details
                    $institueData = json_decode($coursetype['Institute']['course_detail'], true);
                    $high_season_from = ($institueData['high_season_from']);
                    $high_season_to = ($institueData['high_season_to']);
                    
                    $institueData_aco = json_decode($coursetype['Institute']['accommodation_detail'], true);
             
                    $accomodation_high_season_from = ($institueData_aco['accommodation_high_season_from']);
                    $accomodation_high_season_to = ($institueData_aco['accommodation_high_season_to']);
                    //Get the commission on course details
                    $commissionsData = json_decode($coursetype['Institute']['commission'], true);
                }

                if (!empty($coursetype['CoursePrice'])) {
                    //Get the course price
                    $this->CoursePrice->recursive = -1;
                    $price_list = $this->CoursePrice->find('first', array('conditions' => array('CoursePrice.course_types_id' => $coursetype['CourseType']['id'], 'CoursePrice.starting_date <=' => date('Y-m-d'))));

                    $coursePrices [] = $price_list['CoursePrice'];


                    //Get the Commissions price on course
                    $courseCommission = (isset($commissionsData['com_courses']) ? $commissionsData['com_courses'] : 0);

                    //Get the Commissions price on accommodation
                    $courseAccomodation = (isset($commissionsData['com_accommodation']) ? $commissionsData['com_accommodation'] : 0);

                    //Get the discount on % Commissions price on accommodation
                    $courseAccomodation_dis = (isset($commissionsData['com_accommodation_dis']) ? $commissionsData['com_accommodation_dis'] : 0);


                    //Get the Commissions price on accommodation Registration fees
                    $courseAccomodation_reg_fee = (isset($commissionsData['com_accommodation_fee']) ? $commissionsData['com_accommodation_fee'] : 0);


                    //Get the discount on % Commissions price on accommodation  Registration fees
                    $courseAccomodation_reg_fee_dis = (isset($commissionsData['com_accommodation_fee_dis']) ? $commissionsData['com_accommodation_fee_dis'] : 0);

                    //get the commissions % on registration price
                    $courseComReg = (isset($commissionsData['com_registration_fee']) ? $commissionsData['com_registration_fee'] : 0);

                    //get the discount % on commission registration price
                    $courseComReg_dis = (isset($commissionsData['com_registration_fee_dis']) ? $commissionsData['com_registration_fee_dis'] : 0);

                    //Get the discount value by me on course
                    $total_discount_me = json_decode($coursetype['Institute']['commission'], true);
                    $course_discount = (isset($total_discount_me['com_courses_dis']) ? $total_discount_me['com_courses_dis'] : 0);
                    $discount_val = (isset($total_discount_me['com_courses_dis']) ? $total_discount_me['com_courses_dis'] : 0);

                    //Get the discount value by school on course
                    $total_discount_school = json_decode($coursetype['CourseType']['discount'], true);
                    $discount_plan = (isset($total_discount_school['plan']) ? $total_discount_school['plan'] : 0);


                    foreach ($coursePrices as $coursePrice) {

                        $price_chart = json_decode($coursePrice['price_chart'], true);

                        $price_chart_cumulative = json_decode($coursePrice['price_chart_cumulative'], true);

                        //--------Check conditions for Weekly option select-------------------//
                        if ($week_val != '' && !empty($start_date)) {

                            $end_date = date("d-m-Y", strtotime($start_date . " +" . $week_val . " week"));


                            //---check if the end date will enter the next price list------//
                            $this->CoursePrice->recursive = -1;

                            $next_price_list_date = $this->CoursePrice->find('first', array('conditions' => array('CoursePrice.course_types_id' => $coursetype['CourseType']['id'], 'CoursePrice.id <>' => $price_list['CoursePrice']['id'], 'CoursePrice.starting_date <' => date('Y-m-d', strtotime($end_date)), 'CoursePrice.enroll_date <' => date('Y-m-d', strtotime($start_date)))));


                            if ($next_price_list_date && date('Y-m-d') >= $next_price_list_date['CoursePrice']['enroll_date']) {
                                $high_season_to=$accomodation_high_season_from;
                                $high_season_to=$accomodation_high_season_to;
                                $response = $this->price_calculation($next_price_list_date, $coursePrice, $week_val, $start_date, $end_date, $price, $high_season_to, $high_season_from);
                                $price = $response['price'];
                                $week_price = $response['week_price'];
                            } else {
                                
                                
                                $high_season_to=$accomodation_high_season_from;
                                $high_season_to=$accomodation_high_season_to;
                                
                                if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                                    $price = $price + $price_chart_cumulative['all_year_chart'][$week_val];
                                    $week_price = $price_chart_cumulative['all_year_chart'][$week_val];
                                } else {
                                    $high_season_week = 0;
                                    $low_season_week = 0;
                                    $j = 0;
                                     $REG_PRICE = $price;
                                    $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                                    for ($i = strtotime($start_date); $i < strtotime($end_date);) {
                                        if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                            $high_season_week++;
                                        } else {
                                            $low_season_week++;
                                        }

                                        $j++;
                                        $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                        $last_date = $i;
                                    }

                                   
                                    if ($high_season_week > 0) {
                                        if ($coursePrice['price_calculation'] == 0) {
                                            $price = $price+$REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                            $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                                         
                                        } else {
                                            for ($a = 1; $a <= $high_season_week; $a++) {
                                                $price = $price+$REG_PRICE + $price_chart['high_chart'][$a];
                                                $week_price = $week_price + $price_chart['high_chart'][$a];
                                               
                                            }
                                        }
                                    }
                                    if ($low_season_week > 0) {
                                        if ($high_season_week == 0) {

                                            if ($coursePrice['price_calculation'] == 0) {
                                                $price = $price+$REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                                $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                               
                                                
                                            } else {
                                                for ($a = 1; $a <= $low_season_week; $a++) {
                                                    $price = $price+$REG_PRICE + $price_chart['low_chart'][$a];
                                                    $week_price = $week_price + $price_chart['low_chart'][$a];
                                                  
                                                }
                                            }
                                        } else {

                                            if ($coursePrice['price_calculation'] == 0) {
                                                $price = $price+$REG_PRICE +  ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                                $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                               
                                            } else {
                                                for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                                    $price =$price +$REG_PRICE + $price_chart['low_chart'][$a];
                                                    $week_price = $week_price + $price_chart['low_chart'][$a];
                                                  
                                                }
                                            }
                                        }
                                    }
                                }
                                
                               
                            }
                                                           

                            //discount valid------------
                            //without -discount week price
                            $disscount_less_weekPrice = $week_price;
                            if (strtotime($total_discount_school['discount_valid_course_from']) <= strtotime($start_date) && strtotime($total_discount_school['discount_valid_course_to']) > strtotime($start_date)) {

                                switch ($discount_plan) {
                                    case '1':
                                        if (!empty($total_discount_school['discount_percent'])) {
                                            $discount_by_me = ($price * $total_discount_school['discount_percent']) / 100;
                                            $price = $price - $discount_by_me;
                                            $week_price = $week_price - $discount_by_me;
                                            $discount_arrya[] = array(
                                                'class' => 'course_discount_plan1',
                                                'key' => $total_discount_school['discount_percent'] . '% discount',
                                                'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($discount_by_me) ? $discount_by_me : 0)), 2));
                                        }
                                        break;
                                    case '2':
                                        if (!empty($total_discount_school['discount_price'])) {
                                            $discount_by_me = ((($total_discount_school['discount_price']) ? $total_discount_school['discount_price'] : 0) * $week_val);
                                            $price = $price - ((($total_discount_school['discount_price']) ? $total_discount_school['discount_price'] : 0) * $week_val);
                                            $week_price = $week_price - ((($total_discount_school['discount_price']) ? $total_discount_school['discount_price'] : 0) * $week_val);
                                            $discount_arrya[] = array(
                                                'class' => 'course_discount_plan2',
                                                'key' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $total_discount_school['discount_price']), 2) . ' per week discount',
                                                'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($discount_by_me) ? $discount_by_me : 0)), 2));
                                        }
                                        break;
                                    case '3':if (!empty($total_discount_school['discount_price_weekly'])) {
                                            $discount_by_me = (($total_discount_school['discount_price_weekly']) ? $total_discount_school['discount_price_weekly'] : 0);
                                            $price = $price - (($total_discount_school['discount_price_weekly']) ? $total_discount_school['discount_price_weekly'] : 0);
                                            $week_price = $week_price - (($total_discount_school['discount_price_weekly']) ? $total_discount_school['discount_price_weekly'] : 0);
                                            $discount_arrya[] = array(
                                                'class' => 'course_discount_plan3',
                                                'key' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($discount_by_me) ? $discount_by_me : 0)), 2) . ' discount',
                                                'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($discount_by_me) ? $discount_by_me : 0)), 2));
                                        }
                                        break;
                                }
                            }
                            //get the Deposit now ammount only
                            //deduct the discount from course commission  by me
                            if (isset($total_discount_me['com_courses_dis']) && $total_discount_me['com_courses_dis'] != '') {
                                $courseCommission = $courseCommission - $discount_val;
                                $discount_arrya[] = array(
                                    'class' => 'course_commision_discount',
                                    'key' => $total_discount_me['com_courses_dis'] . '% discount',
                                    'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($week_price) ? $week_price : 0) * $discount_val / 100), 2));
                                $deposit_due = (($price * $courseCommission) / 100); //echo $deposit_due;                 
                                $price = $price - ((isset($week_price) ? $week_price : 0) * $discount_val / 100);
                            } else {
                                $deposit_due = (($price * $courseCommission) / 100); //echo $deposit_due;                 
                            }
                        }
                                              

                        //--------END Check conditions for Weekly option select-------------------//
                        //----------Check conditions for accomodation option select----------//
                        if ($accomodation_id != '') {
                            $accomodations = $this->AccomodationPrice->find('first', array('conditions' => array('AccomodationPrice.institute_id' => $coursetype['CourseType']['institute_id'], 'AccomodationPrice.starting_date <=' => date('Y-m-d'), 'AccomodationPrice.accomodation_types_id' => $accomodation_id)));

                            if (!empty($accomodations)) {
                                //Get the price chart for accomodation registration price
                               
                                //Get the price chart for accomodation price
                                $price_chart = json_decode($accomodations['AccomodationPrice']['price_chart'], true);
                                $price_chart_cumulative = json_decode($accomodations['AccomodationPrice']['price_chart_cumulative'], true);
                                /* -------------------------------------------------------- */
                                //--------Check conditions for Weekly option select-------------------//
                                if ($week_val != '' && !empty($start_date)) {

                                    //---check if the end date will enter the next price list------//
                                    $this->AccomodationPrice->recursive = -1;

                                    $next_price_list_date = $this->AccomodationPrice->find('first', array('conditions' => array('AccomodationPrice.accomodation_types_id' => $accomodations['AccomodationPrice']['accomodation_types_id'], 'AccomodationPrice.id <>' => $accomodations['AccomodationPrice']['id'], 'AccomodationPrice.starting_date <' => date('Y-m-d', strtotime($end_date)), 'AccomodationPrice.enroll_date <' => date('Y-m-d', strtotime($start_date)))));

                                    if ($next_price_list_date && date('Y-m-d') >= $next_price_list_date['AccomodationPrice']['enroll_date']) {
                                        $response = $this->price_calculation_accomodation($next_price_list_date, $accomodations, $week_val, $start_date, $end_date, $price, $high_season_to, $high_season_from);
                                        $price = $response['price'];
                                        $accom_price = $response['week_price'];
                                    } else {
                                        $high_season_week = 0;
                                        $low_season_week = 0;
                                        $j = 0;
                                        $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                                        for ($i = strtotime($start_date); $i < strtotime($end_date);) {
                                            if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                                $high_season_week++;
                                            } else {
                                                $low_season_week++;
                                            }

                                            $j++;
                                            $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                            $last_date = $i;
                                        }
                                       
                                        $REG_PRICE = $price;
                                        if ($high_season_week > 0) {
                                            if ($accomodations['AccomodationPrice']['price_calculation'] == 0) {
                                                $price = $REG_PRICE + $price_chart['high_chart'][$j];
                                                $accom_price = $price_chart_cumulative['high_chart'][$high_season_week];
                                       
                                            } else {
                                                for ($a = 1; $a <= $high_season_week; $a++) {
                                                    $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                                    $accom_price = $accom_price + $price_chart['high_chart'][$a];
                                                    
                                                }
                                            }
                                        }
                                        if ($low_season_week > 0) {
                                            if ($high_season_week == 0) {

                                                if ($accomodations['AccomodationPrice']['price_calculation'] == 0) {
                                                    $price = $REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                                    $accom_price = $accom_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                                   
                                                } else {
                                                    for ($a = 1; $a <= $low_season_week; $a++) {
                                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                                        $accom_price = $accom_price + $price_chart['low_chart'][$a];
                                                        
                                                    }
                                                }
                                            } else {

                                                if ($accomodations['AccomodationPrice']['price_calculation'] == 0) {
                                                    $price = $REG_PRICE +  ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                                    $accom_price = $accom_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                                    
                                                } else {
                                                    for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                                        $accom_price = $accom_price + $price_chart['low_chart'][$a];
                                                      
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                            



                             
                            }
                        }
                     
                        //Get the price after acccomodation commission and discount

                        if ($accom_price != '') {
                            if (isset($courseAccomodation) && $courseAccomodation != '') {
                                if (isset($courseAccomodation_dis) && $courseAccomodation_dis != '') {
                                    $courseAccomodation = $courseAccomodation - $courseAccomodation_dis;
                                    $discount_arrya[] = array(
                                        'class' => 'accommodation_discount',
                                        'key' => $courseAccomodation_dis . '% discount',
                                        'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($accom_price) ? $accom_price : 0) * $courseAccomodation_dis / 100), 2));
                                    $price = $price - (isset($accom_price) ? $accom_price : 0) * $courseAccomodation_dis / 100;
                                }
                            }
                            $deposit_due = $deposit_due + (($accom_price * $courseAccomodation) / 100);
                        }


                        //Get the price after acccomodation Registration commission and discount
                        if (isset($accom_reg_fee) && $accom_reg_fee != '') {
                            if (isset($courseAccomodation_reg_fee) && $courseAccomodation_reg_fee != '') {
                                if (isset($courseAccomodation_reg_fee_dis) && $courseAccomodation_reg_fee_dis != '') {
                                    $courseAccomodation_reg_fee = $courseAccomodation_reg_fee - $courseAccomodation_reg_fee_dis;
                                    $discount_arrya[] = array(
                                        'class' => 'accommodation_reg_discount',
                                        'key' => $courseAccomodation_reg_fee_dis . '% discount',
                                        'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($accom_reg_fee) ? $accom_reg_fee : 0) * $courseAccomodation_reg_fee_dis / 100), 2));
                                    $price = $price - (isset($accom_reg_fee) ? $accom_reg_fee : 0) * $courseAccomodation_reg_fee_dis / 100;
                                }
                            }
                            $deposit_due = $deposit_due + (($accom_reg_fee * $courseAccomodation_reg_fee) / 100);
                        }
                    }
                    //----------END Check conditions for accomodation option select----------//
                }
            }
        
            //Extrafee option----------
            $rss_arr['Extra_fee'] = array();
            $fee_array = array();
            $extra_fee = $this->InstituteExtraFee->find('all', array('conditions' => array('AND' => array('InstituteExtraFee.institute_id' => $coursetype['CourseType']['institute_id'], 'InstituteExtraFee.published' => 1))));

            if (!empty($extra_fee)) {
                foreach ($extra_fee as $fee) {
                    if ($fee['InstituteExtraFee']['type'] == 0) {
                        $fee_array[] = array('key' => $fee['InstituteExtraFee']['title'],
                            'price' => $this->Session->read('CURRENCY') . ' ' . $this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $fee['InstituteExtraFee']['price'])
                        );
                        $price = $price + $fee['InstituteExtraFee']['price'];
                    }
                }
                // $rss_arr['Extra_fee']=$fee_array; 
            }
           
            $accommodation_reg_price = (isset($accomodations['AccomodationPrice']['placement_fee']) ? $accomodations['AccomodationPrice']['placement_fee'] : 0);
            $price = $price + (isset($accomodations['AccomodationPrice']['placement_fee']) ? $accomodations['AccomodationPrice']['placement_fee'] : 0);

            //Get the registration price
            if (isset($courseComReg) && $courseComReg != '') {
                if ($this->request->query['setVal'] == 'no') {
                    $institueData['inscription_fee'] = $institueData['inscription_fee'];
                    if (isset($courseComReg_dis) && $courseComReg_dis != '') {
                        $courseComReg = $courseComReg - $courseComReg_dis;
                        $price = $price - ((isset($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg_dis / 100);
                        $discount_arrya[] = array(
                            'class' => 'course_reg_discount',
                            'key' => $courseComReg_dis . '% discount',
                            'value' => $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), (isset($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg_dis / 100), 2));
                    }
                } else {
                    $institueData['inscription_fee'] = 0;
                }
                $deposit_due = $deposit_due + (((isset($institueData['inscription_fee']) ? $institueData['inscription_fee'] : 0) * $courseComReg) / 100);
            }
        }
        
        if ($this->request->query['setVal'] == 'no') {
            $reg_fee = $institueData['inscription_fee'];
        } else {
            $reg_fee = 0;
        }
        //$reg_fee=$this->Institute->exchange_rate_convert($this->Session->read('CURRENCY'),'EUR',$institueData['inscription_fee']);
        $price = $reg_fee + $price;
        //Price Convert
        $deposit_due_eur = 0;
        $CURRENT_CURRENCY = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $price), 2);

        $real_currency = $this->Currency->find('first', array('conditions' => array('Currency.id' => $coursetype['Institute']['currency_id'])));
        $PAID_CURRENCY = $real_currency['Currency']['currrency_symbol'] . number_format($price, 2);

        $week_price = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $disscount_less_weekPrice), 2);
        $accom_price = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $accom_price), 2);
        $accommodation_reg_price = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $accommodation_reg_price), 2);
        $deposit_due_eur = '€ ' . number_format($this->Institute->exchange_rate_convert($currency_name, 'EUR', $deposit_due), 2);
        $deposit_due = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $deposit_due), 2);
        $discount_by_me = $this->Session->read('CURRENCY_SYMBOL') . number_format($this->Institute->exchange_rate_convert($currency_name, $this->Session->read('CURRENCY'), $discount_by_me), 2);
        $reg_fee = $this->Session->read('CURRENCY_SYMBOL') . ' ' . number_format($this->Institute->exchange_rate_convert($this->Session->read('CURRENCY'), 'EUR', $institueData['inscription_fee']), 2);
        $rss_arr = array('msg' => 'success', 'price' => array('CURRENT_CURRENCY' => $CURRENT_CURRENCY, 'PAID_CURRENCY' => $PAID_CURRENCY, 'WEEK_PRICE' => $week_price, 'ACCOM_PRICE' => $accom_price, 'ACCOM_REG_PRICE' => $accommodation_reg_price, 'DEPOSIT_NOW' => $deposit_due, 'DEPOSIT_NOW_EUR' => $deposit_due_eur, 'DISCOUNT_BY_ME' => $discount_by_me, 'Extra_fee' => $fee_array, 'ref_fee' => $reg_fee, 'discount_arr' => $discount_arrya));
        //debug($rss_arr);exit;
        echo json_encode($rss_arr);
        die;
    }

    /*
     * Function to send online ask question to admin
     */

    public function send_online_question() {

        $rss_arr = array('msg' => 'failure');
        if (isset($this->request->query) && !empty($this->request->query)) {
            $this->loadModel('AskQuestion');
            $this->loadModel('Institute');
            $data = $this->request->query['data'];
            if ($this->AskQuestion->save($data)) {
                //get the institute name
                $school_name = '';
                $institute = $this->Institute->find('first', array(
                    'conditions' => array(
                        'Institute.id' => $data['AskQuestion']['institute_id']
                    ),
                    'fields' => array('Institute.title', 'Institute.enrollment', 'Institute.listing_type')
                ));
                if (!empty($institute)) {
                    $school_name = $institute['Institute']['title'];
                }

                //SENDING THE MAIL
                $contact = json_decode($institute['Institute']['enrollment'], true);

                $this->loadModel('EmailTemplate');
                $srch_array = array("{{name}}" => $data['AskQuestion']['name'], "{{email}}" => $data['AskQuestion']['email'], "{{message}}" => $data['AskQuestion']['message'], "{{school_name}}" => $school_name);
                $email_values = $this->EmailTemplate->getvalues('ask_question', $srch_array);
                $to_emailid = $institute['Institute']['listing_type'] != 2 ? $email_values['reply_to'] : $contact['enr_email'];

                $this->Email->from = $data['AskQuestion']['name'] . ' <' . $data['AskQuestion']['email'] . '>';
                $this->Email->to = $to_emailid;
                $this->Email->subject = str_replace('{{school_name}}', $school_name, $email_values['subject']);
                $this->Email->sendAs = 'html';
                if (!empty($email_values['cci'])) {
                    $this->Email->cc = array($email_values['cci']);
                }

                $this->Email->send($email_values['content']);
                $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
            }
        }
        echo json_encode($rss_arr);
        die;
    }

    /*
     * Function to send message to friend
     */

    public function send_message() {

        $this->layout = 'ajax';
        $rss_arr = array('msg' => 'failure');
        if (isset($this->request->query) && !empty($this->request->query)) {

            $data = $this->request->query['data'];


            //SENDING THE MAIL
            $this->loadModel('EmailTemplate');
            $srch_array = array("{{Your_name}}" => $data['Message']['name'], "{{email}}" => $data['Message']['email'], "{{url}}" => $data['Message']['url'], '{{meta_title}}' => $data['Message']['meta_title']);
            $email_values = $this->EmailTemplate->getvalues('mail_to_friend', $srch_array, $srch_array);
            $to_emailid = $data['Message']['email'];
            $this->Email->from = $email_values['from_email'] . ' <' . $email_values['from_email'] . '>';
            $this->Email->to = $to_emailid;
            $this->Email->subject = $email_values['subject'];
            $this->Email->sendAs = 'html';
            if (!empty($email_values['cci'])) {
                $this->Email->cc = array($email_values['cci']);
            }
            $this->Email->send($email_values['content']);
            $rss_arr = array('msg' => 'success', 'message' => "Thank you! We'll get back to you shortly.");
        }
        echo json_encode($rss_arr);
        die;
    }

    public function price_calculation($next_price, $current_price, $week_val, $start_date, $end_date, $price, $high_season_to, $high_season_from) {

        $REG_PRICE = $price;
        $week_price = 0;

        switch ($next_price['CoursePrice']['rule']) {
            case 2:
                $price_chart = json_decode($current_price['price_chart'], true);
                $price_chart_cumulative = json_decode($current_price['price_chart_cumulative'], true);
                //Conditions for getting price from all year price chart
                if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                    $price = $price + $price_chart_cumulative['all_year_chart'][$week_val];
                    $week_price = $price_chart_cumulative['all_year_chart'][$week_val];
                } else {
                    if (!empty($start_date)) {
                        /* ----------------------------------------------- */
                        $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $week_val . " week")));
                        $high_season_week = 0;
                        $low_season_week = 0;
                        $j = 0;
                        $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                        for ($i = strtotime($start_date); $i < $end_date;) {
                            if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                $high_season_week++;
                            } else {
                                $low_season_week++;
                            }
                            $j++;
                            $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                            $last_date = $i;
                        }

                        $REG_PRICE = $price;
                        if ($high_season_week > 0) {
                            if ($current_price['price_calculation'] == 0) {
                                $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                            } else {
                                for ($a = 1; $a <= $high_season_week; $a++) {
                                    $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                    $week_price = $week_price + $price_chart['high_chart'][$a];
                                }
                            }
                        }
                        if ($low_season_week > 0) {


                            if ($high_season_week == 0) {

                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                } else {
                                    for ($a = 1; $a <= $low_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            } else {

                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                } else {
                                    for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            }
                        }
                        /* ------------------------------------------------------------------ */
                    }
                }
                break;
            case 1:
                $price_chart = json_decode($next_price['CoursePrice']['price_chart'], true);
                $price_chart_cumulative = json_decode($next_price['CoursePrice']['price_chart_cumulative'], true);

                //Conditions for getting price from all year price chart
                if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                    $price = $price + $price_chart_cumulative['all_year_chart'][$week_val];
                    $week_price = $price_chart_cumulative['all_year_chart'][$week_val];
                } else {
                    if (!empty($start_date)) {

                        /* ----------------------------------------------- */
                        $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $week_val . " week")));
                        $high_season_week = 0;
                        $low_season_week = 0;
                        $j = 0;
                        $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                        for ($i = strtotime($start_date); $i < $end_date;) {
                            if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                $high_season_week++;
                            } else {
                                $low_season_week++;
                            }
                            $j++;
                            $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                            $last_date = $i;
                        }

                        $REG_PRICE = $price;
                        if ($high_season_week > 0) {
                            if ($next_price['price_calculation'] == 0) {
                                $price = $REG_PRICE +  $price_chart_cumulative['high_chart'][$high_season_week];
                                $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                            } else {
                                for ($a = 1; $a <= $high_season_week; $a++) {
                                    $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                    $week_price = $week_price + $price_chart['high_chart'][$a];
                                }
                            }
                        }
                        if ($low_season_week > 0) {


                            if ($high_season_week == 0) {

                                if ($next_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE +  $price_chart_cumulative['low_chart'][$low_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                } else {
                                    for ($a = 1; $a <= $low_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            } else {

                                if ($next_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE +($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                } else {
                                    for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            }
                        }
                        /* ------------------------------------------------------------------ */
                    }
                }
                break;
            case 3:
                $j = 1;
                $next_week = 0;
                $pre_week = 0;
                $last_date = $start_date;

                for ($i = strtotime($start_date); $i <= strtotime($end_date);) {

                    if ($i > strtotime($next_price['CoursePrice']['starting_date']) && $last_date >= strtotime($next_price['CoursePrice']['starting_date'])) {
                        $next_week++;
                    } else {
                        $pre_week++;
                    }
                    $last_date = $i;
                    $j++;
                    $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                }
                $price_chart = json_decode($current_price['price_chart'], true);
                $price_chart_cumulative = json_decode($current_price['price_chart_cumulative'], true);

                //Conditions for getting price from all year price chart

                if ($pre_week > 0) {

                    if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                        $price = $price + $price_chart_cumulative['all_year_chart'][$pre_week];
                        $week_price = $price_chart_cumulative['all_year_chart'][$pre_week];
                    } else {
                        if (!empty($start_date)) {

                            /* ----------------------------------------------- */
                            $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $pre_week . " week")));
                            $high_season_week = 0;
                            $low_season_week = 0;
                            $j = 0;
                            $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));

                            for ($i = strtotime($start_date); $i < $end_date;) {

                                if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                    $high_season_week++;
                                } else {
                                    $low_season_week++;
                                }
                                $j++;
                                $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                $last_date = $i;
                            }


                            $REG_PRICE = $price;
                            if ($high_season_week > 0) {
                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE +  $price_chart_cumulative['high_chart'][$high_season_week];
                                    $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                                } else {
                                    for ($a = 1; $a <= $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                        $week_price = $week_price + $price_chart['high_chart'][$a];
                                    }
                                }
                            }


                            if ($low_season_week > 0) {

                                if ($high_season_week == 0) {

                                    if ($current_price['CoursePrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                        $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                    } else {
                                        for ($a = 1; $a <= $low_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                } else {

                                    if ($current_price['CoursePrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE +  ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                        $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    } else {
                                        for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                }
                            }

                            /* ------------------------------------------------------------------ */
                        }
                    }
                }

                if ($next_week > 0) {

                    $price_chart = json_decode($next_price['CoursePrice']['price_chart'], true);
                    $price_chart_cumulative = json_decode($next_price['CoursePrice']['price_chart_cumulative'], true);
                    //Conditions for getting price from all year price chart
                    if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                        $weeks = $next_week;
                        $price = $price + $price_chart_cumulative['all_year_chart'][$next_week];
                        $week_price = $week_price + $price_chart_cumulative['all_year_chart'][$next_week];
                    } else {
                        if (!empty($start_date)) {

                            /* ----------------------------------------------- */
                            if (isset($end_date)) {
                                $start_date = date('d-m-Y', $end_date);
                            }


                            $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $next_week . " week")));
                            $high_season_week = 0;
                            $low_season_week = 0;
                            $j = 0;
                            $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                            for ($i = strtotime($start_date); $i < $end_date;) {
                                if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                    $high_season_week++;
                                } else {
                                    $low_season_week++;
                                }
                                $j++;
                                $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                $last_date = $i;
                            }



                            $REG_PRICE = $price;
                            if ($high_season_week > 0) {
                                if ($next_price['CoursePrice']['price_calculation'] == 0) {
                                    $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['high_chart'][$high_season_week];
                                } else {
                                    for ($a = 1; $a <= $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                        $week_price = $week_price + $price_chart['high_chart'][$a];
                                    }
                                }
                            }


                            if ($low_season_week > 0) {

                                if ($high_season_week == 0) {

                                    if ($next_price['CoursePrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                        $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                    } else {
                                        for ($a = 1; $a <= $low_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                } else {

                                    if ($next_price['CoursePrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                        $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    } else {
                                        for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                }
                            }

                            /* ------------------------------------------------------------------ */
                        }
                    }
                }
                break;
        }

        $response = array(
            'price' => $price,
            'week_price' => $week_price
        );

        return $response;
    }
    
    
     public function price_calculation_accomodation($next_price, $current_price, $week_val, $start_date, $end_date, $price, $high_season_to, $high_season_from) {

        $REG_PRICE = $price;
        $week_price = 0;

        switch ($next_price['AccomodationPrice']['rule']) {
            case 2:
                $price_chart = json_decode($current_price['price_chart'], true);
                $price_chart_cumulative = json_decode($current_price['price_chart_cumulative'], true);
                //Conditions for getting price from all year price chart
                if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                    $price = $price + $price_chart_cumulative['all_year_chart'][$week_val];
                    $week_price = $price_chart_cumulative['all_year_chart'][$week_val];
                } else {
                    if (!empty($start_date)) {
                        /* ----------------------------------------------- */
                        $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $week_val . " week")));
                        $high_season_week = 0;
                        $low_season_week = 0;
                        $j = 0;
                        $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                        for ($i = strtotime($start_date); $i < $end_date;) {
                            if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                $high_season_week++;
                            } else {
                                $low_season_week++;
                            }
                            $j++;
                            $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                            $last_date = $i;
                        }

                        $REG_PRICE = $price;
                        if ($high_season_week > 0) {
                            if ($current_price['price_calculation'] == 0) {
                                $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                            } else {
                                for ($a = 1; $a <= $high_season_week; $a++) {
                                    $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                    $week_price = $week_price + $price_chart['high_chart'][$a];
                                }
                            }
                        }
                        if ($low_season_week > 0) {


                            if ($high_season_week == 0) {

                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE +$price_chart_cumulative['low_chart'][$low_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                } else {
                                    for ($a = 1; $a <= $low_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            } else {

                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                } else {
                                    for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            }
                        }
                        /* ------------------------------------------------------------------ */
                    }
                }
                break;
            case 1:
                $price_chart = json_decode($next_price['AccomodationPrice']['price_chart'], true);
                $price_chart_cumulative = json_decode($next_price['AccomodationPrice']['price_chart_cumulative'], true);

                //Conditions for getting price from all year price chart
                if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                    $price = $price + $price_chart_cumulative['all_year_chart'][$week_val];
                    $week_price = $price_chart_cumulative['all_year_chart'][$week_val];
                } else {
                    if (!empty($start_date)) {

                        /* ----------------------------------------------- */
                        $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $week_val . " week")));
                        $high_season_week = 0;
                        $low_season_week = 0;
                        $j = 0;
                        $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                        for ($i = strtotime($start_date); $i < $end_date;) {
                            if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                $high_season_week++;
                            } else {
                                $low_season_week++;
                            }
                            $j++;
                            $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                            $last_date = $i;
                        }

                        $REG_PRICE = $price;
                        if ($high_season_week > 0) {
                            if ($next_price['price_calculation'] == 0) {
                                $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                            } else {
                                for ($a = 1; $a <= $high_season_week; $a++) {
                                    $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                    $week_price = $week_price + $price_chart['high_chart'][$a];
                                }
                            }
                        }
                        if ($low_season_week > 0) {


                            if ($high_season_week == 0) {

                                if ($next_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE +  $price_chart_cumulative['low_chart'][$low_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                } else {
                                    for ($a = 1; $a <= $low_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            } else {

                                if ($next_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                } else {
                                    for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                        $week_price = $week_price + $price_chart['low_chart'][$a];
                                    }
                                }
                            }
                        }
                        /* ------------------------------------------------------------------ */
                    }
                }
                break;
            case 3:
                $j = 1;
                $next_week = 0;
                $pre_week = 0;
                $last_date = $start_date;

                for ($i = strtotime($start_date); $i <= strtotime($end_date);) {

                    if ($i > strtotime($next_price['AccomodationPrice']['starting_date']) && $last_date >= strtotime($next_price['AccomodationPrice']['starting_date'])) {
                        $next_week++;
                    } else {
                        $pre_week++;
                    }
                    $last_date = $i;
                    $j++;
                    $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                }
                $price_chart = json_decode($current_price['price_chart'], true);
                $price_chart_cumulative = json_decode($current_price['price_chart_cumulative'], true);

                //Conditions for getting price from all year price chart

                if ($pre_week > 0) {

                    if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                        $price = $price + $price_chart_cumulative['all_year_chart'][$pre_week];
                        $week_price = $price_chart_cumulative['all_year_chart'][$pre_week];
                    } else {
                        if (!empty($start_date)) {

                            /* ----------------------------------------------- */
                            $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $pre_week . " week")));
                            $high_season_week = 0;
                            $low_season_week = 0;
                            $j = 0;
                            $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));

                            for ($i = strtotime($start_date); $i < $end_date;) {

                                if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                    $high_season_week++;
                                } else {
                                    $low_season_week++;
                                }
                                $j++;
                                $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                $last_date = $i;
                            }


                            $REG_PRICE = $price;
                            if ($high_season_week > 0) {
                                if ($current_price['price_calculation'] == 0) {
                                    $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                    $week_price = $price_chart_cumulative['high_chart'][$high_season_week];
                                } else {
                                    for ($a = 1; $a <= $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                        $week_price = $week_price + $price_chart['high_chart'][$a];
                                    }
                                }
                            }


                            if ($low_season_week > 0) {

                                if ($high_season_week == 0) {

                                    if ($current_price['AccomodationPrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE + $price_chart_cumulative['low_chart'][$low_season_week];
                                        $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                    } else {
                                        for ($a = 1; $a <= $low_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                } else {

                                    if ($current_price['AccomodationPrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE +  ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                        $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    } else {
                                        for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                }
                            }

                            /* ------------------------------------------------------------------ */
                        }
                    }
                }

                if ($next_week > 0) {

                    $price_chart = json_decode($next_price['AccomodationPrice']['price_chart'], true);
                    $price_chart_cumulative = json_decode($next_price['AccomodationPrice']['price_chart_cumulative'], true);
                    //Conditions for getting price from all year price chart
                    if (!empty($price_chart) && !empty($price_chart['all_year_chart'])) {
                        $weeks = $next_week;
                        $price = $price + $price_chart_cumulative['all_year_chart'][$next_week];
                        $week_price = $week_price + $price_chart_cumulative['all_year_chart'][$next_week];
                    } else {
                        if (!empty($start_date)) {

                            /* ----------------------------------------------- */
                            if (isset($end_date)) {
                                $start_date = date('d-m-Y', $end_date);
                            }


                            $end_date = strtotime(date("d-m-Y", strtotime($start_date . " +" . $next_week . " week")));
                            $high_season_week = 0;
                            $low_season_week = 0;
                            $j = 0;
                            $last_date = strtotime(date("d-m-Y", strtotime($start_date . " +1 week")));
                            for ($i = strtotime($start_date); $i < $end_date;) {
                                if ($i >= strtotime($high_season_from) && $last_date <= strtotime($high_season_to)) {
                                    $high_season_week++;
                                } else {
                                    $low_season_week++;
                                }
                                $j++;
                                $i = strtotime(date("d-m-Y", strtotime($start_date . " +" . $j . " week")));
                                $last_date = $i;
                            }



                            $REG_PRICE = $price;
                            if ($high_season_week > 0) {
                                if ($next_price['AccomodationPrice']['price_calculation'] == 0) {
                                    $price = $REG_PRICE + $price_chart_cumulative['high_chart'][$high_season_week];
                                    $week_price = $week_price + $price_chart_cumulative['high_chart'][$high_season_week];
                                } else {
                                    for ($a = 1; $a <= $high_season_week; $a++) {
                                        $price = $REG_PRICE + $price_chart['high_chart'][$a];
                                        $week_price = $week_price + $price_chart['high_chart'][$a];
                                    }
                                }
                            }


                            if ($low_season_week > 0) {

                                if ($high_season_week ==0) {

                                    if ($next_price['AccomodationPrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE +  $price_chart_cumulative['low_chart'][$low_season_week];
                                        $week_price = $week_price + $price_chart_cumulative['low_chart'][$low_season_week];
                                    } else {
                                        for ($a = 1; $a <= $low_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                } else {

                                    if ($next_price['AccomodationPrice']['price_calculation'] == 0) {
                                        $price = $REG_PRICE + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                        $week_price = $week_price + ($price_chart['low_chart'][$low_season_week + $high_season_week] * $low_season_week);
                                    } else {
                                        for ($a = $high_season_week + 1; $a <= $low_season_week + $high_season_week; $a++) {
                                            $price = $REG_PRICE + $price_chart['low_chart'][$a];
                                            $week_price = $week_price + $price_chart['low_chart'][$a];
                                        }
                                    }
                                }
                            }

                            /* ------------------------------------------------------------------ */
                        }
                    }
                }
                break;
        }

        $response = array(
            'price' => $price,
            'week_price' => $week_price
        );

        return $response;
    }


}
