<?php
/*
 * Name : Homes
 * Created : 3 Apr 2013
 * Purpose : Homepage controller
 * Author : Ritish
 */ 
class HomesController extends AppController {
	
	var $name = 'homes';
	var $uses = array('HomepageBlockText', 'Testimonial', 'HomepageBanner');
	
	/*
	 * Purpose: TO fetch teh dynamic content for Home page and to set the home page
	 * Created : 3 Apr 2013
	 * Author: Ritish
	 */
	function index()
	{
		$this->loadModel('Destination');
		$this->loadModel('Language');
		$this->loadModel('Institute');
		
		$this->layout = 'home';
		$blocks = $this->HomepageBlockText->find('all', array('order' => 'id asc'));
		$testimonials = $this->Testimonial->find('all', array('conditions' => array('Testimonial.status' => 'activate'), 'order' => 'id desc'));
		$row_banner = $this->HomepageBanner->find('first');
		
		$ARR_LANGUAGES = $this->Language->find('list', array('fields' => array('id', 'title')));
		$ARR_DESTINATIONS = $this->Destination->find('list', array('fields' => array('country_id', 'name')));
		
		$result_inst = $this->Institute->find('all', array('conditions' => array('Institute.published' => 'Yes'), 'order' => 'id desc'));
		
		$ARR_WEEKS = Configure::read('ARR_WEEKS');
		
		$this->set(compact(array('blocks', 'testimonials', 'row_banner', 'ARR_LANGUAGES', 'ARR_DESTINATIONS', 'ARR_WEEKS', 'result_inst')));
	}
	
}
