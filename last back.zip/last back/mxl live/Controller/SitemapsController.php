<?php
class SitemapsController extends AppController{

    var $name = 'Sitemaps';
    var $uses = array('Institute','Language','Country','Destination','Cms');
 

    function index (){  
        //$this->layout = 'dssdslt';
        configure::write('debug',2);
        
        $cms=$this->Cms->find('all');
       // $link[]=//array('link'=>FULL_BASE_URL.$this->webroot);
        foreach($cms as $page){
            if($page['Cms']['footer-link']!=1){
                $link[]=array('loc'=>'cms/index/'.$page['Cms']['url_key'],
                    'lastmod'=>date('Y-m-d',  strtotime($page['Cms']['modified'])),
                    'changefreq'=>'monthly'
                    );
            }
            else{
               $link[]=array('loc'=>$page['Cms']['url_key'],
                     'lastmod'=>date('Y-m-d',  strtotime($page['Cms']['modified'])),
                  'changefreq'=>'monthly'
                    ); 
            }
        }
        $lanuage_ids=$this->Institute->find('list',array('conditions'=>array('Institute.published'=>'Yes'),'fields'=>array('Institute.language_id'),'group'=>'Institute.language_id'));
        $country_ids=$this->Institute->find('list',array('conditions'=>array('Institute.published'=>'Yes'),'fields'=>array('Institute.country_id'),'group'=>'Institute.country_id'));
        $destination_ids=$this->Institute->find('list',array('conditions'=>array('Institute.published'=>'Yes'),'fields'=>array('Institute.destination_id'),'group'=>'Institute.destination_id'));
        $this->Institute->recursive=-1;
        $institute=$this->Institute->find('all',array('conditions'=>array('Institute.published'=>'Yes'),'fields'=>array('Institute.id','Institute.country_id','Institute.destination_id','Institute.language_id','Institute.slug','Institute.modified'),'group'=>array('Institute.country_id','Institute.destination_id','Institute.language_id')));
        //debug($institute);
	$ARR_LANGUAGES2= $this->Language->find('list', array('conditions'=>array('id'=>$lanuage_ids),'fields' => array('title','id')));
        $contain=array('Destination'=>array('fields'=>array('id','name','slug')));
        $countries=$this->Country->find('all',array('conditions'=>array('Country.id'=>$country_ids),'contain'=>$contain,'fields'=>array('Country.id','Country.name','Country.slug')));
         
        foreach($ARR_LANGUAGES2 as $key=>$language){
            $link[]=array('loc'=>'learn-'.strtolower($key).'-abroad',
                
                  'changefreq'=>'monthly'
                    ); 
            $token_country=0;
            foreach($countries as $country){
                foreach($institute as $inst){
                    if($inst['Institute']['country_id']==$country['Country']['id'] && $inst['Institute']['language_id']==$language && $token_country==0)
                    {
                        $link[]=array('loc'=>'learn-'.strtolower($key).'-in-'.$country['Country']['slug'],
                            'lastmod'=>date('Y-m-d',  strtotime($inst['Institute']['modified'])),
                            'changefreq'=>'monthly'
                              ); 
                        $token_country=1;
                        
                    }
                    foreach($country['Destination'] as $destination){
                         if($inst['Institute']['country_id']==$country['Country']['id'] && $inst['Institute']['language_id']==$language && $inst['Institute']['destination_id']==$destination['id']){
                              $link[]=array('loc'=>'learn-'.strtolower($key).'-in-'.$destination['slug'].'-'.$country['Country']['slug'],
                            'lastmod'=>date('Y-m-d',  strtotime($inst['Institute']['modified'])),
                                  'changefreq'=>'monthly'
                              ); 
                         }
                    }
                    
                }
            }
        }
        
        
        
        foreach ($institute as $ins_page)
        {
            $link[]=array('loc'=>$ins_page['Institute']['slug'],
                   'lastmod'=>date('Y-m-d',  strtotime($ins_page['Institute']['modified'])),
                'changefreq'=>'monthly'
                );
        }
        
        $destination_list=$this->Institute->get_destination_id($ARR_LANGUAGES2);
      // debug($link)   ;exit;
        $this->set('url',$link);
 
        //$this->set('_serialize', array('url'));
         
       // $this->set('_rootNode','uslset');
       
       
    }
}

?>
