 <?php
 App::uses('Component', 'Controller'); 

class LanguageComponent extends Component {
	

	public function translate(){
	$apiKey = 'AIzaSyCYRXMMOVAQj-9Km5PW8FffSaVkDI16Clk';
    $text = 'Hello world!';
    $url = 'https://www.googleapis.com/language/translate/v2?key=' . $apiKey . '&q=' . rawurlencode($text) . '&source=en&target=fr';

    $handle = curl_init($url);
    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($handle);                 
    $responseDecoded = json_decode($response, true);
    debug($responseDecoded);exit;
    curl_close($handle);

    echo 'Source: ' . $text . '<br>';
    echo 'Translation: ' . $responseDecoded['data']['translations'][0]['translatedText'];
		}

}


?> 
