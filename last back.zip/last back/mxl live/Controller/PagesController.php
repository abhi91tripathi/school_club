<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController {

/**
 * This controller does not use a model
 *
 * @var array
 */
	public $uses = array('HomepageBlockText', 'Testimonial','HomepageBanner');

/**
 * Displays a view
 *
 * @param mixed What page to display
 * @return void
 * @throws NotFoundException When the view file could not be found
 *	or MissingViewException in debug mode.
 */
	public function display() {
		$path = func_get_args();

		$count = count($path);
		if (!$count) {
			return $this->redirect('/');
		}
		$page = $subpage = $title_for_layout = null;

		if (!empty($path[0])) {
			$page = $path[0];
		}
		if (!empty($path[1])) {
			$subpage = $path[1];
		}
		if (!empty($path[$count - 1])) {
			$title_for_layout = Inflector::humanize($path[$count - 1]);
		}
		//$this->set(compact('page', 'subpage', 'title_for_layout'));

		try {
			$this->render(implode('/', $path));
		} catch (MissingViewException $e) {
			if (Configure::read('debug')) {
				throw $e;
			}
			throw new NotFoundException();
		}
            
	}
        public function home(){
         
                
                $this->loadModel('Destination');
                $this->loadModel('Language');
		         $this->loadModel('Institute');
                $this->loadModel('Country');
				$this->loadModel('AffiliationLogo');
				$this->loadModel('HomepageBottomText');
		       
                $this->layout = 'home';
		        $logo_list=$this->AffiliationLogo->find('all');
				$blocks = $this->HomepageBlockText->find('all', array('order' => 'id asc'));
				$bottom_text = $this->HomepageBottomText->find('first');
				$testimonials = $this->Testimonial->find('all', array('conditions' => array('Testimonial.status' => 'activate'), 'order' => 'id desc'));
				$row_banner = $this->HomepageBanner->find('first');
				$ARR_LANGUAGES1=array('English'=>'English',
				'Spanish'=>'Spanish',
				'French'=>'French',
				'Italian'=>'Italian',
				'German'=>'German',
				'----------------------------------'
				);
				
				$lanuage_ids=$this->Institute->find('list',array('conditions'=>array('Institute.published'=>'Yes'),'fields'=>array('Institute.language_id')));
				$ARR_LANGUAGES2= $this->Language->find('list', array('conditions'=>array('id'=>$lanuage_ids),'fields' => array('title','title')));
				$ARR_LANGUAGES=array_merge($ARR_LANGUAGES1,$ARR_LANGUAGES2);
				
				$ARR_DESTINATIONS = $this->Country->get_country();
						 $result_inst = $this->Institute->find('all', array('conditions' => array('Institute.published' => 'Yes'), 'order' => 'Institute.id desc'));
				$ARR_WEEKS = Configure::read('ARR_WEEKS');
				$view='home';
                                $LAYOUT_META_TITLE = 'Book your language course at the best price | Maxlanguages.com';
                                $LAYOUT_META_DESCRIPTION = "Search, compare & book your language course abroad in schools worldwide. Best price guaranteed or we'll refund the difference to you.";
                                $og_image=SITE_URL."admin/img/homepage_block_images/" . $row_banner['HomepageBanner']['image'];
                                $this->set(compact(array('blocks', 'testimonials', 'row_banner', 'ARR_LANGUAGES', 'ARR_DESTINATIONS', 'ARR_WEEKS', 'result_inst','logo_list','bottom_text','view','LAYOUT_META_TITLE','LAYOUT_META_DESCRIPTION','og_image'))); 	
		}

      /**
         *Purpose:Get desitnatio on language select
         * created on:5 August
         * @param:Language name
         * @Author: Abhishek TRipathi 
         */
        //
        
      public function get_destination($name=null){
      	$this->loadModel('Language');
		$this->loadModel('Institute');
		$this->loadModel('Country');
      	if($this->request->is('post'))
		{
			$language_name=$this->request->data['language_name'];
			$language_id=$this->Language->get_language_id($language_name);
			
			$countries_list=$this->Institute->get_country_id($language_id);
			$destination_list=$this->Institute->get_destination_id($language_id);
			$html='<option  selected="selected" data-foo="0" value="">Any Destination</option>';
			if(count($countries_list)){
				
			$destination_list= $this->Country->get_country($countries_list,$destination_list);
			foreach ($destination_list as $value) {
				$html.='<option data-foo="'.$value['Country']['flag_image'].'" class="country-name-opt" label="'.strtolower($value['Country']['name']).'" value="'.strtolower($value['Country']['slug']).'"><b><img src="'.SITE_URL.'/files/country_flag/'.$value['Country']['flag_image'].'" width="20px">'.$value['Country']['name'].'</b>';
                                 foreach ($value['Destination'] as $destination) {  
                                         $html.='<option data-foo="0" value="'.strtolower($destination['slug']).'-'.strtolower($value['Country']['slug']).'">&nbsp;&nbsp;&nbsp;'.$destination['name'].'</option>' ;
								 } 
                                    $html.='</option>'; 
			}
								
			
		}
			echo $html; exit;
      }  
	  }
          
          /**
         * Purpose:Currency conversion
         * created on:11/11/14
         * @param:Currency code
         * @Author: Abhishek TRipathi 
         */
        //
        public function conversion($currency_code=null){
            if($currency_code!=null)
            {
                $this->Session->write('CURRENCY',$currency_code);
                $this->loadModel('Currency');
                $symbol=$this->Currency->find('first',array('conditions'=>array('Currency.currency_code'=>$currency_code),'fields'=>array('currency_code','currrency_symbol')));
                $this->Session->write('CURRENCY_SYMBOL',$symbol['Currency']['currrency_symbol']);
                echo 'success';
                exit;
            }
        }
        /**
         * Purpose:cse page
         * created on:6/08/15
         * @param:query string
         * @Author: Abhishek TRipathi 
         */
        //
        public function search(){
            
        }
        
}
