<?php
/**
 * Project : img180.com
 * Author : Nitin
 * Creation Date : 16 Oct 2013
 * Description : FOR AD (add, edit & manage)
 */
class AccomodationController extends AppController {

	var $uses = array('AccomodationType', 'Accomodation','Institute');
	function beforeFilter() {
		parent::beforeFilter();
		$this -> layout = "school_info";

	}

	/**
	 * Purpose : Listing of courses
	 * Created on : 6 May 2014
	 * Author : Rupesh Sharma
	 */
	function index() {
		$cond_arr = array();
		$this -> paginate = array('conditions' => $cond_arr, 'limit' => (!empty($this -> passedArgs['count']) ? $this -> passedArgs['count'] : ADMIN_NUM_PER_PAGE), 'order' => array('Accomodation.id' => 'desc'));

		$result_arr = $this -> paginate('Accomodation');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');
		$view_title = 'Manage Accommodation';
		$this -> set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
		$this -> render('list');
	}

	/**
	 * Purpose : add main course for institue
	 * Created on : 6 may 2014
	 * Author : Rupesh Sharma
	 */
	function add() {
		$errors = array();
		$add_errors = array();
		$error_flag = false;
		if (!empty($this -> data)) {

			$data_arr = $this -> data;
			$this -> Accomodation -> save($data_arr);
			$this -> Session -> setFlash(__('Added successfully.'), 'flash_success');
			$this -> redirect(array('controller' => 'accomodation', 'action' => 'index'));
		}

		$this -> set('view_title', 'Add Accommodation');
		$this -> set('errors', $errors);

	}

	/**
	 * Purpose : edit main course for institue
	 * Created on : 6 may 2014
	 * Author : Rupesh Sharma
	 */
	function edit($id) {
		$errors = array();
		$add_errors = array();
		$error_flag = false;
		$this -> Accomodation -> id = $id;
		if (!empty($this -> data)) {

			$data_arr = $this -> data;
			$this -> Accomodation -> save($data_arr);
			$this -> Session -> setFlash(__('Added successfully.'), 'flash_success');
			$this -> redirect(array('controller' => 'accomodation', 'action' => 'index'));
		}
		$this -> data = $this -> Accomodation -> findById($id);
		$this -> set('view_title', 'Add Accommodation');
		$this -> set('errors', $errors);
		$this -> render('add');
	}

	/**
	 * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE
	 * Created on : 6 May 2014
	 * Author : Rupesh Sharma
	 */
	function manage_actions() {
		if (count($this -> params['data'])) {
			$message = '';

			$ids = $this -> params['data']['list'];

			if (!empty($ids)) {
				$task = $this -> params['data']['task'];

				if ($task == "delete") {
					//$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

					$this -> Accomodation -> deleteAll(array('Accomodation.id' => $ids), true);
					$message = 'Deleted successfully.';
				} elseif ($task == "featured") {
					$this -> Accomodation -> updateAll(array('Accomodation.published' => "1"), array('Course.id' => $ids));
					$message = 'Activated successfully.';
				} elseif ($task == "unfeatured") {
					$this -> Accomodation -> updateAll(array('Accomodation.published' => "0"), array('Course.id' => $ids));
					$message = 'Inactivated successfully.';
				}
				 
				$this -> Session -> setFlash($message, 'flash_success');
			}

			$this -> redirect($this -> referer());
		}
		exit ;
	}

	/**
	 * Purpose : Listing of sub accomodation
	 * Created on : 15 May 2014
	 * Author : Rupesh Sharma
	 */
	function list_sub_accomodation($id) {
                          //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$id),'fields'=>array('mode')));
                           
                         if($mode['Institute']['mode']==1){
                        
            //------------mode check------------------------
		$cond_arr = array('AccomodationType.institute_id' => $id);
		$this -> set('institute_id', $id);

		$this -> AccomodationType -> bindModel(array('belongsTo' => array('Accomodation' => array('className' => 'Accomodation', 'foreignKey' => 'accomodation_id', 'fields' => array('title')))));

		if (isset($_GET['filter'])) {

			$fields = array_filter($_GET['filter']);
			foreach ($fields as $field_name => $value) {
				$cond_arr = array_merge($cond_arr, array('AccomodationType.' . $field_name . ' Like' => $value . '%'));
			}
		}

		$this -> paginate = array('conditions' => $cond_arr, 'limit' => (!empty($this -> passedArgs['count']) ? $this -> passedArgs['count'] : ADMIN_NUM_PER_PAGE), 'order' => array('AccomodationType.id' => 'desc'), 'recursive' => 3);

		$result_arr = $this -> paginate('AccomodationType');
		$ARR_FEATURED = Configure::read('ARR_FEATURED');

		$view_title = 'Manage Sub Accommodation';
		$this -> set(compact('result_arr', 'ARR_FEATURED', 'view_title'));
		$this -> render('list_sub_accomodation');
        } 
                else{
              $this->autoRender = false;
         $this->render('/Schools/mode');
        }
	}

	/**
	 * Purpose : add sub accomodation
	 * Created on : 15 may 2014
	 * Author : Rupesh Sharma
	 * modified on :9 june 2014
	 * by:Abhishek Tripathi
	 */
	function add_sub_accomodation($institute_id) {
            
                  //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$institute_id),'fields'=>array('mode')));
                           
                         if($mode['Institute']['mode']==1){
                         
            //------------mode check------------------------
		$this -> set('institute_id', $institute_id);
		$errors = array();
		$add_errors = array();
		$error_flag = false;
		$this -> loadModel('Accomodation');
		$this -> loadModel('AccomodationFacility');
		$this -> loadModel('Currency');
		$this->loadModel('Admin.Institute');
		$this -> loadModel('AccomodationPrice');
		$this -> loadModel('AccomodationTypeAccomodationFacility');
		$current_year = date('Y');
		$this -> set('current_year', $current_year);
		if (!empty($this -> data)) {
			$data_arr = $this -> data;
			 if(empty($data_arr['AccomodationType']['minimum_age']))
			 {
			 	$data_arr['AccomodationType']['minimum_age']=0;
			 }
			//debug($data_arr);exit;
			//get slug from name
			$slug = $this -> get_slug($data_arr['AccomodationType']['title']);
			$conditions = array("AccomodationType.slug" => $slug);
			$count = $this -> AccomodationType -> find('count', array('conditions' => $conditions));
			if ($count != 0) {
				$data_arr['AccomodationType']['slug'] = $this -> get_unique_slug($slug);
			} else {
				$data_arr['AccomodationType']['slug'] = $slug;
			}
			$data_arr['AccomodationType']['institute_id'] = $institute_id;
			if (!empty($_FILES['pdf']['name'])) {
				$data_arr['AccomodationType']['pdf'] = $this -> upload_file($institute_id, 'pdf');
			}
			//json encode

			//$data_arr['AccomodationType']['price_chart']=json_encode($this->request->data['AccomodationType']['price_chart']);
			$data_arr['AccomodationType']['available_range'] = json_encode($this -> request -> data['AccomodationType']['available_range']);
			$data_arr['AccomodationType']['journey_to_school'] = json_encode($this -> request -> data['AccomodationType']['journey_to_school']);
			$data_arr['AccomodationType']['check_in'] = json_encode($this -> request -> data['AccomodationType']['check_in']);
			$data_arr['AccomodationType']['check_out'] = json_encode($this -> request -> data['AccomodationType']['check_out']);
			if ($this -> AccomodationType -> save($data_arr)) {
				//saved price list
				$current_price_list = array('AccomodationPrice' => array('institute_id' => $institute_id, 'accomodation_types_id' => $this -> AccomodationType -> getlastInsertId(), 'price_chart' => json_encode($data_arr['AccomodationType']['current_year']['price_chart']), 'plan' => $data_arr['AccomodationType']['current_year']['plan'], 'min_no_weeks' => $data_arr['AccomodationType']['current_year']['min_no_weeks'], 'max_no_weeks' => $data_arr['AccomodationType']['current_year']['max_no_weeks'], 'year' => $current_year));
				$this -> AccomodationPrice -> create();
				$this -> AccomodationPrice -> save($current_price_list);

				//saved facility
				$accomodation_type_id = $this -> AccomodationType -> getLastInsertID();
				if (!empty($data_arr['AccomodationType']['facility_id'])) {
					$institute_facility;
					foreach ($data_arr['AccomodationType']['facility_id'] as $key => $value) {
						$institute_facility[] = array('accomodation_type_id' => $accomodation_type_id, 'accomodation_facility_id' => $value);
					}
					$this -> AccomodationTypeAccomodationFacility -> saveMany($institute_facility);
				}
				if(isset($this->request->data['save'])){
				$this->redirect(array('controller'=>'accomodation','action'=>'edit_sub_accomodation',$institute_id,$this->AccomodationType->getLastInsertId()));
                 $this->Session->setFlash(__('Save successfully.'), 'flash_success');
			}
			else{
				$this->redirect(array('controller'=>'Schools','action'=>'edit_form',$institute_id));
			            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
			}
			}
		}
		$board = array('Self service (No meals)', 'Breakfast', 'Half board (breakfast + 1 meal)', 'Full board (breakfast + lunch + dinner)', 'Full board week days and half board weekends', 'Half board weekdays and full board weekends');
		$this -> set('board', $board);
		$bathroom = array('Shared bathroom', 'Private bathroom');
		$this -> set('bathroom', $bathroom);
		$school_way = array('Kilometers', 'minutes walking', 'minutes in public transport', 'minutes by car');
		$this -> set('school_way', $school_way);
		$day = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
		$this -> set('day', $day);
		$price_is = array('per person', 'per room');
		$this -> set('price_is', $price_is);
		$currency_code = $this -> Institute -> find('first', array('conditions' => array('Institute.id' => $institute_id), 'fields' => array('currency_id')));
		$currency_symbol = $this -> Currency -> find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
		$this -> set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);

		$courses = $this -> Accomodation -> find('list');
		$this -> set('courses', $courses);
		$facility = $this -> AccomodationFacility -> find('list', array('fields' => array('id', 'title')));
		$this -> set('facility', $facility);
		 for($i=1;$i<=52;$i++){$week[$i]=$i;}
		 $this->set('week',$week);
		$this -> set('view_title', 'Add Course');
		$this -> set('errors', $errors);
                         }
                         else{
              $this->autoRender = false;
         $this->render('/Schools/mode');
        }

	}

	/**
	 * Purpose : edit  sub accomodation
	 * Created on : 15 may 2014
	 * Author : Rupesh Sharma
	 */
	function edit_sub_accomodation($institute_id, $id) {
            
                  //------------mode check-----------------------
                            $mode=$this->Institute->find('first',array('conditions'=>array('Institute.id'=>$institute_id),'fields'=>array('mode')));
                           
                         if($mode['Institute']['mode']==1){
                        
            //------------mode check------------------------
		$this -> set('institute_id', $institute_id);
		$errors = array();
		$this -> AccomodationType -> id = $id;
		$add_errors = array();
		$error_flag = false;
		$this -> loadModel('Accomodation');
		$this -> loadModel('AccomodationFacility');
		$this -> loadModel('Currency');
			$this->loadModel('Admin.Institute');
		$this -> loadModel('AccomodationPrice');
		$this -> loadModel('AccomodationTypeAccomodationFacility');
		$current_year = date('Y');
		$last_year = date('Y', strtotime('-1 years'));
		$nextyear = date('Y', strtotime('+1 years'));
		$this -> set('current_year', $current_year);
		$this -> set('last_year', $last_year);
		$this -> set('next_year', $nextyear);
		if (!empty($this -> data)) {
			$data_arr = $this -> data;
			//debug($data_arr);exit;
			//
			//json encode
			if ((!empty($data_arr['AccomodationType']['current_year']['plan'])) && (!empty($data_arr['AccomodationType']['current_year']['plan'])) && (!empty($data_arr['AccomodationType']['current_year']['plan']))) {
				$current_price_list = array('AccomodationPrice' => array('institute_id' => $institute_id, 'accomodation_types_id' => $id, 'price_chart' => json_encode($data_arr['AccomodationType']['current_year']['price_chart']), 'plan' => $data_arr['AccomodationType']['current_year']['plan'], 'min_no_weeks' => $data_arr['AccomodationType']['current_year']['min_no_weeks'], 'max_no_weeks' => $data_arr['AccomodationType']['current_year']['max_no_weeks'], 'year' => $current_year, 'placement_fee' => $data_arr['AccomodationType']['current_year']['placement_fee']));

				if ($current_year_price = $this -> get_price_year($current_year, $institute_id, $id)) {
					$this -> AccomodationPrice -> id = $current_year_price;
					$this -> AccomodationPrice -> save($current_price_list);
				} else {
					$this -> AccomodationPrice -> create();
					$this -> AccomodationPrice -> save($current_price_list);
				}
			}

			if ((!empty($data_arr['AccomodationType']['last_year']['plan'])) && (!empty($data_arr['AccomodationType']['last_year']['plan'])) && (!empty($data_arr['AccomodationType']['last_year']['plan']))) {
				$last_price_list = array('AccomodationPrice' => array('institute_id' => $institute_id, 'accomodation_types_id' => $id, 'price_chart' => json_encode($data_arr['AccomodationType']['last_year']['price_chart']), 'plan' => $data_arr['AccomodationType']['last_year']['plan'], 'min_no_weeks' => $data_arr['AccomodationType']['last_year']['min_no_weeks'], 'max_no_weeks' => $data_arr['AccomodationType']['last_year']['max_no_weeks'], 'year' => $last_year, 'placement_fee' => $data_arr['AccomodationType']['last_year']['placement_fee']));
				if ($last_year_price = $this -> get_price_year($last_year, $institute_id, $id)) {
					$this -> AccomodationPrice -> id = $last_year_price;
					$this -> AccomodationPrice -> save($last_price_list);
				} else {
					$this -> AccomodationPrice -> create();
					$this -> AccomodationPrice -> save($last_price_list);
				}
			}

			if ((!empty($data_arr['AccomodationType']['next_year']['plan'])) && (!empty($data_arr['AccomodationType']['next_year']['plan'])) && (!empty($data_arr['AccomodationType']['next_year']['plan']))) {
				$next_price_list = array('AccomodationPrice' => array('institute_id' => $institute_id, 'accomodation_types_id' => $id, 'price_chart' => json_encode($data_arr['AccomodationType']['next_year']['price_chart']), 'plan' => $data_arr['AccomodationType']['next_year']['plan'], 'min_no_weeks' => $data_arr['AccomodationType']['next_year']['min_no_weeks'], 'max_no_weeks' => $data_arr['AccomodationType']['next_year']['max_no_weeks'], 'year' => $nextyear, 'placement_fee' => $data_arr['AccomodationType']['next_year']['placement_fee']));

				if ($next_year_price = $this -> get_price_year($nextyear, $institute_id, $id)) {
					$this -> AccomodationPrice -> id = $next_year_price;
					$this -> AccomodationPrice -> save($next_price_list);
				} else {
					$this -> AccomodationPrice -> create();
					$this -> AccomodationPrice -> save($next_price_list);
				}
			}
			//get slug from name
			$slug = $this -> get_slug($data_arr['AccomodationType']['title']);
			$conditions = array("AccomodationType.slug" => $slug);
			$count = $this -> AccomodationType -> find('count', array('conditions' => $conditions));
			if ($count != 0) {
				$data_arr['AccomodationType']['slug'] = $this -> get_unique_slug($slug);
			} else {
				$data_arr['AccomodationType']['slug'] = $slug;
			}
			$data_arr['AccomodationType']['institute_id'] = $institute_id;
			if (!empty($_FILES['pdf']['name'])) {
				$data_arr['AccomodationType']['pdf'] = $this -> upload_file($institute_id, 'pdf');
			}
			//json encode

			//$data_arr['AccomodationType']['price_chart']=json_encode($this->request->data['AccomodationType']['price_chart']);
			$data_arr['AccomodationType']['available_range'] = json_encode($this -> request -> data['AccomodationType']['available_range']);
			$data_arr['AccomodationType']['journey_to_school'] = json_encode($this -> request -> data['AccomodationType']['journey_to_school']);
			$data_arr['AccomodationType']['check_in'] = json_encode($this -> request -> data['AccomodationType']['check_in']);
			$data_arr['AccomodationType']['check_out'] = json_encode($this -> request -> data['AccomodationType']['check_out']);

			$this -> AccomodationType -> save($data_arr);
			//saved facility
			$accomodation_type_id = $this -> AccomodationType -> getLastInsertID();
			if (!empty($data_arr['AccomodationType']['facility_id'])) {
				$this -> AccomodationTypeAccomodationFacility -> deleteAll(array('AccomodationTypeAccomodationFacility.accomodation_type_id' => $id), false);
				foreach ($data_arr['AccomodationType']['facility_id'] as $key => $value) {
					$institute_facility[] = array('accomodation_type_id' => $id, 'accomodation_facility_id' => $value);
				}
				$this -> AccomodationTypeAccomodationFacility -> saveMany($institute_facility);
			}
			if(isset($this->request->data['save'])){
				$this->redirect(array('controller'=>'accomodation','action'=>'edit_sub_accomodation',$institute_id,$id));
                 $this->Session->setFlash(__('Save successfully.'), 'flash_success');
			}
			else{
				$this->redirect(array('controller'=>'Schools','action'=>'edit_form',$institute_id));
			            $this->Session->setFlash(__('Added successfully.'), 'flash_success');
			}
		}
		$action = $this -> params['action'];
		$this -> set('action', $action);
		$data_arr = $this -> AccomodationType -> findById($id);

		//json decode

		$board = array('Self service (No meals)', 'Breakfast', 'Half board (breakfast + 1 meal)', 'Full board (breakfast + lunch + dinner)', 'Full board week days and half board weekends', 'Half board weekdays and full board weekends');
		$this -> set('board', $board);
		$bathroom = array('Shared bathroom', 'Private bathroom');
		$this -> set('bathroom', $bathroom);
		$school_way = array('Kilometers', 'minutes walking', 'minutes in public transport', 'minutes by car');
		$this -> set('school_way', $school_way);
		$day = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
		$this -> set('day', $day);
		$price_is = array('per person', 'per room');
		$this -> set('price_is', $price_is);
		//                $price_chart['price_chart'] = json_decode($data_arr['AccomodationType']['price_chart'], true);
		//                if (!empty($price_chart)) {
		//                    $new_arr = array_merge($data_arr['AccomodationType'], $price_chart);
		//                    $data_arr = array('AccomodationType' => $new_arr);
		//                }
		$available_range['available_range'] = json_decode($data_arr['AccomodationType']['available_range'], true);
		if (!empty($available_range)) {
			$new_arr = array_merge($data_arr['AccomodationType'], $available_range);
			$data_arr = array('AccomodationType' => $new_arr);
		}
		$journey['journey_to_school'] = json_decode($data_arr['AccomodationType']['journey_to_school'], true);
		if (!empty($journey)) {
			$new_arr = array_merge($data_arr['AccomodationType'], $journey);
			$data_arr = array('AccomodationType' => $new_arr);
		}
		$check_in['check_in'] = json_decode($data_arr['AccomodationType']['check_in'], true);
		if (!empty($check_in)) {
			$new_arr = array_merge($data_arr['AccomodationType'], $check_in);
			$data_arr = array('AccomodationType' => $new_arr);
		}
		$check_out['check_out'] = json_decode($data_arr['AccomodationType']['check_out'], true);
		if (!empty($check_out)) {
			$new_arr = array_merge($data_arr['AccomodationType'], $check_out);
			$data_arr = array('AccomodationType' => $new_arr);
		}
		$this -> AccomodationPrice -> recursive = -1;
		$accomodation_price_lists = $this -> AccomodationPrice -> find('all', array('conditions' => array('AND' => array('AccomodationPrice.institute_id' => $institute_id, 'AccomodationPrice.accomodation_types_id' => $id))));
		foreach ($accomodation_price_lists as $accomodation_price_list) {
			if ($last_year == $accomodation_price_list['AccomodationPrice']['year']) {
				$accomodation_price_list['AccomodationPrice']['price_chart'] = json_decode($accomodation_price_list['AccomodationPrice']['price_chart'], true);
				$data_arr['AccomodationType']['last_year'] = $accomodation_price_list['AccomodationPrice'];
			}
			if ($current_year == $accomodation_price_list['AccomodationPrice']['year']) {
				$accomodation_price_list['AccomodationPrice']['price_chart'] = json_decode($accomodation_price_list['AccomodationPrice']['price_chart'], true);
				$data_arr['AccomodationType']['current_year'] = $accomodation_price_list['AccomodationPrice'];
			}
			if ($nextyear == $accomodation_price_list['AccomodationPrice']['year']) {
				$accomodation_price_list['AccomodationPrice']['price_chart'] = json_decode($accomodation_price_list['AccomodationPrice']['price_chart'], true);
				$data_arr['AccomodationType']['next_year'] = $accomodation_price_list['AccomodationPrice'];
			}
		}
		//debug($data_arr);exit;
		$this -> data = $data_arr;
		$currency_code = $this -> Institute -> find('first', array('conditions' => array('Institute.id' => $institute_id), 'fields' => array('currency_id')));

		$currency_symbol = $this -> Currency -> find('first', array('conditions' => array('Currency.id' => $currency_code['Institute']['currency_id']), 'fields' => array('currrency_symbol')));
		$this -> set('currency_symbol', $currency_symbol['Currency']['currrency_symbol']);
		// debug($this->data);exit;
		$courses = $this -> Accomodation -> find('list');
		$this -> set('courses', $courses);
		$selected_course = array($this -> data['AccomodationType']['accomodation_id']);
		$this -> set('selected_course', $selected_course);
		$facility = $this -> AccomodationFacility -> find('list', array('fields' => array('id', 'title')));
		$this -> set('facility', $facility);
		$selected_facility = $this -> AccomodationTypeAccomodationFacility -> find('list', array('conditions' => array('AccomodationTypeAccomodationFacility.accomodation_type_id' => $id), 'fields' => array('accomodation_facility_id')));
		$this -> set('selected_facility', $selected_facility);
		$this -> set('view_title', 'Add Course');
		 for($i=1;$i<=52;$i++){$week[$i]=$i;}
		 $this->set('week',$week);
		$this -> set('errors', $errors);
		$this -> render('add_sub_accomodation');
                         }
                         else{
          $this->autoRender = false;
         $this->render('/Schools/mode');
        }
	}

	/**
	 * Purpose : upload pdf file
	 * Input :	input field name
	 * Created on : 7 may 2014
	 * Author : Rupesh Sharma
	 */
	function upload_file($institute_id, $field_name) {

		$this -> Upload = $this -> Components -> load('Upload');
		$config['upload_path'] = UPLOAD_INSTITUE_DIR . $institute_id . '/';
		$config['allowed_types'] = 'pdf';
		$config['max_size'] = 1200;
		$config['encrypt_name'] = false;
		$config['is_image'] = 1;
		$this -> Upload -> initializes($config);
		if ($this -> Upload -> do_upload($field_name)) {

			$filedata_arr = $this -> Upload -> data();
			return $filedata_arr['file_name'];
		}

	}

	/**
	 * Purpose : upload images file
	 * Input :	input field name
	 * Created on : 19 may 2014
	 * Author : Rupesh Sharma
	 */
	function upload_image_file($institute_id, $field_name) {

		$this -> Upload = $this -> Components -> load('Upload');
		$config['upload_path'] = UPLOAD_INSTITUE_DIR . $institute_id . '/';
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$config['max_size'] = 1200;
		$config['encrypt_name'] = false;
		$config['is_image'] = 1;
		$this -> Upload -> initializes($config);
		if ($this -> Upload -> do_upload($field_name)) {

			$filedata_arr = $this -> Upload -> data();
			return $filedata_arr['file_name'];
		}

	}

	/**
	 * Purpose : FOR ADMIN TO MAKE ACTION LIKE ACTIVE, INACTIVE AND DELETE for sub courses
	 * Created on : 9 May 2014
	 * Author : Rupesh Sharma
	 */
	function sub_accomodation_manage_actions() {
		if (count($this -> params['data'])) {
			$message = '';

			$ids = $this -> params['data']['list'];

			if (!empty($ids)) {
				$task = $this -> params['data']['task'];

				if ($task == "delete") {
					//$this->unlink_thumbs(UPLOAD_INSTITUE_DIR, 'Course', 'img', array('Course.id' => $ids));

					$this -> AccomodationType -> deleteAll(array('AccomodationType.id' => $ids), true);
					$message = 'Deleted successfully.';
				} elseif ($task == "featured") {
					$this -> AccomodationType -> updateAll(array('AccomodationType.published' => "1"), array('AccomodationType.id' => $ids));
					$message = 'Activated successfully.';
				} elseif ($task == "unfeatured") {
					$this -> AccomodationType -> updateAll(array('AccomodationType.published' => "0"), array('AccomodationType.id' => $ids));
					$message = 'Inactivated successfully.';
				}
					elseif($task == "Duplicate")
                {
                	$this->loadModel('AccomodationPrice');
					$this->loadModel('AccomodationTypeAccomodationFacility');
					
                    $this->AccomodationType->bindModel(array(
					 'hasMany'=>array(
					 'AccomodationTypeAccomodationFacility'=>array(
					    'className'=>'AccomodationTypeAccomodationFacility'
					   )
					 )
					));
							
                	$this->AccomodationType->unBindModel(array('belongsTo'=>array('Institute')));
                	$accommodation_list=$this->AccomodationType->find('all',array('conditions'=>array('AccomodationType.id'=>$ids)));
				
					//$accommodation_list2=Hash::remove($accommodation_list,'{n}.AccomodationType.id');
					//debug($accommodation_list2);exit;
			        foreach($accommodation_list as $accomodation)
					{
						$old_accomodation_id=$accomodation['AccomodationType']['id'];
						$accomodation=Hash::remove($accomodation,'AccomodationType.id');
						unset($accommodation_id);
						$this->AccomodationType->save($accomodation);
						$accommodation_id=$this->AccomodationType->getLastInsertId();
						
						$AccommodationPrice=$accomodation['AccomodationPrice'];
						$AccommodationPrice=Hash::remove($AccommodationPrice,'{n}.id');
						$AccommodationPrice=Hash::remove($AccommodationPrice,'{n}.accomodation_types_id');
						$AccommodationPrice=Hash::insert($AccommodationPrice, '{n}.accomodation_types_id',$accommodation_id);
						$this->AccomodationPrice->saveAll($AccommodationPrice);
						
						
						$AccommodationFacilty=$accomodation['AccomodationTypeAccomodationFacility'];
						$AccommodationFacilty=Hash::remove($AccommodationFacilty,'{n}.id');
						$AccommodationFacilty=Hash::remove($AccommodationFacilty,'{n}.accomodation_type_id');
						$AccommodationFacilty=Hash::insert($AccommodationFacilty, '{n}.accomodation_type_id',$accommodation_id);
						//debug($AccommodationFacilty);exit;
						$this->AccomodationTypeAccomodationFacility->saveAll($AccommodationFacilty);
						
						
					}
					
					$message = 'Duplicate successfully.';
                }


				$this -> Session -> setFlash($message, 'flash_success');
			}

			$this -> redirect($this -> referer());
		}
		exit ;
	}

	/**
	 * Purpose:get price list id
	 * created on:18 june 2014
	 * created by:Abhishek Tripathi
	 * */
	public function get_price_year($year = null, $institute_id = null, $course_id = null) {
		$this -> loadModel('AccomodationPrice');

		$year = $this -> AccomodationPrice -> find('first', array('conditions' => array('AND' => array('AccomodationPrice.year' => $year, 'AccomodationPrice.institute_id' => $institute_id, 'AccomodationPrice.accomodation_types_id' => $course_id)), 'fields' => array('id')));

		if ($year) {
			return $year['AccomodationPrice']['id'];
		} else {
			return FALSE;
		}
	}

}
