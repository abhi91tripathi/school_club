<?php
App::uses('AppModel', 'Model');
/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class Like extends AppModel {
	

	
	
	
	
	
	
	
	
	}
