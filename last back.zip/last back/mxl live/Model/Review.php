<?php
App::uses('AppModel', 'Model');
/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class Review extends AppModel {
	
	
	
	
	/*public $belongsTo=array(
      'Institute'=>array(
      'className'=>'Institute',
      'foreignKey'=>'institute_id'
   )
);*/

   public $hasMany=array(
     'Like'=>array(
        'className'=>'Like',
        'foreignKey'=>'review_id'
      )
   );



public function rating($id=null){
	 $array=array();
         $five_star=0;$four_star=0;$three_star=0;$two_star=0;$one_star=0;
	 $five_star=$this->find('count',array('conditions'=>array('AND'=>array('Review.institute_id'=>$id,'status'=>1,'Review.rating >='=>4.5))));
	 $four_star=$this->find('count',array('conditions'=>array('AND'=>array('Review.institute_id'=>$id,'status'=>1,'Review.rating >='=>3.5,'Review.rating <'=>4.5))));
	 $three_star=$this->find('count',array('conditions'=>array('AND'=>array('Review.institute_id'=>$id,'status'=>1,'Review.rating >='=>2.5,'Review.rating <'=>3.5))));
	 $two_star=$this->find('count',array('conditions'=>array('AND'=>array('Review.institute_id'=>$id,'status'=>1,'Review.rating >='=>1.5,'Review.rating <'=>2.5))));
	 $one_star=$this->find('count',array('conditions'=>array('AND'=>array('Review.institute_id'=>$id,'status'=>1,'Review.rating >='=>.5,'Review.rating <'=>1.5))));
	 
         $total=$five_star+$four_star+$three_star+$two_star+$one_star;
                 $array=array(
	  'five'=>($total==0?0:$five_star/$total*100),
           'revfive'=>$five_star,
	  'four'=>($total==0?0:$four_star/$total*100),
            'revfour'=>$four_star,
	  'three'=>($total==0?0:$three_star/$total*100),
            'revthree'=>$three_star,
	  'two'=>($total==0?0:$two_star/$total*100),
            'revtwo'=>$two_star,
	  'one'=>($total==0?0:$one_star/$total*100),
            'revone'=>$one_star,
	);

	return $array;
	}

public function afterSave($created,$options = array()){
       
           if(isset($this->data['Review']['status']) && $this->data['Review']['status']==1){ 
	   $obj = ClassRegistry::init('Institute');
	   $old_rating_avg=$obj->find('first',array('conditions'=>array('Institute.id'=>$this->data['Review']['institute_id']),'fields'=>array('average_rating','rating_user')));
	   $fields=array('sum(Review.rating) as total');
	   $conditions=array('Review.institute_id'=>$this->data['Review']['institute_id']);
	   $total_rating=$this->find('all',array('conditions'=>$conditions,'fields'=>$fields));
	   $total_user=$this->find('count',array('conditions'=>$conditions));
	  
	    $avreage=(intval($total_rating[0][0]['total'])/intval($total_user));
            $obj->id=$this->data['Review']['institute_id'];
            $obj->saveField('average_rating',$avreage);
            $obj->saveField('rating_user',$total_user);
           }
	
	}	
	
public function reviews($id,$ip){
	   
        $fields=array('Review.*','(SELECT count(Like.id) from likes as `Like` where Like.review_id=Review.id)','(SELECT count(Like.id) from likes as `Like` where Like.review_id=Review.id && Like.like=1)','(SELECT count(Like.id) from likes as `Like` where Like.review_id=Review.id && Like.like=1 && Like.ip_address="'.$ip.'")','(SELECT count(Like.id) from likes as `Like` where Like.review_id=Review.id && Like.like=2 && Like.ip_address="'.$ip.'")');
	$review=$this->find('all',array('conditions'=>array('AND'=>array('status'=>1,'institute_id'=>$id)),'fields'=>$fields,'order'=>array('(SELECT count(Like.id) from likes as `Like` where Like.review_id=Review.id) DESC','Review.id DESC')));
        return $review;
	}	
	
	
	}


                            	
	
	
?>
