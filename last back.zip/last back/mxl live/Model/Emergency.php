<?php
/**
 * Student Model
 * @author Abhishek Agrawal
 * @since [version]
 */
class Emergency extends AppModel
{
	//The $name variable is always a good idea to add, and is used to overcome some class name oddness in PHP4.
	var $name = 'Emergency';
	// var $useTable = false;

	var $validate = array(
			
	);
}
