<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class SpCourseType extends AppModel {
    public $useDbConfig = 'spanish';
         public $useTable='course_types';

/**
 * Display field
 *
 * @var string
 */


/**
 * belongsTo associations
 *
 * @var array
 */
 
 
 
 
	public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			
			
		)
	);
        public $hasMany = array(
        'CoursePrice' => array(
            'className' => 'CoursePrice',
            'foreignKey' => 'course_types_id',
            'conditions' => '',
            'order' => '',
            'limit' => '',
            'dependent' => true
        )
            );
}
