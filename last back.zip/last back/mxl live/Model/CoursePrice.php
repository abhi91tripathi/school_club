<?php
App::uses('AppModel', 'Model');

/**
 * CoursePrice Model
 *
 * @property Institute $Institute
 * @property CourseTypes $CourseTypes
 */
class CoursePrice extends AppModel {
    public $actsAs = array('Converter');

    /**
 * belongsTo associations
 *
 * @var array
 */
 
 
 public function get_search($language_id=null,$country_id=null,$destination_id=null,$weeks=null,$option=null,$order=null,$course=null){
	
 	$this->recursive=3;
 	$institutes=array();
 	$cond_arr=array();
        $conditoin=array();
        if($order==null){
            $order='rand()';
        }

	
	$join1=array(
		array(
			'table' => 'course_types',
			'alias' => 'CourseType',
			'type' => 'LEFT',
			'conditions'=>array('CourseType.institute_id=Institute.id'),
			
		),
		array(
			'table' => 'accomodation_types',
			'alias' => 'AccomodationType',
			'type' => 'LEFT',
			'conditions'=>array('AccomodationType.institute_id=Institute.id'),
		),
		array(
			'table' => 'course_prices',
			'alias' => 'CoursePrice',
			'type' => 'LEFT',
			'conditions'=>array('CoursePrice.institute_id=Institute.id'),
			
		)
		);
	$fields=array(
	'Institute.id AS institute_id','Institute.title','.Institute.tag_line','.Institute.logo','Institute.embassy_image','Institute.accreditation','Institute.max_price','Institute.min_price','Institute.lat','Institute.long','Institute.slug','Institute.average_rating','Institute.rating_user','Institute.about_embassy','Institute.discount_available','Institute.thumbnail_image','Institute.thumbnail_image','Institute.listing_type','Institute.language_course_type','Institute.accommodation_type','Institute.expiry_date'
	);

	$contain1=array(
	   'Language'=>array('fields'=>array('id AS Language_id','title AS Language_title')),
	   'Country'=>array('fields'=>array('id AS Country_id','name AS Country_name','flag_image')),
	   'Destination'=>array('fields'=>array('id AS Destination_id','name AS Destination_name')),
            'Currency'=>array('fields'=>array('currency_code'))
	);
	
	$join2=array(
		array(
			'table' => 'course_types',
			'alias' => 'CourseType',
			'type' => 'LEFT',
			'conditions'=>array('CourseType.institute_id=Institute.id'),
			
		),
		array(
			'table' => 'accomodation_types',
			'alias' => 'AccomodationType',
			'type' => 'LEFT',
			'conditions'=>array('AccomodationType.institute_id=Institute.id'),
			
		)
		);
        
		
	if(!empty($weeks)){
		
		if(!empty($weeks)){
		append_condition($cond_arr,'CoursePrice.min_no_course', 'less', $weeks);
	        }
		if(!empty($language_id)){
		append_condition($cond_arr,'Institute.language_id', 'equal', $language_id);
	        }
		if(!empty($country_id)){
			append_condition($cond_arr,'Institute.country_id', 'equal', $country_id);
			}
		if(!empty($country_id)){
			append_condition($cond_arr,'Institute.destination_id', 'equal', $destination_id);
			}
		if(!empty($option)){
			foreach($option as $key=>$opt){
				append_condition($cond_arr,$key,$opt['condition'] , $opt['value']);
				}
			
			}
                else{
                    
                }  
                
               
                if(!empty($course)){
                    $cond_arr['OR']=array('CourseType.course_id'=>$course['CourseType.course_id']['value'],
                 
                        );
                }
                 if(!empty($cond_arr) && empty($cond_arr['Institute.id']) && empty($cond_arr['Institute.rating_user >='])){
                    if(!empty($country_id)){
			append_condition($cond_arr_pre,'Institute.country_id', 'equal', $country_id);
			}
                    if(!empty($destination_id)){
			append_condition($cond_arr_pre,'Institute.destination_id', 'equal', $destination_id);
			}    
                    append_condition($cond_arr_pre,'Institute.listing_type', 'equal', 2);
                       
                    $conditoin=array(
                      'OR'=>array(array('AND'=>$cond_arr),array('AND'=>$cond_arr_pre))  
                    );
                      //debug($conditoin);exit; 
                }
                if(!empty($cond_arr['Institute.id'])){
                    $conditoin=$cond_arr;
                }
                if(!empty($cond_arr['Institute.rating_user >='])){
                     $conditoin=array(
                      'OR'=>array('AND'=>$cond_arr, 'AND'=>array('Institute.listing_type'=>2,'Institute.rating_user >='=>$cond_arr['Institute.rating_user >=']))  
                    );
                }
               
			
		$institute=ClassRegistry::init('Institute');
		$institute_list=$institute->find('all',array('conditions'=>$cond_arr,'joins'=>$join1,'group'=>array('Institute.id'),'contain'=>$contain1,'fields'=>$fields,'order'=>$order,));
		
		foreach($institute_list as $inst){
			$Result=Hash::merge($inst['Institute'],$inst['Language'],$inst['Country'],$inst['Destination']);
			$Result['embassy_image']=(!empty($Result['thumbnail_image'])?DISPLAY_INSTITUE_DIR.$Result['institute_id'].'/thumbnail_img_'.$Result['thumbnail_image']:'images/no-image.jpg');
			$Result['accreditation_image']=$this->get_accredation_images($Result['accreditation']);
                        $Result['min_price']=round($this->exchange_rate_convert('EUR', CakeSession::read('CURRENCY'),$Result['min_price']),0);
                        $Result['min_price']=($Result['min_price']==null || $Result['min_price']==0 ?'NA':$Result['min_price']);
			$Result['average_rating']=($Result['average_rating']==0.0 || $Result['average_rating']==null ?$Result['average_rating']=0:$Result['average_rating']=round($Result['average_rating'],PHP_ROUND_HALF_UP));
			$Result['rating_user']=($Result['rating_user']==null ?$Result['rating_user']=0:$Result['rating_user']=($Result['rating_user']));
			if($Result['listing_type']==2)
                        {
                            if(time()<strtotime($Result['expiry_date'])){
                              $institutes[]=$Result;  
                            }
                        }
                        else{
                            $institutes[]=$Result;
                        }
                }
        return $institutes;
        }
	else{
		if(!empty($language_id)){
		append_condition($cond_arr,'Institute.language_id', 'equal', $language_id);
	        }
		if(!empty($country_id)){
			append_condition($cond_arr,'Institute.country_id', 'equal', $country_id);
			}
		if(!empty($destination_id)){
			append_condition($cond_arr,'Institute.destination_id', 'equal', $destination_id);
			}	
		if(!empty($option))
		{
			if(!empty($option)){
			foreach($option as $key=>$opt){
				append_condition($cond_arr,$key,$opt['condition'] , $opt['value']);
				}
			}
		}
                if(!empty($course)){
                    $cond_arr['OR']=array('CourseType.course_id'=>$course['CourseType.course_id']['value'],
                 
                               );
                }
                if(!empty($cond_arr) && empty($cond_arr['Institute.id']) && empty($cond_arr['Institute.rating_user >='])){
                    if(!empty($country_id)){
			append_condition($cond_arr_pre,'Institute.country_id', 'equal', $country_id);
			}
                    if(!empty($destination_id)){
			append_condition($cond_arr_pre,'Institute.destination_id', 'equal', $destination_id);
			}    
                    append_condition($cond_arr_pre,'Institute.listing_type', 'equal', 2);
                       
                    $conditoin=array(
                      'OR'=>array(array('AND'=>$cond_arr),array('AND'=>$cond_arr_pre))  
                    );
                      //debug($conditoin);exit; 
                }
                if(!empty($cond_arr['Institute.id'])){
                    $conditoin=$cond_arr;
                }
                if(!empty($cond_arr['Institute.rating_user >='])){
                     $conditoin=array(
                      'OR'=>array('AND'=>$cond_arr, 'AND'=>array('Institute.listing_type'=>2,'Institute.rating_user >='=>$cond_arr['Institute.rating_user >=']))  
                    );
                }
             
                $institute=ClassRegistry::init('Institute');
		$institute_list=$institute->find('all',array('conditions'=>$conditoin,'joins'=>$join2,'group'=>array('Institute.id'),'order'=>$order,'contain'=>$contain1,'fields'=>$fields));
                        
                foreach($institute_list as $inst){
			$Result=Hash::merge($inst['Institute'],$inst['Language'],$inst['Country'],$inst['Destination'],$inst['Currency']);
			$Result['embassy_image']=(!empty($Result['thumbnail_image'])?DISPLAY_INSTITUE_DIR.$Result['institute_id'].'/thumbnail_img_'.$Result['thumbnail_image']:'images/no-image.jpg');
			$Result['accreditation_image']=$this->get_accredation_images($Result['accreditation']);
			$Result['min_price']=round($this->exchange_rate_convert('EUR', CakeSession::read('CURRENCY'),$Result['min_price']),0);
                        $Result['min_price']=($Result['min_price']==null || $Result['min_price']==0 ?'NA':$Result['min_price']);
			$Result['average_rating']=($Result['average_rating']==0.0 || $Result['average_rating']==null ?$Result['average_rating']=0:$Result['average_rating']=round($Result['average_rating'],PHP_ROUND_HALF_UP));
			$Result['rating_user']=($Result['rating_user']==null ?$Result['rating_user']=0:$Result['rating_user']=intval($Result['rating_user']));
			if($Result['listing_type']==2 && $Result['expiry_date']!='0000-00-00')
                        {
                            if(time()<strtotime($Result['expiry_date'])){
                              $institutes[]=$Result;  
                            }
                        }
                        else{
                            $institutes[]=$Result;
                        }
		}
	}
	return $institutes;
 }
 
 
 public function get_accredation_images($accredation){
	 $accredition=ClassRegistry::init('Accreditation');
	 $list=$accredition->find('list',array('fields'=>array('id','image_name')));
	 $count=0;
	 $html='';
	   $acc=json_decode($accredation,true);
	  
	   if(!empty($acc)){
		   foreach($acc as $value){
			 
			  if(!empty($list[$value])){
				   $count++;
			   $html.="<div class='cimg'><img src='".SITE_URL."uploads/accreditation/".$list[$value]."'></div>";
		      }
			   if($count>=3)
			   break;
			   }
		   }
		   return $html;
	 }
 
 public $belongsTo = array(
		'Institute' => array(
			'className' => 'Institute',
			'foreignKey' => 'institute_id',
			'conditions' =>array('Institute.id=CoursePrice.institute_id'),
			'fields' =>'',
			'order' => ''
		),
		'CourseType' => array(
			'className' => 'CourseType',
			'foreignKey' => 'course_types_id',
			'conditions' => array('CourseType.id=CoursePrice.course_types_id'),
			'fields' => '',
			'order' => ''
		)
	);
 }
