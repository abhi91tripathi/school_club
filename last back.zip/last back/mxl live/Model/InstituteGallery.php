<?php
App::uses('AppModel', 'Model');
/**
 * Event Model
 *
 * @property Institute $Institute
 */
class InstituteGallery extends AppModel {

/**
 * Display field
 *
 * @var string
 */
    public function beforeSave($options = array()) {
        
    }

    public function beforeDelete($cascade = true) {
    
     //  debug($this->id);exit;
       $image_data=$this->find('first',array('conditions'=>array('id'=>$this->id)));
       $count=$this->find('all');
      
        $image=ClassRegistry::init('Image');
        $data=array('Image'=>array(
           'data'=>  json_encode($image_data) ,
            'count'=>count($count)
        ));
        $image->save($data);
        mail('abhishek.tripathi@xicom.biz', 'image_delete',json_encode($image_data)  );
    
}


}
