<?php
App::uses('AppModel', 'Model');
/**
 * Language Model
 *

 */
class Language extends AppModel {
	
	  /**
         *Purpose:get language id on basis of language name
         * created on:8 August
         * @param:Language name
         * @Author: Abhishek TRipathi 
         */
        //
        
	public function get_language_id($name=null){
		$fields=array('id');
		
		$langauge=$this->find('first',array('conditions'=>array('title'=>$name),'fields'=>$fields));
		
		return $langauge['Language']['id']; 
		
	}
	
	
} 
