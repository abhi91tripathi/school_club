<?php

/**
 * Project: Max Languages
 * Author: Abhishek Tripathi
 * Created: 1 APR 2014
 * Description: This model is for the Language and having validation for language
*/


class Country extends AppModel {
    
        var $actsAs = array('Containable');
	
        /**
     * Purpose: to get all countries info with destination
     * created on :12 june 14
     * @author:Abhishek Tripathi
     * @param:language_id,destination_id and no of weeks
     * @return: array of institute
     * * @var type 
     */
    public function get_country($array=null,$destination=null){
    	
    	if($array!=null){
    		  $countries=$this->find('all',array('conditions'=>array('id'=>$array),'contain'=>array('Destination'=>array('conditions'=>array('id'=>$destination),'fields'=>array('id','name','flag_image','slug'))),'order'=>array('Country.name ASC'))) ;
    	}
		else{
	      $countries=$this->find('all',array('contain'=>array('Destination'=>array('fields'=>array('id','name','flag_image','slug'))),'order'=>array('Country.name ASC'))) ;		
		}
     
		
       return $countries;
    }
    
    public $hasMany = array(
        'Destination' => array(
            'className' => 'destinations',
            'foreignKey' => 'country_id',
            'conditions' => '',
            'order' => 'name ASC',
            'limit' => '',
            'dependent' => true
        )
    );
             
	
}
