<?php
/**
 * Payment Model
 * @author Abhishek Agrawal
 * @since [version]
 */
class Payment extends AppModel
{
	//The $name variable is always a good idea to add, and is used to overcome some class name oddness in PHP4.
	var $name = 'Payment';
	// var $useTable = false;

	var $actsAs = array('Containable');

	var $validationSet = array(
		'Form2' => array(
			'type' => array(
				'notEmpty' => array(
					'rule' => 'notEmpty',
					'message' => 'Payment type is required.'
					),
				),
			'owner_name' => array(
				'notEmpty' => array(
					'rule' => 'notEmpty',
					'message' => 'Card owner name is required.'
					),
				),
			'card_number' => array(
				'notEmpty' => array(
					'rule' => 'notEmpty',
					'message' => 'Card number is required.'
					),
					/*'minLength' => array(
						'rule' => array('minLength', '16'),
						'message' => 'Card number is required.'
						),*/
			'ccnumber' => array(
				'rule' => array('cc', array('visa', /*'maestro',*/ 'amex', 'mc'), false, null),
				'message' => 'Invalid Credit card number.'
				)
			),
			'expire_date' => array(
				'notEmpty' => array(
					'rule' => 'notEmpty',
					'message' => 'Expire date name is required.'
					),
				),
			'cvv' => array(
				'notEmpty' => array(
					'rule' => 'notEmpty',
					'message' => 'CVV is required.'
					),
				'between' => array(
					'rule' => array('between', 3, 4),
					'message' => 'CVV length should be 3.'
					),
				'number' => array(
					'rule' => array('range', 100, 999),
					'message' => 'CVV is invalid'
					),
				'naturalNumber' => array(
					'rule' => array('naturalNumber', true),
					'message' => 'CVV is invalid.'
					),

				),
			'terms' => array(
					/*'notEmpty' => array(
						'rule' => 'notEmpty',
						'message' => 'Terms is required.'
						),*/
			'boolean' => array(
				'rule' => 'boolean',
				'message' => 'Terms is required.'
				),
					/*'equalTo' => array(
				        'rule' => array('equalTo', 1),
				        'message' => 'Terms must be accepted.'
				        ),*/
			),
			),
);


}
