$(document).ready(function()
{
	$('#HomepageBlockTextAddHomePageBlockForm').validate({
		 rules: {
				image: {
					required: true,
					extension: "gif|jpeg|png|jpg"
				}
			}
	});
});
