//purpose:It contain only comman script which are using every page.
//created by: Abhishek Tripathi
//created on:11/11/14

function conversion(code){
    
   $.post(JS_SITE_URL+'Pages/conversion/'+code,{code:code},function(d){
       if(d=='success'){
           location.reload(true); 
       }
   });
   }
function local_changes(data){
    $.post(JS_SITE_URL+'App/conversion/'+data,{code:data},function(d){
       if(d=='success'){
           location.reload(true); 
       }
   });
}   

