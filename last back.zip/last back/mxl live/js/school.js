//Purpose:School page script
//created on:3 oct 2014
//Author:Abhishek Tripathi

$(document).ready(function(){
	
	//Show review list
	$('.show_review_list').click(function(){
		if($('.review-list').hasClass('hide'))
		{
			$('.review-list').removeClass('hide').addClass('show');
			$('.show_review_list').hide();
		}
		else
		{
			$('.review-list').removeClass('show').addClass('hide');
		}
	})
	
	ko.applyBindings(viewModel);
	latest_school();
	
	if(view=='school'){
	recomended_school();
}


  

	});



function click_view(id){
 console.log($(id).parent().parent().attr('rel'));
var parent=$(id).parent().parent().attr('rel');
$('#'+parent).parent().trigger('click');
$('#'+id.rel).parent().find('.plus-icon').trigger('click');
}

function click_on_list(data){
  $(data).parent().trigger('click');
  var id=$(data).attr('rel');
  console.log($(data).attr('rel'));
  $('#'+id).parent().find('.plus-icon').trigger('click');
	
	}


//Purpose:create model (knockout js)
//created by:Abhishek Tripathi
//created on:6 oct 2014
var viewModel={
			institute:ko.observable(),
		    recomended_institute:ko.observable(),
					
			};   
			



function latest_school(){
	$.post('Institutes/latest_school',{school_id:latest_viewed},function(d){
		  var data=JSON.parse(d);
		   var parsed = JSON.parse(d);		  
		    	viewModel.institute(parsed);
		    		$('.bxslider3').bxSlider({
				  minSlides: 4,
				  maxSlides: 4,
				  slideWidth: 248,
				  slideMargin: 30
				});
		
		})
	}
	
function recomended_school(){
	$.post('Institutes/recomended_school',{city_id:city_id,country_id:country_id,language_id:language_id,institute_id:institute_id},function(d){
		  var data=JSON.parse(d);
		   var parsed = JSON.parse(d);		  
		    	viewModel.recomended_institute(parsed);
		
		})
	}	
				
/-------------------------------------------start rate custome binding--------------------------/
ko.bindingHandlers.rateit = {
    init: function (element, valueAccessor) {
        var local = ko.toJS(valueAccessor()),
            options = {};

        if(typeof local === 'number') {
            local = {
                value: local
            };
        }
        

        ko.utils.extend(options, ko.bindingHandlers.rateit.options);
        ko.utils.extend(options, local);

        $(element).rateit(options);
        //register an event handler to update the viewmodel when the view is updated.
        $(element).bind('rated', function (event, value) {
            var floa = parseFloat(value.toFixed(1));
            var observable = valueAccessor();
            if(ko.isObservable(observable)) {
                observable(floa);
            } else {
                if(observable.value !== undefined && ko.isObservable(observable.value)) {
                    observable.value(floa);
                }
            }
        });
    },
    update: function(element, valueAccessor) {
        var local = ko.toJS(valueAccessor());
        
        if (typeof local === 'number') {
            local = {
                value: local
            };
        }
        
        if (local.value !== undefined) {
            var floa = parseFloat(local.value.toFixed(1));
            $(element).rateit('value', floa);
        }
        
    },
    options: {
        //this section is to allow users to override the rateit defaults on a per site basis.
        //override by adding ko.bindingHandlers.rateit.options = { ... }
    }
};

// review helpfull  
function helpfull(val,id,data){

	
	switch(val){
		case 'yes':
		if($(data).attr('clickable')==0){
		    $.post('Reviews/helpfull',{helpfull:'yes',id:id},function(d){
			$(data).addClass('like_disable');
			$(data).parent().find('.help_no').removeClass('like_disable');
			$(data).parent().find('.help_no').attr('clickable',0);
			$(data).attr('clickable',1);
			//console.log(d);
			});
		}else{
			return false;
			}
		  break;
		case 'no':
		 if($(data).attr('clickable')==0){
		    $.post('Reviews/helpfull',{helpfull:'no',id:id},function(d){
			$(data).addClass('like_disable');
			$(data).parent().find('.help_yes').removeClass('like_disable');
			//console.log(d);
			$(data).parent().find('.help_yes').attr('clickable',0);
				$(data).attr('clickable',1);
			});
		}else{
			return false;
			}
		  break;  
		
		}
	
	}
//Purpose:create function for online quote
//created by:Abhishek Tripathi
//created on:1 december 2014

function view_online_quote(id){
   $('#course_id').val(id);
   $( '#course_id').change();
}

	
