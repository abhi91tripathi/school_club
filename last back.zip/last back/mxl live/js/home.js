// Js for home page

$(document).ready(function(){

  

// on change of language selection
	
$('#lang_input').on('change',function(){
	var name=$('#lang_input').val();
	get_destination(name);
});
/// get destination on page load
get_destination($('#lang_input').val());
$(".select_search").select2(); 
 $("#destination_input").select2({
				formatResult: format,
				formatSelection: format,
				escapeMarkup: function(m) { return m; }
					
			});


// click on search button
$('#school_search').on('click',function(){
	// make custom url 
	var language=$('#lang_input').val().toLowerCase();
	var destination=$('#destination_input').val().toLowerCase();
	var week=$('#week_input').val();
	if(destination=='' && week=='')
    { 
  	var url=JS_SITE_URL+'learn-'+language+'-abroad';
	$('#search_form').attr('action',url);
  	}	
	else{
		if(destination=='' && week!='')
		{
		var url=JS_SITE_URL+'learn-'+language+'-abroad?week='+week;
	    $('#search_form').attr('action',url);
	   }
	   else{
	   	if(destination!='' && week!=''){
	   		var url=JS_SITE_URL+'learn-'+language+'-in-'+destination+'?week='+week;
	        $('#search_form').attr('action',url);
	   	}
	   	
	   	else{
	   		if(destination!='' && week==''){
	   	   var url=JS_SITE_URL+'learn-'+language+'-in-'+destination;
	        $('#search_form').attr('action',url);
	   	}
	   	}
	   }
	}
	//window.location.href=url;
	//alert($('#search_form').attr('action'));
	//alert(language+':'+destination+':'+week);
	//return false;
	
});


$('.homeslider').bxSlider({
			minSlides : 1,
			maxSlides : 5,
			slideWidth : 219,
			slideMargin : 10,
			moveSlides : 1,
			pager : false,
			infiniteLoop : false
		});
		
      
  
	//latest_school();

});


// Purpose: get destination list 
function get_destination(language_name){
var name=language_name;
	$.post(JS_SITE_URL+'Pages/get_destination',{language_name:name},function(d){

	 $('#destination_input').html(d); 
	 $('#select2-chosen-4').html('Any Destination');
	});	
}


//Purpose:set flag on select input
//created by:Abhishek Tripathi
//created on:22/09/14

function format(state) {
var originalOption = state.element;
 console.log($(originalOption).data('foo')); 
 if($(originalOption).data('foo')!='0'){
	 var flag_name=$(originalOption).data('foo');
	
     return "<img class='flag' src='"+JS_SITE_URL+"files/country_flag/"+flag_name+"' alt='" + $(originalOption).data('foo') + "' width='20px'/>&nbsp;" + state.text; 
 }
 else{
 return state.text;	
	}
}



   





