/*<script>
  window.fbAsyncInit = function() {
	FB.init({
	  appId      : '1499373583646203',
	  xfbml      : true,
	  version    : 'v2.2'
	});
  };

  (function(d, s, id){
	 var js, fjs = d.getElementsByTagName(s)[0];
	 if (d.getElementById(id)) {return;}
	 js = d.createElement(s); js.id = id;
	 js.src = "//connect.facebook.net/en_US/sdk.js";
	 fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
</script>*/

function fb_login(){
	jQuery.ajaxSetup({ cache: true });
	jQuery.getScript('//connect.facebook.net/en_UK/all.js', function(){
		FB.init({
			appId: '877721082285793',
			status: true,
			cookie: true,
			channelUrl: 'http://demo.xicom.us/Max-Languages/website',
			xfbml      : true,
			version    : 'v2.2'
  		});
		FB.getLoginStatus(function(response) {
			if (response.status === 'connected') {
				console.log(response);
				var uid = response.authResponse.userID;
				var accessToken = response.authResponse.accessToken;
				testAPI();
			} else if (response.status === 'not_authorized') {
				//window.opener.location.href = WEBSITE_URL;
				//window.close();
				FB.login(function(response) {
					// console.log(response);
					if (response.authResponse) {
						var uid = response.authResponse.userID;
						var accessToken = response.authResponse.accessToken;
						testAPI();
						// callFbFriends(uid, accessToken);
					} else {
						if(window.opener != null)
						{
							window.opener.location.href = site_url;
							window.close();
						}
					}
				}, {scope: 'public_profile, email'});
			} else {
				FB.login(function(response) {
					if (response.authResponse) {
						var uid = response.authResponse.userID;
						var accessToken = response.authResponse.accessToken;
						testAPI();
						// callFbFriends(uid, accessToken);
					} else {
						window.opener.location.href = site_url;
						window.close();
					}
				}, {scope: 'public_profile, email'});
			}
		});
	});

}

/*function callFbFriends(userID, accessToken)
{
	var datastring = 'limit=5000&access_token='+accessToken;
	jQuery.ajax({
		url: 'https://graph.facebook.com/'+userID+'/friends',
		dataType: 'jsonp',
		data: datastring,
		success: function(data) {
			var fbfriendsHTML = '';
			jQuery.each(data.data, function(key, val){
				fbfriendsHTML += '<li class="fb_friend_list">';
					fbfriendsHTML += '<div class="user_img">';
						fbfriendsHTML += '<img src="https://graph.facebook.com/'+val.id+'/picture?width=80&height=80" width="80" height="80">';
					fbfriendsHTML += '</div>';
					fbfriendsHTML += '<div class="user_name">';
						fbfriendsHTML += val.name;
					fbfriendsHTML += '</div>';
					fbfriendsHTML += '<div class="button_invite">';
						fbfriendsHTML += '<a href="javascript:void(0)" user-id="'+val.id+'" onclick="callInvite('+val.id+',\''+val.name+'\', \'fb\')" class="btn btn-success invite-btn">Invite</a>';
					fbfriendsHTML += '</div>';
				fbfriendsHTML += '</li>';
			});
			jQuery('.facebook').html(fbfriendsHTML);
		}
	});
}*/

//New function
function callFbFriends(userID, accessToken)
{
	var datastring = 'limit=5000&access_token='+accessToken;
	jQuery.ajax({
		url: 'https://graph.facebook.com/'+userID+'/friends',
		dataType: 'jsonp',
		data: datastring,
		success: function(data) {
			var fbfriendsHTML = '';
			jQuery.each(data.data, function(key, val){
				fbfriendsHTML += '<li class="fb_friend_list">';
				fbfriendsHTML += '<div class="user_img">';
				fbfriendsHTML += '<img src="https://graph.facebook.com/'+val.id+'/picture?width=80&height=80" width="80" height="80">';
				fbfriendsHTML += '</div>';
				fbfriendsHTML += '<div class="name user_name">';
				fbfriendsHTML += val.name;
				fbfriendsHTML += '</div>';
				fbfriendsHTML += '<div class="button_invite">';
				fbfriendsHTML += '<a href="javascript:void(0)" user-id="'+val.id+'" onclick="callInvite('+val.id+',\''+val.name+'\', \'fb\')" class="btn btn-success invite-btn">Invite</a>';
				fbfriendsHTML += '</div>';
				fbfriendsHTML += '</li>';
			});
			jQuery('.facebook').html(fbfriendsHTML);
			var options = { valueNames: [ "name", "born" ]};
			var userList = new List("users", options);
		}
	});
}
function callInvite(user_id,user_name, site)
{
	var invite_code = c;
	var token=user_id+Math.floor((Math.random() * 999) + 1);
	var url=invite_code+'/'+token;
	FB.ui({
		to: user_id,
		method: 'send',
		picture: site_url+'/'+theme_url+'/images/logo.png',
		name: 'Join Sherlock',
		display: 'popup',
		link: 'http://invitation.shoppingsherlock.com/'+url,
		description: 'You have been invited to join Sherlock.'
	},function(response) {
		if(response.success === true)
		{

			afterInvite(user_id,user_name, 'facebook',token, invite_code, 'single');
			//window.close();
		}
		else{
			//window.close();
		}
	});
}
function afterInvite(user_id,user_name,site,token,invite_code, type)
{
	var url = site_url+'/index.php?a=invite_friends&t=afterinvite&type='+type+'&u='+user_id+'&user_name='+user_name+'&s='+site+'&invite_code='+invite_code+'&token='+token;
	jQuery.ajax({
		type: 'GET',
		url: url,
		dataType: "jsonp",
		success: function(response){
			//window.close();

		},
		complete: function(resp){

			self.close();
		   // window.close();
	   }
   });
}

function testAPI() {
	console.log('Welcome!  Fetching your information.... ');
	FB.api('/me', function(response) {
		console.log(response);
		$('#StudentFirstName').val(response.first_name);
		$('#StudentEmail').val(response.email);
                $('#StudentComfirmEmail').val(response.email);
		$('#StudentLastName').val(response.last_name);
		$('#StudentGender').val(response.gender);

		$('#StudentFbId').val(response.id);
                var image='https://graph.facebook.com/'+response.id+'/picture?width=160&height=160';
		$('#StudentFbImage').val(image);
		$('#reffered').val(2);
		$('#StudentAllFbDetail').val( JSON.stringify(response) );
                
                //----------------------------confirm page----------------------
                $('#EmergencyName').val(response.name);
                $('#EmergencyEmail').val(response.email);
                $('#user_image').attr('src',image);
               $('#img_name').val(image);
	});
	FB.api('/public_profile', function(response) {
		console.log(response);

	});
}


/*window.onunload = refreshParent;
function refreshParent()
{
	if(window.opener != null)
	{
		window.opener.location.reload();
	}
}
*/