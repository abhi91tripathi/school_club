<?php
if($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '192.168.1.124' || $_SERVER['HTTP_HOST'] == '192.168.1.107')
{
	define('SITE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/max-language-live/');
	define('SITE_URL_NOSLH', 'http://'.$_SERVER['HTTP_HOST'].'/max-language-live/');
	define('LIVE', FALSE);
	define('LOCALMODE', true);
       
}
elseif($_SERVER['HTTP_HOST'] == 'demo.xicom.us' || $_SERVER['HTTP_HOST'] == '192.168.1.201')
{
	define('SITE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/Max-Languages/website/');
	define('SITE_URL_NOSLH', 'http://'.$_SERVER['HTTP_HOST'].'/Max-Languages/website');
	define('LIVE', TRUE);
	define('LOCALMODE', FALSE);
    
}
elseif($_SERVER['HTTP_HOST'] == 'maxlanguages.com' || $_SERVER['HTTP_HOST'] == '192.168.1.201'){
    define('SITE_URL', 'http://'.$_SERVER['HTTP_HOST'].'/');
	define('SITE_URL_NOSLH', 'http://'.$_SERVER['HTTP_HOST'].'/');
	define('LIVE', TRUE);
	define('LOCALMODE', FALSE);
}

elseif($_SERVER['HTTP_HOST'] == '94.23.33.101' || $_SERVER['HTTP_HOST'] == 'www.maxlanguages.com'){
    define('SITE_URL', 'https://'.$_SERVER['HTTP_HOST'].'/');
	define('SITE_URL_NOSLH', 'https://'.$_SERVER['HTTP_HOST'].'');
	define('LIVE', TRUE);
	define('LOCALMODE', FALSE);
}



define('CAPCHA_PUBLIC_KEY', '6LeApdUSAAAAANeFXLihTLfrDCqnD-0_WhE41m1a');
define('CAPCHA_PRIVATE_KEY', '6LeApdUSAAAAAHOa7TmhFQ9pQl3mx7DQsbPi3jaI');

define('CAKE_ADMIN', 'admin');

 define('SITE_NAME','Maxlanguage.com');
define('SITENAME', 'Maxlanguage.com');


define('NUM_PER_PAGE', '30');
define('ADMIN_NUM_PER_PAGE', '500');
define('ROOT_IMG', SITE_URL.'img/');
define('IMAGES_PATH', SITE_URL.'images/');
define('IMAGES_FS_PATH', 'images/');
define('JS_PATH', SITE_URL.'js/');
define('CSS_PATH', SITE_URL.'css/');

define('ADMIN_IMAGES_PATH', SITE_URL.'admin/images/');
define('ADMIN_IMAGES_FS_PATH', 'admin/images/');
define('ADMIN_JS_PATH', SITE_URL.'admin/js/');
define('ADMIN_CSS_PATH', SITE_URL.'admin/css/');

define('EMAIL_LOGO_PATH', SITE_URL.'img/logo.png');

define('DEFAULT_META_TITLE', "MaxLanguages.com");
define('DEFAULT_META_DESCRIPTION', "MaxLanguages.com");
define('DEFAULT_META_KEYWORDS', "MaxLanguages.com");

//SOCIAL NETWORKING SITE URLS
define('SITE_FACEBOOK_URL', 'http://www.facebook.com/');
define('SITE_TWITTER_URL', 'http://www.twitter.com/');
define('SITE_GPLUS_URL', 'https://plus.google.com/');

// Paypal Test Credentials

         //test sandbox
        /*define('PAYPAL_sandbox', true);
	define('PAYPAL_nvpUsername', 'abhishek.tripathi_api1.xicom.biz');
	define('PAYPAL_nvpPassword', 'DRFNUVRJN95AYBBT');
	define('PAYPAL_nvpSignature', 'AjMWk.qkuCbVH8vTr6hU7jcrEzcVAN1qkeqaXEHIFRtoEqXty8CvDZ0Y');
	define('PAYPAL_oAuthClientId', 'AfoulxAbRiFtHz7S_w_NMYgOCKRIm0bXUfWkCS9Slmpb5ohSsmbPafeYhaKJ');
	define('PAYPAL_oAuthSecret', 'EE1ZTxAssYdXKxV0ooPbQXM3obQ_Ci6GXols-R3ZT6Dg4PFfNpXHhE1bTL8-');
                    */
        
        //clinet sandbox
        /*define('PAYPAL_sandbox', true);
	define('PAYPAL_nvpUsername', 'maxime_api1.mylanguagetravel.com');
	define('PAYPAL_nvpPassword', '3GC88YNK3USBZ2H4');
	define('PAYPAL_nvpSignature', 'AFcWxV21C7fd0v3bYYYRCpSSRl31AWWFcSkBPtEq92QK57bYvlKQEdDO');
	define('PAYPAL_oAuthClientId', 'Ae5-_G49OxN46ipUXAEI7ZVqdfXfTA_M12PH8p3mL8CD17DLG_c48gne2hZIgicmji-lFS9QetH5CSw5');
	define('PAYPAL_oAuthSecret', 'EKGMgppNDwDu7DF90Fd0B9lDXIm3mnZMtMqNtiyFHgDBT8TBwQKkREVI63zSkdxI24KxGqxxsaWsCqfA');
        */
        
        //client main
                 define('PAYPAL_sandbox', FALSE);
	define('PAYPAL_nvpUsername', 'maxime_api1.mylanguagetravel.com');
	define('PAYPAL_nvpPassword', 'X78TFR2D3SLEPP2L');
	define('PAYPAL_nvpSignature', 'Ap7F3CE0JgBZOUPMOBzFGGoXvUxbA.I78MnT46NGhzxXmfndBE1Dv4np');
	define('PAYPAL_oAuthClientId', 'AX_ivAB4UV3uiC36hRxg5u_r62BCTw9lmfnpwrE_SFHpq_P4sdEK3cTaxHIDCHozir0T_Rq9VZ9P7FUk');
	define('PAYPAL_oAuthSecret', 'EIyvEH__v5PV1i1G93V-2KFP4khRTHxRZwO0fcgzewwTFlPbVjVEO9Cw4hjprYG58OekKbg9d2oc0SYo');
         
        


//define('USER_NO', SITE_URL.'images/logo.gif');

define('DEFAULT_CURRENCY_NAME', 'USD');
define('DEFAULT_CURRENCY', '$');


define('UPLOAD_DIR', 'uploads');
define('DISPLAY_UPLOAD_DIR', SITE_URL.UPLOAD_DIR.'/');
//define('UPLOAD_INSTITUE_DIR', '/var/www/Max_Languages/website/app/webroot/'.UPLOAD_DIR.DS.'institute'.DS);
define('UPLOAD_INSTITUE_DIR', UPLOAD_DIR.DS.'institute'.DS);
define('DISPLAY_INSTITUE_DIR', SITE_URL.UPLOAD_DIR.'/institute/');
$config['WEEKS']=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
$config['STATUS'] = array('1' => 'Active', '2' => 'Inactive');
$config['ARR_WEEKS'] = array('1' => '1 week', '2' => '2 weeks', '3' => '3 weeks', '4' => '4 weeks', '5' => '5 weeks', '6' => '6 weeks', '7' => '7 weeks', '8' => '8 weeks');
$config['ARR_FEATURED'] = array('Yes' => 'Yes', 'No' => 'No');
$config['THUMB'] = array(
							"VS" => array("width" => 53,"height" =>36),
							"S" => array("width" => 75,"height" =>75),
							"M" => array("width" => 136,"height" =>70),
							"L" => array("width" => 772,"height" =>542)
						);
$config['STARTING_DATE']=array('1'=>'Every Day','2'=>'Every Monday','3'=>'1st Monday of the month');
$config['STARTING_DATE_BEG']=array('1'=>'Every Day','2'=>'Every Monday','3'=>'1st Monday of the month','5'=>'This course is not suitable for complete beginners');

$config['level'] = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advanced', 'Proficient', 'All levels');
$config['new_level'] = array('Complete Beginner', 'Beginner/Elementary', 'Pre-intermediate', 'Intermediate', 'Upper Intermediate', 'Advanced', 'Proficient');
// Accommodation constant---------------------------------
$config['BOARD']=array('Self service (No meals)','Breakfast','Half board (breakfast + 1 meal)','Full board (breakfast + lunch + dinner)','Full board week days and half board weekends','Half board weekdays and full board weekends');
$config['SCHOOL_WAY']=array('Kilometer(s)','minute(s) walking','minute(s) in public transport','minute(s) by car');
$config['BATHROOM']=array('Shared bathroom','Private bathroom');

/**
 * class : Thumbnail class
 * description : array for thumbnials for images that we are using in are site
 */
define('REVIEW_MAX_IMAGE_SIZE', '10240'); // SIZE IN kb

define('BASE_CURRENCY', 'EUR'); // SIZE IN kb
define('BASE_CURRENCY_SYMBOL', '&euro;'); // SIZE IN kb

$config['PAYMENT_TYPE']=array(1=>'Credit Card',2=>'PayPal',3=>'Bank Transfer');
$config['RESPONSE']=array('Cancelled','Accepted','Rejected','Pending Response','Not validate','Validated');
class Thumbnail
{
	// Thumb for user images
	static function review_images()
	{
		$thumb = array(
					array(
						'width' => 120,
						'height' => 180,
						'suffix' => 'REV'
					)
			);
		return $thumb;
	}
        // Thumb for user images
	static function logo_image()
	{
		$thumb = array(
					array(
						'width' => 140,
						'height' => 75,
						'suffix' => 'REV'
					)
			);
		return $thumb;
	}
	
	static function payment_image()
	{
		$thumb = array(
					array(
						'width' => 120,
						'height' => 180,
						'suffix' => 'PAY-'
					)
			);
		return $thumb;
	}
        
        static function our_team_image()
	{
		$thumb = array(
					array(
						'width' => 441,
						'height' => 238,
						'suffix' => 'Team_'
					)
			);
		return $thumb;
	}
        static function embassy_image()
	{
		$thumb = array(
					array(
						'width' => 441,
						'height' => 238,
						'suffix' => 'embasy_'
					)
			);
		return $thumb;
	}
        static function brand_image()
	{
		$thumb = array(
					array(
						'width' => 441,
						'height' => 238,
						'suffix' => 'brand_'
					)
			);
		return $thumb;
	}
        static function first_day_image()
	{
		$thumb = array(
					array(
						'width' => 441,
						'height' => 238,
						'suffix' => 'first_day_'
					)
			);
		return $thumb;
	}
         static function activities_social_image()
	{
		$thumb = array(
					array(
						'width' => 441,
						'height' => 320,
						'suffix' => 'activities_social_'
					)
			);
		return $thumb;
	}
        static function main_img_image()
	{
		$thumb = array(
					array(
						'width' => 770,
						'height' => 320,
						'suffix' => 'main_img_'
					)
			);
		return $thumb;
	}
        static function thumbnail_image()
	{
		$thumb = array(
					array(
						'width' => 248,
						'height' => 140,
						'suffix' => 'thumbnail_img_'
					)
			);
		return $thumb;
	}
}

