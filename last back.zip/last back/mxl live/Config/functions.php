<?php

	//THIS IS TEMPORARY VARIABLE DECLARED BECAUSE IT IS NECESSARY TO DECLARE ATLEAST ONE $config VARIABLE IF WE LOAD THE FILE USING Configure::load
	$config['ZX'] = 'X';

	
	/**
	 * Purpose : TO GET THE CLEAN URL BY REPLACING EXTRA CHARACTERS
	 * Created on : 20-Dec-2011
	 * Author : Nitin
	*/

/**
	 * Purpose : TO ADD CONDITION TO THE CONDITIONS ARRAY
	 * Created on : 20-Dec-2011
	 * Author : Nitin
	*/
	function append_condition(&$cond_arr, $field, $condition, $field_val)
	{
		if($field && $condition && $field_val)
		{
			switch($condition)
			{
				case 'equal': $cond_arr[$field] = $field_val;
					break;
				case 'in': $cond_arr[$field] = @explode(',', $field_val);
					break;
				case 'like': $cond_arr[$field.' LIKE'] = $field_val.'%';
					break;
				case 'any_like': $cond_arr[$field.' LIKE'] = '%'.$field_val.'%';
					break;
				case 'not_equal':	$cond_arr[$field.' <>'] = $field_val;
				    break;
				case 'less':	$cond_arr[$field.' <'] = $field_val; 
				     break; 
				case 'greater':	$cond_arr[$field.' >'] = $field_val; 
				     break; 
				case 'lessequal':	$cond_arr[$field.' >='] = intval($field_val); 
				     break;
				case 'greaterequal':	$cond_arr[$field.' <='] = intval($field_val); 
				     break;              
				default: $cond_arr[$field.' '.$condition] = $field_val;
					break;
			}
		}
	}
	
	function Getfloat($str) {
	  if(strstr($str, ",")) {
		$str = str_replace(".", "", $str); // replace dots (thousand seps) with blancs
		$str = str_replace(",", ".", $str); // replace ',' with '.'
	  }
	 
	  if(preg_match("#([0-9\.]+)#", $str, $match)) { // search for number that may contain '.'
		return floatval($match[0]);
	  } else {
		return floatval($str); // take some last chances with floatval
	  }
	} 
?>
