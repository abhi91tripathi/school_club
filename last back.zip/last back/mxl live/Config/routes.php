<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different URLs to chosen controllers and their actions (functions).
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 * its action called 'display', and we pass a param to select the view file
 * to use (in this case, /app/View/Pages/home.ctp)...
 */
Router::connect('/sitemap/*', array('controller' => 'sitemaps','action'=>'index',));  
	Router::connect('/', array('controller' => 'pages', 'action' =>  'home'));

	Router::connect('/admin', array('controller' => 'users', 'action' =>  'login','plugin'=>'admin'));
        
        //Router::connect('/sitemap', array('controller' => 'sitemaps', 'action' => 'index')); 

/**
 * ...and connect the rest of 'Pages' controller's URLs.
 */
	Router::connect('/pages/*', array('controller' => 'pages', 'action' => 'display'));
        Router::connect('/search/*', array('controller' => 'pages', 'action' => 'search'));

		//Router::connect('/Results/*', array('controller' => 'Results'));

	//FOR THE CMS PAGES
	Router::connect('/terms-conditions', array('controller' => 'cms', 'action' => 'index', 'terms-conditions'));
	Router::connect('/Legal_notice', array('controller' => 'cms', 'action' => 'index', 'Legal_notice'));
	Router::connect('/about-us', array('controller' => 'cms', 'action' => 'index', 'about-us'));
	Router::connect('/faq', array('controller' => 'cms', 'action' => 'index', 'faq'));
	Router::connect('/terms-conditions', array('controller' => 'cms', 'action' => 'index', 'terms-conditions'));
        Router::connect('/ContactUs', array('controller' => 'ContactUs', 'action' => 'index', 'index'));
        


	// search result page routing-------------------------------------------------------
	Router::connect('/learn-:language', array('controller' => 'Results', 'action' => 'language' ), array('language' => '(.*)-abroad'));
	Router::connect('/learn-:language', array('controller' => 'Results', 'action' => 'city' ),array('language'=>'(.*)-in-(.*)-(.*)'));
	Router::connect('/learn-:language', array('controller' => 'Results', 'action' =>'country' ),array('language'=>'(.*)-in-(.*)'));
	Router::connect('/Results/:action', array('controller' => 'Results'));
	Router::connect('/institute/:action', array('controller' => 'institute'));
	Router::connect('/Schools/:action', array('controller' => 'Schools'));
	Router::connect('/Accomodation/:action', array('controller' => 'Accomodation'));
	Router::connect('/AccomodationFacilities/:action', array('controller' => 'AccomodationFacilities'));
	Router::connect('/Accreditations/:action', array('controller' => 'Accreditations'));
	Router::connect('/AdminApp/:action', array('controller' => 'AdminApp'));
	Router::connect('/Emails/:action', array('controller' => 'Emails'));
	Router::connect('/Exams/:action', array('controller' => 'Exams'));
	Router::connect('/Facilities/:action', array('controller' => 'Facilities'));
	Router::connect('/HomepageManagement/:action', array('controller' => 'HomepageManagement'));
	Router::connect('/Language/:action', array('controller' => 'Language'));
	Router::connect('/Settings/:action', array('controller' => 'Settings'));
	Router::connect('/Users/:action', array('controller' => 'Users'));
	Router::connect('/students/:action', array('controller' => 'students'));
        
	//Router::connect('/Results/get_country_list/:language', array('controller' => 'Results', 'action' =>'get_country_list'));

	Router::connect('/:slug', array('controller' => 'Institutes', 'action' =>  'view',''));


/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();

/**
 * Load the CakePHP default routes. Only remove this if you do not want to use
 * the built-in default routes.
 */
	require CAKE . 'Config' . DS . 'routes.php';

//-----------------for pdf-------------------------\
Router::parseExtensions('pdf');

Router::parseExtensions('rss','xml'); 
